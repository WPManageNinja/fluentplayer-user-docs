<?php

namespace FluentPlayerPro\Database;

use FluentPlayerPro\Database\Migrations\VisitsMigrator;

class DBMigrator
{
    /**
     * Run database migrations
     *
     * @param bool $force Force visits table creation even if analytics is disabled (used during version upgrades)
     */
    public static function run($force = false)
    {
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // Only create/update visits table if analytics is enabled or forced (version upgrade)
        if ($force || self::isAnalyticsEnabled()) {
            VisitsMigrator::migrate();
        }
    }

    /**
     * Check if analytics is enabled in settings
     *
     * @return bool
     */
    private static function isAnalyticsEnabled()
    {
        $settings = get_option('fluent_player_settings', []);

        return !empty($settings['analytics']['enabled']);
    }
}
