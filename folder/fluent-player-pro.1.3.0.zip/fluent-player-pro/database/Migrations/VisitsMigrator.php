<?php

namespace FluentPlayerPro\Database\Migrations;

class VisitsMigrator
{
    public static function migrate()
    {
        global $wpdb;
        $charsetCollate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'flp_visits';

        if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) != $table) {
            $sql = "CREATE TABLE $table (
                `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `media_id` bigint(20) NOT NULL,
                `user_id` bigint(20) NULL,
                `ip_address` varchar(100) NULL,
                `country` varchar(2) NULL,
                `device` varchar(100) NULL,
                `browser` varchar(100) NULL,
                `duration` float DEFAULT 0 NOT NULL,
                `percentage` tinyint unsigned DEFAULT 0 NOT NULL,
                `created_at` datetime NOT NULL,
                `updated_at` datetime NOT NULL,
                INDEX `media_id` (`media_id`),
                INDEX `user_id` (`user_id`),
                INDEX `ip_address` (`ip_address`),
                INDEX `created_at` (`created_at`),
                INDEX `media_created` (`media_id`, `created_at`),
                INDEX `user_created` (`user_id`, `created_at`)
            ) $charsetCollate;";
            dbDelta($sql);
        } else {
            // Existing table — add percentage column if missing
            $columns = $wpdb->get_col("DESCRIBE $table", 0); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            if (!in_array('percentage', $columns, true)) {
                $wpdb->query("ALTER TABLE $table ADD `percentage` tinyint unsigned DEFAULT 0 NOT NULL AFTER `duration`"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange
            }

            // Add missing indexes for performance
            $indexes = $wpdb->get_results("SHOW INDEX FROM $table"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $indexNames = array_column($indexes, 'Key_name');

            if (!in_array('user_id', $indexNames, true)) {
                $wpdb->query("ALTER TABLE $table ADD INDEX `user_id` (`user_id`)"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange
            }
            if (!in_array('ip_address', $indexNames, true)) {
                $wpdb->query("ALTER TABLE $table ADD INDEX `ip_address` (`ip_address`)"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange
            }
            if (!in_array('media_created', $indexNames, true)) {
                $wpdb->query("ALTER TABLE $table ADD INDEX `media_created` (`media_id`, `created_at`)"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange
            }
            if (!in_array('user_created', $indexNames, true)) {
                $wpdb->query("ALTER TABLE $table ADD INDEX `user_created` (`user_id`, `created_at`)"); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange
            }
        }
    }
}
