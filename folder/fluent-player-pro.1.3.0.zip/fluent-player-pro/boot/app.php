<?php
if (!defined('ABSPATH')) {
    exit;
}

use FluentPlayerPro\App\Core\Application;
use FluentPlayerPro\App\Hooks\Handlers\FreeDependencyNotice;
use FluentPlayerPro\App\Services\PluginManager\FluentLicensing;

return function($file) {
    FreeDependencyNotice::register();

    add_action('fluent_player/loaded', function($app) use ($file) {
        if (!FreeDependencyNotice::coreMeetsMinimum(FLUENT_PLAYER_VERSION, FLUENT_PLAYER_PRO_MIN_CORE_VERSION)) {
            FreeDependencyNotice::registerOutdatedCoreNotice();
            return;
        }

        new Application($app, $file);

        $fluentLicensing = (new FluentLicensing())->register([
            'version'           => FLUENT_PLAYER_PRO_VERSION,
            'item_id'           => 7571232,
            'basename'          => plugin_basename(FLUENT_PLAYER_PRO_DIR_FILE),
            'api_url'           => 'https://fluentapi.wpmanageninja.com/',
            'store_url'         => 'https://wpmanageninja.com/',
            'purchase_url'      => 'https://fluentplayer.com/',
            'settings_key'      => '__fluent-player-pro_sl_info',
            'activate_url'      => admin_url('admin.php?page=fluent-player#/settings/licensing'),
            'show_check_update' => true,
            'plugin_title'      => 'FluentPlayer Pro',
        ]);

        // Surface license issues inside the FluentPlayer admin app via the shared
        // notice channel (rendered by AdminNotice.vue). Resolved at filter-call
        // time so the pro textdomain is loaded before __() runs.
        add_filter('fluent_player/admin_notices', function ($notices) use ($fluentLicensing) {
            $licenseNotice = $fluentLicensing->getLicenseMessages();
            if (empty($licenseNotice['message'])) {
                return $notices;
            }

            $notices[] = [
                'id'   => 'fluent_player_pro_license',
                'type' => 'warning',
                'html' => $licenseNotice['message'],
            ];

            return $notices;
        });

        // Run pro migrations if DB version is stale
        $currentDBVersion = get_option('fluent_player_pro_db_version');
        if (!$currentDBVersion || version_compare($currentDBVersion, FLUENT_PLAYER_PRO_DB_VERSION, '<')) {
            \FluentPlayerPro\Database\DBMigrator::run(true);
            update_option('fluent_player_pro_db_version', FLUENT_PLAYER_PRO_DB_VERSION, 'no');
        }

    });
};
