=== FluentPlayer Pro ===
Contributors: wpmanageninja
Tags: media player, video player, audio player, playlist, analytics, bunnycdn
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Pro extension for FluentPlayer - Adds advanced integrations, playlist layouts, analytics, and marketing features.

== Description ==

FluentPlayer Pro is the premium extension for FluentPlayer, transforming it into a powerful tool for professional video and audio management on WordPress. It offers advanced features for customization, marketing, and high-performance content delivery.

= Pro-Exclusive Features =

* **Advanced Playlist Layouts** - Grid and Learning-focused designs beyond the standard player
* **BunnyCDN Integration** - Connect with BunnyCDN Stream and Storage for optimized video delivery
* **In-Depth Analytics** - Track views, engagement, and key performance metrics
* **Marketing Automation** - Integrate with Mailchimp and Webhooks for lead capture
* **Advanced Customization** - Customizable presets and a powerful CSS generator
* **Gutenberg Block** - Embed and configure playlists directly in the block editor

= Requirements =

* WordPress 5.0+
* PHP 7.4+
* FluentPlayer (free version) must be installed and activated

== Installation ==

1. Ensure the free version of FluentPlayer is installed and activated.
2. Upload the `fluent-player-pro` plugin folder to `/wp-content/plugins/` directory.
3. Activate the plugin through the 'Plugins' screen in WordPress.
4. Navigate to FluentPlayer settings to configure Pro features.

== Frequently Asked Questions ==

= Do I need the free version? =

Yes, FluentPlayer Pro requires the free FluentPlayer plugin to be installed and activated.

= What integrations are available? =

FluentPlayer Pro supports BunnyCDN (Stream & Storage), Mailchimp, FluentCRM, Google Analytics, and custom Webhooks.

= Which hosted subtitle service URL does Pro use by default? =

The current managed hosted subtitle service default is `https://api.fluentplayer.com`. Pro signs requests to that HTTPS endpoint when no custom subtitle-service URL and token are configured.

= Can I use advanced playlist layouts? =

Yes, Pro adds Grid and Learning layouts with full customization options for typography, colors, and spacing.

== Changelog ==
= 1.3.0 (Date: July 22, 2026) =
- Feature: Audio support for CDN providers — upload and play audio through Bunny, Mux, Cloudflare R2, and Gumlet
- Feature: Server-side uploads for Mux and Gumlet, so uploads work on non-public and local sites
- Feature: Connected providers are advertised to the block editor, so the source picker reflects their connection state
- Improvement: Editors can now add and edit playlists (previously admin-only)
- Improvement: BunnyCDN Stream is now called Bunny Stream
- Improvement: Ad layers gain clickable media, a disclosure badge, a skip countdown, and video sound control
- Fix: Bunny Stream playback no longer fails with a 403 from stacked signing tokens
- Fix: Bunny Storage files with consecutive dots in the filename stream correctly
- Fix: Gumlet audio is detected from asset metadata so it renders as an audio player
- Fix: The storage settings link is only shown to users who can open the settings page
- Fix: PHP 7.4 compatibility in timed-content rendering
- Security: Mux signing keys, stream-key reset, and playback restrictions stay admin-only while authoring opens to editors
- Security: CDN upload types are restricted — script-capable files (php, svg, html, js) are always rejected

= 1.2.0 (Date: July 8, 2026) =
- Feature: LearnDash integration — automatically mark lessons complete based on video watch progress
- Feature: Gumlet video provider support — VOD and live streaming with signed URLs
- Feature: Cloudflare R2 storage provider for media delivery
- Fix: Playlists with titles that look like "playlist-2" now resolve to the correct page
- Fix: Playlist runtime strings are now translatable on standalone playlist pages

= 1.1.0 (Date: July 6, 2026) =
- Improvement: Compatibility with FluentPlayer 1.1.0

= 1.0.9 (Date: June 30, 2026) =
- Feature: Bulk actions in the media list — manage tags and playlists for multiple items at once
- Feature: Choose how the playlist player and tracklist are divided — none, a line, or a space
- Feature: Trash and restore playlists instead of deleting them outright
- Feature: Hide the "Powered by FluentPlayer" branding from the player menu and capture emails
- Improvement: Honor WordPress password protection on playlists — protected playlists unlock right on the page
- Improvement: Validate the Mux signing key when saving and guard against malformed values
- Security: Editing timed content now requires the proper edit permission
- Security: Block directory listing with index.php guards across plugin folders
- Fix: Playlists without their own thumbnail now fall back to the first video's poster image
- Fix: Mixed audio-and-video playlists now show the right player for each item
- Fix: Playlist display conditions now resolve correctly
- Fix: The menu toggle is now correctly hidden for grid-layout playlists
- Fix: Timed content now loads consistently across all playback methods

= 1.0.7 (Date: June 22, 2026) =
- Feature: Render global Custom CSS on the frontend
- Feature: Back button in the playlist editor header
- Improvement: Expose the first media type for the playlist list icon
- Fix: Detect the free plugin folder-agnostically for the dependency notice
- Fix: Use the fluent-player-pro text domain for all Pro strings

= 1.0.6 (Date: May 15, 2026) =
- Feature: Player share links and context menu
- Feature: Playlist navigation controls
- Feature: Playlist preset source selection with brand color sync from preset source
- Improvement: Internal modularity refactor across services and controllers
- Fix: Reject analytics events for replayed or invalid media IDs
- Fix: Stop returning raw admin exception messages
- Fix: Normalize timed content padding in the frontend renderer

= 1.0.5 (Date: April 24, 2026) =
- Feature: Support for FluentCRM based conditions
- Feature: Condition support in Dynamic layer, Email Capture & More
- Feature: Media tag management support
- Feature: YouTube subtitle import through the external subtitle service, including caption and hover preview support
- Feature: Tag-based playlist rendering shortcode
- Feature: FluentCommunity playlist block support
- Improvement: Playlist aspect ratio alignment and legacy ratio handling cleanup
- Security: Hardening across TLS, signed URLs, analytics, playlist layout guards, and Bunny Storage upload path traversal
- Fix: Playlist asset cache busting now uses the active free plugin version
- Fix: Mux signed media URLs, signing key settings copy, and playlist window.fluent_player YouTube settings
- Fix: Bunny Storage CDN signing, Stream asset tokens, and missing tag options service wiring
- Fix: Analytics unique viewers now count anonymous viewers and preserve dominant country and device per user
- Fix: Bunny browser uncategorized video filter for root-level video browsing
- Fix: Debounced YouTube subscriber count lookup in preset editor

= 1.0.4 (Date: March 17, 2026) =
- Feature: FluentCRM smartcode parsing for timed content
- Feature: Mux integration with API client, service, controller, and routes
- Feature: Configurable playlist aspect ratio selection for all playlist layouts
- Feature: Playlist per-video overlay and layers support
- Feature: BunnyCDN signed URL support for Stream and Storage
- Security: Stronger output escaping across playlist layout templates
- Improvement: Analytics tracker behavior with fewer unnecessary flush calls on play/pause
- Feature: Timed content rendering and API controller
- Feature: Shortcode processing in timed content output
- Improvement: Playlist player gesture controls
- Fix: PHP 8.x compatibility issues
- Fix: Subtitle endpoints querying non-existent wp_medias table

= 1.0.2 (Date: February 28, 2026) =
- Feature: BunnyCDN subtitles import and HLS MP4 fallback
- Fix: Caption `srclang` validation

= 1.0.1 (Date: February 24, 2026) =
- Feature: `.srt` subtitle file support
- Feature: Manageable captions from preset
- Feature: Alignment support for playlist block
- Improvement: Analytics service with percentage tracking
- Improvement: BunnyCDN Storage upload performance
- Fix: BunnyCDN video playback

= 1.0.0 (Date: February 10, 2026) =
- Feature: Initial release of FluentPlayer Pro
- Feature: Playlist system with Standard and Grid layouts
- Feature: Playlist Gutenberg block with dedicated CPT
- Feature: Playlist visibility (public/private) and slug-based permalinks
- Feature: BunnyCDN Stream integration for video delivery
- Feature: BunnyCDN Storage integration with streaming proxy and upload
- Feature: Mailchimp email provider integration
- Feature: Webhook email provider integration
- Feature: Player analytics with view tracking and audience retention
- Feature: Google Analytics event integration
- Feature: Preset management (CRUD) with customizable settings
- Feature: Player subtitles/captions support
- Feature: Sidebar width and title position settings for playlists
- Feature: Brand color and control bar color customization

== External Services ==

This plugin connects to external services to provide enhanced functionality. Below are the services used:

= BunnyCDN Storage and Streaming =
This plugin can connect to BunnyCDN's services including bunny.net (API) and video.bunnycdn.com (video streaming) to host and deliver video content via CDN. It sends API keys, video files, metadata, user IP addresses, and streaming requests when BunnyCDN integration is configured with API keys. This feature is disabled by default and requires manual API key configuration. This service is provided by BunnyWay d.o.o.: Terms of Service (https://bunny.net/terms/), Privacy Policy (https://bunny.net/privacy/).

= Mailchimp Email Marketing =
This plugin can connect to Mailchimp's services to collect email addresses for marketing campaigns. It sends email addresses, subscriber data, and list information when Mailchimp integration is configured. This feature is disabled by default and requires manual API key configuration. This service is provided by Mailchimp (Intuit): Terms of Service (https://mailchimp.com/legal/terms/), Privacy Policy (https://mailchimp.com/legal/privacy/).

= FluentCRM Integration =
This plugin can integrate with FluentCRM (a WordPress plugin) to manage email subscribers locally within WordPress. This is a local WordPress integration - no external service connection.

= Custom Webhook Integration =
This plugin can send collected email addresses to user-configured webhook endpoints. The destination service depends on user configuration.

For questions about data processing or privacy, please contact the Fluent Team.

== Support ==

For support, feature requests, or bug reports, please visit our support forum or contact the Fluent Team.
