<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Fluent Player Pro Actions
 *
 * This file registers pro-specific actions that extend the free version.
 * The pro version hooks into the free version's application instance.
 */

/**
 * @var $app FluentPlayer\Framework\Foundation\Application (from free version)
 */

(new \FluentPlayerPro\App\Integrations\LearnDash\LearnDashIntegration())->register();

(new \FluentPlayerPro\App\Hooks\Handlers\WatchProgressBridge())->register();

// Register with higher priority (5) to ensure it runs before the main plugin's registration
$app->addAction('fluent_player/register_email_providers', function() {
    // Check if provider is already registered to avoid duplicates
    $existingProviders = FluentPlayer\App\Services\EmailProviderService::getRegisteredProviders();
    
    // Register Webhook provider
    if (!isset($existingProviders['webhook'])) {
        $provider = new FluentPlayerPro\App\EmailProviders\WebhookProvider();
        FluentPlayer\App\Services\EmailProviderService::registerProvider($provider);
    }
});

$app->addShortCode('fluentplaylist', ['FluentPlayerPro\App\Hooks\Handlers\PlaylistShortcodeHandler', 'handle']);

$app->addAction('fluent_player/register_media_taxonomies', ['FluentPlayerPro\App\Services\TagService', 'registerTaxonomy']);
$app->addAction('fluent_player/after_save_media', ['FluentPlayerPro\App\Services\TagService', 'onSaveMedia'], 10, 2);
$app->addAction(
    'fluent_player_pro/generate_storyboard',
    ['FluentPlayerPro\App\Services\SubtitleService', 'maybeGenerateStoryboardForMedia'],
    10,
    1
);
$app->addFilter('fluent_player/media_paginate_query', ['FluentPlayerPro\App\Services\TagService', 'filterQuery'], 10, 2);

$app->addAction('init', ['FluentPlayerPro\App\Hooks\Handlers\CPTHandler', 'registerPostTypes']);
$app->addAction('init', ['FluentPlayerPro\App\Hooks\Handlers\FluentPlaylistCPT', 'addRewriteRules'], 20);
$app->addAction('init', ['FluentPlayerPro\App\Hooks\Handlers\CPTHandler', 'maybeFlushRules'], 30);
$app->addAction('init', ['FluentPlayerPro\App\Blocks\PlaylistBlock', 'register']);

// Analytics Handler - Pro feature
$app->addAction('init', function() {
    \FluentPlayerPro\App\Hooks\Handlers\AnalyticsHandler::handle();
});

// Custom CSS rendering - Pro feature (value stored in free settings)
\FluentPlayerPro\App\Hooks\Handlers\CustomCssHandler::handle();

// Daily cleanup hooks — piggyback on free plugin's daily cron
$app->addAction('fluent_player/daily_cleanup', ['FluentPlayerPro\App\Services\AnalyticsService', 'runCleanup']);
$app->addAction('fluent_player/daily_cleanup', ['FluentPlayerPro\App\Models\Playlist', 'cleanupAutoDrafts']);

// Clean up managed subtitle attachments while the free plugin still has media settings available.
$app->addAction('fluent_player/before_delete_media', function($mediaId, $settings) {
    $mediaId = absint($mediaId);
    if (!$mediaId) {
        return;
    }

    \FluentPlayerPro\App\Services\SubtitleService::cleanupManagedSubtitleAttachments($settings, $mediaId);
    \FluentPlayerPro\App\Services\SubtitleService::cleanupGeneratedStoryboard($settings, $mediaId);
}, 10, 2);

// Clean up orphaned data when media is deleted
$app->addAction('fluent_player/after_delete_media', function($mediaId) {
    if (!$mediaId) {
        return;
    }
    \FluentPlayerPro\App\Models\Visit::where('media_id', $mediaId)->delete();
});

// Register Mailchimp provider
$app->addAction('fluent_player/register_email_providers', function() {
    $existingProviders = FluentPlayer\App\Services\EmailProviderService::getRegisteredProviders();
    if (!isset($existingProviders['mailchimp']) && class_exists('FluentPlayerPro\App\EmailProviders\MailchimpProvider')) {
        $provider = new FluentPlayerPro\App\EmailProviders\MailchimpProvider();
        FluentPlayer\App\Services\EmailProviderService::registerProvider($provider);
    }
});

// FluentCommunity: playlist block support (frontend assets, block allow-list,
// block editor assets, editor-canvas iframe styles).
\FluentPlayerPro\App\Hooks\Handlers\FluentCommunityPlaylistBlock::register();
