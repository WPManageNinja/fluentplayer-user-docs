<?php

namespace FluentPlayerPro\App\Hooks\Handlers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Warns the admin when FluentPlayer Pro is active but the free FluentPlayer
 * plugin is not.
 *
 * This must be registered OUTSIDE the `fluent_player/loaded` action (which only
 * fires when the free plugin is present) so it can actually detect free's
 * absence. Detection is folder-agnostic: the free plugin can live in any folder
 * (fluent-player-dev, fluent-player, a renamed zip), so we key off the
 * FLUENT_PLAYER_VERSION constant the free plugin defines on load rather than a
 * hardcoded plugin basename.
 */
class FreeDependencyNotice
{
    public static function register()
    {
        add_action('admin_notices', [self::class, 'maybeRender']);
    }

    /**
     * Pure decision seam (unit-tested): show the nag only when the free plugin
     * is missing and the current user can manage plugins.
     *
     * @param bool $isFreeLoaded     Whether the free plugin has loaded.
     * @param bool $canManagePlugins Whether the current user can manage plugins.
     * @return bool
     */
    public static function shouldRender($isFreeLoaded, $canManagePlugins)
    {
        return !$isFreeLoaded && $canManagePlugins;
    }

    public static function maybeRender()
    {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        if (self::shouldRender(defined('FLUENT_PLAYER_VERSION'), true)) {
            self::render(__('FluentPlayer Pro requires the free FluentPlayer plugin to be installed and activated.', 'fluent-player-pro'));
            return;
        }

        // Free is present but too old to provide a shared dependency (e.g. a newer
        // Pro paired with an outdated free build that predates BulkActionHelper).
        if (!class_exists('FluentPlayer\\App\\Helpers\\BulkActionHelper')) {
            self::render(__('FluentPlayer Pro requires a newer version of the free FluentPlayer plugin. Please update FluentPlayer.', 'fluent-player-pro'));
        }
    }

    private static function render($message)
    {
        echo '<div class="notice notice-error"><p>' . esc_html($message) . '</p></div>';
    }

    /**
     * Pure decision seam (unit-tested): does the loaded free core satisfy the
     * minimum version Pro needs to run safely?
     *
     * @param string $coreVersion    The loaded free plugin version.
     * @param string $minimumVersion The minimum version Pro requires.
     * @return bool
     */
    public static function coreMeetsMinimum($coreVersion, $minimumVersion)
    {
        return version_compare($coreVersion, $minimumVersion, '>=');
    }

    public static function registerOutdatedCoreNotice()
    {
        add_action('admin_notices', [self::class, 'renderOutdatedCore']);
    }

    public static function renderOutdatedCore()
    {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        echo '<div class="notice notice-error"><p>';
        echo esc_html(sprintf(
            /* translators: %s: minimum required free FluentPlayer version */
            __('FluentPlayer Pro requires the free FluentPlayer plugin version %s or higher. Please update FluentPlayer.', 'fluent-player-pro'),
            FLUENT_PLAYER_PRO_MIN_CORE_VERSION
        ));
        echo '</p></div>';
    }
}
