<?php

namespace FluentPlayerPro\App\Hooks\Handlers;

if (!defined('ABSPATH')) {
    exit;
}

use FluentPlayer\App\Services\MediaService;
use FluentPlayer\App\Helpers\Helper;

class TimedContentHandler
{
    private static function normalizePaddingValue($value)
    {
        if (is_numeric($value)) {
            return (string) $value;
        }

        if (!is_string($value)) {
            return '0';
        }

        $trimmed = trim($value);
        if ($trimmed === '') {
            return '0';
        }

        if (preg_match('/-?\d*\.?\d+/', $trimmed, $matches)) {
            return $matches[0];
        }

        return '0';
    }

    private static function formatPaddingSide($value, $unit)
    {
        $normalized = self::normalizePaddingValue($value);

        return $normalized . $unit;
    }

    /**
     * Filter callback for 'fluent_player/media_block_inner'.
     * Injects timed content HTML into the player output when pro is active.
     *
     * @param string $output     The player HTML output.
     * @param array  $attributes Block attributes.
     * @param int    $media_id   The media post ID.
     * @param string $content    InnerBlocks content (timed content sections).
     *
     * @return string Modified output with timed content injected.
     */
    public static function injectTimedContent($output, $attributes, $media_id, $content)
    {
        $tc_enabled = $attributes['timedContentStyle']['enabled'] ?? true;

        if ($tc_enabled === false) {
            return $output;
        }

        $has_timed_content = !empty($content);

        // If no local timed content, check the CPT post's saved block content
        if (!$has_timed_content) {
            $content = self::getTimedContentFromPost($media_id);
            $has_timed_content = !empty($content);
        }

        if (!$has_timed_content) {
            return $output;
        }

        // Route through the free canonical seam so the asset registers under one
        // shared handle and WordPress dedupes it against the free render path.
        //
        // Guarded (no fallback) because Pro enforces no minimum free version. The
        // guard-only path is safe: every invocation of this handler runs via the
        // `fluent_player/media_block_inner` filter, which the free MediaBlock::render
        // applies AFTER MediaRenderer::render() has already enqueued this asset under
        // the same canonical handle. So on an older free build lacking the seam, the
        // script is already enqueued — skipping here loses nothing.
        if (method_exists(Helper::class, 'enqueueTimedContentScript')) {
            Helper::enqueueTimedContentScript();
        }

        $tc_style = $attributes['timedContentStyle'] ?? [];
        $style_parts = [];

        $pad = $tc_style['padding'] ?? [];
        if (!empty($pad)) {
            $unit   = sanitize_key($pad['unit'] ?? 'px') ?: 'px';
            $linked = ($pad['linked'] ?? true) !== false;
            $top    = self::formatPaddingSide($pad['top'] ?? '0', $unit);
            $right  = self::formatPaddingSide($pad['right'] ?? ($linked ? ($pad['top'] ?? '0') : '0'), $unit);
            $bottom = self::formatPaddingSide($pad['bottom'] ?? ($linked ? ($pad['top'] ?? '0') : '0'), $unit);
            $left   = self::formatPaddingSide($pad['left'] ?? ($linked ? ($pad['top'] ?? '0') : '0'), $unit);

            if ($top !== '0px' || $right !== '0px' || $bottom !== '0px' || $left !== '0px') {
                $style_parts[] = 'padding:' . esc_attr("{$top} {$right} {$bottom} {$left}");
            }
        }
        if (!empty($tc_style['backgroundColor'])) {
            $style_parts[] = 'background-color:' . esc_attr($tc_style['backgroundColor']);
        }
        if (!empty($tc_style['textColor'])) {
            $style_parts[] = 'color:' . esc_attr($tc_style['textColor']);
        }

        $inline_style = !empty($style_parts) ? ' style="' . implode('; ', $style_parts) . '"' : '';

        $processed_content = str_contains($content, '[') ? do_shortcode($content) : $content;
        $processed_content = MediaService::parseSmartcodes($processed_content);

        $timed_html = '<div class="fp-timed-content-container"' . $inline_style . '>'
                    . $processed_content
                    . '</div>';

        // Insert timed content before the closing </div> of .fp-media-block
        $pos = strrpos($output, '</div>');
        if ($pos !== false) {
            $output = substr_replace($output, $timed_html, $pos, 0);
        } else {
            $output .= $timed_html;
        }

        return $output;
    }

    /**
     * Extract rendered timed content from the CPT post's saved block content.
     * Used when the block is embedded on another page without local InnerBlocks.
     */
    private static function getTimedContentFromPost($mediaId)
    {
        $media_post = get_post($mediaId);
        if (!$media_post || $media_post->post_type !== 'fluent_player_media' || empty($media_post->post_content)) {
            return '';
        }

        $blocks = parse_blocks($media_post->post_content);

        foreach ($blocks as $block) {
            if ($block['blockName'] !== 'fluent-player/media' || empty($block['innerBlocks'])) {
                continue;
            }

            $inner_html = '';
            foreach ($block['innerBlocks'] as $inner_block) {
                $inner_html .= render_block($inner_block);
            }

            return trim($inner_html);
        }

        return '';
    }
}
