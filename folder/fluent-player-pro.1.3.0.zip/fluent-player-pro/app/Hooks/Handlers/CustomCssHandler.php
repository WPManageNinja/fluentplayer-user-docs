<?php

namespace FluentPlayerPro\App\Hooks\Handlers;

if (!defined('ABSPATH')) exit;

use FluentPlayer\App\Helpers\Helper;
use FluentPlayer\Framework\Support\Arr;

/**
 * Renders the global Custom CSS on the frontend. This is a Pro feature: the
 * value is stored in the free settings (general.custom_css) and edited in the
 * free admin only when Pro is active, but the actual frontend injection lives
 * here so Custom CSS does not apply on a free-only install.
 */
class CustomCssHandler
{
    protected static $cssOutputDone = false;

    public static function handle()
    {
        add_action('fluent_player/before_render_media', [self::class, 'addCss'], 10, 1);
    }

    /**
     * Output the sanitized global Custom CSS once per request.
     *
     * @param mixed $media Media object (unused; the CSS is global).
     */
    public static function addCss($media = null)
    {
        if (self::$cssOutputDone) {
            return;
        }
        self::$cssOutputDone = true;

        $settings = Helper::getSettings();
        $css = Arr::get($settings, 'general.custom_css', '');

        if (function_exists('wpfp_sanitize_css')) {
            $css = wpfp_sanitize_css($css);
        }

        if (!$css) {
            return;
        }

        wp_register_style('fluent-player-custom-css', false, [], FLUENT_PLAYER_PRO_VERSION);
        wp_enqueue_style('fluent-player-custom-css');
        wp_add_inline_style('fluent-player-custom-css', $css);
    }
}
