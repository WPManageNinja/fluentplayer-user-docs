<?php

namespace FluentPlayerPro\App\Hooks\Handlers;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

use FluentPlayer\Framework\Support\Arr;

class FluentPlaylistCPT
{
    /**
     * The custom post type slug
     * @var string
     */
    protected static $post_type = 'fluent_playlist';

    /**
     * The URL slug
     * @var string
     */
    public static $url_slug = 'fluent-playlist';

    /**
     * Bump whenever the generated rewrite rules change so existing installs
     * flush their persisted rules once, independent of the plugin version.
     * v2: playlist-{n} now routes through fp_playlist_ref (slug-first resolution).
     * @var string
     */
    const REWRITE_SCHEMA_VERSION = '2';

    /**
     * Register the post type and all related hooks
     */
    public function registerPostType()
    {
        $slug = self::$post_type;

        $labels = [
            'name'               => __('Fluent Playlists', 'fluent-player-pro'),
            'singular_name'      => __('Playlist', 'fluent-player-pro'),
            'menu_name'          => __('Fluent Playlists', 'fluent-player-pro'),
            'name_admin_bar'     => __('Fluent Playlist', 'fluent-player-pro'),
            'add_new'            => __('Add New', 'fluent-player-pro'),
            'add_new_item'       => __('Add New Playlist', 'fluent-player-pro'),
            'new_item'           => __('New Playlist', 'fluent-player-pro'),
            'edit_item'          => __('Edit Playlist', 'fluent-player-pro'),
            'view_item'          => __('View Playlist', 'fluent-player-pro'),
            'all_items'          => __('All Playlists', 'fluent-player-pro'),
            'search_items'       => __('Search Playlists', 'fluent-player-pro'),
            'parent_item_colon'  => __('Parent Playlist:', 'fluent-player-pro'),
            'not_found'          => __('No playlists found.', 'fluent-player-pro'),
            'not_found_in_trash' => __('No playlists found in Trash.', 'fluent-player-pro')
        ];

        register_post_type($slug, [
            'labels'                => $labels,
            'public'                => true,
            'publicly_queryable'    => true,
            'show_in_rest'          => true,
            'show_ui'               => true,
            'show_in_menu'          => false,
            'show_in_nav_menus'     => false,
            'show_in_admin_bar'     => true,
            'supports'              => ['title', 'editor', 'custom-fields'],
            'has_archive'           => false,
            'menu_icon'             => 'dashicons-playlist-video',
            'description'           => __('Custom post type for FluentPlayer playlists.', 'fluent-player-pro'),
            'template'              => [
                ['fluent-player/playlist', []]
            ],
            'template_lock'         => 'all',
            'rewrite'               => [
                'slug' => self::$url_slug,
                'with_front' => false
            ],
            'capability_type'       => 'post',
            'hierarchical'          => false,
        ]);

        add_filter('allowed_block_types_all', [$this, 'restrictAllowedBlocks'], 10, 2);
        add_action('load-post.php', [$this, 'maybeInsertBlockContent']);
        add_filter('admin_title', [$this, 'modifyAdminTitle'], 10, 2);

        // Resolve the ambiguous /playlist-{n}/ permalink (slug first, id fallback)
        add_filter('query_vars', [$this, 'registerPlaylistQueryVar']);
        add_filter('request', [$this, 'resolvePlaylistReference']);

        // Intercept the frontend request to render our dedicated page
        add_action('template_redirect', [$this, 'renderDedicatedPlaylistPage']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueConditionalAssets']);

        add_filter('fluent_player/admin_vars', function ($vars) {
            $vars['playlist_view_url'] = home_url(self::$url_slug);
            return $vars;
        });

        add_filter('post_type_link', [$this, 'customizePermalink'], 10, 2);
    }

    /**
     * Add custom rewrite rules for fluent_playlist post - slug-based permalinks
     */
    public static function addRewriteRules() {
        // /fluent-playlist/playlist-{n}/ is ambiguous: a titled playlist can own
        // the slug "playlist-{n}" while an untitled one uses a synthetic
        // playlist-{ID} permalink. Route it through a reference var so the
        // request filter can prefer the slug and fall back to the post id.
        add_rewrite_rule(
            self::$url_slug . '/playlist-([0-9]+)/?$',
            'index.php?fp_playlist_ref=$matches[1]',
            'top'
        );
        // Primary rule for slug-based URLs: /fluent-playlist/{slug}/
        add_rewrite_rule(
            self::$url_slug . '/([^/]+)/?$',
            'index.php?post_type=' . self::$post_type . '&name=$matches[1]',
            'top'
        );
        update_option('fluent_player_pro_rewrite_rules_added', true);
    }

    /**
     * Whitelist the reference query var the playlist-{n} rule sets, so WordPress
     * keeps it through request parsing.
     *
     * @param array $vars
     * @return array
     */
    public function registerPlaylistQueryVar($vars)
    {
        $vars[] = 'fp_playlist_ref';
        return $vars;
    }

    /**
     * Resolve a /fluent-playlist/playlist-{n}/ request to the right post: by
     * slug when a "playlist-{n}" playlist exists (titled), otherwise by post id
     * (untitled synthetic permalink).
     *
     * @param array $queryVars
     * @return array
     */
    public function resolvePlaylistReference($queryVars)
    {
        if (!isset($queryVars['fp_playlist_ref'])) {
            return $queryVars;
        }

        $ref = (int) $queryVars['fp_playlist_ref'];
        unset($queryVars['fp_playlist_ref']);

        if ($ref <= 0) {
            return $queryVars;
        }

        return array_merge($queryVars, self::decidePlaylistQueryVars($ref, self::playlistSlugExists($ref)));
    }

    /**
     * Decide the query vars for a playlist-{ref} URL. Pure so it is unit-testable.
     *
     * @param int  $ref
     * @param bool $slugExists  whether a playlist with slug "playlist-{ref}" exists
     * @return array
     */
    public static function decidePlaylistQueryVars($ref, $slugExists)
    {
        if ($slugExists) {
            return ['post_type' => self::$post_type, 'name' => 'playlist-' . $ref];
        }
        return ['post_type' => self::$post_type, 'p' => $ref];
    }

    /**
     * @param int $ref
     * @return bool  true when a published/any playlist owns the slug "playlist-{ref}"
     */
    protected static function playlistSlugExists($ref)
    {
        $post = get_page_by_path('playlist-' . $ref, OBJECT, self::$post_type);
        return $post instanceof \WP_Post && $post->post_type === self::$post_type;
    }

    /**
     * Customize the permalink structure for fluent_playlist post type
     */
    public function customizePermalink($post_link, $post) {
        if (isset($post->post_type) && $post->post_type === self::$post_type) {
            // Use post_name (slug) if it's a valid non-numeric slug
            // Fallback to 'playlist-{ID}' for untitled posts (where post_name is empty or just the ID)
            $hasValidSlug = !empty($post->post_name) && !is_numeric($post->post_name);
            $slug = $hasValidSlug ? $post->post_name : 'playlist-' . $post->ID;
            return home_url( self::$url_slug . '/' . $slug . '/');
        }
        return $post_link;
    }


    /**
     * If this is a single playlist page, hijack the request and render our own template.
     */
    public function renderDedicatedPlaylistPage()
    {
        // Only run this logic on single pages for our CPT
        if (!is_singular(self::$post_type)) {
            return;
        }

        global $post;

        if (!isset($post)) {
            return;
        }
        $isPublic = $post->post_status === 'publish';
	      $isUserCanNotEdit = !current_user_can('edit_post', $post->ID);
        if ($isUserCanNotEdit && !$isPublic) {
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            get_template_part(404);
            exit();
        }

        $statusLabels = [
            'private' => __('Private', 'fluent-player-pro'),
            'draft'   => __('Draft', 'fluent-player-pro'),
            'pending' => __('Pending', 'fluent-player-pro'),
            'future'  => __('Scheduled', 'fluent-player-pro'),
        ];
        $statusLabel = Arr::get($statusLabels, $post->post_status, __('Private', 'fluent-player-pro'));
        $scheduledTime = '';
        if ($post->post_status === 'future') {
            $scheduledTime = wp_date(get_option('date_format') . ' ' . get_option('time_format'), get_post_timestamp($post));
        }

        // Start outputting our custom page
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?> class="fluent-playlist-html">
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php echo esc_html($post->post_title); ?> - <?php bloginfo('name'); ?></title>
            <?php wp_head(); // This will include our enqueued styles and scripts ?>
        </head>
        <?php
        // Locked playlist shows the form with no JS init — mark body ready or the opacity:0 container hides it.
        $bodyClass = post_password_required($post->ID) ? 'fluent-playlist-body fluent-playlist-ready' : 'fluent-playlist-body';
        ?>
        <body <?php body_class($bodyClass); ?>>
        <div class="fluent-playlist-dedicated-page">
            <header class="fluent-playlist-header">
                <h1 class="fluent-playlist-header-title">
                    <span class="fluent-playlist-header-title-text">
                        <?php echo esc_html($post->post_title); ?>
                    </span>
                    <?php if (!$isPublic) : ?>
                        <span class="fluent-playlist-header-title-status">
                            <?php echo esc_html($statusLabel); ?>
                            <?php if ($scheduledTime) : ?>
                                <span class="fluent-playlist-header-title-time">· <?php echo esc_html($scheduledTime); ?></span>
                            <?php endif; ?>
                        </span>
                    <?php endif; ?>
                </h1>
            </header>

            <main class="fluent-playlist-main-container">
                <?php
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped within the shortcode handler
                echo do_shortcode('[fluentplaylist id="' . absint($post->ID) . '"]');
                ?>
            </main>
        </div>
        <?php wp_footer(); ?>
        </body>
        </html>
        <?php
        exit();
    }

    /**
     * Conditionally enqueue assets (styles and scripts) for the dedicated playlist page layout.
     */
    public function enqueueConditionalAssets()
    {
        // Only load these styles on our dedicated single playlist page
        if (is_singular(self::$post_type)) {
            $this->enqueueInlineStyles();
            $this->enqueueInlineScript();
        }
    }

    private function enqueueInlineStyles()
    {
        wp_register_style(
            'fluent-playlist-single-page',
            false,
            [],
            FLUENT_PLAYER_PRO_VERSION
        );
        wp_enqueue_style('fluent-playlist-single-page');

        $custom_css = "
                html.fluent-playlist-html,
                html.fluent-playlist-html body.fluent-playlist-body {
                    width: 100%;
                    min-height: 100%;
                    height: -webkit-fill-available;
                    margin: 0;
                    padding: 0;
                    background-color: #000;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif;
                    overflow-x: hidden;
                }
                .fluent-playlist-dedicated-page {
                    display: flex;
                    gap: 10px;
                    flex-direction: column;
                    justify-content: start;
                    align-items: center;
                    width: 100%;
                    min-height: 100%;
                    background-color: #fafafa;
                    position: relative;
                }
                .fluent-playlist-main-container {
                    opacity: 0; 
                    transition: opacity 0.3s ease;
                }
                body.fluent-playlist-ready .fluent-playlist-main-container {
                    opacity: 1;
                }
                .fluent-playlist-header {
                    display: flex;
                    gap: 2em;
                    align-items: center;
                    justify-content: center;
                    background: #2e2e2e;
                    color: #fff;
                    padding: 15px;
                    z-index: 1;
                    position: relative;
                    width: 100%;
                    box-sizing: border-box;
                }
                .fluent-playlist-header-title {
                    color: #fff;
                    font-size: 15px;
                    font-weight: 600;
                    line-height: 18px;
                    display: flex;
                    align-items: center;
                    gap: .5em;
                    max-width: 100vw;
                    box-sizing: border-box;
                    padding: 0 1rem;
                }
                .fluent-playlist-header-title-text {
                    overflow: hidden;
                    text-overflow: ellipsis;
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                }
                .fluent-playlist-header-title-status {
                    display: inline-flex;
                    align-items: center;
                    border: none;
                    white-space: nowrap;
                    -webkit-user-select: none;
                    user-select: none;
                    font-weight: 700;
                    border-radius: 9999px;
                    padding: 0 .5em;
                    background: grey;
                    color: #000;
                    line-height: 1.4;
                    font-size: 12px;
                }
                .fluent-playlist-main-container {
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    width: 80%;
                    margin: 0 auto;
                    padding: 1rem;
                    box-sizing: border-box;
                    position: relative;
                }
            ";

        wp_add_inline_style('fluent-playlist-single-page', $custom_css);
    }

    private function enqueueInlineScript() {
        wp_register_script('fluent-playlist-single-page-logic', false, [], FLUENT_PLAYER_PRO_VERSION, true);
        wp_enqueue_script('fluent-playlist-single-page-logic');

        $custom_js = "
            document.addEventListener('fluentPlaylistInitialized', function() {
                document.body.classList.add('fluent-playlist-ready');
            });
        ";

        wp_add_inline_script('fluent-playlist-single-page-logic', $custom_js);
    }

    /**
     * Modify the admin title for our custom post type for a polished feel.
     */
    public function modifyAdminTitle($admin_title, $title)
    {
        global $post_type, $pagenow;

        if (!isset($pagenow) || !isset($post_type) || $post_type !== self::$post_type) {
            return $admin_title;
        }

        if ($pagenow === 'post.php') {
            return __('Edit Playlist', 'fluent-player-pro') . ' &lsaquo; ' . get_bloginfo('name');
        }

        if ($pagenow === 'post-new.php') {
            return __('Add New Playlist', 'fluent-player-pro') . ' &lsaquo; ' . get_bloginfo('name');
        }

        return $admin_title;
    }

    /**
     * Ensure playlist has block content when editing
     */
    public function maybeInsertBlockContent()
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only; used to load post for block content check
        if (!isset($_GET['post']) || !isset($_GET['action']) || $_GET['action'] !== 'edit') {
            return;
        }

        $post_id = absint(wp_unslash($_GET['post']));
        $post = get_post($post_id);

        if (!$post || $post->post_type !== self::$post_type) {
            return;
        }

        if (empty(trim($post->post_content ?? ''))) {
            $block_content = '<!-- wp:fluent-player/playlist {"playlistId":' . $post_id . '} /-->';

            wp_update_post([
                'ID' => $post_id,
                'post_content' => $block_content
            ]);
        }
    }

    /**
     * Restrict allowed blocks for playlist post type
     * Only restricts blocks within the playlist CPT editor
     */
    public function restrictAllowedBlocks($allowed_block_types, $block_editor_context)
    {
        if (!isset($block_editor_context->post) || !$block_editor_context->post) {
            return $allowed_block_types;
        }

        // For playlist CPT: only allow the playlist block
        if ($block_editor_context->post->post_type === self::$post_type) {
            return ['fluent-player/playlist'];
        }

        // For other post types: allow all blocks including playlist block
        return $allowed_block_types;
    }

}

