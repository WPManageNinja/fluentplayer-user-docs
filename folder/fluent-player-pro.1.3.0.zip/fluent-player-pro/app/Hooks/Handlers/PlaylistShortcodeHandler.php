<?php

namespace FluentPlayerPro\App\Hooks\Handlers;
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

use FluentPlayer\App\App;
use FluentPlayer\App\Helpers\Helper;
use FluentPlayerPro\App\Layouts\PlaylistLayoutFactory;
use FluentPlayer\App\Models\Media;
use FluentPlayer\App\Services\UnlockService;
use FluentPlayer\App\Services\MediaService;
use FluentPlayerPro\App\Services\PlaylistCssGenerator;
use FluentPlayerPro\App\Services\PlaylistSettingsHelper;
use FluentPlayer\App\Services\SettingsService;
use FluentPlayer\App\Utils\Enqueuer\Enqueue;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Models\Playlist;

class PlaylistShortcodeHandler
{
    private const ALLOWED_ORDERBY = ['date', 'title', 'modified', 'rand'];

    /**
     * $app Application instance
     * @var App
     */
    protected $app;

    public function __construct()
    {
        $this->app = App::make();
    }

    public function handle($atts, $content = '')
    {
        $data = [
            'id'      => null,
            'tags'    => '',
            'settings'=> '',
            'limit'   => 20,
            'orderby' => 'date',
            'order'   => 'DESC',
        ];
        $shortcodeDefaults = apply_filters('fluent_player/playlist_shortcode_defaults', $data, $atts);
        $atts = shortcode_atts($shortcodeDefaults, $atts);

        if (!empty($atts['tags'])) {
            return $this->renderPlaylistByTags($atts);
        }

        return $this->renderPlaylist($atts);
    }

    private function runBeforeRenderPlaylistHook($playlist)
    {
        do_action('fluent_player/before_render_playlist', $playlist); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Base plugin hook
    }

    protected function renderPlaylistByTags($atts)
    {
        $tagPlaylist = $this->normalizeTagPlaylistArgs($atts);
        if (!$tagPlaylist) {
            return '';
        }

        $posts = $this->getTagPlaylistPosts($tagPlaylist);

        if (empty($posts)) {
            return '';
        }

        $medias = $this->hydrateTagPlaylistMedias($posts);

        if (empty($medias)) {
            return '';
        }

        $virtualPlaylist = $this->makeVirtualTagPlaylist($tagPlaylist);

        $this->runBeforeRenderPlaylistHook($virtualPlaylist);

        return $this->renderPreparedPlaylist(
            $virtualPlaylist,
            $medias,
            SettingsService::getPlaylistDefaultSettings($virtualPlaylist->settings, $virtualPlaylist->ID),
            'fluent_playlist_tag_' . $virtualPlaylist->ID,
            []
        );
    }

    protected function renderPlaylist($atts)
    {
        $id = Arr::get($atts, 'id');
        if (!intval($id)) {
            return '';
        }
        $playlist = Playlist::find($id);
        if (!$playlist) {
            return '';
        }

        if ($playlist->post_status !== 'publish' && !current_user_can('read_post', $playlist->ID)) {
            return '';
        }

        if (class_exists(UnlockService::class) && post_password_required($playlist->ID) && !UnlockService::cookieUnlocked($playlist->ID)) {
            // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.InvalidPrefixPassed -- Filter hook name is a valid string, not a PHP identifier
            $message = apply_filters('fluent_player/playlist_password_message', __('This playlist is password protected. Enter the password to view it.', 'fluent-player-pro'), $playlist->ID);
            return \FluentPlayer\App\Services\MediaRenderer::renderLockedForm($playlist->ID, $message);
        }

        $this->runBeforeRenderPlaylistHook($playlist);

        $mediaIds = Arr::get($playlist->settings, 'medias');
        $medias = [];
        if ($mediaIds) {
            $atts = [
                'medias' => $mediaIds,
            ];
            $medias = Media::search($atts);
        }
        if (!$medias) {
            return '';
        }

        $mediaItems = is_array($medias) ? $medias : $medias->all();
        $relevantMediaIds = array_values(array_unique(array_map(function ($media) {
            return (int) $media->ID;
        }, $mediaItems)));

        // Process medias to merge preset settings and parse smartcodes
        foreach ($medias as $media) {
            $media->settings = $this->prepareMediaSettings($media, $relevantMediaIds);
        }

        // Get default settings for the first media (or use playlist settings)
        $defaultSettings = SettingsService::getPlaylistDefaultSettings($playlist->settings, $playlist->ID);

        return $this->renderPreparedPlaylist(
            $playlist,
            $medias,
            $defaultSettings,
            'fluent_playlist_' . $playlist->ID
        );
    }

    protected function normalizeTagPlaylistArgs($atts)
    {
        $rawTags = Arr::get($atts, 'tags', []);
        if (is_array($rawTags)) {
            $tags = array_values(array_filter(array_map('sanitize_text_field', $rawTags)));
        } else {
            $tags = array_values(array_filter(array_map('sanitize_text_field', explode(',', (string) $rawTags))));
        }

        if (empty($tags)) {
            return null;
        }

        $settings = PlaylistSettingsHelper::sanitizeAndValidate(Arr::get($atts, 'settings', []));
        unset($settings['medias']);

        $orderby = sanitize_key(Arr::get($atts, 'orderby', 'date'));
        if (!in_array($orderby, self::ALLOWED_ORDERBY, true)) {
            $orderby = 'date';
        }

        return [
            'tags'     => $tags,
            'settings' => $settings,
            'limit'    => min(absint(Arr::get($atts, 'limit', 20)), 100),
            'orderby'  => $orderby,
            'order'    => strtoupper(Arr::get($atts, 'order')) === 'ASC' ? 'ASC' : 'DESC',
        ];
    }

    protected function getTagPlaylistPosts($tagPlaylist)
    {
        return get_posts([
            'post_type'      => 'fluent_player_media',
            'posts_per_page' => $tagPlaylist['limit'],
            'orderby'        => $tagPlaylist['orderby'],
            'order'          => $tagPlaylist['order'],
            'post_status'    => 'publish',
            'tax_query'      => [[
                'taxonomy' => 'flp_media_tag',
                'field'    => 'name',
                'terms'    => $tagPlaylist['tags'],
                'operator' => 'IN',
            ]],
        ]);
    }

    protected function hydrateTagPlaylistMedias($posts)
    {
        $postIds = array_column($posts, 'ID');
        Media::batchLoadMediaSettings($posts);

        foreach ($posts as $post) {
            $post->settings = Media::getMediaSettings($post);
            $post->settings = $this->prepareMediaSettings($post, $postIds);
        }

        return $posts;
    }

    protected function makeVirtualTagPlaylist($tagPlaylist)
    {
        $virtualId = PlaylistSettingsHelper::generateTagPlaylistId($tagPlaylist['tags'], [
            'limit'   => $tagPlaylist['limit'],
            'orderby' => $tagPlaylist['orderby'],
            'order'   => $tagPlaylist['order'],
        ], $tagPlaylist['settings']);

        return (object) [
            'ID'         => $virtualId,
            'post_title' => implode(', ', $tagPlaylist['tags']),
            'post_name'  => sanitize_title(implode('-', $tagPlaylist['tags']) . '-' . $virtualId),
            'settings'   => $tagPlaylist['settings'],
        ];
    }

    protected function renderPreparedPlaylist($playlist, $medias, $defaultSettings, $playlistVarName, $inlinePlaylistSettings = null)
    {
        $medias = $this->filterAccessibleMedias($medias);
        if (empty($medias)) {
            return '';
        }

        $this->enqueuePlaylistAssets($playlist->ID, $defaultSettings, $medias);

        $frontendPlaylist = $this->makeFrontendPlaylist($playlist);
        $frontendMedias = $this->makeFrontendMedias($medias);

        $this->localizePlaylist($playlistVarName, $frontendPlaylist, $frontendMedias, $defaultSettings);

        $inlinePlaylist = $frontendPlaylist;
        if (is_array($inlinePlaylistSettings)) {
            $inlinePlaylist['settings'] = $inlinePlaylistSettings;
        }

        $inlineConfig = $this->makeInlinePlaylistConfig($playlistVarName, $inlinePlaylist, $frontendMedias, $defaultSettings);
        $rendered = $this->renderPlaylistLayout($playlist, $medias, $defaultSettings, $playlist->ID, $playlistVarName);

        return $rendered !== '' ? $inlineConfig . $rendered : '';
    }

    protected function enqueuePlaylistAssets($playlistId, $defaultSettings, $medias)
    {
        Enqueue::script('fluent_playlist', 'js/fluent-playlist.js', [], FLUENT_PLAYER_VERSION, true);
        Enqueue::style('fluent_playlist_css', 'scss/public/fluent-playlist.scss', [], FLUENT_PLAYER_VERSION);

        $gaService = new \FluentPlayer\App\Services\GoogleAnalyticsService();
        $gaService->enqueueScript();

        self::enqueuePlaylistStyles($playlistId, $defaultSettings);
        $this->addResourceHints($medias);
    }

    // Drop status-hidden media; keep password-protected ones as locked items
    // (src stripped) so no protected src reaches the HTML/config/script.
    protected function filterAccessibleMedias($medias)
    {
        $ids = [];
        foreach ($medias as $media) {
            $id = (int) ($media->ID ?? 0);
            if ($id) {
                $ids[] = $id;
            }
        }
        if ($ids) {
            _prime_post_caches($ids, false, false);
        }

        $filtered = [];
        foreach ($medias as $media) {
            $mediaId = (int) ($media->ID ?? 0);
            if (!$mediaId) {
                continue;
            }
            $post = get_post($mediaId);
            if (!$post || $post->post_type !== Media::$postType) {
                continue;
            }
            if ($post->post_status !== 'publish' && !current_user_can('read_post', $mediaId)) {
                continue;
            }
            if (class_exists(UnlockService::class) && post_password_required($post) && !UnlockService::cookieUnlocked($mediaId)) {
                $media->settings = self::stripLockedMediaSource(is_array($media->settings) ? $media->settings : []);
            }
            $filtered[] = $media;
        }

        return $filtered;
    }

    /**
     * Strip every source / provider-token key from a password-locked playlist
     * item's settings before it is serialized into the page config, then flag it
     * locked. Signed CDN material (Bunny/Mux/Gumlet + Cloudflare Stream tokens,
     * Cloudflare R2 object keys) must never reach the browser for a media the
     * viewer has not unlocked — otherwise the protected src can be reconstructed
     * despite the WP password gate. Mirrors the free MediaRenderer provider strip.
     *
     * @param array $settings
     * @return array
     */
    protected static function stripLockedMediaSource(array $settings)
    {
        unset(
            $settings['src'], $settings['url'], $settings['posterSrc'],
            $settings['bunny'], $settings['bunny_storage'], $settings['mux'], $settings['gumlet'],
            $settings['stream'], $settings['r2']
        );
        $settings['locked'] = true;

        return $settings;
    }

    protected function makeFrontendPlaylist($playlist)
    {
        return [
            'ID'         => $playlist->ID,
            'post_title' => $playlist->post_title,
            'post_name'  => $playlist->post_name ?? '',
            'settings'   => $playlist->settings ?? [],
        ];
    }

    protected function makeFrontendMedias($medias)
    {
        $frontendMedias = [];
        foreach ($medias as $media) {
            $frontendMedias[] = [
                'ID'         => $media->ID,
                'post_title' => $media->post_title,
                'settings'   => $media->settings ?? [],
            ];
        }

        return $frontendMedias;
    }

    protected function localizePlaylist($playlistVarName, $frontendPlaylist, $frontendMedias, $defaultSettings)
    {
        wp_localize_script('fluent_playlist', $playlistVarName, [
            'playlist'        => $frontendPlaylist,
            'medias'          => $frontendMedias,
            'defaultSettings' => $defaultSettings,
        ]);

        wp_localize_script('fluent_playlist', 'fluent_player', $this->getPlaylistFluentPlayerGlobals());
    }

    protected function makeInlinePlaylistConfig($playlistVarName, $frontendPlaylist, $frontendMedias, $defaultSettings)
    {
        return '<script type="application/json" id="fp-playlist-config-' . esc_attr($playlistVarName)
            . '" class="fluent-playlist-config" data-var="' . esc_attr($playlistVarName) . '">'
            . wp_json_encode([
                'playlist'        => $frontendPlaylist,
                'medias'          => $frontendMedias,
                'defaultSettings' => $defaultSettings,
            ], JSON_HEX_TAG | JSON_UNESCAPED_UNICODE)
            . '</script>';
    }

    protected function renderPlaylistLayout($playlist, $medias, $defaultSettings, $playlistId, $playlistVarName)
    {
        try {
            $layout = PlaylistLayoutFactory::create(
                $playlist,
                $medias,
                $defaultSettings,
                $playlistId,
                $playlistVarName
            );
            return $layout->render();
        } catch (\Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Error logging for debugging
                error_log('Playlist Layout Factory Error: ' . $e->getMessage());
            }

            return $this->renderView('playlist', [
                'playlist_id'       => $playlistId,
                'playlist_var_name' => $playlistVarName,
                'playlist'          => $playlist,
                'medias'            => $medias,
                'defaultSettings'   => $defaultSettings,
            ]);
        }
    }

    protected function renderView($view, $data = [])
    {
        return $this->app->make('view')->make($view, $data);
    }

    /**
     * Prepare media settings consistently across playlist shortcode entry points.
     *
     * @param object $media
     * @param array $relevantMediaIds
     * @return array
     */
    protected function prepareMediaSettings($media, $relevantMediaIds = [])
    {
        $settings = Media::mergePresetSettings($media->settings);
        $settings = MediaService::parseSmartcodes($settings);

        if (class_exists('\FluentPlayerPro\App\Services\ConditionService')) {
            $settings = \FluentPlayerPro\App\Services\ConditionService::maybePrepareConditionState($settings, $media->ID, $relevantMediaIds);
        }

        // YouTube Privacy-Enhanced Mode: serve posters from the cookieless i.ytimg.com
        // host so playlist thumbnails and the player poster make no youtube.com request
        // before playback. Applied here (the single point every media flows through) so
        // it covers the player media-poster, audio background, and every list/grid item.
        // getSettings() is statically cached, so reading it per media is cheap.
        // method_exists guard: privacyEnhanceYouTubePoster is a newer free surface, so
        // fail closed (leave the poster unchanged) on older free builds rather than fatal.
        if (method_exists(Helper::class, 'privacyEnhanceYouTubePoster')) {
            $privacyMode = (bool) Arr::get(Helper::getSettings(), 'youtube.privacy_mode', false);
            $settings['posterSrc'] = Helper::privacyEnhanceYouTubePoster(
                Arr::get($settings, 'posterSrc', ''),
                $privacyMode
            );
        }

        // Sign token-protected provider URLs (Bunny Stream/Storage, Mux) as the final prep
        // step — mirrors the free single-media paths (e.g. MediaRenderer) which pair frontend
        // prep with this signing filter. Every playlist media flows through here exactly once,
        // so signing here (not in the layout/localize output) avoids the double-token that a
        // second pass would produce for Bunny Stream. Without it, playlist items with a
        // token-protected src are emitted unsigned and the CDN returns 403 on playback.
        $settings = apply_filters('fluent_player/player_settings', $settings);

        return $settings;
    }

    /**
     * Global script data for window.fluent_player (playlists share the same shape as single-player embeds).
     *
     * @return array<string, mixed>
     */
    private function getPlaylistFluentPlayerGlobals()
    {
        $settings = Helper::getSettings();
        $youtubeSettings = Arr::get($settings, 'youtube', []);

        return [
            'ajax_url'         => admin_url('admin-ajax.php'),
            'nonce'            => wp_create_nonce('fluent_player_frontend'),
            'analytics'        => Arr::get($settings, 'analytics', []),
            'google_analytics' => Arr::get($settings, 'google_analytics', []),
            'has_pro'          => true,
            'show_powered_by'  => (bool) Arr::get($settings, 'branding.show_powered_by', false),
            // A standalone playlist page renders no single player, so free's
            // MediaRenderer::localizeGlobals() (the usual source of this dict)
            // never runs. Without `trans`, FluentPlaylist.js's $t() calls fall
            // back to English. Reuse free's frontend strings so they localize.
            'trans'            => \FluentPlayer\App\Services\Translations\TransStrings::getFrontendStrings(),
            'resume_playback'  => Arr::get($settings, 'general.resume_playback', false) === true,
            'youtube'          => [
                'privacy_mode'          => (bool) Arr::get($youtubeSettings, 'privacy_mode', false),
                'show_subscribe_button' => (bool) Arr::get($youtubeSettings, 'show_subscribe_button', false),
            ],
        ];
    }

    private static $preconnectAdded = false;

    private function addResourceHints($medias)
    {
        if (self::$preconnectAdded || empty($medias)) {
            return;
        }

        self::$preconnectAdded = true;

        $firstMedia = $medias[0] ?? null;
        if (!$firstMedia || empty($firstMedia->settings)) {
            return;
        }

        $settings = $firstMedia->settings;
        $src = Arr::get($settings, 'src', '');
        if (empty($src)) {
            return;
        }

        $domains = [];
        $provider = Arr::get($settings, 'provider', '');

        if ($provider === 'youtube' || strpos($src, 'youtube.com') !== false || strpos($src, 'youtu.be') !== false) {
            $domains = ['https://www.youtube.com', 'https://i.ytimg.com'];
        } elseif ($provider === 'vimeo' || strpos($src, 'vimeo.com') !== false) {
            $domains = ['https://player.vimeo.com', 'https://i.vimeocdn.com'];
        } elseif (strpos($src, 'bunny.net') !== false || strpos($src, 'bunnycdn.com') !== false || strpos($src, 'b-cdn.net') !== false) {
            $parsed = wp_parse_url($src);
            if (is_array($parsed) && !empty($parsed['host'])) {
                $scheme = isset($parsed['scheme']) ? $parsed['scheme'] : 'https';
                $domains = [$scheme . '://' . $parsed['host']];
            }
        }

        if (empty($domains)) {
            return;
        }

        add_action('wp_head', function () use ($domains) {
            foreach ($domains as $domain) {
                $host = wp_parse_url($domain, PHP_URL_HOST);
                if ($host === false || $host === null || $host === '') {
                    continue;
                }
                echo '<link rel="dns-prefetch" href="//' . esc_attr($host) . '">' . "\n";
                echo '<link rel="preconnect" href="' . esc_url($domain) . '" crossorigin>' . "\n";
            }
        }, 1);
    }

    /**
     * Enqueue playlist-specific styles using CSS generator
     *
     * @param int $playlistId
     * @param array $defaultSettings
     */
    private static function enqueuePlaylistStyles($playlistId, $defaultSettings)
    {
        static $processedPlaylists = [];
        if (isset($processedPlaylists[$playlistId])) {
            return;
        }
        $processedPlaylists[$playlistId] = true;

        if (!wp_style_is('fluent_playlist_css', 'enqueued')) {
            if (!wp_style_is('fluent_playlist_css', 'registered')) {
                wp_register_style('fluent_playlist_css', false, [], FLUENT_PLAYER_VERSION);
            }
            wp_enqueue_style('fluent_playlist_css');
        }

        // Generate CSS using dedicated CSS generator
        $cssGenerator = PlaylistCssGenerator::create();
        $css = $cssGenerator->generatePlaylistCss($playlistId, $defaultSettings);

        if (!empty($css)) {
            wp_add_inline_style('fluent_playlist_css', $css);
        }
    }
}
