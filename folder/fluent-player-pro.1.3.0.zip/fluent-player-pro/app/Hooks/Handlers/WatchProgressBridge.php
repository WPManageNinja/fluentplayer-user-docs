<?php

namespace FluentPlayerPro\App\Hooks\Handlers;

use FluentPlayerPro\App\Services\AnalyticsService;
use FluentPlayer\Framework\Support\Arr;

if (!defined('ABSPATH')) exit;

/**
 * Bridges the server-authoritative progression flow into analytics.
 *
 * On every fluent_player/watch_recorded the coverage (a scrub-proof, server
 * recomputed ratio) is persisted into the per-user Visit store, so the same
 * daily row analytics keeps also reflects real watched progress. Decoupled
 * from any LMS — it only reads the generic seam and defers gating (analytics
 * enabled, login-only) to AnalyticsService::recordCoverage().
 */
class WatchProgressBridge
{
    public function register()
    {
        add_action('fluent_player/watch_recorded', [$this, 'onWatchRecorded'], 10, 3);
    }

    public function onWatchRecorded($mediaId, $userId, $payload)
    {
        $coverage = Arr::get($payload, 'coverage');
        if (!$userId || $coverage === null) {
            return;
        }

        AnalyticsService::recordCoverage(
            $mediaId,
            $userId,
            (float) Arr::get($payload, 'duration', 0),
            (int) round(((float) $coverage) * 100)
        );
    }
}
