<?php

namespace FluentPlayerPro\App\Hooks\Handlers;
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

use FluentPlayer\App\App;
use FluentPlayer\App\Helpers\Helper;
use FluentPlayer\App\Models\Media;
use FluentPlayerPro\App\Services\AnalyticsService;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Validator\Validator;
use FluentPlayer\Framework\Support\Sanitizer;

class AnalyticsHandler
{
    /**
     * @var \FluentPlayer\Framework\Foundation\Application
     */
    protected $app;

    public function __construct()
    {
        $this->app = App::make();
    }

    public function isAnalyticsEnabled()
    {
        $settings = Helper::getSettings();
        $analytics = Arr::get($settings, 'analytics', []);
        if (Arr::get($analytics, 'enabled', false)) {
            return true;
        }

        return false;
    }

    /**
     * Register AJAX hooks
     */
    public static function handle()
    {
        $instance = new self();
        if (!$instance->isAnalyticsEnabled()) {
            return;
        }

        $schemaVersion = '1.1';
        if (get_option('flp_visits_schema_version') !== $schemaVersion) {
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            \FluentPlayerPro\Database\Migrations\VisitsMigrator::migrate();
            update_option('flp_visits_schema_version', $schemaVersion, true);
        }

        add_action('wp_ajax_fluent_player_track_event', [$instance, 'trackEvent']);
        add_action('wp_ajax_nopriv_fluent_player_track_event', [$instance, 'trackEvent']);
    }

    /**
     * Handle tracking of video analytics events.
     */
    public function trackEvent()
    {
        try {
            // 1. Require a nonce before any input processing
            $nonce = sanitize_text_field($this->app->request->get('nonce', ''));
            if (!$nonce) {
                wp_send_json_error([
                    'message' => __('Security check failed', 'fluent-player-pro')
                ], 403);
                return;
            }

            // 2. Rate limit: max 30 requests per minute per IP (transient-based)
            $ipAddress = $this->app->request->getIp();
            $rateLimitKey = 'flp_track_' . md5($ipAddress);
            $requestCount = (int) get_transient($rateLimitKey);

            if ($requestCount >= 30) {
                wp_send_json_error([
                    'message' => __('Too many requests', 'fluent-player-pro')
                ], 429);
                return;
            }

            set_transient($rateLimitKey, $requestCount + 1, 60); // 60 second window

            // 3. Sanitize input data
            $rawData = $this->app->request->all();
            $sanitizedData = Sanitizer::sanitize($rawData, [
                'media_id'   => 'intval',
                'duration'   => 'floatval',
                'percentage' => 'intval',
            ]);

            // 4. Validate core fields
            $validation = Validator::make($sanitizedData, [
                'media_id'   => 'required|integer',
                'duration'   => 'required|numeric|min:0',
                'percentage' => 'integer|min:0|max:100',
            ]);

            if ($validation->fails()) {
                wp_send_json_error([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
                return;
            }

            // 5. Extract and cap values
            $mediaId    = $sanitizedData['media_id'];
            $duration   = min($sanitizedData['duration'], 86400); // Cap at 24 hours
            $percentage = isset($sanitizedData['percentage']) ? min((int) $sanitizedData['percentage'], 100) : 0;

            $expectedNonceAction = 'fluent_player_track_event:' . $mediaId;
            if (!wp_verify_nonce($nonce, $expectedNonceAction)) {
                wp_send_json_error([
                    'message' => __('Security check failed', 'fluent-player-pro')
                ], 403);
                return;
            }

            $media = Media::findVisible($mediaId);
            if (!$media) {
                wp_send_json_error([
                    'message' => __('Invalid media', 'fluent-player-pro')
                ], 404);
                return;
            }

            // 6. Collect visitor context
            $userId  = get_current_user_id();
            $context = AnalyticsService::collectVisitorContext();

            // 7. Record visit
            AnalyticsService::recordVisit($mediaId, $userId, $context['ip_address'], $context['browser'], $context['device'], $duration, $context['country'], $percentage);

            wp_send_json_success([
                'message' => __('Visit recorded successfully', 'fluent-player-pro')
            ]);
        } catch (\Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('FluentPlayer Pro Analytics Error: ' . $e->getMessage());
            }
            wp_send_json_error([
                'message' => __('An unexpected error occurred', 'fluent-player-pro')
            ], 500);
        }
    }
}
