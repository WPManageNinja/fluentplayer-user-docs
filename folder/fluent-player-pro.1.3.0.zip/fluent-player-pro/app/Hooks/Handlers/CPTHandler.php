<?php

namespace FluentPlayerPro\App\Hooks\Handlers;

use FluentPlayer\App\App;

class CPTHandler
{
	/*
	* Add all Custom Post Type classes here to
	* register all of your Custom Post Types.
	*/

	protected $customPostTypes = [
        FluentPlaylistCPT::class
	];

	public function registerPostTypes()
	{
		foreach ($this->customPostTypes as $cpt) {
			App::make($cpt)->registerPostType();
		}
	}

    /**
     * Flush rewrite rules if necessary
     */
    public function maybeFlushRules()
    {
        $current_version = defined('FLUENT_PLAYER_PRO_VERSION') ? FLUENT_PLAYER_PRO_VERSION : '1.0';
        $current_schema  = FluentPlaylistCPT::REWRITE_SCHEMA_VERSION;

        $shouldFlush = self::shouldFlushRewriteRules([
            'stored_version'  => get_option('fluent_player_pro_rewrite_version', '0'),
            'current_version' => $current_version,
            // Default '1' so installs predating the schema option flush once.
            'stored_schema'   => get_option('fluent_player_pro_rewrite_schema', '1'),
            'current_schema'  => $current_schema,
            'rules_added'     => (bool) get_option('fluent_player_pro_rewrite_rules_added'),
            'force_flush'     => (bool) get_option('fluent_player_pro_force_flush_rules'),
        ]);

        if ($shouldFlush) {
            // This is expensive, so we only do it when needed
            flush_rewrite_rules();

            update_option('fluent_player_pro_rewrite_version', $current_version);
            update_option('fluent_player_pro_rewrite_schema', $current_schema);
            update_option('fluent_player_pro_rewrite_rules_added', true);
            delete_option('fluent_player_pro_force_flush_rules');
        }
    }

    /**
     * Decide whether the rewrite rules must be flushed. Pure so it is unit-testable.
     * Flush when the plugin version changed, the rewrite schema changed (a rule
     * change that must reach existing installs even without a version bump), the
     * rules were never added, or a one-time force flag is set.
     *
     * @param array $state
     * @return bool
     */
    public static function shouldFlushRewriteRules(array $state)
    {
        return $state['stored_version'] !== $state['current_version']
            || $state['stored_schema'] !== $state['current_schema']
            || empty($state['rules_added'])
            || !empty($state['force_flush']);
    }
}
