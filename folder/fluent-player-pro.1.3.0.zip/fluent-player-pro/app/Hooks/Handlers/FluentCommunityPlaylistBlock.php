<?php

namespace FluentPlayerPro\App\Hooks\Handlers;

if (!defined('ABSPATH')) {
    exit;
}

use FluentPlayer\App\Utils\Enqueuer\Enqueue;
use FluentPlayer\App\Utils\Enqueuer\Vite;

/**
 * Registers Fluent Player playlist support inside FluentCommunity's portal.
 *
 * FC's portal does not run wp_footer() or wp_enqueue_scripts() per-lesson,
 * so standard WP enqueueing is bypassed. These hooks inject the playlist
 * frontend assets and block editor assets through FC's own APIs.
 */
class FluentCommunityPlaylistBlock
{
    public static function register()
    {
        if (!defined('FLUENT_COMMUNITY_PLUGIN_VERSION')) {
            return;
        }
        
        add_filter('fluent_player/fluent_community_portal_data', [self::class, 'injectFrontendAssets']);
        add_filter('fluent_player/fluent_community_allowed_blocks', [self::class, 'allowPlaylistBlock']);
        add_action('fluent_player/fluent_community_enqueue_block_assets', [self::class, 'enqueueBlockEditorAssets']);
        add_filter('fluent_player/fluent_community_iframe_assets', [self::class, 'injectIframeStyles'], 10, 3);
    }

    /**
     * Inject playlist CSS + JS into FC's portal_data_vars so fluent-playlist.js
     * loads on lesson view pages (where wp_footer() does not run).
     */
    public static function injectFrontendAssets($data)
    {
        $data['css_files']['fluent_playlist_css'] = [
            'url' => Vite::getEnqueuePath('scss/public/fluent-playlist.scss')
        ];
        $data['js_files']['fluent_playlist_js'] = [
            'url'  => Vite::getEnqueuePath('js/fluent-playlist.js'),
            'deps' => []
        ];
        return $data;
    }

    /**
     * Add fluent-player/playlist to the list of blocks FC allows in its editor.
     */
    public static function allowPlaylistBlock($allowedBlockTypes)
    {
        $allowedBlockTypes[] = 'fluent-player/playlist';
        return $allowedBlockTypes;
    }

    /**
     * Enqueue playlist block editor assets in the FC context.
     * PlaylistBlock::enqueueEditorAssets() bails early when !is_admin(), so
     * this action fires the enqueue directly via the FC-specific hook.
     */
    public static function enqueueBlockEditorAssets()
    {
        Enqueue::script(
            'fluent-player-playlist-block-editor',
            'blocks/playlist/fluent-playlist-block.jsx',
            [
                'wp-blocks',
                'wp-element',
                'wp-i18n',
                'wp-components',
                'wp-block-editor',
                'wp-api-fetch',
                'jquery-ui-sortable',
            ],
            FLUENT_PLAYER_PRO_VERSION,
            true
        );

        Enqueue::style(
            'fluent-player-playlist-block-editor-style',
            'scss/fluent-player-playlist-block.scss',
            [],
            FLUENT_PLAYER_PRO_VERSION
        );
    }

    /**
     * Inject playlist block CSS into the editor-canvas iframe so the block
     * preview is styled correctly inside the apiVersion 3 canvas.
     *
     * @param array  $settings   Block editor settings array (contains __unstableResolvedAssets)
     * @param bool   $isDevMode  Whether the Vite dev server is active
     * @param string $ver        Asset version string for cache-busting
     */
    public static function injectIframeStyles($settings, $isDevMode, $ver)
    {
        $styleUrl = Vite::getEnqueuePath('scss/fluent-player-playlist-block.scss');

        if (!empty($settings['__unstableResolvedAssets']) && !empty($styleUrl) &&
            strpos($settings['__unstableResolvedAssets']['styles'] ?? '', 'fluent-player-playlist') === false) {
            $verParam = $isDevMode ? '' : '?ver=' . $ver;
            $settings['__unstableResolvedAssets']['styles'] .= '<link rel="stylesheet" href="' . esc_url($styleUrl . $verParam) . '" id="fluent-player-playlist-block-style-css" />';
        }

        return $settings;
    }
}
