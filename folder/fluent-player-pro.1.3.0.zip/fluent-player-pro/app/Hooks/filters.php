<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Fluent Player Pro Filters
 *
 * This file registers pro-specific filters that extend the free version.
 */

/**
 * @var $app FluentPlayer\Framework\Foundation\Application (from free version)
 */

/**
 * Register Pro integrations with the integration system
 */
$app->addFilter('fluent_player/integrations', function($integrations) {
    $integrations['bunnycdn_stream'] = \FluentPlayerPro\App\Integrations\BunnyCDNStreamIntegration::class;
    $integrations['bunnycdn_storage'] = \FluentPlayerPro\App\Integrations\BunnyCDNStorageIntegration::class;
    $integrations['mux'] = \FluentPlayerPro\App\Integrations\MuxIntegration::class;
    $integrations['gumlet'] = \FluentPlayerPro\App\Integrations\GumletIntegration::class;
    $integrations['cloudflare_r2'] = \FluentPlayerPro\App\Integrations\R2Integration::class;
    $integrations['cloudflare_stream'] = \FluentPlayerPro\App\Integrations\CloudflareStreamIntegration::class;
    return $integrations;
});

/**
 * Inject signed URLs, DRM tokens, and Mux Data env key at render time
 */
$app->addFilter('fluent_player/player_settings', [\FluentPlayerPro\App\Services\MuxService::class, 'filterPlayerSettings'], 10, 1);

/**
 * Inject signed/tokenized URLs for BunnyCDN Stream and Storage at render time
 */
$app->addFilter('fluent_player/player_settings', [\FluentPlayerPro\App\Services\BunnyCDNService::class, 'filterPlayerSettings'], 10, 1);

/**
 * Inject signed URLs for private Gumlet assets at render time
 */
$app->addFilter('fluent_player/player_settings', [\FluentPlayerPro\App\Services\GumletService::class, 'filterPlayerSettings'], 10, 1);

/**
 * Inject the public playback URL for Cloudflare R2 and Stream media at render time
 */
$app->addFilter('fluent_player/player_settings', [\FluentPlayerPro\App\Services\R2Service::class, 'filterPlayerSettings'], 10, 1);
$app->addFilter('fluent_player/player_settings', [\FluentPlayerPro\App\Services\CloudflareStreamService::class, 'filterPlayerSettings'], 10, 1);

$app->addFilter('fluent_player/media_block_inner', [
    \FluentPlayerPro\App\Hooks\Handlers\TimedContentHandler::class,
    'injectTimedContent'
], 10, 4);

$app->addFilter('fluent_player/media_tags_request', function ($response, $action, $request) {
    $methods = [
        'get'    => 'getTags',
        'create' => 'createTag',
        'rename' => 'renameTag',
        'delete' => 'deleteTag',
    ];

    if (!isset($methods[$action])) {
        return $response;
    }

    $controller = new \FluentPlayerPro\App\Http\Controllers\TagController();

    return $controller->{$methods[$action]}($request);
}, 10, 3);

$injectSubtitleApiFlags = function ($vars) {
    $subtitleApi = wp_parse_args((array)($vars['subtitleApi'] ?? []), [
        'upload'            => false,
        'delete'            => false,
        'youtubeImport'     => false,
        'youtubeStoryboard' => false,
        'maxTrackSelection' => \FluentPlayerPro\App\Services\SubtitleService::MAX_REMOTE_TRACK_SELECTION,
    ]);
    
    $subtitleApi['upload'] = true;
    $subtitleApi['delete'] = true;
    $subtitleApi['youtubeImport'] = true;
    $subtitleApi['youtubeStoryboard'] = true;
    $subtitleApi['maxTrackSelection'] = \FluentPlayerPro\App\Services\SubtitleService::MAX_REMOTE_TRACK_SELECTION;
    
    $vars['subtitleApi'] = $subtitleApi;
    
    return $vars;
};

$app->addFilter('fluent_player/media_block_vars', $injectSubtitleApiFlags, 10, 2);
$app->addFilter('fluent_player/fluent_community_block_vars', $injectSubtitleApiFlags, 10, 2);

// Advertise the video providers this Pro build supports (i.e. has REST routes
// for), so the free block picker can gate capability-specific providers like
// Gumlet instead of relying on generic Pro availability. An older Pro without
// this flag simply won't advertise them, and free hides those providers.
$advertiseProProviders = function ($vars) {
    // Contract: pro_providers and connected_providers both speak the block
    // picker's SOURCE keys (bunnycdn, mux_stream, ...) — not service-layer
    // provider slugs ('bunny') nor integration keys ('bunnycdn_stream').
    $vars['pro_providers'] = array_values(array_unique(array_merge(
        (array) ($vars['pro_providers'] ?? []),
        ['bunnycdn', 'bunny_storage', 'mux', 'mux_stream', 'gumlet', 'gumlet_live', 'cloudflare_r2', 'cloudflare_stream']
    )));
    return $vars;
};
$app->addFilter('fluent_player/media_block_vars', $advertiseProProviders, 10, 1);
$app->addFilter('fluent_player/fluent_community_block_vars', $advertiseProProviders, 10, 1);

// Advertise which providers are actually connected (integration enabled), so the
// block picker can dim disconnected ones and route the user to their setup page
// instead of opening a form that would fail. Keyed by the block's own source keys.
$advertiseConnectedProviders = function ($vars) {
    $sourceToIntegration = [
        'bunnycdn'          => 'bunnycdn_stream',
        'bunny_storage'     => 'bunnycdn_storage',
        'mux'               => 'mux',
        'mux_stream'        => 'mux',
        'gumlet'            => 'gumlet',
        'gumlet_live'       => 'gumlet',
        'cloudflare_r2'     => 'cloudflare_r2',
        'cloudflare_stream' => 'cloudflare_stream',
    ];

    $connected = [];
    foreach ($sourceToIntegration as $sourceKey => $integrationKey) {
        $integration = \FluentPlayer\App\Services\IntegrationService::getIntegration($integrationKey);
        if ($integration && $integration->isEnabled()) {
            $connected[] = $sourceKey;
        }
    }

    $vars['connected_providers'] = $connected;
    // Settings page is manage_options-gated (AdminMenuHandler); only send the
    // deep-link to users who can open it — others get a non-navigating button.
    if (current_user_can('manage_options')) {
        $vars['storageConfigBaseUrl'] = admin_url('admin.php?page=fluent-player#/settings/storage/');
    }
    return $vars;
};
// Only the wp-admin block editor — the FluentCommunity front-end editor would
// route authors (who lack settings caps) to an admin page they can't open.
$app->addFilter('fluent_player/media_block_vars', $advertiseConnectedProviders, 10, 1);

$app->addFilter('fluent_player/admin_vars', function ($vars) {
    $vars['licensing'] = wp_parse_args((array) ($vars['licensing'] ?? []), [
        'enabled' => false,
    ]);

    $vars['licensing']['enabled'] = true;

    return $vars;
});

$app->addFilter(
    'fluent_player/settings_section/subtitle_service',
    [\FluentPlayerPro\App\Services\SubtitleService::class, 'filterSubtitleServiceSettings'],
    10,
    2
);

$app->addFilter('fluent_player/unlockable_post_types', function ($types) {
    $types[] = 'fluent_playlist';
    return $types;
});

$app->addFilter('fluent_player/media_bulk_action', [
    \FluentPlayerPro\App\Services\BulkActionService::class,
    'handleMediaBulkAction',
], 10, 4);


(new \FluentPlayerPro\App\Services\PluginManager\PluginInstaller())->registerCoreUpdater();
