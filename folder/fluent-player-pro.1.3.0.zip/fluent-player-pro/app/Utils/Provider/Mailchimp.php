<?php

namespace FluentPlayerPro\App\Utils\Provider;

use FluentPlayer\Framework\Support\Arr;

class Mailchimp
{
    /**
     * Mailchimp API key
     *
     * @var string
     */
    protected $apiKey;

    /**
     * Mailchimp API server
     *
     * @var string
     */
    protected $server;

    /**
     * Constructor
     *
     * @param string $apiKey Mailchimp API key
     */
    public function __construct($apiKey = null)
    {
        if (!$apiKey) {
            $apiSettings = get_option('fluent_player_email_providers', []);
            $mailchimpSettings = json_decode($apiSettings, true);
            $apiKey = $mailchimpSettings['mailchimp']['api_key'] ?? '';
        }

        $this->apiKey = $apiKey;

        // Extract server from API key
        if ($apiKey && strpos($apiKey, '-') !== false) {
            $parts = explode('-', $apiKey);
            $this->server = end($parts);
        }
    }

    /**
     * Make a request to the Mailchimp API
     *
     * @param string $endpoint API endpoint
     * @param array $data Request data
     * @param string $method HTTP method (GET, POST, PUT, PATCH, DELETE)
     * @return array Response data
     */
    public function makeRequest($endpoint, $data = [], $method = 'GET')
    {
        if (empty($this->apiKey) || empty($this->server)) {
            return [
                'success' => false,
                'message' => 'Mailchimp API key not configured or invalid'
            ];
        }

        // Build the full API URL
        $url = "https://{$this->server}.api.mailchimp.com/3.0/{$endpoint}";

        // Set up request arguments
        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode('anystring:' . $this->apiKey),
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json'
            ],
            'timeout' => 15
        ];

        // Add body for non-GET requests
        if ($method !== 'GET' && !empty($data)) {
            $args['body'] = json_encode($data);
        }

        // Make the request
        $response = wp_remote_request($url, $args);

        // Handle errors
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message()
            ];
        }

        // Get response code and body
        $responseCode = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        // Return formatted response
        if ($responseCode >= 200 && $responseCode < 300) {
            return [
                'success' => true,
                'message' => 'Mailchimp integration runs successfully',
                'code'    => $responseCode,
                'data'    => $body
            ];
        } else {
            return [
                'success'  => false,
                'message'  => Arr::get($body, 'detail', 'Error communicating with Mailchimp'),
                'code'     => $responseCode
            ];
        }
    }

    /**
     * Add or update a subscriber in a Mailchimp list
     *
     * @param string $email Subscriber email
     * @param string $listId Mailchimp list ID
     * @param array $tags Tags to apply to the subscriber
     * @param array $mergeFields Merge fields for the subscriber
     * @return array Response data
     */
    public function addSubscriber($email, $listId, $tags = [], $mergeFields = [])
    {
        // Create subscriber hash (MD5 hash of lowercase email)
        $subscriberHash = md5(strtolower($email));

        // Prepare data
        $data = [
            'email_address' => $email,
            'status'        => 'subscribed',
            'status_if_new' => 'subscribed'
        ];

        // Add merge fields if provided
        if (!empty($mergeFields)) {
            $data['merge_fields'] = $mergeFields;
        }

        // Add tags if provided
        if (!empty($tags)) {
            $data['tags'] = $tags;
        }

        // Make the request to add/update the subscriber
        return $this->makeRequest("lists/{$listId}/members/{$subscriberHash}", $data, 'PUT');
    }

    /**
     * Get all lists from Mailchimp
     *
     * @param int $count Number of lists to retrieve
     * @return array Response data
     */
    public function getLists($count = 100)
    {
        return $this->makeRequest('lists', ['count' => $count], 'GET');
    }

    /**
     * Ping Mailchimp API to validate API key
     * @return array
     */
    public function ping()
    {
        try {
            $ping = $this->makeRequest('ping');

            $code = $ping['code'];

            if ($code === 200) {
                return [
                    'success' => true,
                    'message' => 'API key is valid'
                ];
            }

            return [
                'success' => false,
                'message' => 'Invalid API key'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Add or update a subscriber in a Mailchimp list with tags
     *
     * @param string $listId Mailchimp list ID
     * @param string $email Subscriber email
     * @param array $data Additional data
     * @return array Response data
     */
    public function subscribe($listId, $email, $data = [])
    {
        // Create subscriber hash (MD5 hash of lowercase email)
        $subscriberHash = md5(strtolower($email));

        // Prepare data
        $subscribeData = [
            'email_address' => $email,
            'status' => 'subscribed',
            'status_if_new' => 'subscribed'
        ];

        // Add merge fields if provided
        if (!empty($data['merge_fields'])) {
            $subscribeData['merge_fields'] = $data['merge_fields'];
        }

        // First add/update the subscriber
        $response = $this->makeRequest("lists/{$listId}/members/{$subscriberHash}", $subscribeData, 'PUT');

        if (!$response['success']) {
            return $response;
        }

        // Now add tags if provided
        if (!empty($data['tags']) && is_array($data['tags'])) {
            $tags = array_map(function($tagId) {
                return ['id' => $tagId, 'status' => 'active'];
            }, $data['tags']);

            $tagData = [
                'tags' => $tags
            ];

            $tagResponse = $this->makeRequest("lists/{$listId}/members/{$subscriberHash}/tags", $tagData, 'POST');

            if (!$tagResponse['success']) {
                // We succeeded in adding the subscriber but failed with tags
                return [
                    'success' => true,
                    'message' => __('Subscriber added but failed to add tags', 'fluent-player-pro'),
                    'tag_error' => $tagResponse['message']
                ];
            }
        }

        return $response;
    }
}

