<?php

namespace FluentPlayerPro\App\Utils\Provider;

use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Support\Str;

class Webhook
{
    /**
     * Default request timeout in seconds
     *
     * @var int
     */
    protected $timeout = 15;

    /**
     * Default user agent
     *
     * @var string
     */
    protected $userAgent = 'FluentPlayer/1.0';

    /**
     * Default url
     *
     * @var string
     */
    protected $url;

    /**
     * Default method
     *
     * @var string
     */
    protected $method = 'POST';

    /**
     * Default Field Name
     *
     * @var string
     */
    protected $fieldName = 'email';

    /**
     * Default headers
     *
     * @var string
     */
    protected $headers = [];

    /**
     * Email
     *
     * @var string
     */
    protected $email;

    /**
     * Webhook ID for tracking
     *
     * @var string
     */
    protected $webhookId = '';

    /**
     * Static cache for processed webhooks in this request
     *
     * @var array
     */
    protected static $processedWebhooks = [];

    /**
     * Constructor
     */
    public function __construct($url, $method, $fieldName, $headers, $email)
    {
        $this->url = $url;
        $this->method = $method;
        $this->fieldName = $fieldName;
        $this->headers = $headers;
        $this->email = $email;
    }

    /**
     * Set webhook ID
     *
     * @param string $id
     * @return $this
     */
    public function setWebhookId($id)
    {
        $this->webhookId = $id;
        return $this;
    }

    /**
     * Make a request to a webhook endpoint
     *
     * @param string $url The webhook URL
     * @param array $data The data to send
     * @param string $method The HTTP method (GET, POST, PUT)
     * @param array $headers Custom headers
     * @return array Response data
     */
    public function makeRequest($url, $data = [], $method = 'POST', $headers = [])
    {
        if (empty($url)) {
            return [
                'success' => false,
                'message' => 'Webhook URL not configured'
            ];
        }

        // Validate URL scheme
        $parsedUrl = wp_parse_url($url);
        if (empty($parsedUrl['host']) || !in_array($parsedUrl['scheme'] ?? '', ['http', 'https'], true)) {
            return [
                'success' => false,
                'message' => 'Invalid webhook URL'
            ];
        }

        // Block requests to private/internal IPs (SSRF prevention)
        $ip = gethostbyname($parsedUrl['host']);
        if ($ip && (
            filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false
        )) {
            return [
                'success' => false,
                'message' => 'Webhook URL resolves to a private or reserved IP address'
            ];
        }

        // Validate method
        $method = strtoupper($method);
        if (!in_array($method, ['GET', 'POST', 'PUT'])) {
            $method = 'POST';
        }

        // Set default headers
        $defaultHeaders = [
            'Content-Type' => 'application/json',
            'User-Agent'   => $this->userAgent
        ];

        // Merge with custom headers
        $requestHeaders = array_merge($defaultHeaders, $headers);

        // Prepare request args
        $args = [
            'method'  => $method,
            'headers' => $requestHeaders,
            'timeout' => $this->timeout,
        ];

        // Add body for POST/PUT requests
        if ($method !== 'GET') {
            $args['body'] = json_encode($data);
        } else {
            $url = add_query_arg($data, $url);
        }

        // Make the request
        $response = wp_remote_request($url, $args);

        // Handle errors
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message()
            ];
        }

        // Get response code and body
        $responseCode = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if (defined('WP_DEBUG') && WP_DEBUG) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Error logging for debugging webhook responses
            error_log(sprintf(
                'Webhook response: ID=%s, Code=%s',
                $this->webhookId ?: 'none',
                $responseCode
            ));
        }

        // Try to parse JSON response
        $parsedBody = json_decode($body, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $body = $parsedBody;
        }

        // Return formatted response
        if ($responseCode >= 200 && $responseCode < 300) {
            return [
                'success' => true,
                'message' => __('Webhook sent successfully', 'fluent-player-pro'),
                'data'    => $body,
                'code'    => $responseCode
            ];
        } else {
            return [
                'success' => false,
                'message' => "Webhook returned error code: {$responseCode}",
                'data'    => $body,
                'code'    => $responseCode
            ];
        }
    }

    /**
     * Send data to a webhook
     *
     * @return array Response data
     */
    public function send()
    {
        try {
            if (!empty($this->webhookId) && isset(self::$processedWebhooks[$this->webhookId])) {
                $result = self::$processedWebhooks[$this->webhookId];
                $result['cached'] = true;
                return $result;
            }

            // Validate URL
            if (empty($this->url)) {
                return [
                    'success' => false,
                    'message' => 'Webhook URL not configured'
                ];
            }

            // Validate method
            $method = strtoupper($this->method);
            if (!in_array($method, ['GET', 'POST', 'PUT'])) {
                $method = 'POST';
            }

            // Prepare data for webhook
            $data = [
                $this->fieldName => $this->email,
                'timestamp' => time(),
                'source' => 'fluent_player'
            ];

            // Add webhook ID to data if available
            if (!empty($this->webhookId)) {
                $data['webhook_id'] = $this->webhookId;
            }

            $data = apply_filters('fluent_player/webhook_data', $data, $this->email);

            // Process headers
            $customHeaders = [];
            if (!empty($this->headers) && is_array($this->headers)) {
                foreach ($this->headers as $header) {
                    $headerName = Arr::get($header, 'name');
                    if ($headerName && isset($header['value'])) {
                        $headerName = Str::replace(' ', '-', $headerName);
                        if ($headerName = Str::trim($headerName, '-')) {
                            $customHeaders[$headerName] = $header['value'];
                        }
                    }
                }
            }

            $customHeaders = apply_filters('fluent_player/webhook_headers', $customHeaders, $this->email);

            $result = $this->makeRequest($this->url, $data, $method, $customHeaders);

            // Cache the result for this webhook ID to prevent duplicates
            if (!empty($this->webhookId)) {
                self::$processedWebhooks[$this->webhookId] = $result;
            }

            return $result;
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
}
