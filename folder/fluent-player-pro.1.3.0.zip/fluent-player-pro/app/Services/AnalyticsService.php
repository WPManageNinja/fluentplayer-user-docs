<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayerPro\App\Models\Visit;
use FluentPlayer\App\App;
use FluentPlayer\App\Models\Media;
use FluentPlayer\App\Utils\Browser\Browser;
use FluentPlayer\Framework\Database\Orm\Builder;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Support\Collection;

class AnalyticsService
{
    /**
     * Resolve the current request's visitor context (ip, browser, device,
     * country). Shared by the analytics beacon and the progression coverage
     * path so a Visit persists the same metadata shape whichever seam wrote it.
     *
     * @return array{ip_address: string, browser: string, device: string, country: string|null}
     */
    public static function collectVisitorContext()
    {
        $browser = new Browser();
        $ipAddress = App::make()->request->getIp();

        return [
            'ip_address' => $ipAddress,
            'browser'    => $browser->getBrowser(),
            'device'     => $browser->getPlatform(),
            'country'    => self::getCountryCode($ipAddress),
        ];
    }

    /**
     * Get country code from request headers or IP address
     * Priority:  Custom hook > CDN headers
     *
     * @param string|null $ipAddress
     * @return string|null 2-letter ISO country code
     */
    public static function getCountryCode($ipAddress = null)
    {
        $country = apply_filters('fluent_player/get_country_code_by_ip', null, $ipAddress); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Base plugin hook
        if ($country && strlen($country) === 2 && ctype_alpha($country)) {
            return $country;
        }
        
        
        // Check Cloudflare header (most common)
        if (isset($_SERVER['HTTP_CF_IPCOUNTRY'])) {
            $country = strtoupper(sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_IPCOUNTRY'])));
            if (strlen($country) === 2 && ctype_alpha($country)) {
                return $country;
            }
        }

        // Check AWS CloudFront header
        if (isset($_SERVER['HTTP_CLOUDFRONT_VIEWER_COUNTRY'])) {
            $country = strtoupper(sanitize_text_field(wp_unslash($_SERVER['HTTP_CLOUDFRONT_VIEWER_COUNTRY'])));
            if (strlen($country) === 2 && ctype_alpha($country)) {
                return $country;
            }
        }

        //Check other common CDN headers
        $headers = [
            'HTTP_X_COUNTRY_CODE',
            'HTTP_X_CLIENT_COUNTRY',
            'HTTP_X_GEOIP_COUNTRY'
        ];

        foreach ($headers as $header) {
            if (isset($_SERVER[$header])) {
                $country = strtoupper(sanitize_text_field(wp_unslash($_SERVER[$header])));
                if (strlen($country) === 2 && ctype_alpha($country)) {
                    return $country;
                }
            }
        }

        return null; // Unknown
    }

    /**
     * Record a video visit
     *
     * @param int $mediaId
     * @param int|null $userId
     * @param string|null $ipAddress
     * @param string|null $browser
     * @param string|null $device
     * @param float $duration
     * @param string|null $country
     * @param int $percentage 0-100 rounded watch percentage
     * @return \FluentPlayerPro\App\Models\Visit
     */
    public static function recordVisit($mediaId, $userId, $ipAddress, $browser, $device, $duration, $country = null, $percentage = 0)
    {
        // Store NULL instead of 0 for anonymous users
        $userId = $userId ?: null;

        return self::upsertDailyVisit($mediaId, $userId, $ipAddress, (int) $percentage, (float) $duration, [
            'browser' => $browser,
            'device'  => $device,
            'country' => $country,
        ]);
    }

    /**
     * Record server-authoritative watched coverage (from the progression flow)
     * into the same per-user daily Visit row analytics uses. Gated on analytics
     * being enabled; the keep-max upsert means the trustworthy value wins over a
     * client-reported one. Login-only (per-user).
     */
    public static function recordCoverage($mediaId, $userId, $duration, $percentage)
    {
        if (!$userId) {
            return null;
        }
        $settings = \FluentPlayer\App\Services\SettingsService::getSettings();
        if (!Arr::get($settings, 'analytics.enabled', false)) {
            return null;
        }

        $context = self::collectVisitorContext();

        return self::upsertDailyVisit($mediaId, (int) $userId, $context['ip_address'], (int) $percentage, (float) $duration, [
            'browser' => $context['browser'],
            'device'  => $context['device'],
            'country' => $context['country'],
        ]);
    }

    /**
     * Find today's Visit for this user (or IP when anonymous) and keep the
     * highest watched percentage; create it if absent. One row per user/media
     * per day. Shared by recordVisit() and recordCoverage().
     */
    private static function upsertDailyVisit($mediaId, $userId, $ipAddress, $percentage, $duration, array $extra = [])
    {
        // Range comparison instead of whereDate() for better index usage.
        $now = current_time('timestamp');
        $today = wp_date('Y-m-d', $now);
        $tomorrow = wp_date('Y-m-d', $now + DAY_IN_SECONDS);

        $existingVisit = Visit::where('media_id', $mediaId)
            ->where(function ($query) use ($userId, $ipAddress) {
                if ($userId) {
                    $query->where('user_id', $userId);
                } else {
                    $query->where('ip_address', $ipAddress);
                }
            })
            ->where('created_at', '>=', $today . ' 00:00:00')
            ->where('created_at', '<', $tomorrow . ' 00:00:00')
            ->first();

        if (isset($existingVisit->id)) {
            // Watch time and completion percentage are independent: a later session
            // can accumulate more watch time while reaching a lower percentage (e.g.
            // a re-watch that rewound). Always keep the longer duration; only gate
            // the percentage write on it actually improving.
            $keptDuration = max((float) $existingVisit->duration, (float) $duration);

            if ($percentage <= (int) $existingVisit->percentage) {
                if ($keptDuration > (float) $existingVisit->duration) {
                    $existingVisit->update([
                        'duration'   => $keptDuration,
                        'updated_at' => current_time('mysql'),
                    ]);
                }
                return $existingVisit;
            }

            $existingVisit->update([
                'duration'   => $keptDuration,
                'percentage' => $percentage,
                'updated_at' => current_time('mysql'),
            ]);
            return $existingVisit;
        }

        return Visit::create(array_merge($extra, [
            'media_id'   => $mediaId,
            'user_id'    => $userId,
            'ip_address' => $ipAddress,
            'duration'   => $duration,
            'percentage' => $percentage,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ]));
    }

    /**
     * Get total views for a media
     *
     * @param int $mediaId
     * @param string|null $startDate
     * @param string|null $endDate
     * @return int
     */
    public static function getTotalViews($mediaId = null, $startDate = null, $endDate = null)
    {
        $query = Visit::query();

        if ($mediaId !== null && $mediaId !== '') {
            $query->where('media_id', (int) $mediaId);
        }
        self::applyDateRange($query, $startDate, $endDate);
        return $query->count('id');
    }

    /**
     * Calculate trend data (percentage change between current and previous period)
     *
     * @param float $currentValue Current period value
     * @param float $previousValue Previous period value
     * @return array ['change' => float, 'is_positive' => bool, 'percentage' => float]
     */
    public static function getTrendData($currentValue, $previousValue)
    {
        if ($previousValue == 0) {
            if ($currentValue > 0) {
                return [
                    'change' => 100,
                    'is_positive' => true,
                    'percentage' => 100.0
                ];
            }
            return [
                'change' => 0,
                'is_positive' => false,
                'percentage' => 0.0
            ];
        }

        // Calculate percentage change: ((current - previous) / previous) * 100
        $percentageChange = (($currentValue - $previousValue) / $previousValue) * 100;

        return [
            'change' => round($percentageChange, 2),
            'is_positive' => $percentageChange >= 0,
            'percentage' => round(abs($percentageChange), 2)
        ];
    }

    /**
     * Apply start_date / end_date filters to a Visit query.
     *
     * @param \FluentPlayer\Framework\Database\Orm\Builder $query
     * @param string|null $startDate
     * @param string|null $endDate
     * @return \FluentPlayer\Framework\Database\Orm\Builder
     */
    protected static function applyDateRange($query, $startDate, $endDate)
    {
        if ($startDate) {
            $query->where('created_at', '>=', $startDate . ' 00:00:00');
        }
        if ($endDate) {
            $query->where('created_at', '<=', $endDate . ' 23:59:59');
        }
        return $query;
    }

    /**
     * Get total watch time for a media
     *
     * @param int $mediaId
     * @param string|null $startDate
     * @param string|null $endDate
     * @return float
     */
    public static function getTotalWatchTime($mediaId = null, $startDate = null, $endDate = null)
    {
        $query = Visit::query();

        if ($mediaId) {
            $query->where('media_id', $mediaId);
        }
        self::applyDateRange($query, $startDate, $endDate);
        $sum = $query->sum('duration') ?: 0;

        return $sum;
    }

    /**
     * Get top videos by views
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @param int $limit
     * @return \FluentPlayer\Framework\Database\Orm\Builder[]|Collection
     */
    public static function getTopVideos($startDate = null, $endDate = null, $limit = 5)
    {
        $query = Visit::selectRaw('media_id, COUNT(*) as views, SUM(duration) as total_watch_time, AVG(percentage) as avg_percentage')
            ->groupBy('media_id')
            ->orderBy('views', 'DESC')
            ->limit($limit);
        self::applyDateRange($query, $startDate, $endDate);
        return $query->get();
    }

    /**
     * Get top users with primary country/device and WordPress display data for dashboard.
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @param int $limit
     * @return array<int, array> Each item: user_id, display_name, avatar_url, location, device, views, total_watch_time, average_watch_time
     */
    public static function getTopUsers($startDate, $endDate, $limit = 10)
    {
        $query = Visit::selectRaw('user_id, COUNT(*) as views, SUM(duration) as total_watch_time')
            ->whereNotNull('user_id')
            ->groupBy('user_id')
            ->orderBy('total_watch_time', 'DESC')
            ->limit($limit);
        self::applyDateRange($query, $startDate, $endDate);
        $topUsers = $query->get();
        if ($topUsers->isEmpty()) {
            return [];
        }

        $userIds = $topUsers->pluck('user_id')->all();
        $locationDeviceByUser = self::getPrimaryCountryAndDeviceForUsers($userIds, $startDate, $endDate);
        return self::buildTopUsersResult($topUsers, $locationDeviceByUser);
    }

    /**
     * Get top users for a specific video (by watch time)
     *
     * @param int $mediaId
     * @param string|null $startDate
     * @param string|null $endDate
     * @param int $limit
     * @return array<int, array> Each item: user_id, display_name, avatar_url, location, device, views, total_watch_time, average_watch_time, user_view_url
     */
    public static function getVideoTopViewers($mediaId, $startDate = null, $endDate = null, $limit = 10)
    {
        $query = Visit::selectRaw('user_id, COUNT(*) as views, SUM(duration) as total_watch_time')
            ->where('media_id', $mediaId)
            ->whereNotNull('user_id')
            ->groupBy('user_id')
            ->orderBy('total_watch_time', 'DESC')
            ->limit($limit);
        self::applyDateRange($query, $startDate, $endDate);
        $topUsers = $query->get();
        if ($topUsers->isEmpty()) {
            return [];
        }

        $userIds = $topUsers->pluck('user_id')->all();
        $locationDeviceByUser = self::getPrimaryCountryAndDeviceForUsers($userIds, $startDate, $endDate, $mediaId);
        return self::buildTopUsersResult($topUsers, $locationDeviceByUser, true);
    }

    /**
     * Build result rows for top users: location, device, display_name, avatar_url, user_view_url, views, watch time.
     *
     * @param Collection $topUsers Collection of objects with user_id, views, total_watch_time
     * @param array<int, array{location: string, device: string}> $locationDeviceByUser
     * @param bool $useAdminUrlFallback If true, fallback user_view_url to admin user-edit when author URL is empty
     * @return array<int, array>
     */
    protected static function buildTopUsersResult($topUsers, $locationDeviceByUser, $useAdminUrlFallback = false)
    {
        $result = [];
        foreach ($topUsers as $user) {
            $uid = (int) $user->user_id;
            $device = Arr::get($locationDeviceByUser, $uid . '.device', 'Unknown');
            $location = Arr::get($locationDeviceByUser, $uid . '.location', 'Unknown');
            $userData = function_exists('get_userdata') ? get_userdata($user->user_id) : null;
            $userDataArray = $userData && isset($userData->data) ? (array) $userData->data : [];
            $displayName = Arr::get($userDataArray, 'display_name', "User #{$user->user_id}");
            $userViewUrl = function_exists('get_author_posts_url') ? get_author_posts_url((int) $user->user_id) : '';
            if ($useAdminUrlFallback && $userViewUrl === '' && function_exists('admin_url')) {
                $userViewUrl = admin_url('user-edit.php?user_id=' . (int) $user->user_id);
            }
            $avatarUrl = (function_exists('get_avatar_url')) ? get_avatar_url($user->user_id, ['size' => 40]) : '';
            $result[] = [
                'user_id'            => $user->user_id,
                'display_name'       => $displayName,
                'avatar_url'         => $avatarUrl,
                'user_view_url'      => $userViewUrl,
                'location'           => $location,
                'device'             => $device,
                'views'              => $user->views,
                'total_watch_time'   => $user->total_watch_time,
                'average_watch_time' => $user->views > 0 ? $user->total_watch_time / $user->views : 0,
            ];
        }
        return $result;
    }

    /**
     * Get primary (most frequent) country and device per user. Optional $mediaId scopes to one media.
     *
     * @param int[] $userIds
     * @param string|null $startDate
     * @param string|null $endDate
     * @param int|null $mediaId Optional; when set, only visits for this media are considered.
     * @return array<int, array{location: string, device: string}>
     */
    protected static function getPrimaryCountryAndDeviceForUsers($userIds, $startDate, $endDate, $mediaId = null)
    {
        $out = [];
        if (empty($userIds)) {
            return $out;
        }
        $userIds = array_map('intval', array_values($userIds));

        $countryQuery = Visit::selectRaw('user_id, country, COUNT(*) as count')
            ->whereIn('user_id', $userIds)
            ->whereNotNull('country')
            ->where('country', '!=', '');
        if ($mediaId && ($mediaId = intval($mediaId))) {
            $countryQuery->where('media_id', $mediaId);
        }
        self::applyDateRange($countryQuery, $startDate, $endDate);
        $countryRows = $countryQuery->groupBy('user_id', 'country')
            ->orderBy('user_id')
            ->orderBy('count', 'DESC')
            ->get();
        $countryByUser = self::mapFirstGroupedValueByUser($countryRows, 'country');

        $deviceQuery = Visit::selectRaw('user_id, device, COUNT(*) as count')
            ->whereIn('user_id', $userIds)
            ->whereNotNull('device')
            ->where('device', '!=', '');
        if ($mediaId && ($mediaId = intval($mediaId))) {
            $deviceQuery->where('media_id', $mediaId);
        }
        self::applyDateRange($deviceQuery, $startDate, $endDate);
        $deviceRows = $deviceQuery->groupBy('user_id', 'device')
            ->orderBy('user_id')
            ->orderBy('count', 'DESC')
            ->get();
        $deviceByUser = self::mapFirstGroupedValueByUser($deviceRows, 'device');

        $countryMap = self::getCountryNameMap();
        foreach ($userIds as $uid) {
            $countryCode = Arr::get($countryByUser, $uid);
            $out[$uid] = [
                'location' => $countryCode ? Arr::get($countryMap, $countryCode) : 'Unknown',
                'device'   => self::normalizeDeviceLabel(Arr::get($deviceByUser, $uid, 'Unknown')),
            ];
        }
        return $out;
    }

    /**
     * Convert grouped rows ordered by highest count first into a per-user map.
     *
     * The analytics queries sort each user's grouped rows by count DESC. We must
     * keep the first value for each user, not the last one, otherwise rarer
     * country/device values overwrite the dominant one.
     *
     * @param Collection $rows
     * @param string $valueKey
     * @return array<int|string, string>
     */
    protected static function mapFirstGroupedValueByUser($rows, $valueKey)
    {
        $mapped = [];

        foreach ($rows as $row) {
            $userId = self::getRowValue($row, 'user_id');
            if ($userId === null || array_key_exists($userId, $mapped)) {
                continue;
            }

            $mapped[$userId] = self::getRowValue($row, $valueKey);
        }

        return $mapped;
    }

    /**
     * Read a field from grouped ORM rows that may be arrays or objects.
     *
     * @param mixed $row
     * @param string $key
     * @return mixed|null
     */
    protected static function getRowValue($row, $key)
    {
        if (is_array($row)) {
            return Arr::get($row, $key);
        }

        if (is_object($row) && isset($row->{$key})) {
            return $row->{$key};
        }

        return null;
    }

    /**
     * Normalize device string to Mobile, Tablet, or Desktop
     *
     * @param string $device
     * @return string
     */
    protected static function normalizeDeviceLabel($device)
    {
        $d = strtolower((string) $device);
        if ($d === '' || $d === 'mobile' || strpos($d, 'android') !== false || strpos($d, 'iphone') !== false) {
            return 'Mobile';
        }
        if (strpos($d, 'tablet') !== false || strpos($d, 'ipad') !== false) {
            return 'Tablet';
        }
        if (strpos($d, 'desktop') !== false || strpos($d, 'windows') !== false || strpos($d, 'mac') !== false || $d === 'pc' || $d === 'apple') {
            return 'Laptop';
        }
        return ucfirst($d) ?: $device;
    }

    /**
     * Country code to display name map (shared by location breakdown and top users)
     *
     * @return array<string, string>
     */
    protected static function getCountryNameMap()
    {
        return [
            'US' => 'United States',
            'GB' => 'United Kingdom',
            'CA' => 'Canada',
            'DE' => 'Germany',
            'FR' => 'France',
            'AU' => 'Australia',
            'IN' => 'India',
            'BR' => 'Brazil',
            'MX' => 'Mexico',
            'IT' => 'Italy',
            'ES' => 'Spain',
            'NL' => 'Netherlands',
            'SE' => 'Sweden',
            'NO' => 'Norway',
            'DK' => 'Denmark',
            'FI' => 'Finland',
            'PL' => 'Poland',
            'JP' => 'Japan',
            'CN' => 'China',
            'KR' => 'South Korea',
            'SG' => 'Singapore',
            'NZ' => 'New Zealand',
            'IE' => 'Ireland',
            'BE' => 'Belgium',
            'CH' => 'Switzerland',
            'AT' => 'Austria',
            'PT' => 'Portugal',
            'GR' => 'Greece',
            'TR' => 'Turkey',
            'RU' => 'Russia',
            'ZA' => 'South Africa',
            'AE' => 'UAE',
            'SA' => 'Saudi Arabia',
            'AR' => 'Argentina',
            'CL' => 'Chile',
            'CO' => 'Colombia',
            'PE' => 'Peru',
            'VE' => 'Venezuela',
            'PH' => 'Philippines',
            'TH' => 'Thailand',
            'VN' => 'Vietnam',
            'ID' => 'Indonesia',
            'MY' => 'Malaysia',
            'HK' => 'Hong Kong',
            'TW' => 'Taiwan',
        ];
    }

    /**
     * Compute previous period dates (same length as current, or default 7 days).
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array{0: string|null, 1: string|null} [previousStartDate, previousEndDate]
     */
    protected static function getPreviousPeriodDates($startDate, $endDate)
    {
        $periodLength = null;
        if ($startDate && $endDate) {
            $periodLength = strtotime($endDate) - strtotime($startDate);
            if ($periodLength === 0) {
                $periodLength = 86400;
            }
        }
        if ($startDate && $endDate && $periodLength) {
            $previousEndDate = gmdate('Y-m-d', strtotime($startDate . ' -1 day'));
            $previousStartDate = gmdate('Y-m-d', strtotime($previousEndDate . ' -' . $periodLength . ' seconds'));
        } else {
            $previousEndDate = $startDate ? gmdate('Y-m-d', strtotime($startDate . ' -1 day')) : gmdate('Y-m-d', strtotime('-8 days'));
            $previousStartDate = $startDate ? gmdate('Y-m-d', strtotime($startDate . ' -8 days')) : gmdate('Y-m-d', strtotime('-14 days'));
        }
        return [$previousStartDate, $previousEndDate];
    }

    /**
     * Current and previous period Visit aggregates (views, total_watch_time).
     * Optional scope by media_id or user_id; optional unique_viewers for dashboard.
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @param string|null $prevStartDate
     * @param string|null $prevEndDate
     * @param array{media_id?: int|null, user_id?: int|null, include_unique_viewers?: bool} $options
     * @return array{views: int, total_watch_time: float, previous_views: int, previous_total_watch_time: float, unique_viewers?: int, previous_unique_viewers?: int}
     */
    protected static function getVisitAggregatesCurrentAndPrevious($startDate, $endDate, $prevStartDate, $prevEndDate, $options = [])
    {
        if ($startDate === null) {
            $startDate = gmdate('Y-m-d', strtotime('-7 days'));
        }
        if ($endDate === null) {
            $endDate = gmdate('Y-m-d');
        }
        if ($prevStartDate === null || $prevEndDate === null) {
            [$prevStartDate, $prevEndDate] = self::getPreviousPeriodDates($startDate, $endDate);
        }
        $mediaId = Arr::get($options, 'media_id');
        $userId = Arr::get($options, 'user_id');

        $query = Visit::query();
        if (($mediaId = absint($mediaId))) {
            $query->where('media_id', $mediaId);
        }
        if (($userId = absint($userId))) {
            $query->where('user_id', $userId);
        }
        $query->where(function ($q) use ($startDate, $endDate, $prevStartDate, $prevEndDate) {
            $q->where(function ($q2) use ($startDate, $endDate) {
                if ($startDate) {
                    $q2->where('created_at', '>=', $startDate . ' 00:00:00');
                }
                if ($endDate) {
                    $q2->where('created_at', '<=', $endDate . ' 23:59:59');
                }
            })->orWhere(function ($q2) use ($prevStartDate, $prevEndDate) {
                if ($prevStartDate) {
                    $q2->where('created_at', '>=', $prevStartDate . ' 00:00:00');
                }
                if ($prevEndDate) {
                    $q2->where('created_at', '<=', $prevEndDate . ' 23:59:59');
                }
            });
        });

        $startDateTime = $startDate . ' 00:00:00';
        $endDateTime = $endDate . ' 23:59:59';
        $prevStartDateTime = $prevStartDate . ' 00:00:00';
        $prevEndDateTime = $prevEndDate . ' 23:59:59';

        if (Arr::isTrue($options, 'include_unique_viewers')) {
            $row = $query->selectRaw(
                "SUM(CASE WHEN (created_at >= ? AND created_at <= ?) THEN 1 ELSE 0 END) as views,
                 SUM(CASE WHEN (created_at >= ? AND created_at <= ?) THEN COALESCE(duration, 0) ELSE 0 END) as total_watch_time,
                 AVG(CASE WHEN (created_at >= ? AND created_at <= ?) THEN percentage END) as avg_completion,
                 SUM(CASE WHEN (created_at >= ? AND created_at <= ?) THEN 1 ELSE 0 END) as previous_views,
                 SUM(CASE WHEN (created_at >= ? AND created_at <= ?) THEN COALESCE(duration, 0) ELSE 0 END) as previous_total_watch_time,
                 AVG(CASE WHEN (created_at >= ? AND created_at <= ?) THEN percentage END) as previous_avg_completion,
                 COUNT(DISTINCT CASE
                     WHEN (created_at >= ? AND created_at <= ?) AND user_id IS NOT NULL AND user_id != 0
                         THEN CONCAT('user:', user_id)
                     WHEN (created_at >= ? AND created_at <= ?) AND (user_id IS NULL OR user_id = 0) AND ip_address IS NOT NULL AND ip_address != ''
                         THEN CONCAT('ip:', ip_address)
                 END) as unique_viewers,
                 COUNT(DISTINCT CASE
                     WHEN (created_at >= ? AND created_at <= ?) AND user_id IS NOT NULL AND user_id != 0
                         THEN CONCAT('user:', user_id)
                     WHEN (created_at >= ? AND created_at <= ?) AND (user_id IS NULL OR user_id = 0) AND ip_address IS NOT NULL AND ip_address != ''
                         THEN CONCAT('ip:', ip_address)
                 END) as previous_unique_viewers",
                [
                    $startDateTime, $endDateTime,
                    $startDateTime, $endDateTime,
                    $startDateTime, $endDateTime,
                    $prevStartDateTime, $prevEndDateTime,
                    $prevStartDateTime, $prevEndDateTime,
                    $prevStartDateTime, $prevEndDateTime,
                    $startDateTime, $endDateTime,
                    $startDateTime, $endDateTime,
                    $prevStartDateTime, $prevEndDateTime,
                    $prevStartDateTime, $prevEndDateTime,
                ]
            )->first();
            return [
                'views'                     => (int) ($row->views ?? 0),
                'total_watch_time'          => (float) ($row->total_watch_time ?? 0),
                'avg_completion'            => (float) ($row->avg_completion ?? 0),
                'previous_views'            => (int) ($row->previous_views ?? 0),
                'previous_total_watch_time' => (float) ($row->previous_total_watch_time ?? 0),
                'previous_avg_completion'   => (float) ($row->previous_avg_completion ?? 0),
                'unique_viewers'            => (int) ($row->unique_viewers ?? 0),
                'previous_unique_viewers'   => (int) ($row->previous_unique_viewers ?? 0),
            ];
        }

        $row = $query->selectRaw(
            "SUM(CASE WHEN (created_at >= ? AND created_at <= ?) THEN 1 ELSE 0 END) as views,
             SUM(CASE WHEN (created_at >= ? AND created_at <= ?) THEN COALESCE(duration, 0) ELSE 0 END) as total_watch_time,
             AVG(CASE WHEN (created_at >= ? AND created_at <= ?) THEN percentage END) as avg_completion,
             SUM(CASE WHEN (created_at >= ? AND created_at <= ?) THEN 1 ELSE 0 END) as previous_views,
             SUM(CASE WHEN (created_at >= ? AND created_at <= ?) THEN COALESCE(duration, 0) ELSE 0 END) as previous_total_watch_time,
             AVG(CASE WHEN (created_at >= ? AND created_at <= ?) THEN percentage END) as previous_avg_completion",
            [
                $startDateTime, $endDateTime,
                $startDateTime, $endDateTime,
                $startDateTime, $endDateTime,
                $prevStartDateTime, $prevEndDateTime,
                $prevStartDateTime, $prevEndDateTime,
                $prevStartDateTime, $prevEndDateTime,
            ]
        )->first();
        return [
            'views'                     => (int) ($row->views ?? 0),
            'total_watch_time'          => (float) ($row->total_watch_time ?? 0),
            'avg_completion'            => (float) ($row->avg_completion ?? 0),
            'previous_views'            => (int) ($row->previous_views ?? 0),
            'previous_total_watch_time' => (float) ($row->previous_total_watch_time ?? 0),
            'previous_avg_completion'   => (float) ($row->previous_avg_completion ?? 0),
        ];
    }

    /**
     * Dashboard current and previous period aggregates (views, watch time, unique viewers).
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @param string|null $prevStartDate
     * @param string|null $prevEndDate
     * @return array{total_views: int, total_watch_time: float, unique_viewers: int, previous_total_views: int, previous_total_watch_time: float, previous_unique_viewers: int}
     */
    protected static function getDashboardAggregates($startDate, $endDate, $prevStartDate, $prevEndDate)
    {
        $agg = self::getVisitAggregatesCurrentAndPrevious($startDate, $endDate, $prevStartDate, $prevEndDate, ['include_unique_viewers' => true]);
        return [
            'total_views'               => $agg['views'],
            'total_watch_time'          => $agg['total_watch_time'],
            'avg_completion'            => $agg['avg_completion'],
            'unique_viewers'            => $agg['unique_viewers'],
            'previous_total_views'      => $agg['previous_views'],
            'previous_total_watch_time' => $agg['previous_total_watch_time'],
            'previous_avg_completion'   => $agg['previous_avg_completion'],
            'previous_unique_viewers'   => $agg['previous_unique_viewers'],
        ];
    }

    /**
     * Get dashboard stats with trends (completion rate, plays, watch time, etc.)
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array Stats with completion rate and trends
     */
    public static function getDashboardStatsWithTrends($startDate = null, $endDate = null)
    {
        [$previousStartDate, $previousEndDate] = self::getPreviousPeriodDates($startDate, $endDate);
        $agg = self::getDashboardAggregates($startDate, $endDate, $previousStartDate, $previousEndDate);
        $totalPlays = $agg['total_views'];
        $totalWatchTime = $agg['total_watch_time'];
        $uniqueViewers = $agg['unique_viewers'];
        $previousTotalPlays = $agg['previous_total_views'];
        $previousTotalWatchTime = $agg['previous_total_watch_time'];
        $previousUniqueViewers = $agg['previous_unique_viewers'];

        $completionRate = $agg['avg_completion'];
        $previousCompletionRate = $agg['previous_avg_completion'];

        $avgWatchTime = $totalPlays > 0 ? $totalWatchTime / $totalPlays : 0;
        $previousAvgWatchTime = $previousTotalPlays > 0 ? $previousTotalWatchTime / $previousTotalPlays : 0;

        // Calculate trends
        $totalPlaysTrend = self::getTrendData($totalPlays, $previousTotalPlays);
        $uniqueViewersTrend = self::getTrendData($uniqueViewers, $previousUniqueViewers);
        $avgWatchTimeTrend = self::getTrendData($avgWatchTime, $previousAvgWatchTime);
        $completionRateTrend = self::getTrendData($completionRate, $previousCompletionRate);

        return [
            'total_plays' => (int)$totalPlays,
            'unique_viewers' => (int)$uniqueViewers,
            'avg_watch_time' => round($avgWatchTime, 2),
            'total_watch_time' => round($totalWatchTime, 2),
            'completion_rate' => round($completionRate, 2),
            'total_plays_change' => $totalPlaysTrend['change'],
            'total_plays_is_positive' => $totalPlaysTrend['is_positive'],
            'unique_viewers_change' => $uniqueViewersTrend['change'],
            'unique_viewers_is_positive' => $uniqueViewersTrend['is_positive'],
            'avg_watch_time_change' => $avgWatchTimeTrend['change'],
            'avg_watch_time_is_positive' => $avgWatchTimeTrend['is_positive'],
            'completion_rate_change' => $completionRateTrend['change'],
            'completion_rate_is_positive' => $completionRateTrend['is_positive'],
            'start_date' => $startDate,
            'end_date' => $endDate
        ];
    }

    /**
     * Get video-specific stats with period-over-period trends.
     *
     * @param int $mediaId
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array
     */
    public static function getVideoStats($mediaId, $startDate = null, $endDate = null)
    {
        [$previousStartDate, $previousEndDate] = self::getPreviousPeriodDates($startDate, $endDate);
        $agg = self::getVisitAggregatesCurrentAndPrevious($startDate, $endDate, $previousStartDate, $previousEndDate, ['media_id' => $mediaId]);
        $views = $agg['views'];
        $totalWatchTime = $agg['total_watch_time'];
        $averageWatchTime = $views > 0 ? $totalWatchTime / $views : 0;
        $previousViews = $agg['previous_views'];
        $previousTotalWatchTime = $agg['previous_total_watch_time'];
        $previousAverageWatchTime = $previousViews > 0 ? $previousTotalWatchTime / $previousViews : 0;

        $completionRate = $agg['avg_completion'];
        $previousCompletionRate = $agg['previous_avg_completion'];

        $viewsTrend = self::getTrendData($views, $previousViews);
        $averageWatchTimeTrend = self::getTrendData($averageWatchTime, $previousAverageWatchTime);
        $totalWatchTimeTrend = self::getTrendData($totalWatchTime, $previousTotalWatchTime);
        $completionRateTrend = self::getTrendData($completionRate, $previousCompletionRate);

        return [
            'views' => $views,
            'total_watch_time' => $totalWatchTime,
            'average_watch_time' => (float) $averageWatchTime,
            'completion_rate' => round($completionRate, 2),
            'views_change' => $viewsTrend['change'],
            'views_is_positive' => $viewsTrend['is_positive'],
            'average_watch_time_change' => $averageWatchTimeTrend['change'],
            'average_watch_time_is_positive' => $averageWatchTimeTrend['is_positive'],
            'total_watch_time_change' => $totalWatchTimeTrend['change'],
            'total_watch_time_is_positive' => $totalWatchTimeTrend['is_positive'],
            'completion_rate_change' => $completionRateTrend['change'],
            'completion_rate_is_positive' => $completionRateTrend['is_positive'],
            'start_date' => $startDate,
            'end_date' => $endDate
        ];
    }

    /**
     * Get unique users count
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @return int
     */
    public static function getUniqueUsers($startDate = null, $endDate = null)
    {
        $query = Visit::query()
            ->whereNotNull('user_id')
            ->distinct('user_id');
        self::applyDateRange($query, $startDate, $endDate);
        return $query->count('user_id');
    }

    /**
     * Get video retention data.
     *
     * @param int $mediaId
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array
     */
    public static function getVideoRetention($mediaId, $startDate = null, $endDate = null)
    {
        $settings = Media::getMediaSettings($mediaId);
        $duration = (float) Arr::get($settings, 'duration', 0);

        if ($duration <= 0) {
            return [
                'average_percentage' => 0,
                'data'               => [],
                'duration'           => 0
            ];
        }

        $visitQuery = Visit::query()->where('media_id', $mediaId);
        self::applyDateRange($visitQuery, $startDate, $endDate);
        $row = $visitQuery->selectRaw('COUNT(*) as views, AVG(percentage) as avg_percentage')->first();
        $totalViews = (int) ($row->views ?? 0);

        if ($totalViews == 0) {
            return [
                'average_percentage' => 0,
                'data'               => [],
                'duration'           => (float) $duration
            ];
        }

        $averagePercentage = min(100, (float) ($row->avg_percentage ?? 0));

        $retentionData = [];
        $totalPoints = 10;
        
        for ($i = 0; $i < $totalPoints; $i++) {
            $positionPercentage = ($i + 1) * (100 / $totalPoints);
            $dropFactor = $i / $totalPoints;
            $retentionPercentage = 100 - ((100 - $averagePercentage) * $dropFactor * 1.5);
            $retentionPercentage = max(0, $retentionPercentage);

            $estimatedSeconds = ($positionPercentage / 100) * $duration * ($retentionPercentage / 100);
            $timeSeconds = ($positionPercentage / 100) * $duration;
            $retentionData[] = [
                'time'               => round($positionPercentage, 1),
                'retention'          => round($retentionPercentage, 1),
                'estimated_seconds'  => round($estimatedSeconds, 1),
                'time_seconds'       => round($timeSeconds, 1)
            ];
        }

        return [
            'average_percentage' => round($averagePercentage, 1),
            'data'               => $retentionData,
            'duration'           => (float) $duration
        ];
    }

    /**
     * Get aggregated retention across all (top 50) videos: view-weighted average by position %.
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @param int $maxVideos
     * @return array{data: array, duration: float}
     */
    public static function getDashboardRetention($startDate, $endDate, $maxVideos = 50)
    {
        $topVideos = self::getTopVideos($startDate, $endDate, $maxVideos);
        
        if ($topVideos->isEmpty()) {
            return ['data' => [], 'duration' => 0];
        }
        $mediaIds = $topVideos->pluck('media_id')->map(function ($id) {
            return (int) $id;
        })->unique()->values()->all();
        
        Media::batchLoadMediaSettings($mediaIds);
        $totalPoints = 10;
        $positionPercentages = [];
        for ($i = 0; $i < $totalPoints; $i++) {
            $positionPercentages[$i] = ($i + 1) * (100 / $totalPoints);
        }
        $perPositionWeightedSum = array_fill(0, $totalPoints, 0.0);
        $perPositionWeight = array_fill(0, $totalPoints, 0);
        $durationSum = 0.0;
        $durationCount = 0;
        foreach ($topVideos as $row) {
            $views = (int) $row->views;
            if ($views <= 0) {
                continue;
            }
            $settings = Media::getMediaSettings((int) $row->media_id);
            $duration = (float) Arr::get($settings, 'duration', 0);
            if ($duration <= 0) {
                continue;
            }
            $durationSum += $duration;
            $durationCount++;
            $averagePercentage = min(100.0, (float) ($row->avg_percentage ?? 0));
            for ($i = 0; $i < $totalPoints; $i++) {
                $dropFactor = $i / $totalPoints;
                $retentionPercentage = 100 - ((100 - $averagePercentage) * $dropFactor * 1.5);
                $retentionPercentage = max(0, $retentionPercentage);
                $perPositionWeightedSum[$i] += $retentionPercentage * $views;
                $perPositionWeight[$i] += $views;
            }
        }
        if ($durationCount === 0) {
            return ['data' => [], 'duration' => 0];
        }
        $averageDuration = $durationSum / $durationCount;
        $retentionData = [];
        for ($i = 0; $i < $totalPoints; $i++) {
            $positionPercentage = $positionPercentages[$i];
            $weight = $perPositionWeight[$i];
            $retention = $weight > 0 ? $perPositionWeightedSum[$i] / $weight : 0;
            $timeSeconds = ($positionPercentage / 100) * $averageDuration;
            $estimatedSeconds = ($positionPercentage / 100) * $averageDuration * ($retention / 100);
            $retentionData[] = [
                'time'               => round($positionPercentage, 1),
                'retention'          => round($retention, 1),
                'estimated_seconds'  => round($estimatedSeconds, 1),
                'time_seconds'       => round($timeSeconds, 1)
            ];
        }
        return [
            'data'     => $retentionData,
            'duration' => round($averageDuration, 1)
        ];
    }

    /**
     * Get aggregated retention for a user (across their top videos in date range).
     * Same shape as getRetention: { data: array, duration: float }.
     *
     * @param int $userId
     * @param string|null $startDate
     * @param string|null $endDate
     * @param int $maxVideos
     * @return array{data: array, duration: float}
     */
    public static function getUserRetention($userId, $startDate = null, $endDate = null, $maxVideos = 50)
    {
        $topVideos = self::getUserTopVideos($userId, $startDate, $endDate, $maxVideos);

        if ($topVideos->isEmpty()) {
            return ['data' => [], 'duration' => 0];
        }
        $mediaIds = $topVideos->pluck('media_id')->map(function ($id) {
            return (int) $id;
        })->unique()->values()->all();

        Media::batchLoadMediaSettings($mediaIds);
        $totalPoints = 10;
        $positionPercentages = [];
        for ($i = 0; $i < $totalPoints; $i++) {
            $positionPercentages[$i] = ($i + 1) * (100 / $totalPoints);
        }
        $perPositionWeightedSum = array_fill(0, $totalPoints, 0.0);
        $perPositionWeight = array_fill(0, $totalPoints, 0);
        $durationSum = 0.0;
        $durationCount = 0;
        foreach ($topVideos as $row) {
            $views = (int) $row->views;
            if ($views <= 0) {
                continue;
            }
            $settings = Media::getMediaSettings((int) $row->media_id);
            $duration = (float) Arr::get($settings, 'duration', 0);
            if ($duration <= 0) {
                continue;
            }
            $durationSum += $duration;
            $durationCount++;
            $averagePercentage = min(100.0, (float) ($row->avg_percentage ?? 0));
            for ($i = 0; $i < $totalPoints; $i++) {
                $dropFactor = $i / $totalPoints;
                $retentionPercentage = 100 - ((100 - $averagePercentage) * $dropFactor * 1.5);
                $retentionPercentage = max(0, $retentionPercentage);
                $perPositionWeightedSum[$i] += $retentionPercentage * $views;
                $perPositionWeight[$i] += $views;
            }
        }
        if ($durationCount === 0) {
            return ['data' => [], 'duration' => 0];
        }
        $averageDuration = $durationSum / $durationCount;
        $retentionData = [];
        for ($i = 0; $i < $totalPoints; $i++) {
            $positionPercentage = $positionPercentages[$i];
            $weight = $perPositionWeight[$i];
            $retention = $weight > 0 ? $perPositionWeightedSum[$i] / $weight : 0;
            $timeSeconds = ($positionPercentage / 100) * $averageDuration;
            $estimatedSeconds = ($positionPercentage / 100) * $averageDuration * ($retention / 100);
            $retentionData[] = [
                'time'               => round($positionPercentage, 1),
                'retention'          => round($retention, 1),
                'estimated_seconds'  => round($estimatedSeconds, 1),
                'time_seconds'       => round($timeSeconds, 1)
            ];
        }
        return [
            'data'     => $retentionData,
            'duration' => (float) round($averageDuration, 1)
        ];
    }

    /**
     * Provider keys to display names (legend order)
     */
    protected static $providerDisplayNames = [
        'vimeo'         => 'Vimeo',
        'youtube'       => 'Youtube',
        'bunnycdn'      => 'BunnyCDN Stream',
        'bunny_storage'  => 'BunnyCDN Storage',
        'gumlet'         => 'Gumlet',
        'gumlet_live'    => 'Gumlet Live',
        'wordpress'      => 'Self Hosted',
    ];

    /**
     * Build performance-over-time series by provider from visits.
     * Granularity derived from range: <= 31 days → day, <= 92 days → week, else → month.
     *
     * @param array $visits Array of arrays with keys media_id, created_at, duration
     * @param string $startDate
     * @param string $endDate
     * @param string $metric 'plays' or 'watch_time'
     * @return array{ dates: string[], series: array }
     */
    protected static function buildSeriesByProvider($visits, $startDate, $endDate, $metric = 'plays')
    {
        $startTs = strtotime($startDate);
        $endTs = strtotime($endDate);
        $days = (int) round(($endTs - $startTs) / 86400);
        if ($days <= 31) {
            $granularity = 'day';
        } elseif ($days <= 92) {
            $granularity = 'week';
        } else {
            $granularity = 'month';
        }

        $mediaIds = [];
        foreach ($visits as $v) {
            $mid = Arr::get($v, 'media_id');
            if ($mid && !in_array($mid, $mediaIds, true)) {
                $mediaIds[] = $mid;
            }
        }
        if (!empty($mediaIds)) {
            Media::batchLoadMediaSettings($mediaIds);
        }

        $mediaToProvider = [];
        foreach ($mediaIds as $mid) {
            $settings = Media::getMediaSettings($mid);
            $provider = Arr::get($settings, 'provider', 'wordpress');
            $provider = is_string($provider) ? strtolower(trim($provider)) : 'wordpress';
            if (!isset(static::$providerDisplayNames[$provider])) {
                $provider = 'wordpress';
            }
            $mediaToProvider[$mid] = $provider;
        }

        $dates = [];
        if ($granularity === 'day') {
            $current = $startTs;
            while ($current <= $endTs) {
                $dates[] = gmdate('Y-m-d', $current);
                $current = strtotime('+1 day', $current);
            }
        } elseif ($granularity === 'week') {
            $current = strtotime('monday this week', $startTs);
            while ($current <= $endTs) {
                $dates[] = gmdate('Y-m-d', $current);
                $current = strtotime('+1 week', $current);
            }
        } else {
            $current = $startTs;
            while ($current <= $endTs) {
                $dates[] = gmdate('Y-m', $current);
                $current = strtotime('+1 month', $current);
            }
        }

        $aggregate = [];
        foreach ($dates as $d) {
            $aggregate[$d] = [];
        }

        foreach ($visits as $v) {
            $createdAt = Arr::get($v, 'created_at');
            $mediaId = Arr::get($v, 'media_id');
            $duration = (float) Arr::get($v, 'duration', 0);
            if (!$createdAt) {
                continue;
            }
            $ts = strtotime($createdAt);
            if ($granularity === 'day') {
                $bucket = gmdate('Y-m-d', $ts);
            } elseif ($granularity === 'week') {
                $bucket = gmdate('Y-m-d', strtotime('monday this week', $ts));
            } else {
                $bucket = gmdate('Y-m', $ts);
            }
            if (!isset($aggregate[$bucket])) {
                continue;
            }
            $provider = Arr::get($mediaToProvider, $mediaId, 'wordpress');
            if (!isset($aggregate[$bucket][$provider])) {
                $aggregate[$bucket][$provider] = ['count' => 0, 'duration' => 0.0];
            }
            $count = (int) Arr::get($v, '_count', 1);
            $aggregate[$bucket][$provider]['count'] += $count;
            $aggregate[$bucket][$provider]['duration'] += $duration;
        }

        $availableProviders = array_unique(array_values($mediaToProvider));
        $series = [];
        foreach ($availableProviders as $providerKey) {
            $displayName = static::$providerDisplayNames[$providerKey] ?? ucfirst(str_replace('_', ' ', $providerKey));
            $data = [];
            foreach ($dates as $d) {
                $isDuration = $metric === 'watch_time';
                $key = "{$d}.{$providerKey}";
                if ($isDuration) {
                    $key .= ".duration";
                } else {
                    $key .= ".count";
                }
                $val = Arr::get($aggregate, $key, 0);
                $data[] = $isDuration ? (float) $val : (int) $val;
            }
            $series[] = [
                'provider_key' => $providerKey,
                'name'        => $displayName,
                'data'        => $data,
            ];
        }

        return [
            'dates'  => $dates,
            'series' => $series,
        ];
    }

    /**
     * Get performance over time by provider.
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @param string $metric 'plays' or 'watch_time'
     * @param int|null $userId Optional: filter by user (user analytics).
     * @param int|null $mediaId Optional: filter by media (video analytics).
     * @return array{ dates: string[], series: array{ provider_key: string, name: string, data: float[] }[] }
     */
    public static function getPerformanceOverTime($startDate = null, $endDate = null, $metric = 'plays', $userId = null, $mediaId = null)
    {
        if (!$startDate) {
            $startDate = gmdate('Y-m-d', strtotime('-365 days'));
        }
        if (!$endDate) {
            $endDate = gmdate('Y-m-d');
        }

        // Aggregate at SQL level to avoid loading millions of rows into memory
        $visitsQuery = Visit::query()
            ->selectRaw('media_id, DATE(created_at) as visit_date, COUNT(*) as play_count, SUM(duration) as total_duration');
        if ($userId !== null) {
            $visitsQuery->where('user_id', $userId);
        }
        if ($mediaId !== null) {
            $visitsQuery->where('media_id', $mediaId);
        }
        self::applyDateRange($visitsQuery, $startDate, $endDate);
        $aggregated = $visitsQuery->groupBy('media_id', 'visit_date')->get()->toArray();

        // Convert aggregated rows back to the format buildSeriesByProvider expects
        $visits = [];
        foreach ($aggregated as $row) {
            $count = (int) Arr::get($row, 'play_count', 1);
            $duration = (float) Arr::get($row, 'total_duration', 0);
            // Create one representative row per media/date with pre-aggregated data
            $visits[] = [
                'media_id'   => Arr::get($row, 'media_id'),
                'created_at' => Arr::get($row, 'visit_date'),
                'duration'   => $duration,
                '_count'     => $count,
            ];
        }
        return self::buildSeriesByProvider($visits, $startDate, $endDate, $metric);
    }

    /**
     * Get new vs returning viewers' segmentation.
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array New and returning viewer counts with percentages
     */
    public static function getNewVsReturningViewers($startDate = null, $endDate = null)
    {
        // Use DISTINCT queries instead of loading all visits into memory
        $userQuery = Visit::query()->select('user_id')->whereNotNull('user_id')->where('user_id', '!=', 0)->distinct();
        self::applyDateRange($userQuery, $startDate, $endDate);
        $userIdsInPeriod = $userQuery->pluck('user_id')->all();

        $ipQuery = Visit::query()->select('ip_address')->where(function ($q) {
            $q->whereNull('user_id')->orWhere('user_id', 0);
        })->whereNotNull('ip_address')->where('ip_address', '!=', '')->distinct();
        self::applyDateRange($ipQuery, $startDate, $endDate);
        $ipsInPeriod = $ipQuery->pluck('ip_address')->all();

        $returningUserIds = [];
        $returningIps = [];
        if ($startDate) {
            if (!empty($userIdsInPeriod)) {
                $returningUserIds = Visit::query()
                    ->select('user_id')
                    ->whereIn('user_id', $userIdsInPeriod)
                    ->where('created_at', '<', $startDate . ' 00:00:00')
                    ->distinct()
                    ->pluck('user_id')
                    ->all();
            }
            if (!empty($ipsInPeriod)) {
                $returningIps = Visit::query()
                    ->select('ip_address')
                    ->whereIn('ip_address', $ipsInPeriod)
                    ->where('created_at', '<', $startDate . ' 00:00:00')
                    ->distinct()
                    ->pluck('ip_address')
                    ->all();
            }
        }

        $returningUserSet = array_flip($returningUserIds);
        $returningIpSet = array_flip($returningIps);
        $newCount = 0;
        $returningCount = 0;
        foreach ($userIdsInPeriod as $uid) {
            if (isset($returningUserSet[$uid])) {
                $returningCount++;
            } else {
                $newCount++;
            }
        }
        foreach ($ipsInPeriod as $ip) {
            if ($ip === null || $ip === '') {
                continue;
            }
            if (isset($returningIpSet[$ip])) {
                $returningCount++;
            } else {
                $newCount++;
            }
        }

        $totalViewers = $newCount + $returningCount;
        $newPercentage = $totalViewers > 0 ? ($newCount / $totalViewers) * 100 : 0;
        $returningPercentage = $totalViewers > 0 ? ($returningCount / $totalViewers) * 100 : 0;

        return [
            'new' => [
                'count' => $newCount,
                'percentage' => round($newPercentage, 2)
            ],
            'returning' => [
                'count' => $returningCount,
                'percentage' => round($returningPercentage, 2)
            ],
            'total' => $totalViewers
        ];
    }

    /**
     * Get location breakdown (country distribution)
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array Array of countries with counts
     */
    public static function getLocationBreakdown($startDate = null, $endDate = null)
    {
        $query = Visit::selectRaw('country, COUNT(*) as count')
            ->whereNotNull('country')
            ->groupBy('country')
            ->orderBy('count', 'DESC');
        self::applyDateRange($query, $startDate, $endDate);
        $results = $query->get();
        $countryNames = self::getCountryNameMap();

        $locationData = [];
        foreach ($results as $result) {
            $countryCode = strtoupper($result->country);
            $countryName = Arr::get($countryNames, $countryCode, $countryCode);
            
            $locationData[] = [
                'country' => $countryName,
                'country_code' => $countryCode,
                'count' => (int)$result->count
            ];
        }

        return $locationData;
    }

    /**
     * Get location breakdown for a specific video
     *
     * @param int $mediaId
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array Array of countries with counts
     */
    public static function getVideoLocationBreakdown($mediaId, $startDate = null, $endDate = null)
    {
        $query = Visit::selectRaw('country, COUNT(*) as count')
            ->where('media_id', $mediaId)
            ->whereNotNull('country')
            ->groupBy('country')
            ->orderBy('count', 'DESC');
        self::applyDateRange($query, $startDate, $endDate);
        $results = $query->get();
        $countryNames = self::getCountryNameMap();

        $locationData = [];
        foreach ($results as $result) {
            $countryCode = strtoupper($result->country);
            $countryName = Arr::get($countryNames, $countryCode, $countryCode);

            $locationData[] = [
                'country'     => $countryName,
                'country_code' => $countryCode,
                'count'       => (int) $result->count
            ];
        }

        return $locationData;
    }

    /**
     * Get dashboard device breakdown (all visits in date range)
     *
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array<int, array{device_type: string, count: int}>
     */
    public static function getDevices($startDate = null, $endDate = null)
    {
        $query = Visit::selectRaw('device as device_type, COUNT(*) as count')
            ->whereNotNull('device')
            ->where('device', '!=', '')
            ->groupBy('device')
            ->orderBy('count', 'DESC');
        self::applyDateRange($query, $startDate, $endDate);
        $results = $query->get();
        return self::aggregateDevicesByLabel($results);
    }

    /**
     * Get video device breakdown
     *
     * @param int $mediaId
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array
     */
    public static function getVideoDevices($mediaId, $startDate = null, $endDate = null)
    {
        $query = Visit::selectRaw('device as device_type, COUNT(*) as count')
            ->where('media_id', $mediaId)
            ->whereNotNull('device')
            ->where('device', '!=', '')
            ->groupBy('device')
            ->orderBy('count', 'DESC');
        self::applyDateRange($query, $startDate, $endDate);
        $results = $query->get();
        return self::aggregateDevicesByLabel($results);
    }

    /**
     * Get user
     *
     * @param int $userId
     * @return array
     */
    public static function getUser($userId)
    {
        $userData = get_userdata($userId);
        
        if (!$userData) {
            return [];
        }

        return [
            'id'           => $userData->data->ID,
            'display_name' => $userData->data->display_name,
            'email'        => $userData->data->user_email,
            'author_url'   => function_exists('get_author_posts_url') ? get_author_posts_url((int) $userId) : '',
        ];
    }

    /**
     * Get user stats.
     *
     * @param int $userId
     * @param string|null $startDate
     * @param string|null $endDate
     * @return array
     */
    public static function getUserStats($userId, $startDate = null, $endDate = null)
    {
        [$previousStartDate, $previousEndDate] = self::getPreviousPeriodDates($startDate, $endDate);
        $agg = self::getVisitAggregatesCurrentAndPrevious($startDate, $endDate, $previousStartDate, $previousEndDate, ['user_id' => $userId]);
        $views = $agg['views'];
        $totalWatchTime = $agg['total_watch_time'];
        $averageWatchTime = $views > 0 ? $totalWatchTime / $views : 0;
        $previousViews = $agg['previous_views'];
        $previousTotalWatchTime = $agg['previous_total_watch_time'];
        $previousAverageWatchTime = $previousViews > 0 ? $previousTotalWatchTime / $previousViews : 0;

        $completionRate = $agg['avg_completion'];
        $previousCompletionRate = $agg['previous_avg_completion'];
        $completionRateTrend = self::getTrendData($completionRate, $previousCompletionRate);

        $viewsTrend = self::getTrendData($views, $previousViews);
        $averageWatchTimeTrend = self::getTrendData($averageWatchTime, $previousAverageWatchTime);
        $totalWatchTimeTrend = self::getTrendData($totalWatchTime, $previousTotalWatchTime);

        return [
            'views' => $views,
            'total_watch_time' => $totalWatchTime,
            'average_watch_time' => $averageWatchTime,
            'completion_rate' => $completionRate,
            'views_change' => $viewsTrend['change'],
            'views_is_positive' => $viewsTrend['is_positive'],
            'average_watch_time_change' => $averageWatchTimeTrend['change'],
            'average_watch_time_is_positive' => $averageWatchTimeTrend['is_positive'],
            'total_watch_time_change' => $totalWatchTimeTrend['change'],
            'total_watch_time_is_positive' => $totalWatchTimeTrend['is_positive'],
            'completion_rate_change' => $completionRateTrend['change'],
            'completion_rate_is_positive' => $completionRateTrend['is_positive'],
        ];
    }

    /**
     * Get user's top videos
     *
     * @param int $userId
     * @param string|null $startDate
     * @param string|null $endDate
     * @param int $limit
     * @return Builder[]|Collection
     */
    public static function getUserTopVideos($userId, $startDate = null, $endDate = null, $limit = 10)
    {
        $query = Visit::selectRaw('media_id, COUNT(*) as views, SUM(duration) as total_watch_time, AVG(percentage) as avg_percentage')
            ->where('user_id', $userId)
            ->groupBy('media_id')
            ->orderBy('total_watch_time', 'DESC')
            ->limit($limit);
        self::applyDateRange($query, $startDate, $endDate);
        return $query->get();
    }

    /**
     * Aggregate raw device rows by normalized label (Mobile, Tablet, Laptop, etc.) and sum counts.
     *
     * @param Collection $rows Collection of objects with device_type and count
     * @return array<int, array{device_type: string, count: int}>
     */
    protected static function aggregateDevicesByLabel($rows)
    {
        $aggregated = [];
        foreach ($rows as $row) {
            $label = self::normalizeDeviceLabel($row->device_type ?? '');
            if (!isset($aggregated[$label])) {
                $aggregated[$label] = ['device_type' => $label, 'count' => 0];
            }
            $aggregated[$label]['count'] += (int) ($row->count ?? 0);
        }
        usort($aggregated, function ($a, $b) {
            return $b['count'] - $a['count'];
        });
        return array_values($aggregated);
    }

    /**
     * Run analytics auto-cleanup — called via fluentplayer/daily_cleanup cron hook.
     * Deletes visits older than the configured number of days in batches.
     */
    public static function runCleanup()
    {
        $settings = \FluentPlayer\App\Services\SettingsService::getSettings();

        if (!Arr::get($settings, 'analytics.enabled', false)) {
            return;
        }

        $autoCleanup = Arr::get($settings, 'analytics.auto_cleanup', []);

        if (!Arr::get($autoCleanup, 'enabled', true)) {
            return;
        }

        $days = max(1, min((int) Arr::get($autoCleanup, 'days', 30), 730));
        $cutoffDate = wp_date('Y-m-d H:i:s', current_time('timestamp') - ($days * DAY_IN_SECONDS));

        try {
            $batchSize = 1000;
            do {
                $deleted = Visit::where('created_at', '<', $cutoffDate)
                    ->limit($batchSize)
                    ->delete();
            } while ($deleted >= $batchSize);
        } catch (\Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('FluentPlayer Analytics Cleanup Error: ' . $e->getMessage());
            }
        }
    }

}
