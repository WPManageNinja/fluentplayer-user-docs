<?php

namespace FluentPlayerPro\App\Services\PluginManager;

if (!defined('ABSPATH')) {
    exit;
}

class PluginUpdater
{
    private $cache_key;

    private $config = [];

    public function __construct($config = [])
    {
        $defaults = [
            'type'                 => 'plugin',
            'slug'                 => '',
            'item_id'              => '',
            'basename'             => '',
            'version'              => '',
            'api_url'              => '',
            'license_key'          => '',
            'license_key_callback' => '',
            'show_check_update'    => false,
        ];

        $config = wp_parse_args($config, $defaults);

        $this->config = $config;
        $this->cache_key = 'fsl_' . md5($config['basename'] . '_' . $config['item_id']) . '_version_info';

        if ($config['type'] === 'plugin') {
            $this->initPluginUpdaterHooks();
        }
    }

    private function initPluginUpdaterHooks()
    {
        add_filter('pre_set_site_transient_update_plugins', array($this, 'checkPluginUpdate'));
        add_filter('plugins_api', array($this, 'pluginsApiFilter'), 10, 3);

        if ($this->config['show_check_update']) {

            $getParam = 'fluent_sl_check_update_' . $this->config['slug'];

            add_filter('plugin_row_meta', function ($links, $file) use ($getParam) {
                if ($this->config['basename'] !== $file) {
                    return $links;
                }

                $checkUpdateUrl = esc_url(admin_url('plugins.php?' . $getParam . '=' . time()));
                $row_meta = array(
                    'check_update' => '<a  style="color: #583fad;font-weight: 600;" href="' . $checkUpdateUrl . '" aria-label="' . esc_attr__('Check Update', 'fluent-player-pro') . '">' . esc_html__('Check Update', 'fluent-player-pro') . '</a>',
                );

                return array_merge($links, $row_meta);

            }, 10, 2);

            if (isset($_GET[$getParam])) {
                add_action('admin_init', function () {
                    if (current_user_can('update_plugins')) {
                        delete_transient($this->cache_key);

                        add_filter('fluent_sl/api_request_query_params', function ($params) {
                            $params['disable_cache'] = 'yes';
                            return $params;
                        });

                        remove_filter('pre_set_site_transient_update_plugins', [$this, 'checkPluginUpdate']);

                        $update_cache = get_site_transient('update_plugins');
                        if ($update_cache && !empty($update_cache->response[$this->config['basename']])) {
                            unset($update_cache->response[$this->config['basename']]);
                        }

                        $update_cache = $this->checkPluginUpdate($update_cache);
                        set_site_transient('update_plugins', $update_cache);

                        add_filter('pre_set_site_transient_update_plugins', [$this, 'checkPluginUpdate']);

                        wp_redirect(admin_url('plugins.php?s=' . $this->config['slug'] . '&plugin_status=all'));
                        exit();
                    }
                });
            }
        }
    }

    public function checkPluginUpdate($transient_data)
    {
        global $pagenow;

        if (!is_object($transient_data)) {
            $transient_data = new \stdClass();
        }

        if ('plugins.php' === $pagenow && is_multisite()) {
            return $transient_data;
        }

        if (!empty($transient_data->response) && !empty($transient_data->response[$this->config['basename']])) {
            return $transient_data;
        }

        $version_info = $this->getVersionInfo();

        if (false !== $version_info && is_object($version_info) && isset($version_info->new_version)) {
            unset($version_info->sections);
            if (version_compare($this->config['version'], $version_info->new_version, '<')) {
                $transient_data->response[$this->config['basename']] = $version_info;
            } else {
                $transient_data->no_update[$this->config['basename']] = $version_info;
            }

            $transient_data->last_checked = time();
            $transient_data->checked[$this->config['basename']] = $this->config['version'];
        }

        return $transient_data;
    }

    public function pluginsApiFilter($data, $action = '', $args = null)
    {
        if ('plugin_information' !== $action || !$args) {
            return $data;
        }

        $slug = $this->config['slug'];

        if (!isset($args->slug) || ($args->slug !== $slug)) {
            return $data;
        }

        $data = $this->getVersionInfo();

        if (is_wp_error($data)) {
            return $data;
        }

        if (!$data) {
            return new \WP_Error('no_data', 'No data found for this plugin');
        }

        return $data;
    }

    private function getCachedVersionInfo()
    {
        global $pagenow;

        if ('update-core.php' === $pagenow || ($pagenow === 'plugin-install.php' && !empty($_GET['plugin']))) {
            return false;
        }

        return get_transient($this->cache_key);
    }

    private function setCachedVersionInfo($value)
    {
        if (!$value) {
            return;
        }

        set_transient($this->cache_key, $value, 3 * HOUR_IN_SECONDS);
    }

    private function getVersionInfo()
    {
        $versionInfo = $this->getCachedVersionInfo();

        if (false === $versionInfo) {
            $versionInfo = $this->getRemoteVersionInfo();
            $this->setCachedVersionInfo($versionInfo);
        }

        return $versionInfo;
    }

    private function getRemoteVersionInfo()
    {
        $url = $this->config['api_url'];
        $fullUrl = add_query_arg(apply_filters('fluent_sl/api_request_query_params', array(
            'fluent-cart' => 'get_license_version',
        ), $this->config), $url);

        $payload = [
            'item_id'          => $this->config['item_id'],
            'current_version'  => $this->config['version'],
            'site_url'         => home_url(),
            'platform_version' => get_bloginfo('version'),
            'server_version'   => PHP_VERSION,
            'license_key'      => $this->config['license_key'],
        ];

        if (empty($payload['license_key']) && !empty($this->config['license_key_callback'])) {
            $payload['license_key'] = call_user_func($this->config['license_key_callback']);
        }

        $payload = apply_filters('fluent_sl/updater_payload_' . $this->config['slug'], $payload, $this->config);

        $response = wp_remote_post($fullUrl, array(
            'timeout'   => 15,
            'body'      => $payload
        ));

        if (is_wp_error($response)) {
            return false;
        }

        if (200 !== wp_remote_retrieve_response_code($response)) {
            return false;
        }

        $responseBody = wp_remote_retrieve_body($response);

        if (empty($responseBody)) {
            return false;
        }

        $versionInfo = json_decode($responseBody);
        if (null === $versionInfo || !is_object($versionInfo)) {
            return false;
        }

        if (!isset($versionInfo->new_version)) {
            return false;
        }

        $versionInfo->plugin = $this->config['basename'];
        $versionInfo->slug = $this->config['slug'];

        if (!empty($versionInfo->sections)) {
            $versionInfo->sections = (array)$versionInfo->sections;
        }

        if (!isset($versionInfo->banners)) {
            $versionInfo->banners = array();
        } else {
            $versionInfo->banners = (array)$versionInfo->banners;
        }

        if (!isset($versionInfo->icons)) {
            $versionInfo->icons = array();
        } else {
            $versionInfo->icons = (array)$versionInfo->icons;
        }

        return $versionInfo;
    }
}
