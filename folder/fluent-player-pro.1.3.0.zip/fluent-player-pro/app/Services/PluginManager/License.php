<?php

namespace FluentPlayerPro\App\Services\PluginManager;

if (!defined('ABSPATH')) {
    exit;
}

class License
{
    const SETTINGS_KEY = '__fluent-player-pro_sl_info';

    public static function getKey()
    {
        $storedKey = self::getStoredKey();
        $defaultKey = defined('FLUENT_PLAYER_PRO_LICENSE_KEY')
            ? (string) FLUENT_PLAYER_PRO_LICENSE_KEY
            : $storedKey;

        $licenseKey = apply_filters('fluent_player_pro/license_key', $defaultKey, $storedKey);

        if (!is_string($licenseKey)) {
            return '';
        }

        return sanitize_text_field($licenseKey);
    }

    protected static function getStoredKey()
    {
        try {
            return FluentLicensing::getInstance()->getCurrentLicenseKey();
        } catch (\Exception $exception) {
            $licenseData = get_option(self::SETTINGS_KEY, []);

            if (!is_array($licenseData) || empty($licenseData['license_key'])) {
                return '';
            }

            return sanitize_text_field((string) $licenseData['license_key']);
        }
    }
}
