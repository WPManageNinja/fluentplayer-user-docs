<?php

namespace FluentPlayerPro\App\Services;

if (!defined('ABSPATH')) exit;

use FluentPlayer\App\Helpers\BulkActionHelper;
use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayerPro\App\Models\Playlist;

class PlaylistService
{
    const BULK_STATUSES = ['publish', 'private', 'draft'];

    /**
     * Validate and run a bulk action over playlists.
     *
     * @return array|\WP_Error Success payload (message + counts), or a WP_Error carrying an HTTP status.
     */
    public function manageBulkActions(Request $request)
    {
        // Guard against a newer Pro paired with an outdated free build (no shared helper).
        // The user-facing nag is handled at boot by FreeDependencyNotice; here we just bail safely.
        if (!class_exists(BulkActionHelper::class)) {
            return new \WP_Error(
                'fp_outdated_free',
                __('Please update the free FluentPlayer plugin to use bulk actions.', 'fluent-player-pro'),
                ['status' => 500]
            );
        }

        $action = sanitize_text_field((string) $request->get('action'));
        $ids = BulkActionHelper::sanitizeIds($request->get('playlist_ids'));

        if (empty($ids)) {
            return new \WP_Error('fp_bulk_empty', __('No items were selected', 'fluent-player-pro'), ['status' => 422]);
        }

        if (count($ids) > BulkActionHelper::MAX) {
            return new \WP_Error(
                'fp_bulk_too_many',
                // translators: %d is the maximum number of items per bulk request.
                sprintf(__('You can process up to %d items at once', 'fluent-player-pro'), BulkActionHelper::MAX),
                ['status' => 422]
            );
        }

        switch ($action) {
            case 'trash':
                $result = BulkActionHelper::run($ids, function ($id) {
                    return $this->isLivePlaylist($id) && (bool) wp_trash_post($id);
                });
                break;
            case 'restore':
                $result = BulkActionHelper::run($ids, function ($id) {
                    return $this->isPlaylist($id) && get_post_status($id) === 'trash' && (bool) wp_untrash_post($id);
                });
                break;
            case 'delete_permanently':
                $result = BulkActionHelper::run($ids, function ($id) {
                    return $this->isPlaylist($id) && (bool) wp_delete_post($id, true);
                });
                break;
            case 'change_status':
                $status = sanitize_text_field((string) $request->get('status'));
                if (!in_array($status, self::BULK_STATUSES, true)) {
                    return new \WP_Error('fp_bulk_invalid_status', __('Invalid status', 'fluent-player-pro'), ['status' => 422]);
                }
                $result = BulkActionHelper::run($ids, function ($id) use ($status) {
                    if (!$this->isLivePlaylist($id)) {
                        return false;
                    }
                    $updated = wp_update_post(['ID' => $id, 'post_status' => $status], true);
                    return !is_wp_error($updated) && $updated > 0;
                });
                break;
            default:
                return new \WP_Error('fp_bulk_invalid_action', __('Invalid bulk action', 'fluent-player-pro'), ['status' => 422]);
        }

        return BulkActionHelper::format($result);
    }

    /** A playlist of the correct type (guards against mutating arbitrary posts). */
    protected function isPlaylist($id)
    {
        return get_post_type($id) === Playlist::getPostType();
    }

    /** A non-trashed playlist (eligible for trash / status change). */
    protected function isLivePlaylist($id)
    {
        return $this->isPlaylist($id) && get_post_status($id) !== 'trash';
    }
}
