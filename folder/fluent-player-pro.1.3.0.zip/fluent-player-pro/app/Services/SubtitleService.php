<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Services\PluginManager\License;

class SubtitleService
{
    const MAX_SUBTITLE_BYTES = 5242880;
    const MAX_SERVICE_RESPONSE_BYTES = 26214400;
    const MAX_REMOTE_TRACK_SELECTION = 10;
    const MAX_STORYBOARD_ASSET_BYTES = 5242880;
    const MAX_STORYBOARD_REMOTE_URLS = 20;
    const MAX_STORYBOARD_ASSET_TIMEOUT_SECONDS = 5;
    const MAX_STORYBOARD_FETCH_WINDOW_SECONDS = 30;
    const BETA_DEFAULT_SERVICE_URL = 'https://api.fluentplayer.com';
    const BETA_DEFAULT_API_TOKEN = '4641c319347dad4db62746d2daff31f518df61abbf03d97ee85558d889a03e29';
    const LICENSE_REQUEST_HEADER = 'X-Fluent-Player-License';
    const SIGNATURE_VERSION = 'v1';
    const SIGNATURE_INSTALL_OPTION = 'fluent_player_subtitle_service_install_id';
    const STORYBOARD_GENERATION_HOOK = 'fluent_player_pro/generate_storyboard';
    const STORYBOARD_GENERATION_LOCK_PREFIX = 'fluent_player_pro_storyboard_generation_';
    const STORYBOARD_GENERATION_LOCK_TTL = 300;
    const STORYBOARD_STATUS_SETTING = 'storyboard_generation_status';
    const STORYBOARD_STATUS_MESSAGE_SETTING = 'storyboard_generation_message';
    const GENERATED_ATTACHMENT_MEDIA_META = '_fluent_player_generated_subtitle_media_id';
    const GENERATED_STORYBOARD_MEDIA_META = '_fluent_player_generated_storyboard_media_id';
    const GENERATED_STORYBOARD_ASSET_DIR_META = '_fluent_player_generated_storyboard_asset_dir';
    const STORYBOARD_ALLOWED_REMOTE_HOSTS = [
        'i.ytimg.com',
        'img.youtube.com',
        'yt3.ggpht.com',
        'googleusercontent.com',
        'ggpht.com',
        'youtube.com',
        'youtube-nocookie.com',
        'googlevideo.com',
    ];

    /**
     * Validate subtitle file
     *
     * @param string $filePath
     * @return array
     */
    public static function validateSubtitleFile($filePath)
    {
        if (!file_exists($filePath)) {
            return ['valid' => false, 'error' => __('File not found', 'fluent-player-pro')];
        }

        $fileExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

        if (!in_array($fileExtension, ['vtt', 'srt'], true)) {
            return ['valid' => false, 'error' => __('Invalid file type. Only .vtt and .srt files are allowed', 'fluent-player-pro')];
        }

        if (filesize($filePath) > self::MAX_SUBTITLE_BYTES) {
            return ['valid' => false, 'error' => __('File too large. Maximum size is 5MB', 'fluent-player-pro')];
        }

        return ['valid' => true];
    }

    public static function isValidYouTubeVideoId($videoId)
    {
        return is_string($videoId) && preg_match('/^[a-zA-Z0-9_-]{11}$/', $videoId);
    }

    public static function getServiceSettings()
    {
        $settings = \FluentPlayer\App\Services\SettingsService::getSection('subtitle_service');
        $serviceUrl = untrailingslashit((string) Arr::get($settings, 'service_url', ''));
        $apiToken = (string) Arr::get($settings, 'api_token', '');
        // Pro always manages the hosted subtitle service availability when the addon is active.
        $enabled = true;
        $timeoutSeconds = (int) Arr::get($settings, 'timeout_seconds', 45);
        $serviceSchemeValid = true;

        // Beta fallback stays opt-in: only enabled installs with no custom credentials
        // inherit the built-in hosted endpoint defaults.
        if ($enabled && $serviceUrl === '' && $apiToken === '') {
            $serviceUrl = untrailingslashit(self::BETA_DEFAULT_SERVICE_URL);
            $apiToken = self::BETA_DEFAULT_API_TOKEN;
            $timeoutSeconds = max($timeoutSeconds, 45);
        }

        if ($serviceUrl !== '' && !self::isSecureServiceUrl($serviceUrl)) {
            $serviceSchemeValid = false;
            $serviceUrl = '';
            $apiToken = '';
        }

        return [
            'enabled'              => $enabled,
            'service_url'          => $serviceUrl,
            'api_token'            => $apiToken,
            'timeout_seconds'      => max(5, min(60, $timeoutSeconds)),
            'service_scheme_valid' => $serviceSchemeValid,
            'max_track_selection'  => self::MAX_REMOTE_TRACK_SELECTION,
        ];
    }

    public static function filterSubtitleServiceSettings($settings, $allSettings = [])
    {
        $settings = is_array($settings) ? $settings : [];
        $serviceUrl = untrailingslashit(self::BETA_DEFAULT_SERVICE_URL);
        $apiToken = self::BETA_DEFAULT_API_TOKEN;

        $settings['enabled'] = true;

        if ($serviceUrl !== '') {
            $settings['service_url'] = $serviceUrl;
        }

        if ($apiToken !== '') {
            $settings['api_token'] = $apiToken;
        }

        $settings['max_track_selection'] = self::MAX_REMOTE_TRACK_SELECTION;

        return $settings;
    }

    public static function isServiceConfigured()
    {
        $settings = self::getServiceSettings();
        return $settings['enabled'] && !empty($settings['service_url']);
    }

    protected static function getHostedServiceLicenseKey($serviceUrl)
    {
        $serviceHost = strtolower((string) wp_parse_url((string) $serviceUrl, PHP_URL_HOST));
        $managedHost = strtolower((string) wp_parse_url(self::BETA_DEFAULT_SERVICE_URL, PHP_URL_HOST));

        if (!$serviceHost || !$managedHost || $serviceHost !== $managedHost) {
            return '';
        }

        return License::getKey();
    }

    /**
     * Get language label from code
     *
     * @param string $languageCode
     * @return string
     */
    public static function getLanguageLabel($languageCode)
    {
        $languageMap = [
            'en' => __('English', 'fluent-player-pro'),
            'es' => __('Spanish', 'fluent-player-pro'),
            'fr' => __('French', 'fluent-player-pro'),
            'de' => __('German', 'fluent-player-pro'),
            'it' => __('Italian', 'fluent-player-pro'),
            'pt' => __('Portuguese', 'fluent-player-pro'),
            'ru' => __('Russian', 'fluent-player-pro'),
            'ja' => __('Japanese', 'fluent-player-pro'),
            'ko' => __('Korean', 'fluent-player-pro'),
            'zh' => __('Chinese', 'fluent-player-pro'),
            'ar' => __('Arabic', 'fluent-player-pro'),
            'hi' => __('Hindi', 'fluent-player-pro')
        ];

        return Arr::get($languageMap, $languageCode, __('Unknown', 'fluent-player-pro'));
    }

    public static function listRemoteTracks($videoId)
    {
        return self::callRemoteService('/subtitles/list', [
            'video_id' => $videoId,
        ]);
    }

    public static function downloadRemoteTracks($videoId, $trackIds)
    {
        return self::callRemoteService('/subtitles/download', [
            'video_id'  => $videoId,
            'track_ids' => array_values($trackIds),
        ]);
    }

    public static function getRemoteStoryboard($videoId)
    {
        return self::callRemoteService('/thumbnails/storyboard', [
            'video_id' => $videoId,
        ]);
    }

    public static function generateStoryboardForMedia($media, $videoId)
    {
        if (!$media || empty($media->ID)) {
            return new \WP_Error('subtitle_storyboard_invalid_media', __('Media not found', 'fluent-player-pro'), ['status' => 404]);
        }

        $mediaId = absint($media->ID);
        $settings = get_post_meta($mediaId, 'settings', true);
        if (!is_array($settings)) {
            $settings = is_array($media->settings) ? $media->settings : [];
        }

        if (!empty(Arr::get($settings, 'thumbnails'))) {
            $settings[self::STORYBOARD_STATUS_SETTING] = 'completed';
            $settings[self::STORYBOARD_STATUS_MESSAGE_SETTING] = __('Hover preview enabled.', 'fluent-player-pro');
            update_post_meta($mediaId, 'settings', $settings);

            return [
                'generated'                => false,
                'already_exists'           => true,
                'thumbnails'               => (string) Arr::get($settings, 'thumbnails', ''),
                'storyboard_attachment_id' => absint(Arr::get($settings, 'storyboard_attachment_id', 0)),
                'storyboard_status'        => 'completed',
                'storyboard_message'       => __('Hover preview is already enabled.', 'fluent-player-pro'),
            ];
        }

        $settings[self::STORYBOARD_STATUS_SETTING] = 'processing';
        $settings[self::STORYBOARD_STATUS_MESSAGE_SETTING] = __('Generating hover preview...', 'fluent-player-pro');
        update_post_meta($mediaId, 'settings', $settings);

        $storyboardResponse = self::getRemoteStoryboard($videoId);
        if (is_wp_error($storyboardResponse)) {
            self::setStoryboardGenerationState($mediaId, 'failed', $storyboardResponse->get_error_message());
            return $storyboardResponse;
        }

        $storyboard = self::normalizeRemoteStoryboard($storyboardResponse);
        if (!$storyboard) {
            self::setStoryboardGenerationState($mediaId, 'failed', __('Hover preview could not be generated right now.', 'fluent-player-pro'));
            return new \WP_Error(
                'subtitle_storyboard_invalid_response',
                __('Hover preview could not be generated right now.', 'fluent-player-pro'),
                ['status' => 422]
            );
        }

        $attachment = self::saveStoryboardAsAttachment(
            Arr::get($storyboard, 'vtt_content', ''),
            $mediaId,
            $media->post_title ?: Arr::get($settings, 'title', 'media'),
            Arr::get($storyboard, 'filename', '')
        );

        if (is_wp_error($attachment)) {
            self::setStoryboardGenerationState($mediaId, 'failed', $attachment->get_error_message());
            return $attachment;
        }

        if (!$attachment) {
            self::setStoryboardGenerationState($mediaId, 'failed', __('Hover preview could not be saved right now.', 'fluent-player-pro'));
            return new \WP_Error(
                'subtitle_storyboard_save_failed',
                __('Hover preview could not be saved right now.', 'fluent-player-pro'),
                ['status' => 500]
            );
        }

        $settings['thumbnails'] = Arr::get($attachment, 'url', '');
        $settings['storyboard_attachment_id'] = Arr::get($attachment, 'id');
        $settings[self::STORYBOARD_STATUS_SETTING] = 'completed';
        $settings[self::STORYBOARD_STATUS_MESSAGE_SETTING] = __('Hover preview enabled.', 'fluent-player-pro');
        update_post_meta($mediaId, 'settings', $settings);

        return [
            'generated'                => !empty($settings['thumbnails']),
            'already_exists'           => false,
            'thumbnails'               => (string) Arr::get($settings, 'thumbnails', ''),
            'storyboard_attachment_id' => absint(Arr::get($settings, 'storyboard_attachment_id', 0)),
            'storyboard_status'        => (string) Arr::get($settings, self::STORYBOARD_STATUS_SETTING, ''),
            'storyboard_message'       => (string) Arr::get($settings, self::STORYBOARD_STATUS_MESSAGE_SETTING, ''),
        ];
    }

    public static function maybeGenerateStoryboardForMedia($mediaId)
    {
        $mediaId = absint($mediaId);
        $lockKey = self::getStoryboardGenerationLockKey($mediaId);

        try {
            $context = self::getStoryboardGenerationContext($mediaId);
            if (!$context) {
                return;
            }

            $result = self::generateStoryboardForMedia($context['media'], $context['video_id']);
            if (is_wp_error($result)) {
                return;
            }
        } finally {
            if ($lockKey) {
                delete_transient($lockKey);
            }
        }
    }

    protected static function callRemoteService($path, $payload)
    {
        $settings = self::getServiceSettings();

        if (!$settings['enabled']) {
            return new \WP_Error('subtitle_service_disabled', __('Subtitle service is disabled', 'fluent-player-pro'));
        }

        if (!$settings['service_scheme_valid']) {
            return new \WP_Error(
                'subtitle_service_invalid_url',
                __('Subtitle service URL must use HTTPS', 'fluent-player-pro')
            );
        }

        if (empty($settings['service_url'])) {
            return new \WP_Error('subtitle_service_missing_url', __('Subtitle service URL is not configured', 'fluent-player-pro'));
        }

        $body = wp_json_encode($payload);
        if (!is_string($body) || $body === '') {
            return new \WP_Error(
                'subtitle_service_invalid_request',
                __('Subtitle service request could not be prepared', 'fluent-player-pro')
            );
        }

        $headers = [
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        ];

        $licenseKey = self::getHostedServiceLicenseKey($settings['service_url']);
        if ($licenseKey !== '') {
            // Only send the Pro license key to the managed Fluent Player
            // service host so custom third-party service URLs never receive it.
            $headers[self::LICENSE_REQUEST_HEADER] = $licenseKey;
        }

        if (!empty($settings['api_token'])) {
            $headers['Authorization'] = 'Bearer ' . $settings['api_token'];
            $headers = array_merge($headers, self::buildSignedHeaders($path, $body, $settings['api_token']));
        }

        $response = wp_remote_post($settings['service_url'] . $path, [
            'headers'             => $headers,
            'body'                => $body,
            'timeout'             => $settings['timeout_seconds'],
            'limit_response_size' => self::MAX_SERVICE_RESPONSE_BYTES,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $status = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if (strlen($body) >= self::MAX_SERVICE_RESPONSE_BYTES) {
            return new \WP_Error(
                'subtitle_service_response_too_large',
                __('Subtitle service response exceeded the allowed size limit', 'fluent-player-pro'),
                ['status' => 413]
            );
        }

        $data = json_decode($body, true);

        if (!is_array($data)) {
            $data = [];
        }

        if ($status < 200 || $status >= 300) {
            $message = Arr::get($data, 'detail.message', Arr::get($data, 'detail', __('Subtitle service request failed', 'fluent-player-pro')));
            if (is_array($message)) {
                $message = __('Subtitle service request failed', 'fluent-player-pro');
            }
            return new \WP_Error('subtitle_service_request_failed', $message, ['status' => $status, 'data' => $data]);
        }

        return $data;
    }

    protected static function bustRemoteCache($videoId)
    {
        if (!self::isValidYouTubeVideoId($videoId)) {
            return;
        }

        $response = self::callRemoteService('/cache/bust', [
            'video_id' => $videoId,
        ]);

        if (is_wp_error($response)) {
            return;
        }
    }

    protected static function isSecureServiceUrl($url)
    {
        $url = trim((string) $url);

        if ($url === '' || !wp_http_validate_url($url)) {
            return false;
        }

        return strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) === 'https';
    }

    protected static function buildSignedHeaders($path, $body, $secret)
    {
        $timestamp = (string) time();
        $nonce = wp_generate_uuid4();
        $siteUrl = self::getSubtitleServiceSiteUrl();
        $installId = self::getSubtitleServiceInstallId();
        $pluginVersion = defined('FLUENT_PLAYER_PRO_VERSION')
            ? FLUENT_PLAYER_PRO_VERSION
            : (defined('FLUENT_PLAYER_VERSION') ? FLUENT_PLAYER_VERSION : 'unknown');
        $bodyHash = hash('sha256', $body);
        $signaturePayload = implode("\n", [
            self::SIGNATURE_VERSION,
            'POST',
            $path,
            $siteUrl,
            $timestamp,
            $nonce,
            $bodyHash,
        ]);
        $signature = 'sha256=' . hash_hmac('sha256', $signaturePayload, $secret);

        return [
            'X-Fluent-Player-Signature-Version' => self::SIGNATURE_VERSION,
            'X-Fluent-Player-Signature'         => $signature,
            'X-Fluent-Player-Timestamp'         => $timestamp,
            'X-Fluent-Player-Nonce'             => $nonce,
            'X-Fluent-Player-Site'              => $siteUrl,
            'X-Fluent-Player-Install'           => $installId,
            'X-Fluent-Player-Version'           => (string) $pluginVersion,
        ];
    }

    protected static function getSubtitleServiceSiteUrl()
    {
        $siteUrl = home_url('/');
        if (is_multisite()) {
            $siteUrl = network_home_url('/');
        }

        return untrailingslashit(esc_url_raw($siteUrl));
    }

    protected static function getSubtitleServiceInstallId()
    {
        $installId = get_option(self::SIGNATURE_INSTALL_OPTION, '');
        if (is_string($installId) && wp_is_uuid($installId)) {
            return $installId;
        }

        $installId = wp_generate_uuid4();
        update_option(self::SIGNATURE_INSTALL_OPTION, $installId, false);

        return $installId;
    }

    public static function normalizeRemoteTracks($response)
    {
        $tracks = [];
        foreach ((array) Arr::get($response, 'tracks', []) as $track) {
            $trackId = sanitize_text_field((string) Arr::get($track, 'track_id', ''));
            if (!$trackId) {
                continue;
            }

            $languageCode = sanitize_text_field((string) Arr::get($track, 'language', ''));
            $label = sanitize_text_field((string) Arr::get($track, 'label', Arr::get($track, 'language', '')));

            $tracks[] = [
                'trackId'      => $trackId,
                'languageCode' => $languageCode,
                'label'        => $label,
                'isAuto'       => (bool) Arr::get($track, 'is_auto', false),
                'isDownloadable' => (bool) Arr::get($track, 'is_downloadable', true),
                'isConfirmed'  => (bool) Arr::get($track, 'is_confirmed', false),
                'sourceType'   => sanitize_text_field((string) Arr::get($track, 'source', ((bool) Arr::get($track, 'is_auto', false) ? 'auto' : 'manual'))),
            ];
        }

        return $tracks;
    }

    public static function normalizeRemoteDownloadTrack($track)
    {
        $content = (string) Arr::get($track, 'vtt_content', '');
        if (!$content || strlen($content) > self::MAX_SUBTITLE_BYTES || strpos(ltrim($content, "\xEF\xBB\xBF \t\n\r"), 'WEBVTT') !== 0) {
            return null;
        }

        $trackId = sanitize_text_field((string) Arr::get($track, 'track_id', ''));
        $language = sanitize_text_field((string) Arr::get($track, 'language', ''));
        $label = sanitize_text_field((string) Arr::get($track, 'label', Arr::get($track, 'language', '')));
        $filename = sanitize_file_name((string) Arr::get($track, 'filename', 'subtitle.vtt'));

        return [
            'track_id'    => $trackId,
            'language'    => $language,
            'label'       => $label,
            'is_auto'     => (bool) Arr::get($track, 'is_auto', false),
            'filename'    => $filename ?: 'subtitle.vtt',
            'vtt_content' => $content,
        ];
    }

    public static function normalizeRemoteStoryboard($response)
    {
        $storyboard = (array) Arr::get($response, 'storyboard', []);
        $content = (string) Arr::get($storyboard, 'vtt_content', '');
        if (!$content || strlen($content) > self::MAX_SUBTITLE_BYTES || strpos(ltrim($content, "\xEF\xBB\xBF \t\n\r"), 'WEBVTT') !== 0) {
            return null;
        }

        $filename = sanitize_file_name((string) Arr::get($storyboard, 'filename', 'storyboard.vtt'));

        return [
            'filename'    => $filename ?: 'storyboard.vtt',
            'vtt_content' => $content,
        ];
    }

    public static function preserveManagedMediaSettings($existingSettings, $incomingSettings)
    {
        $existingSettings = is_array($existingSettings) ? $existingSettings : [];
        $incomingSettings = is_array($incomingSettings) ? $incomingSettings : [];

        if (empty($incomingSettings['subtitles']) && !empty($existingSettings['subtitles'])) {
            $incomingSettings['subtitles'] = $existingSettings['subtitles'];
        }

        if (empty($incomingSettings['thumbnails']) && !empty($existingSettings['thumbnails'])) {
            $incomingSettings['thumbnails'] = $existingSettings['thumbnails'];
        }

        if (empty($incomingSettings['storyboard_attachment_id']) && !empty($existingSettings['storyboard_attachment_id'])) {
            $incomingSettings['storyboard_attachment_id'] = $existingSettings['storyboard_attachment_id'];
        }

        if (!empty($existingSettings[self::STORYBOARD_STATUS_SETTING])) {
            $incomingSettings[self::STORYBOARD_STATUS_SETTING] = $existingSettings[self::STORYBOARD_STATUS_SETTING];
        }

        if (array_key_exists(self::STORYBOARD_STATUS_MESSAGE_SETTING, $existingSettings)) {
            $incomingSettings[self::STORYBOARD_STATUS_MESSAGE_SETTING] = (string) $existingSettings[self::STORYBOARD_STATUS_MESSAGE_SETTING];
        }

        return $incomingSettings;
    }

    public static function hasMediaSourceChanged($existingSettings, $incomingSettings)
    {
        $existingSignature = self::buildMediaSourceSignature($existingSettings);
        $incomingSignature = self::buildMediaSourceSignature($incomingSettings);

        if (!$existingSignature || !$incomingSignature) {
            return false;
        }

        return $existingSignature !== $incomingSignature;
    }

    protected static function buildMediaSourceSignature($settings)
    {
        $settings = is_array($settings) ? $settings : [];
        $provider = sanitize_text_field((string) Arr::get($settings, 'provider', ''));
        $src = trim((string) Arr::get($settings, 'src', ''));

        if (!$provider || !$src) {
            return '';
        }

        if ($provider === 'youtube') {
            $videoId = self::extractYouTubeVideoId($src);

            return $videoId ? 'youtube:' . $videoId : 'youtube:' . $src;
        }

        return $provider . ':' . $src;
    }

    protected static function getStoryboardGenerationContext($mediaId)
    {
        $mediaId = absint($mediaId);
        if (!$mediaId || !class_exists('\FluentPlayer\App\Models\Media')) {
            return null;
        }

        $media = \FluentPlayer\App\Models\Media::find($mediaId);
        if (!$media) {
            return null;
        }

        $settings = is_array($media->settings) ? $media->settings : [];
        if (Arr::get($settings, 'provider') !== 'youtube' || !empty(Arr::get($settings, 'thumbnails'))) {
            return null;
        }

        $videoId = self::getYouTubeVideoIdFromSettings($settings);
        if (!$videoId || !self::isServiceConfigured()) {
            return null;
        }

        return [
            'media'    => $media,
            'video_id' => $videoId,
        ];
    }

    protected static function getStoryboardGenerationLockKey($mediaId)
    {
        $mediaId = absint($mediaId);

        return $mediaId ? self::STORYBOARD_GENERATION_LOCK_PREFIX . $mediaId : '';
    }

    public static function queueStoryboardGenerationForMedia($mediaId)
    {
        $mediaId = absint($mediaId);
        if (!$mediaId || !function_exists('wp_schedule_single_event') || !self::getStoryboardGenerationContext($mediaId)) {
            return false;
        }

        $lockKey = self::getStoryboardGenerationLockKey($mediaId);
        if (!$lockKey || get_transient($lockKey)) {
            return false;
        }

        if (wp_next_scheduled(self::STORYBOARD_GENERATION_HOOK, [$mediaId])) {
            return false;
        }

        self::setStoryboardGenerationState($mediaId, 'queued', __('Hover preview queued. Reload or refresh status in a moment.', 'fluent-player-pro'));
        set_transient($lockKey, 1, self::STORYBOARD_GENERATION_LOCK_TTL);
        $scheduled = wp_schedule_single_event(time() + 3, self::STORYBOARD_GENERATION_HOOK, [$mediaId]);

        if (!$scheduled) {
            delete_transient($lockKey);
            self::setStoryboardGenerationState($mediaId, 'failed', __('Hover preview could not be queued right now.', 'fluent-player-pro'));
            return false;
        }

        return true;
    }

    protected static function setStoryboardGenerationState($mediaId, $status, $message = '')
    {
        $mediaId = absint($mediaId);
        if (!$mediaId) {
            return false;
        }

        $settings = get_post_meta($mediaId, 'settings', true);
        if (!is_array($settings)) {
            $settings = [];
        }

        $settings[self::STORYBOARD_STATUS_SETTING] = sanitize_text_field((string) $status);
        $settings[self::STORYBOARD_STATUS_MESSAGE_SETTING] = sanitize_text_field((string) $message);

        update_post_meta($mediaId, 'settings', $settings);

        return true;
    }

    public static function getYouTubeVideoIdFromMedia($media)
    {
        if (!$media) {
            return '';
        }

        $settings = is_array($media->settings) ? $media->settings : [];

        return self::getYouTubeVideoIdFromSettings($settings);
    }

    public static function getYouTubeVideoIdFromSettings($settings)
    {
        $settings = is_array($settings) ? $settings : [];

        return self::extractYouTubeVideoId((string) Arr::get($settings, 'src', ''));
    }

    protected static function extractYouTubeVideoId($url)
    {
        $url = is_string($url) ? trim($url) : '';
        if (!$url) {
            return '';
        }

        if (preg_match('/^[A-Za-z0-9_-]{11}$/', $url)) {
            return $url;
        }

        if (preg_match('/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:embed\/|v\/|live\/|shorts\/|watch\?v=))([^&\n?#]+)/', $url, $matches)) {
            return (string) ($matches[1] ?? '');
        }

        return '';
    }

    public static function saveVttAsAttachment($vttContent, $language, $mediaId, $mediaName = '', $label = '', $filename = '')
    {
        $uploadDir = wp_upload_dir();
        $subDir = 'fluent-player/subtitles';
        $targetDir = trailingslashit($uploadDir['basedir']) . $subDir;

        if (!file_exists($targetDir)) {
            wp_mkdir_p($targetDir);
        }

        $safeName = sanitize_file_name($mediaName ?: 'media');
        $safeLabel = sanitize_file_name($label ?: $language);
        $baseName = $safeName . '-' . $mediaId . '-' . $safeLabel;
        if ($filename) {
            $filename = sanitize_file_name(pathinfo($filename, PATHINFO_FILENAME)) . '.vtt';
            $baseName = pathinfo($filename, PATHINFO_FILENAME);
        }

        $filePath = null;
        $fileUrl = null;

        for ($attempt = 0; $attempt < 3; $attempt++) {
            $resolvedFilename = wp_unique_filename($targetDir, $baseName . '.vtt');
            $filePath = trailingslashit($targetDir) . $resolvedFilename;
            $handle = @fopen($filePath, 'xb');

            if (!$handle) {
                continue;
            }

            $written = fwrite($handle, $vttContent);
            fclose($handle);

            if ($written === false || $written !== strlen($vttContent)) {
                @unlink($filePath);
                return null;
            }

            $fileUrl = trailingslashit($uploadDir['baseurl']) . $subDir . '/' . $resolvedFilename;
            $filename = $resolvedFilename;
            break;
        }

        if (!$filePath || !$fileUrl || !file_exists($filePath)) {
            return null;
        }

        $attachmentTitle = $baseName;
        $attachmentId = wp_insert_attachment([
            'post_mime_type' => 'text/vtt',
            'post_title'     => $attachmentTitle,
            'post_content'   => '',
            'post_status'    => 'inherit',
        ], $filePath, 0);

        if (is_wp_error($attachmentId) || !$attachmentId) {
            @unlink($filePath);
            return null;
        }

        update_post_meta($attachmentId, self::GENERATED_ATTACHMENT_MEDIA_META, absint($mediaId));

        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attachmentData = wp_generate_attachment_metadata($attachmentId, $filePath);
        wp_update_attachment_metadata($attachmentId, $attachmentData);

        return [
            'id'       => $attachmentId,
            'url'      => $fileUrl,
            'filename' => $filename,
        ];
    }

    public static function markSubtitleAttachmentAsManaged($attachmentId, $mediaId)
    {
        $attachmentId = absint($attachmentId);
        $mediaId = absint($mediaId);

        if (!$attachmentId || !$mediaId || !get_post($attachmentId)) {
            return false;
        }

        update_post_meta($attachmentId, self::GENERATED_ATTACHMENT_MEDIA_META, $mediaId);

        return true;
    }

    public static function saveStoryboardAsAttachment($vttContent, $mediaId, $mediaName = '', $filename = '')
    {
        $uploadDir = wp_upload_dir();
        $subDir = 'fluent-player/storyboards';
        $targetDir = trailingslashit($uploadDir['basedir']) . $subDir;

        if (!file_exists($targetDir)) {
            wp_mkdir_p($targetDir);
        }

        $safeName = sanitize_file_name($mediaName ?: 'media');
        $baseName = $safeName . '-' . $mediaId . '-storyboard';
        if ($filename) {
            $filename = sanitize_file_name(pathinfo($filename, PATHINFO_FILENAME)) . '.vtt';
            $baseName = pathinfo($filename, PATHINFO_FILENAME);
        }

        $filePath = null;
        $fileUrl = null;
        $assetDirName = '';

        for ($attempt = 0; $attempt < 3; $attempt++) {
            $resolvedFilename = wp_unique_filename($targetDir, $baseName . '.vtt');
            $filePath = trailingslashit($targetDir) . $resolvedFilename;
            $handle = @fopen($filePath, 'xb');

            if (!$handle) {
                continue;
            }

            $localizedStoryboard = self::localizeStoryboardAssets(
                $vttContent,
                $targetDir,
                trailingslashit($uploadDir['baseurl']) . $subDir,
                pathinfo($resolvedFilename, PATHINFO_FILENAME)
            );

            if (is_wp_error($localizedStoryboard)) {
                fclose($handle);
                @unlink($filePath);
                return $localizedStoryboard;
            }

            $vttContent = (string) Arr::get($localizedStoryboard, 'vtt_content', $vttContent);
            $assetDirName = (string) Arr::get($localizedStoryboard, 'asset_dir_name', '');

            $written = fwrite($handle, $vttContent);
            fclose($handle);

            if ($written === false || $written !== strlen($vttContent)) {
                self::cleanupStoryboardAssetDirectory($assetDirName);
                @unlink($filePath);
                return null;
            }

            $fileUrl = trailingslashit($uploadDir['baseurl']) . $subDir . '/' . $resolvedFilename;
            $filename = $resolvedFilename;
            break;
        }

        if (!$filePath || !$fileUrl || !file_exists($filePath)) {
            return null;
        }

        $attachmentTitle = $baseName;
        $attachmentId = wp_insert_attachment([
            'post_mime_type' => 'text/vtt',
            'post_title'     => $attachmentTitle,
            'post_content'   => '',
            'post_status'    => 'inherit',
        ], $filePath, 0);

        if (is_wp_error($attachmentId) || !$attachmentId) {
            self::cleanupStoryboardAssetDirectory($assetDirName);
            @unlink($filePath);
            return null;
        }

        update_post_meta($attachmentId, self::GENERATED_STORYBOARD_MEDIA_META, absint($mediaId));
        if ($assetDirName) {
            update_post_meta($attachmentId, self::GENERATED_STORYBOARD_ASSET_DIR_META, $assetDirName);
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attachmentData = wp_generate_attachment_metadata($attachmentId, $filePath);
        wp_update_attachment_metadata($attachmentId, $attachmentData);

        return [
            'id'       => $attachmentId,
            'url'      => $fileUrl,
            'filename' => $filename,
        ];
    }

    protected static function localizeStoryboardAssets($vttContent, $targetDir, $baseUrl, $baseName)
    {
        preg_match_all('/^https?:\/\/[^\s#]+/mi', (string) $vttContent, $matches);
        $remoteUrls = array_values(array_unique(array_filter((array) Arr::get($matches, 0, []))));

        if (empty($remoteUrls)) {
            return [
                'vtt_content'    => $vttContent,
                'asset_dir_name' => '',
            ];
        }

        if (count($remoteUrls) > self::MAX_STORYBOARD_REMOTE_URLS) {
            return new \WP_Error(
                'subtitle_storyboard_asset_limit_exceeded',
                __('Hover preview could not be generated right now.', 'fluent-player-pro'),
                ['status' => 422]
            );
        }

        foreach ($remoteUrls as $remoteUrl) {
            if (!self::isAllowedStoryboardAssetUrl($remoteUrl)) {
                return new \WP_Error(
                    'subtitle_storyboard_asset_host_not_allowed',
                    __('Hover preview images could not be downloaded right now.', 'fluent-player-pro'),
                    ['status' => 422]
                );
            }
        }

        $assetDirName = sanitize_file_name($baseName) . '-assets';
        $assetDirPath = trailingslashit($targetDir) . $assetDirName;

        if (!file_exists($assetDirPath)) {
            wp_mkdir_p($assetDirPath);
        }

        if (!file_exists($assetDirPath) || !is_dir($assetDirPath)) {
            return new \WP_Error(
                'subtitle_storyboard_asset_directory_failed',
                __('Hover preview images could not be prepared right now.', 'fluent-player-pro'),
                ['status' => 500]
            );
        }

        $settings = self::getServiceSettings();
        $replacements = [];
        $assetTimeout = max(1, min((int) Arr::get($settings, 'timeout_seconds', 20), self::MAX_STORYBOARD_ASSET_TIMEOUT_SECONDS));
        $startedAt = microtime(true);

        foreach ($remoteUrls as $index => $remoteUrl) {
            if ((microtime(true) - $startedAt) >= self::MAX_STORYBOARD_FETCH_WINDOW_SECONDS) {
                self::cleanupStoryboardAssetDirectory($assetDirName);
                return new \WP_Error(
                    'subtitle_storyboard_asset_fetch_timed_out',
                    __('Hover preview images could not be downloaded right now.', 'fluent-player-pro'),
                    ['status' => 422]
                );
            }

            $response = wp_safe_remote_get($remoteUrl, [
                'timeout'             => $assetTimeout,
                'redirection'         => 3,
                'limit_response_size' => self::MAX_STORYBOARD_ASSET_BYTES,
                'reject_unsafe_urls'  => true,
                'headers'             => [
                    'Accept'          => 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
                    'Accept-Language' => 'en-US,en;q=0.9',
                    'Referer'         => 'https://www.youtube.com/',
                    'User-Agent'      => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
                ],
            ]);

            if (is_wp_error($response)) {
                self::cleanupStoryboardAssetDirectory($assetDirName);
                return new \WP_Error(
                    'subtitle_storyboard_asset_fetch_failed',
                    __('Hover preview images could not be downloaded right now.', 'fluent-player-pro'),
                    ['status' => 422]
                );
            }

            $status = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            $contentType = strtolower((string) wp_remote_retrieve_header($response, 'content-type'));

            if ($status < 200 || $status >= 300 || !$body || strpos($contentType, 'image/') !== 0) {
                self::cleanupStoryboardAssetDirectory($assetDirName);
                return new \WP_Error(
                    'subtitle_storyboard_asset_invalid_response',
                    __('Hover preview images could not be downloaded right now.', 'fluent-player-pro'),
                    ['status' => 422]
                );
            }

            $extension = self::resolveStoryboardAssetExtension($remoteUrl, $contentType);
            $localFilename = sprintf('sheet-%02d.%s', $index, $extension);
            $localPath = trailingslashit($assetDirPath) . $localFilename;
            $written = file_put_contents($localPath, $body, LOCK_EX);

            if ($written === false || $written !== strlen($body)) {
                self::cleanupStoryboardAssetDirectory($assetDirName);
                return new \WP_Error(
                    'subtitle_storyboard_asset_save_failed',
                    __('Hover preview images could not be saved right now.', 'fluent-player-pro'),
                    ['status' => 500]
                );
            }

            $replacements[$remoteUrl] = trailingslashit($baseUrl) . $assetDirName . '/' . $localFilename;
        }

        return [
            'vtt_content'    => strtr($vttContent, $replacements),
            'asset_dir_name' => $assetDirName,
        ];
    }

    protected static function isAllowedStoryboardAssetUrl($url)
    {
        $url = trim((string) $url);
        if (!$url || !wp_http_validate_url($url)) {
            return false;
        }

        $scheme = strtolower((string) wp_parse_url($url, PHP_URL_SCHEME));
        if ($scheme !== 'https') {
            return false;
        }

        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        if (!$host) {
            return false;
        }

        foreach (self::getAllowedStoryboardAssetHosts() as $allowedHost) {
            if (self::hostMatchesAllowedStoryboardHost($host, $allowedHost)) {
                return true;
            }
        }

        return false;
    }

    protected static function getAllowedStoryboardAssetHosts()
    {
        $settings = self::getServiceSettings();
        $serviceHost = strtolower((string) wp_parse_url((string) Arr::get($settings, 'service_url', ''), PHP_URL_HOST));

        $hosts = array_merge(self::STORYBOARD_ALLOWED_REMOTE_HOSTS, $serviceHost ? [$serviceHost] : []);
        $hosts = array_values(array_unique(array_filter(array_map('strtolower', $hosts))));

        return (array) apply_filters('fluent_player_pro/storyboard_asset_allowed_hosts', $hosts);
    }

    protected static function hostMatchesAllowedStoryboardHost($host, $allowedHost)
    {
        $host = strtolower(trim((string) $host));
        $allowedHost = strtolower(trim((string) $allowedHost));

        if (!$host || !$allowedHost) {
            return false;
        }

        return $host === $allowedHost || substr($host, -strlen('.' . $allowedHost)) === '.' . $allowedHost;
    }

    protected static function resolveStoryboardAssetExtension($url, $contentType)
    {
        $contentTypeMap = [
            'image/jpeg' => 'jpg',
            'image/jpg'  => 'jpg',
            'image/png'  => 'png',
            'image/webp' => 'webp',
            'image/avif' => 'avif',
            'image/gif'  => 'gif',
        ];

        if (!empty($contentTypeMap[$contentType])) {
            return $contentTypeMap[$contentType];
        }

        $path = wp_parse_url($url, PHP_URL_PATH);
        $extension = strtolower((string) pathinfo((string) $path, PATHINFO_EXTENSION));

        return $extension ?: 'jpg';
    }

    public static function cleanupStoryboardAssetDirectory($assetDirName)
    {
        $assetDirName = sanitize_file_name((string) $assetDirName);
        if (!$assetDirName) {
            return true;
        }

        $uploadDir = wp_upload_dir();
        $baseStoryboardDir = trailingslashit($uploadDir['basedir']) . 'fluent-player/storyboards/';
        $assetDirPath = trailingslashit($baseStoryboardDir) . $assetDirName;

        if (!file_exists($assetDirPath) || !is_dir($assetDirPath)) {
            return true;
        }

        if (strpos(wp_normalize_path($assetDirPath), wp_normalize_path($baseStoryboardDir)) !== 0) {
            return false;
        }

        $files = array_diff(scandir($assetDirPath) ?: [], ['.', '..']);
        foreach ($files as $file) {
            $filePath = trailingslashit($assetDirPath) . $file;
            if (is_dir($filePath)) {
                return false;
            }

            if (!@unlink($filePath)) {
                return false;
            }
        }

        return @rmdir($assetDirPath);
    }

    public static function cleanupGeneratedStoryboard(&$settings, $mediaId, $deleteAttachment = true)
    {
        $settings = is_array($settings) ? $settings : [];
        $mediaId = absint($mediaId);
        $attachmentId = absint(Arr::get($settings, 'storyboard_attachment_id', 0));
        $warning = '';
        $deleted = false;
        $cleared = false;
        $assetDirName = $attachmentId ? (string) get_post_meta($attachmentId, self::GENERATED_STORYBOARD_ASSET_DIR_META, true) : '';
        // `thumbnails` is shared across providers, so only clear it for managed storyboard attachments.
        $isManagedStoryboard = $attachmentId && self::canDeleteManagedStoryboardAttachment($attachmentId, $mediaId);

        if ($deleteAttachment && $isManagedStoryboard) {
            if ($assetDirName && !self::cleanupStoryboardAssetDirectory($assetDirName)) {
                $warning = __('Hover preview cleanup could not delete the storyboard images.', 'fluent-player-pro');
            }
            $deleted = (bool) wp_delete_attachment($attachmentId, true);
            if (!$deleted) {
                $warning = trim($warning . ' ' . __('Hover preview cleanup could not delete the storyboard attachment.', 'fluent-player-pro'));
            }
        }

        if ($isManagedStoryboard) {
            unset(
                $settings['thumbnails'],
                $settings['storyboard_attachment_id'],
                $settings[self::STORYBOARD_STATUS_SETTING],
                $settings[self::STORYBOARD_STATUS_MESSAGE_SETTING]
            );
            $cleared = true;
        }

        return [
            'deleted' => $deleted,
            'warning' => $warning,
            'cleared' => $cleared,
        ];
    }

    public static function cleanupManagedSubtitleAttachments($settings, $mediaId, $deleteAttachments = true)
    {
        $settings = is_array($settings) ? $settings : [];
        $mediaId = absint($mediaId);
        $subtitles = Arr::get($settings, 'subtitles', []);
        $deleted = 0;
        $failed = [];

        if (!$mediaId || empty($subtitles) || !is_array($subtitles)) {
            return [
                'deleted' => $deleted,
                'failed'  => $failed,
            ];
        }

        foreach ($subtitles as $subtitle) {
            $attachmentId = absint(Arr::get($subtitle, 'attachment_id', 0));

            if (!$deleteAttachments || !$attachmentId) {
                continue;
            }

            if (!self::canDeleteManagedSubtitleAttachment($attachmentId, $mediaId)) {
                continue;
            }

            if (wp_delete_attachment($attachmentId, true)) {
                $deleted++;
                continue;
            }

            $failed[] = [
                'attachment_id' => $attachmentId,
                'label'         => (string) Arr::get($subtitle, 'label', Arr::get($subtitle, 'language', '')),
            ];
        }

        return [
            'deleted' => $deleted,
            'failed'  => $failed,
        ];
    }

    public static function canDeleteManagedSubtitleAttachment($attachmentId, $mediaId)
    {
        $attachmentId = absint($attachmentId);
        $mediaId = absint($mediaId);

        if (!$attachmentId || !$mediaId || !get_post($attachmentId)) {
            return false;
        }

        if (!current_user_can('delete_post', $attachmentId)) {
            return false;
        }

        $managedMediaId = absint(get_post_meta($attachmentId, self::GENERATED_ATTACHMENT_MEDIA_META, true));

        return $managedMediaId === $mediaId;
    }

    public static function canDeleteManagedStoryboardAttachment($attachmentId, $mediaId)
    {
        $attachmentId = absint($attachmentId);
        $mediaId = absint($mediaId);

        if (!$attachmentId || !$mediaId || !get_post($attachmentId)) {
            return false;
        }

        if (!current_user_can('delete_post', $attachmentId)) {
            return false;
        }

        $managedMediaId = absint(get_post_meta($attachmentId, self::GENERATED_STORYBOARD_MEDIA_META, true));

        return $managedMediaId === $mediaId;
    }
}
