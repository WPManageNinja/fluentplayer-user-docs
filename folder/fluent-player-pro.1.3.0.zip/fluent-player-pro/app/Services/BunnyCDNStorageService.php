<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayer\App\Helpers\Helper;
use FluentPlayerPro\App\Libraries\BunnyCDNStorage;
use FluentPlayer\Framework\Support\Arr;

class BunnyCDNStorageService
{
    const ALLOWED_VIDEO_EXTENSIONS = ['mp4', 'webm', 'mov', 'avi', 'mkv'];

    /**
     * File extensions accepted for upload to Bunny Storage: the video formats plus
     * the free plugin's filterable audio extensions (fluent_player/audio_extensions),
     * so audio files upload like video. Normalized lowercase + de-duplicated.
     *
     * @return string[]
     */
    public static function allowedUploadExtensions()
    {
        // method_exists (not class_exists): the free Helper always exists, but an older
        // free version lacks these methods — guard against a fatal if pro updates first.
        if (!method_exists(Helper::class, 'audioExtensions')) {
            return self::ALLOWED_VIDEO_EXTENSIONS;
        }

        $all = array_merge(self::ALLOWED_VIDEO_EXTENSIONS, Helper::audioExtensions());

        // Sanitize (denylist scriptable/executable) so a detection-oriented filter
        // can never widen what may be uploaded to the CDN.
        if (method_exists(Helper::class, 'sanitizeUploadExtensions')) {
            return Helper::sanitizeUploadExtensions($all);
        }

        return array_values(array_unique(array_map('strtolower', $all)));
    }

    /**
     * Get BunnyCDN Storage integration instance
     *
     * @return \FluentPlayer\App\Integrations\BunnyCDNStorageIntegration|\WP_Error
     */
    protected static function getIntegration()
    {
        $integrationClass = apply_filters('fluent_player/integrations', [])['bunnycdn_storage'] ?? null; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Base plugin hook

        if (!$integrationClass || !class_exists($integrationClass)) {
            return new \WP_Error('integration_not_found', __('BunnyCDN Storage integration not found', 'fluent-player-pro'));
        }

        return new $integrationClass();
    }

    /**
     * Get BunnyCDN storage settings
     *
     * @return array
     */
    public static function getSettings()
    {
        $integration = self::getIntegration();
        if (is_wp_error($integration)) {
            return [];
        }

        return $integration->getSettingsWithDefaults();
    }

    /**
     * Save BunnyCDN storage settings
     *
     * @param array $settings
     * @return array|\WP_Error
     */
    public static function saveSettings($settings)
    {
        $integration = self::getIntegration();
        if (is_wp_error($integration)) {
            return $integration;
        }

        return $integration->saveSettings($settings);
    }

    /**
     * Get storage instance
     *
     * @return BunnyCDNStorage|\WP_Error
     */
    protected static function getStorage()
    {
        $integration = self::getIntegration();
        if (is_wp_error($integration)) {
            return $integration;
        }

        if (!$integration->isEnabled()) {
            return new \WP_Error('disabled', __('BunnyCDN Storage integration is not enabled', 'fluent-player-pro'));
        }

        return $integration->getStorageClient();
    }

    /**
     * Get streaming URL for a file with HMAC signed token.
     *
     * @param string $fileName
     * @param int    $expiry Seconds until token expires (default 4 hours)
     * @return string
     */
    public static function getStreamingUrl($fileName, $expiry = 14400)
    {
        $restUrl = Arr::get(Helper::getRestInfo(), 'url');
        $streamUrl = "{$restUrl}/bunny/storage/stream";
        $expires = time() + $expiry;
        $token = self::generateStreamToken($fileName, $expires);

        return add_query_arg([
            'file_name' => $fileName,
            'expires'   => $expires,
            'token'     => $token,
        ], $streamUrl);
    }

    /**
     * Get or create the dedicated secret key for stream token signing.
     *
     * @return string
     */
    private static function getStreamSecret()
    {
        static $secret = null;
        if ($secret !== null) {
            return $secret;
        }

        $secret = get_option('flp_stream_secret');
        if (!$secret) {
            $secret = wp_generate_password(64, true, true);
            update_option('flp_stream_secret', $secret, false);
        }
        return $secret;
    }

    /**
     * Generate an HMAC token for a stream URL.
     *
     * @param string $fileName
     * @param int    $expires Unix timestamp
     * @return string
     */
    public static function generateStreamToken($fileName, $expires)
    {
        return hash_hmac('sha256', $fileName . '|' . $expires, self::getStreamSecret());
    }

    /**
     * Verify an HMAC stream token.
     *
     * @param string $fileName
     * @param string $expires
     * @param string $token
     * @return bool
     */
    public static function verifyStreamToken($fileName, $expires, $token)
    {
        if (!$expires || !$token || time() > (int) $expires) {
            return false;
        }
        $expected = self::generateStreamToken($fileName, (int) $expires);
        return hash_equals($expected, $token);
    }

    /**
     * Get parent path from current path
     *
     * @param string $currentPath
     * @return string
     */
    protected static function getParentPath($currentPath)
    {
        if (empty($currentPath)) {
            return '';
        }

        $currentPath = rtrim($currentPath, '/');
        $parts = explode('/', $currentPath);
        
        // Remove the last part
        array_pop($parts);
        
        return !empty($parts) ? implode('/', $parts) . '/' : '';
    }

    /**
     * Get CDN URL for a file if a pull zone hostname is configured
     * Returns empty string if no CDN hostname is set
     *
     * @param string $fileName
     * @param array $settings
     * @return string CDN URL or empty string
     */
    protected static function getCdnUrl($fileName, $settings)
    {
        $cdnHostname = Arr::get($settings, 'cdn_hostname');
        if (empty($cdnHostname)) {
            return '';
        }
        // Remove protocol if user included it
        $cdnHostname = preg_replace('#^https?://#', '', rtrim($cdnHostname, '/'));
        // Encode each path segment individually while preserving '/' separators
        $encodedFileName = implode('/', array_map('rawurlencode', explode('/', $fileName)));
        return "https://{$cdnHostname}/{$encodedFileName}";
    }

    /**
     * Add video to videos array if it's a valid video file
     *
     * @param array $item
     * @param array &$videos
     * @param array $settings
     * @param string $currentPath
     * @return void
     */
    /**
     * Whether a stored object should appear in the media picker: any allowed video or
     * audio file (denylisted/scriptable extensions excluded). Audio files live in the
     * same bucket as video and must be listable too.
     *
     * @param string $objectName
     * @return bool
     */
    /**
     * Detect real directory-traversal in a storage path/filename. Checks for a ".."
     * path *segment* (../ ..\ or a trailing ..), NOT any ".." substring — so a
     * legitimate filename with consecutive dots ("Best version..mp3") is allowed.
     *
     * @param string $path
     * @return bool
     */
    public static function hasPathTraversal($path)
    {
        $normalized = str_replace('\\', '/', (string) $path);
        foreach (explode('/', $normalized) as $segment) {
            if ($segment === '..') {
                return true;
            }
        }
        return false;
    }

    public static function isListableMediaFile($objectName)
    {
        $extension = strtolower(pathinfo((string) $objectName, PATHINFO_EXTENSION));
        return in_array($extension, self::allowedUploadExtensions(), true);
    }

    protected static function addVideoIfValid($item, &$videos, $settings, $currentPath)
    {
        // Include video AND audio files (audio lives in the same storage zone).
        if (!self::isListableMediaFile($item['ObjectName'])) {
            return;
        }

        $extension = strtolower(pathinfo($item['ObjectName'], PATHINFO_EXTENSION));
        $audioExtensions = method_exists(Helper::class, 'audioExtensions') ? Helper::audioExtensions() : [];

        $fileName = $currentPath . $item['ObjectName'];
        $streamingUrl = self::getStreamingUrl($fileName);
        // Use CDN URL if configured, otherwise fall back to proxy
        $cdnUrl = self::getCdnUrl($fileName, $settings);
        $publicUrl = $cdnUrl ?: $streamingUrl;

        $videos[] = [
            'id'           => $item['Guid'] ?? md5($fileName),
            'title'        => $fileName,
            'streamingUrl' => $streamingUrl,
            'url'          => $publicUrl,
            'size'         => $item['Length'] ?? 0,
            'updated_at'   => $item['LastChanged'] ?? '',
            'created_at'   => $item['DateCreated'] ?? '',
            'is_audio'     => in_array($extension, $audioExtensions, true),
        ];
    }

    /**
     * List videos from storage
     *
     * @param string $currentPath Current directory path
     * @return array|\WP_Error
     */
    public static function listVideos($currentPath = '')
    {
        try {
            $storage = self::getStorage();

            if (is_wp_error($storage)) {
                return $storage;
            }

            $settings = self::getSettings();

            // Get items in the current directory
            $items = $storage->getStorageObjects($currentPath);

            if (is_wp_error($items)) {
                return $items;
            }

            $directories = [];
            $videos = [];

            // Process items in the current directory
            foreach ($items as $item) {
                // If it's a directory, add to directories array
                if (Arr::isTrue($item, 'IsDirectory')) {
                    $directories[] = [
                        'id'         => Arr::get($item, 'Guid') ?? md5($currentPath . Arr::get($item, 'ObjectName')),
                        'name'       => Arr::get($item, 'ObjectName'),
                        'path'       => $currentPath . Arr::get($item, 'ObjectName') . '/',
                        'type'       => 'directory',
                        'updated_at' => Arr::get($item, 'LastChanged') ?? '',
                        'created_at' => Arr::get($item, 'DateCreated') ?? ''
                    ];
                    continue;
                }

                // Process video files
                self::addVideoIfValid($item, $videos, $settings, $currentPath);
            }

            return [
                'current_path' => $currentPath,
                'directories'  => $directories,
                'videos'       => $videos,
                'parent_path'  => self::getParentPath($currentPath)
            ];

        } catch (\Exception $e) {
            return new \WP_Error('list_error', $e->getMessage());
        }
    }

    /**
     * Get a single video info
     *
     * @param string $fileName
     * @return array|\WP_Error
     */
    public static function getVideo($fileName)
    {
        try {
            if (empty($fileName)) {
                return new \WP_Error('missing_filename', __('File name is required', 'fluent-player-pro'));
            }

            $storage = self::getStorage();
            
            if (is_wp_error($storage)) {
                return $storage;
            }
            
            $settings = self::getSettings();
            
            // Get the directory path and file name
            $pathInfo = pathinfo($fileName);
            $dirPath = !empty($pathInfo['dirname']) && $pathInfo['dirname'] !== '.'
                ? $pathInfo['dirname'] . '/'
                : '';
            $basename = Arr::get($pathInfo, 'basename');
            
            // Get items in the directory
            $items = $storage->getStorageObjects($dirPath);
            
            if (is_wp_error($items)) {
                return $items;
            }
            
            // Find the specific file
            $fileItem = null;
            foreach ($items as $item) {
                if (!Arr::isTrue($item, 'IsDirectory') && Arr::get($item, 'ObjectName') === $basename) {
                    $fileItem = $item;
                    break;
                }
            }
            
            if (!$fileItem) {
                return new \WP_Error('file_not_found', __('File not found', 'fluent-player-pro'));
            }
            
            // Use CDN URL if configured, otherwise fall back to proxy
            $streamingUrl = self::getStreamingUrl($fileName);
            $cdnUrl = self::getCdnUrl($fileName, $settings);
            $publicUrl = $cdnUrl ?: $streamingUrl;

            return [
                'id'           => Arr::get($fileItem, 'Guid') ?? md5($fileName),
                'title'        => $fileName,
                'streamingUrl' => $streamingUrl,
                'url'          => $publicUrl,
                'size'         => Arr::get($fileItem, 'Length') ?? 0,
                'updated_at'   => Arr::get($fileItem, 'LastChanged') ?? '',
                'created_at'   => Arr::get($fileItem, 'DateCreated') ?? ''
            ];
            
        } catch (\Exception $e) {
            return new \WP_Error('get_error', $e->getMessage());
        }
    }

    /**
     * Upload a video to BunnyCDN Storage
     *
     * @param int $attachmentId WordPress attachment ID
     * @param string $fileName Target file name (can include directory path)
     * @return array|\WP_Error
     */
    public static function uploadVideo($attachmentId, $fileName)
    {
        try {
            // Verify attachment exists and is a video
            $attachment = get_post($attachmentId);
            if (!$attachment || 'attachment' !== $attachment->post_type) {
                return new \WP_Error('invalid_attachment', __('Invalid attachment ID', 'fluent-player-pro'));
            }
            
            // Get the file path and check existence
            $filePath = get_attached_file($attachmentId);
            if (!$filePath || !file_exists($filePath)) {
                return new \WP_Error('attachment_not_found', __('WordPress attachment file not found', 'fluent-player-pro'));
            }
            
            // Check file size
            $fileSize = filesize($filePath);
            if ($fileSize === false || $fileSize === 0) {
                return new \WP_Error('empty_file', __('File is empty or cannot be read', 'fluent-player-pro'));
            }

            // Verify file extension (video + audio formats)
            $originalExtension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
            $allowedExtensions = self::allowedUploadExtensions();

            if (!in_array($originalExtension, $allowedExtensions, true)) {
                return new \WP_Error('invalid_extension',
                    sprintf(
                        /* translators: %s: comma-separated list of allowed file extensions */
                        __('Invalid file format. Allowed formats: %s', 'fluent-player-pro'),
                        implode(', ', $allowedExtensions)
                    ));
            }

            // Ensure the target filename has the correct extension
            $fileNameInfo = pathinfo($fileName);
            $fileNameExtension = isset($fileNameInfo['extension']) ? strtolower($fileNameInfo['extension']) : '';

            // If no extension or wrong extension, append/replace with the correct one
            if (empty($fileNameExtension) || $fileNameExtension !== $originalExtension) {
                // Preserve the directory part if it exists
                $dirName = dirname($fileName);
                $baseName = pathinfo($fileName, PATHINFO_FILENAME);

                if ($dirName && $dirName !== '.') {
                    $fileName = trailingslashit($dirName) . $baseName . '.' . $originalExtension;
                } else {
                    $fileName = $baseName . '.' . $originalExtension;
                }
            }

            $storage = self::getStorage();

            if (is_wp_error($storage)) {
                return $storage;
            }

            // Upload the file - fileName already includes any subdirectory
            $result = $storage->uploadFile($filePath, $fileName);

            if (is_wp_error($result)) {
                return $result;
            }

            // Use CDN URL if configured, otherwise fall back to proxy
            $settings = self::getSettings();
            $streamingUrl = self::getStreamingUrl($fileName);
            $cdnUrl = self::getCdnUrl($fileName, $settings);
            $publicUrl = $cdnUrl ?: $streamingUrl;

            return [
                'message' => 'Video uploaded successfully',
                'file'    => [
                    'title'        => $fileName,
                    'previewUrl'   => $publicUrl,
                    'url'          => $publicUrl,
                    'streamingUrl' => $streamingUrl,
                    'size'         => $fileSize,
                ]
            ];

        } catch (\Exception $e) {
            return new \WP_Error('upload_error', $e->getMessage());
        }
    }

    /**
     * Delete a video from storage
     *
     * @param string $fileName
     * @return array|\WP_Error
     */
    public static function deleteVideo($fileName = '')
    {
        try {
            if (empty($fileName)) {
                return new \WP_Error('missing_filename', __('File name is required', 'fluent-player-pro'));
            }

            $storage = self::getStorage();

            if (is_wp_error($storage)) {
                return $storage;
            }

            // Delete file
            $deleted = $storage->deleteObject($fileName);

            if (is_wp_error($deleted)) {
                return $deleted;
            }

            return [
                'message' => 'Video deleted successfully',
                'deleted' => true
            ];

        } catch (\Exception $e) {
            return new \WP_Error('delete_error', $e->getMessage());
        }
    }

    /**
     * Stream a video file directly from BunnyCDN Storage
     *
     * @param string $fileName The file name to stream
     * @return void
     */
    public static function streamVideo($fileName)
    {
        $storage = self::getStorage();

        if (is_wp_error($storage)) {
            // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- WP_Error message for exception
            throw new \Exception($storage->get_error_message());
        }

        // Stream the file directly (exits on success, throws on failure)
        $storage->getFile($fileName);
    }

    /**
     * Create a directory in BunnyCDN Storage
     *
     * @param string $path Directory path (can be nested like "parent/child")
     * @param string $currentPath Current directory path
     * @return array|\WP_Error
     */
    public static function createDirectory($path, $currentPath = '')
    {
        try {
            if (empty($path)) {
                return new \WP_Error('missing_path', __('Directory name is required', 'fluent-player-pro'));
            }

            $storage = self::getStorage();

            if (is_wp_error($storage)) {
                return $storage;
            }

            // Build full path
            $fullPath = $currentPath ? rtrim($currentPath, '/') . '/' . $path : $path;

            // Create directory
            $result = $storage->createDirectory($fullPath);

            if (is_wp_error($result)) {
                return $result;
            }

            return [
                'message' => 'Directory created successfully',
                'path' => $fullPath
            ];

        } catch (\Exception $e) {
            return new \WP_Error('create_error', $e->getMessage());
        }
    }

}
