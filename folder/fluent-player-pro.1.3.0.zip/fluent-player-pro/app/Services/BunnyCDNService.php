<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayerPro\App\Libraries\BunnyCDN;
use FluentPlayer\Framework\Support\Arr;

class BunnyCDNService
{
    /**
     * Get BunnyCDN Stream integration instance
     *
     * @return \FluentPlayer\App\Integrations\BunnyCDNStreamIntegration|\WP_Error
     */
    protected function getIntegration()
    {
        $integrationClass = apply_filters('fluent_player/integrations', [])['bunnycdn_stream'] ?? null; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Base plugin hook

        if (!$integrationClass || !class_exists($integrationClass)) {
            return new \WP_Error('integration_not_found', __('BunnyCDN Stream integration not found', 'fluent-player-pro'));
        }
        
        return new $integrationClass();
    }

    /**
     * Get library API key from stored settings
     *
     * @param string $libraryId
     * @param array $libraries
     * @return string
     */
    public function getLibraryApiKey($libraryId, $libraries)
    {
        foreach ($libraries as $library) {
            if (Arr::get($library, 'Id') == $libraryId) {
                return Arr::get($library, 'ApiKey', '');
            }
        }

        return '';
    }

    /**
     * Get stored pull zone hostname for a library from saved settings
     * Avoids extra API calls to fetch libraries + pull zones on every request
     *
     * @param string $libraryId
     * @param array $settings
     * @return string Hostname or empty string
     */
    protected function getStoredHostname($libraryId, $settings)
    {
        $libraries = Arr::get($settings, 'libraries', []);

        foreach ($libraries as $library) {
            if (Arr::get($library, 'Id') == $libraryId) {
                return Arr::get($library, 'Hostname', '');
            }
        }

        return '';
    }

    /**
     * Validate BunnyCDN settings and get client
     *
     * @param string $libraryId
     * @return array|\WP_Error
     */
    protected function validateAndGetClient($libraryId = null)
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return $integration;
        }
        
        if (!$integration->isEnabled()) {
            return new \WP_Error('disabled', __('BunnyCDN Stream integration is not enabled', 'fluent-player-pro'));
        }
        
        $client = $integration->getClient();
        if (is_wp_error($client)) {
            return $client;
        }
        
        $settings = $integration->getSettings();
        
        // If no library ID is provided, return client and settings
        if (!$libraryId) {
            return [
                'client' => $client,
                'settings' => $settings
            ];
        }
        
        // Get library API key from stored settings
        $libraries = Arr::get($settings, 'libraries', []);
        $libraryApiKey = $this->getLibraryApiKey($libraryId, $libraries);
        
        if (empty($libraryApiKey)) {
            return new \WP_Error('no_library_key', __('Library API key not found. Please refresh your BunnyCDN settings.', 'fluent-player-pro'));
        }
        
        return [
            'client' => $client,
            'settings' => $settings,
            'library_api_key' => $libraryApiKey
        ];
    }

    /**
     * Get videos from a specific library
     *
     * @param string $libraryId
     * @param array $params
     * @return array|\WP_Error
     */
    public function getVideos($libraryId, $params = [])
    {
        $result = $this->validateAndGetClient($libraryId);

        if (is_wp_error($result)) {
            return $result;
        }

        $client = Arr::get($result, 'client');
        $libraryApiKey = Arr::get($result, 'library_api_key');

        // Pass stored hostname to avoid extra API calls in the library
        $pullZoneUrl = $this->getStoredHostname($libraryId, Arr::get($result, 'settings', []));

        $videos = $client->getVideos($libraryId, $libraryApiKey, $params, $pullZoneUrl);

        if (is_wp_error($videos)) {
            return $videos;
        }

        return $videos;
    }

    /**
     * Get BunnyCDN libraries and setup stream
     *
     * @return array|\WP_Error
     */
    public function getLibraries()
    {
        $result = $this->validateAndGetClient();
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $client = $result['client'];
        $settings = $result['settings'];
        
        $libraries = $client->getLibraries();
        
        if (is_wp_error($libraries)) {
            return $libraries;
        }
        
        // Update settings with library data
        $this->updateLibrarySettings($settings, $libraries, $client);
        
        // Format libraries data to include only necessary information
        $formattedLibraries = [];
        foreach ($libraries as $library) {
            $formattedLibraries[] = [
                'id' => Arr::get($library, 'Id'),
                'name' => Arr::get($library, 'Name')
            ];
        }
        
        return [
            'items' => $formattedLibraries
        ];
    }

    /**
     * Update library settings in the database
     *
     * @param array $settings
     * @param array $libraries
     * @param BunnyCDN $client
     * @return void
     */
    private function updateLibrarySettings($settings, $libraries, $client)
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return;
        }
        
        $settings['libraries'] = [];
        foreach ($libraries as $library) {
            $pullZoneId = Arr::get($library, 'PullZoneId');
            
            $libraryData = [
                'Id' => Arr::get($library, 'Id'),
                'Name' => Arr::get($library, 'Name'),
                'ApiKey' => Arr::get($library, 'ApiKey')
            ];
            
            if ($pullZoneId) {
                $pullzone = $client->fetchPullZone($pullZoneId);
                
                if (!is_wp_error($pullzone)) {
                    // Store security key
                    $libraryData['SecurityKey'] = Arr::get($pullzone, 'ZoneSecurityKey');
                    
                    // Get hostname from pullzone
                    $hostnames = Arr::get($pullzone, 'Hostnames', []);
                    $default = '';
                    
                    foreach ($hostnames as $hostname) {
                        if (Arr::get($hostname, 'IsSystemHostname') && !empty(Arr::get($hostname, 'Value'))) {
                            $default = Arr::get($hostname, 'Value');
                            break;
                        }
                    }
                    
                    if (!empty($default)) {
                        $libraryData['Hostname'] = $default;
                    }
                }
            }
            
            $settings['libraries'][] = $libraryData;
        }
        
        // Save updated settings through the integration
        $integration->saveSettings($settings);
    }

    /**
     * Get collections from a specific library
     *
     * @param string $libraryId
     * @return array|\WP_Error
     */
    public function getCollections($libraryId)
    {
        $result = $this->validateAndGetClient($libraryId);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $client = $result['client'];
        $libraryApiKey = $result['library_api_key'];
        
        $collections = $client->getCollections($libraryId, $libraryApiKey);
        
        if (is_wp_error($collections)) {
            return $collections;
        }
        
        return [
            'items' => $collections
        ];
    }

    /**
     * Create a new collection in a library
     *
     * @param string $libraryId
     * @param string $name
     * @return array|\WP_Error
     */
    public function createCollection($libraryId, $name)
    {
        $result = $this->validateAndGetClient($libraryId);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $client = $result['client'];
        $libraryApiKey = $result['library_api_key'];
        
        return $client->createCollection($libraryId, $libraryApiKey, $name);
    }

    /**
     * Create a new video in a library
     *
     * @param string $libraryId
     * @param string $title
     * @param array $params
     * @return array|\WP_Error
     */
    public function createVideo($libraryId, $title, $params = [])
    {
        $result = $this->validateAndGetClient($libraryId);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        $client = $result['client'];
        $libraryApiKey = $result['library_api_key'];
        
        $videoParams = [
            'title' => $title
        ];
        
        if (!empty($params['collection_id'])) {
            $videoParams['collection_id'] = $params['collection_id'];
        }
        
        return $client->createVideo($libraryId, $libraryApiKey, $videoParams);
    }

    /**
     * Upload a video file to BunnyCDN
     * Uses curl streaming to avoid loading entire file into PHP memory
     *
     * @param string $libraryId
     * @param string $videoId
     * @param int $attachmentId
     * @return array|\WP_Error
     */
    /**
     * Bunny metaTags payload marking a video's source media type. Bunny transcodes
     * audio into a real video, erasing the audio/video distinction, so we persist the
     * source type (from the upload MIME) as a metaTag — the authoritative signal read
     * back by the block picker (detectStreamAudioHint) to render the audio player.
     *
     * @param bool $isAudio
     * @return array
     */
    public static function buildMediaTypeMetaTags($isAudio)
    {
        return [
            ['property' => 'fp_media_type', 'value' => $isAudio ? 'audio' : 'video'],
        ];
    }

    /**
     * Persist the source media type on the Bunny video as a metaTag. Best-effort:
     * detection has fallbacks, so a failure here must not fail the upload.
     *
     * @param string $libraryId
     * @param string $videoId
     * @param bool   $isAudio
     * @return array|\WP_Error
     */
    public function markVideoMediaType($libraryId, $videoId, $isAudio)
    {
        $result = $this->validateAndGetClient($libraryId);
        if (is_wp_error($result)) {
            return $result;
        }

        return $result['client']->updateVideo(
            $libraryId,
            $result['library_api_key'],
            $videoId,
            ['metaTags' => self::buildMediaTypeMetaTags($isAudio)]
        );
    }

    public function uploadVideo($libraryId, $videoId, $attachmentId)
    {
        $result = $this->validateAndGetClient($libraryId);

        if (is_wp_error($result)) {
            return $result;
        }

        $libraryApiKey = $result['library_api_key'];

        // Get the WordPress attachment file
        $filePath = get_attached_file($attachmentId);

        if (!$filePath || !file_exists($filePath)) {
            return new \WP_Error('file_not_found', __('WordPress attachment file not found', 'fluent-player-pro'));
        }

        // Check file size
        $fileSize = filesize($filePath);
        if ($fileSize === false || $fileSize === 0) {
            return new \WP_Error('empty_file', __('File is empty or cannot be read', 'fluent-player-pro'));
        }

        $url = "https://video.bunnycdn.com/library/{$libraryId}/videos/{$videoId}";

        // Open file handle for streaming upload (avoids loading into memory)
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        $fileHandle = fopen($filePath, 'r');
        if (!$fileHandle) {
            return new \WP_Error('read_error', __('Could not open file for reading', 'fluent-player-pro'));
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
        $ch = curl_init();
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_URL, $url);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_PUT, true);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_INFILE, $fileHandle);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_INFILESIZE, $fileSize);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'AccessKey: ' . $libraryApiKey,
            'Content-Type: application/octet-stream'
        ]);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_TIMEOUT, 600);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
        $responseBody = curl_exec($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_error
        $curlError = curl_error($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
        curl_close($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($fileHandle);

        if (!empty($curlError)) {
            return new \WP_Error('upload_error', sprintf(__('Upload failed: %s', 'fluent-player-pro'), $curlError));
        }

        if ($statusCode < 200 || $statusCode >= 300) {
            return new \WP_Error(
                'api_error',
                'BunnyCDN API error',
                [
                    'details' => $responseBody,
                    'http_code' => $statusCode
                ]
            );
        }

        return [
            'message' => 'Video uploaded successfully',
            'video_id' => $videoId
        ];
    }

    /**
     * Delete a video from BunnyCDN
     *
     * @param string $libraryId
     * @param string $videoId
     * @return array|\WP_Error
     */
    public function deleteVideo($libraryId, $videoId)
    {
        $result = $this->validateAndGetClient($libraryId);

        if (is_wp_error($result)) {
            return $result;
        }

        $client = $result['client'];
        $libraryApiKey = $result['library_api_key'];

        $result = $client->deleteVideo($libraryId, $libraryApiKey, $videoId);

        if (is_wp_error($result)) {
            return $result;
        }

        return [
            'message' => 'Video deleted successfully'
        ];
    }

    /**
     * Get a single video from BunnyCDN
     *
     * @param string $libraryId
     * @param string $videoId
     * @return array|\WP_Error
     */
    public function getVideo($libraryId, $videoId)
    {
        $result = $this->validateAndGetClient($libraryId);

        if (is_wp_error($result)) {
            return $result;
        }

        $client = Arr::get($result, 'client');
        $libraryApiKey = Arr::get($result, 'library_api_key');

        // Pass stored hostname to avoid extra API calls in the library
        $pullZoneUrl = $this->getStoredHostname($libraryId, Arr::get($result, 'settings', []));

        return $client->getVideo($libraryId, $libraryApiKey, $videoId, $pullZoneUrl);
    }

    /**
     * Update a collection in BunnyCDN
     *
     * @param string $libraryId
     * @param string $collectionId
     * @param string $name
     * @return array|\WP_Error
     */
    public function updateCollection($libraryId, $collectionId, $name)
    {
        $result = $this->validateAndGetClient($libraryId);

        if (is_wp_error($result)) {
            return $result;
        }

        $client = $result['client'];
        $libraryApiKey = $result['library_api_key'];

        return $client->updateCollection($libraryId, $libraryApiKey, $collectionId, $name);
    }

    /**
     * Delete a collection from BunnyCDN
     *
     * @param string $libraryId
     * @param string $collectionId
     * @return array|\WP_Error
     */
    public function deleteCollection($libraryId, $collectionId)
    {
        $result = $this->validateAndGetClient($libraryId);

        if (is_wp_error($result)) {
            return $result;
        }

        $client = $result['client'];
        $libraryApiKey = $result['library_api_key'];

        $deleted = $client->deleteCollection($libraryId, $libraryApiKey, $collectionId);

        if (is_wp_error($deleted)) {
            return $deleted;
        }

        return [
            'message' => 'Collection deleted successfully'
        ];
    }

    // ─── Signed URL Support ────────────────────────────────────────

    /**
     * Default token expiry in seconds (2 hours)
     */
    const SIGNED_URL_EXPIRY = 7200;

    /**
     * Compute a BunnyCDN URL-safe token from a hashable string
     *
     * Algorithm: Base64(SHA256(hashable)) with URL-safe encoding (+ → -, / → _, strip =)
     *
     * @param string $hashableBase The concatenated string to hash
     * @return string URL-safe token
     */
    private static function computeToken($hashableBase)
    {
        $token = hash('sha256', $hashableBase, true);
        $token = base64_encode($token);
        $token = strtr($token, '+/', '-_');

        return rtrim($token, '=');
    }

    /**
     * Remove Bunny pull-zone token query params so we never append a second token=…&expires=…
     * (e.g. when post meta already stores a previously signed URL and render signs again).
     *
     * @param string $url
     * @return string URL without token/expires query pairs; other query params preserved
     */
    private static function stripBunnyPullZoneTokenQuery($url)
    {
        $parsed = wp_parse_url($url);
        if ($parsed === false || empty($parsed['host']) || empty($parsed['query'])) {
            return $url;
        }

        $pairsOut = [];
        foreach (explode('&', $parsed['query']) as $pair) {
            if ($pair === '') {
                continue;
            }
            $parts = explode('=', $pair, 2);
            $key = rawurldecode($parts[0]);
            if (strcasecmp($key, 'token') === 0 || strcasecmp($key, 'expires') === 0) {
                continue;
            }
            $pairsOut[] = $pair;
        }

        $scheme = isset($parsed['scheme']) ? $parsed['scheme'] . '://' : '';
        $host = $parsed['host'];
        if (!empty($parsed['port'])) {
            $host .= ':' . $parsed['port'];
        }
        $path = isset($parsed['path']) ? $parsed['path'] : '';
        $rebuilt = $scheme . $host . $path;
        if (!empty($pairsOut)) {
            $rebuilt .= '?' . implode('&', $pairsOut);
        }
        if (!empty($parsed['fragment'])) {
            $rebuilt .= '#' . $parsed['fragment'];
        }

        return $rebuilt;
    }

    /**
     * Generate a signed/tokenized URL for BunnyCDN Token Authentication
     *
     * @param string $baseUrl Full URL to sign
     * @param string $securityKey Pull Zone token authentication key
     * @param int $expirationTime Unix timestamp when the token expires
     * @return string Signed URL with token and expires query params
     */
    public static function generateSignedUrl($baseUrl, $securityKey, $expirationTime)
    {
        $securityKey = trim($securityKey);
        if (empty($securityKey)) {
            return $baseUrl;
        }

        $baseUrl = self::stripBunnyPullZoneTokenQuery($baseUrl);

        $parsedUrl = wp_parse_url($baseUrl);
        if ($parsedUrl === false || !isset($parsedUrl['path'])) {
            return $baseUrl;
        }

        // BunnyCDN expects the decoded path in the hash (e.g., "/test 2/4.mp4" not "/test%202/4.mp4")
        $path = urldecode($parsedUrl['path']);
        $token = self::computeToken($securityKey . $path . $expirationTime);
        $separator = (strpos($baseUrl, '?') !== false) ? '&' : '?';

        return $baseUrl . $separator . 'token=' . $token . '&expires=' . $expirationTime;
    }

    /**
     * Whether the URL is the WordPress REST proxy for Bunny Storage (HMAC token in query).
     * CDN pull-zone signing must not be applied on top — it would add a second token= and
     * expires= and break playback.
     *
     * Matches both pretty permalinks (path contains the segment) and plain permalinks
     * (rest_route=.../bunny/storage/stream in the query string).
     *
     * @param string $url
     * @return bool
     */
    private static function isBunnyStorageRestStreamUrl($url)
    {
        if (!is_string($url) || $url === '') {
            return false;
        }

        return strpos($url, 'bunny/storage/stream') !== false;
    }

    /**
     * Generate a player/embed token for BunnyCDN Stream
     *
     * Used for DRM license and certificate endpoints. Different from CDN token auth:
     * hex SHA256 of (security_key + video_id + expiration), appended as query params.
     *
     * @param string $securityKey Pull Zone token authentication key
     * @param string $videoId Video GUID
     * @param int $expirationTime Unix timestamp
     * @return string Query string fragment: token={hex}&expires={timestamp}
     */
    public static function generatePlayerToken($securityKey, $videoId, $expirationTime)
    {
        $securityKey = trim($securityKey);
        if (empty($securityKey) || empty($videoId)) {
            return '';
        }

        $token = hash('sha256', $securityKey . $videoId . $expirationTime);

        return 'token=' . $token . '&expires=' . $expirationTime;
    }

    /**
     * Append player token query params to a URL
     *
     * @param string $url Base URL
     * @param string $tokenParams Token query string from generatePlayerToken()
     * @return string URL with token params
     */
    private static function appendPlayerToken($url, $tokenParams)
    {
        if (empty($tokenParams)) {
            return $url;
        }

        // Idempotent: the stored URL already carries a token (persisted at selection),
        // so strip any existing token/expires first — otherwise every render stacks
        // `?token=…&expires=…&token=…` and Bunny returns 403.
        $url = self::stripPlayerToken($url);

        // Keep the token in the query string, before any fragment.
        $fragment = '';
        $hashPos = strpos($url, '#');
        if ($hashPos !== false) {
            $fragment = substr($url, $hashPos);
            $url = substr($url, 0, $hashPos);
        }

        $separator = (strpos($url, '?') !== false) ? '&' : '?';

        return $url . $separator . $tokenParams . $fragment;
    }

    /**
     * Remove any `token` / `expires` query parameters (however many are stacked)
     * from a URL, preserving the path, other query params, and the fragment.
     *
     * @param string $url
     * @return string
     */
    private static function stripPlayerToken($url)
    {
        if (!is_string($url) || $url === '') {
            return $url;
        }

        $fragment = '';
        $hashPos = strpos($url, '#');
        if ($hashPos !== false) {
            $fragment = substr($url, $hashPos);
            $url = substr($url, 0, $hashPos);
        }

        $qPos = strpos($url, '?');
        if ($qPos === false) {
            return $url . $fragment;
        }

        $base = substr($url, 0, $qPos);
        $query = substr($url, $qPos + 1);

        $kept = [];
        foreach (explode('&', $query) as $pair) {
            if ($pair === '') {
                continue;
            }
            $key = strtolower(explode('=', $pair, 2)[0]);
            if ($key === 'token' || $key === 'expires') {
                continue;
            }
            $kept[] = $pair;
        }

        return $base . ($kept ? '?' . implode('&', $kept) : '') . $fragment;
    }

    /**
     * True when a Stream CDN URL belongs to this video (custom hostname or b-cdn.net) and needs embed token.
     *
     * @param string $url
     * @param string $videoGuid
     * @return bool
     */
    private static function streamAssetNeedsPlayerToken($url, $videoGuid)
    {
        if (!is_string($url) || $url === '' || !is_string($videoGuid) || $videoGuid === '') {
            return false;
        }
        if (strpos($url, 'http') !== 0) {
            return false;
        }

        // A pre-tokened URL still needs (re)signing — appendPlayerToken() strips the
        // stale/stacked token before applying a fresh one, so an existing `token=` is
        // no longer a reason to skip. Sign any asset under this video's GUID.
        return strpos($url, $videoGuid) !== false;
    }

    /**
     * Filter player settings to inject signed URLs for BunnyCDN Stream and Storage
     *
     * Follows the same pattern as MuxService::filterPlayerSettings — hooked into
     * fluent_player/player_settings and runs at render time.
     *
     * @param array $settings
     * @return array
     */
    public static function filterPlayerSettings($settings)
    {
        $provider = Arr::get($settings, 'provider', '');

        if ($provider === 'bunny') {
            return self::signBunnyStreamUrls($settings);
        }

        if ($provider === 'bunny_storage') {
            return self::signBunnyStorageUrls($settings);
        }

        return $settings;
    }

    /**
     * Sign BunnyCDN Stream URLs and inject DRM config
     *
     * Bunny Stream uses library-level Player Token Authentication, not CDN token auth.
     * Token = SHA256_HEX(ApiKey + videoId + expiry) — a single token valid for all
     * paths under the video GUID (playlist, sub-playlists, .ts segments, thumbnails).
     * This token is passed to hls.js so it can append it to all segment requests.
     *
     * @param array $settings Player settings with provider='bunny' and bunny.library_id/video_id
     * @return array
     */
    protected static function signBunnyStreamUrls($settings)
    {
        static $integrationSettings = null;

        if ($integrationSettings === null) {
            $integrationClass = apply_filters('fluent_player/integrations', [])['bunnycdn_stream'] ?? null;
            if (!$integrationClass || !class_exists($integrationClass)) {
                return $settings;
            }
            $integration = new $integrationClass();
            $integrationSettings = $integration->getSettings();
        }

        $libraryId = Arr::get($settings, 'bunny.library_id', '');
        $videoGuid = Arr::get($settings, 'bunny.video_id', '');
        $libraries = Arr::get($integrationSettings, 'libraries', []);

        // Find the library's API key (used for Player Token Auth)
        $libraryApiKey = '';
        foreach ($libraries as $library) {
            if (Arr::get($library, 'Id') == $libraryId) {
                $libraryApiKey = Arr::get($library, 'ApiKey', '');
                break;
            }
        }

        if (empty($libraryApiKey) || empty($videoGuid)) {
            return $settings;
        }

        // Token expiry must exceed video duration, otherwise playback cuts off mid-stream
        $duration = floatval(Arr::get($settings, 'duration', Arr::get($settings, 'bunny.duration', 0)));
        $expSeconds = max(self::SIGNED_URL_EXPIRY, intval(ceil($duration)) + 3600); // duration + 1 hour buffer
        $expirationTime = time() + $expSeconds;

        // Player token: SHA256_HEX(ApiKey + videoId + expiry)
        // A single token valid for all paths under the video GUID
        $tokenParams = self::generatePlayerToken($libraryApiKey, $videoGuid, $expirationTime);

        if (empty($tokenParams)) {
            return $settings;
        }

        // Sign HLS source URL
        $src = Arr::get($settings, 'src', '');
        if (!empty($src)) {
            $settings['src'] = self::appendPlayerToken($src, $tokenParams);

            // Pass the token query string to the frontend so hls.js can append it
            // to all relative sub-playlist and .ts segment requests
            $settings['bunny_token_query'] = $tokenParams;
        }

        // Sign poster image (any pull-zone hostname — not only *.b-cdn.net)
        $posterSrc = Arr::get($settings, 'posterSrc', '');
        if (!empty($posterSrc) && self::streamAssetNeedsPlayerToken($posterSrc, $videoGuid)) {
            $settings['posterSrc'] = self::appendPlayerToken($posterSrc, $tokenParams);
        }

        // Sign thumbnail/storyboard URL
        $thumbnails = Arr::get($settings, 'thumbnails', '');
        if (!empty($thumbnails) && self::streamAssetNeedsPlayerToken($thumbnails, $videoGuid)) {
            $settings['thumbnails'] = self::appendPlayerToken($thumbnails, $tokenParams);
        }

        // Sign MP4 fallback URLs (same embed token as HLS when pull zone requires it)
        $mp4Urls = Arr::get($settings, 'bunny.mp4_urls', []);
        if (is_array($mp4Urls) && !empty($mp4Urls)) {
            $signedMp4 = [];
            foreach ($mp4Urls as $u) {
                if (!is_string($u) || $u === '') {
                    $signedMp4[] = $u;
                    continue;
                }
                if (self::streamAssetNeedsPlayerToken($u, $videoGuid)) {
                    $signedMp4[] = self::appendPlayerToken($u, $tokenParams);
                } else {
                    $signedMp4[] = $u;
                }
            }
            if (!isset($settings['bunny']) || !is_array($settings['bunny'])) {
                $settings['bunny'] = [];
            }
            $settings['bunny']['mp4_urls'] = $signedMp4;
        }

        return $settings;
    }

    /**
     * Sign BunnyCDN Storage URLs (CDN pull zone URL)
     *
     * @param array $settings
     * @return array
     */
    protected static function signBunnyStorageUrls($settings)
    {
        static $integrationSettings = null;

        if ($integrationSettings === null) {
            $integrationClass = apply_filters('fluent_player/integrations', [])['bunnycdn_storage'] ?? null;
            if (!$integrationClass || !class_exists($integrationClass)) {
                return $settings;
            }
            $integration = new $integrationClass();
            $integrationSettings = $integration->getSettings();
        }

        $securityKey = Arr::get($integrationSettings, 'cdn_security_key', '');
        if (empty($securityKey)) {
            return $settings;
        }

        // Token expiry must exceed video duration, otherwise playback cuts off mid-stream
        $duration = floatval(Arr::get($settings, 'duration', 0));
        $expSeconds = max(self::SIGNED_URL_EXPIRY, intval(ceil($duration)) + 3600); // duration + 1 hour buffer
        $expirationTime = time() + $expSeconds;

        // Sign the main source URL (pull zone only — not the signed REST proxy)
        $src = Arr::get($settings, 'src', '');
        if (!empty($src) && !self::isBunnyStorageRestStreamUrl($src)) {
            $settings['src'] = self::generateSignedUrl($src, $securityKey, $expirationTime);
        }

        // Sign the bunny_storage.url if present (same rule: skip REST stream proxy)
        $storageUrl = Arr::get($settings, 'bunny_storage.url', '');
        if (!empty($storageUrl) && !self::isBunnyStorageRestStreamUrl($storageUrl)) {
            if (!isset($settings['bunny_storage']) || !is_array($settings['bunny_storage'])) {
                $settings['bunny_storage'] = [];
            }
            $settings['bunny_storage']['url'] = self::generateSignedUrl($storageUrl, $securityKey, $expirationTime);
        }

        return $settings;
    }

    /**
     * Update a video in BunnyCDN
     *
     * @param string $libraryId
     * @param string $videoId
     * @param array $data
     * @return array|\WP_Error
     */
    public function updateVideo($libraryId, $videoId, $data)
    {
        $result = $this->validateAndGetClient($libraryId);

        if (is_wp_error($result)) {
            return $result;
        }

        $client = $result['client'];
        $libraryApiKey = $result['library_api_key'];

        return $client->updateVideo($libraryId, $libraryApiKey, $videoId, $data);
    }
}
