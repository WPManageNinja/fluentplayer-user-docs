<?php

namespace FluentPlayerPro\App\Services;

if (!defined('ABSPATH')) {
    exit;
}

use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Libraries\Gumlet;

/**
 * Orchestrates the Gumlet integration: lists/normalizes assets, imports uploads,
 * polls transcode status, renames/deletes, and rewrites playback URLs at render
 * time (signing private assets — see filterPlayerSettings).
 */
class GumletService
{
    /**
     * @var \FluentPlayerPro\App\Integrations\GumletIntegration|\WP_Error|null
     */
    private $cachedIntegration = null;

    /**
     * @return \FluentPlayerPro\App\Integrations\GumletIntegration|\WP_Error
     */
    protected function getIntegration()
    {
        if ($this->cachedIntegration !== null) {
            return $this->cachedIntegration;
        }

        // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Base plugin hook
        $integrationClass = apply_filters('fluent_player/integrations', [])['gumlet'] ?? null;

        if (!$integrationClass || !class_exists($integrationClass)) {
            $this->cachedIntegration = new \WP_Error('integration_not_found', __('Gumlet integration not found', 'fluent-player-pro'));
            return $this->cachedIntegration;
        }

        $this->cachedIntegration = new $integrationClass();
        return $this->cachedIntegration;
    }

    /**
     * @return array Integration settings (empty array when unavailable).
     */
    protected function getSettings()
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return [];
        }
        return $integration->getSettings();
    }

    /**
     * @return array|\WP_Error ['client' => Gumlet, 'settings' => array]
     */
    protected function validateAndGetClient()
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return $integration;
        }

        if (!$integration->isEnabled()) {
            return new \WP_Error('disabled', __('Gumlet integration is not enabled', 'fluent-player-pro'));
        }

        $client = $integration->getClient();
        if (is_wp_error($client)) {
            return $client;
        }

        return ['client' => $client, 'settings' => $integration->getSettings()];
    }

    // ─── Assets (VOD) ────────────────────────────────────────────────

    /**
     * @param array $params ['offset' => int, 'size' => int]
     * @return array|\WP_Error ['items' => array, 'totalItems' => int, 'hasMore' => bool]
     */
    public function listVideos($params = [])
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $workspaceId = Arr::get($result['settings'], 'workspace_id', '');
        if (empty($workspaceId)) {
            return new \WP_Error('missing_workspace', __('Gumlet Workspace ID is not configured', 'fluent-player-pro'));
        }

        $offset = max(0, intval(Arr::get($params, 'offset', 0)));
        $size = min(100, max(1, intval(Arr::get($params, 'size', 20))));

        /** @var Gumlet $client */
        $client = $result['client'];
        $response = $client->listAssets($workspaceId, ['offset' => $offset, 'size' => $size]);
        if (is_wp_error($response)) {
            return $response;
        }

        $rawAssets = Arr::get($response, 'all_assets', []);
        $items = [];
        foreach ($rawAssets as $asset) {
            if (is_array($asset)) {
                $items[] = $this->normalizeAsset($asset);
            }
        }

        // When signed URLs are enabled, private-asset thumbnails also require a
        // token or the editor grid posters 401. Sign them for the list response.
        $settings = $result['settings'];
        if (Arr::isTrue($settings, 'enable_signed_urls')) {
            $secret = (string) Arr::get($settings, 'signing_secret', '');
            if ($secret !== '') {
                $expires = time() + 7200;
                foreach ($items as &$item) {
                    if (!empty($item['is_private']) && self::isGumletPlaybackUrl($item['thumbnail'])) {
                        $signed = self::signPlaybackUrl($item['thumbnail'], $secret, $expires);
                        if ($signed !== '') {
                            $item['thumbnail'] = $signed;
                        }
                    }
                }
                unset($item);
            }
        }

        $total = intval(Arr::get($response, 'total_asset_count', count($items)));
        $currentOffset = intval(Arr::get($response, 'current_offset', $offset + count($items)));

        return [
            'items'      => $items,
            'totalItems' => $total,
            'hasMore'    => $currentOffset < $total,
        ];
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function getVideo($assetId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getAsset($assetId);
        if (is_wp_error($response)) {
            return $response;
        }

        return $this->normalizeAsset($response);
    }

    /**
     * Import a media file into Gumlet from a publicly reachable URL.
     * NOTE: Gumlet's servers fetch the URL, so it must be reachable from the
     * public internet (a local dev host will stay stuck in a processing/error
     * state — the block UI surfaces that).
     *
     * @param string $inputUrl
     * @param string $title
     * @return array|\WP_Error normalized asset
     */
    public function importFromUrl($inputUrl, $title = '')
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $body = self::buildImportBody($inputUrl, $title, $result['settings']);
        if (empty($body)) {
            return new \WP_Error('missing_input', __('A source URL is required to import into Gumlet', 'fluent-player-pro'));
        }

        $response = $result['client']->createAsset($body);
        if (is_wp_error($response)) {
            return $response;
        }

        return $this->normalizeAsset($response);
    }

    /**
     * Build the Gumlet create-asset payload for an import-from-URL upload.
     * Pure (no HTTP) so the request contract is unit-testable. Collection falls
     * back to the workspace; title is omitted when blank (Gumlet derives one).
     *
     * @param string $inputUrl
     * @param string $title
     * @param array  $settings Integration settings (workspace_id, collection_id).
     * @return array Empty array when the input URL is blank.
     */
    protected static function buildImportBody($inputUrl, $title, $settings)
    {
        $inputUrl = trim((string) $inputUrl);
        if ($inputUrl === '') {
            return [];
        }

        $collectionId = Arr::get($settings, 'collection_id', '');
        if (empty($collectionId)) {
            $collectionId = Arr::get($settings, 'workspace_id', '');
        }

        $body = [
            'input'         => $inputUrl,
            'collection_id' => $collectionId,
            'format'        => 'ABR',
        ];

        $title = trim((string) $title);
        if ($title !== '') {
            $body['title'] = $title;
        }

        return $body;
    }

    /**
     * Create a direct upload: returns a presigned S3 URL the browser PUTs the
     * file bytes to, plus the new asset id. Unlike import-from-URL this needs no
     * inbound reachability, so it works on local/private sites too.
     *
     * @param string $title
     * @return array|\WP_Error ['id' => assetId, 'upload_url' => presignedUrl]
     */
    public function createDirectUpload($title = '')
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $body = self::buildDirectUploadBody($title, $result['settings']);
        if (empty($body)) {
            return new \WP_Error('missing_workspace', __('Gumlet Collection ID is not configured', 'fluent-player-pro'));
        }

        $response = $result['client']->createDirectUpload($body);
        if (is_wp_error($response)) {
            return $response;
        }

        $normalized = self::normalizeDirectUpload($response);
        if (empty($normalized['upload_url']) || empty($normalized['id'])) {
            return new \WP_Error('upload_url_missing', __('Gumlet did not return an upload URL', 'fluent-player-pro'));
        }

        return $normalized;
    }

    /**
     * Upload a WP media-library attachment to Gumlet entirely server-side
     * (the browser only sends the attachment id — matches the Cloudflare Stream
     * flow). Creates a direct-upload target, then streams the local file to the
     * presigned URL from the server, so nothing is buffered/re-transferred in
     * the browser and it works even on non-public sites.
     *
     * @param int $attachmentId
     * @return array|\WP_Error ['id' => assetId]
     */
    public function uploadFromAttachment($attachmentId)
    {
        $attachmentId = absint($attachmentId);
        if (!$attachmentId) {
            return new \WP_Error('invalid_attachment', __('A valid attachment is required', 'fluent-player-pro'));
        }

        $filePath = get_attached_file($attachmentId);
        if (!$filePath || !file_exists($filePath)) {
            return new \WP_Error('attachment_not_found', __('The attachment file could not be found', 'fluent-player-pro'));
        }

        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        /** @var Gumlet $client */
        $client = $result['client'];

        $body = self::buildDirectUploadBody((string) get_the_title($attachmentId), $result['settings']);
        if (empty($body)) {
            return new \WP_Error('missing_workspace', __('Gumlet Collection ID is not configured', 'fluent-player-pro'));
        }

        $response = $client->createDirectUpload($body);
        if (is_wp_error($response)) {
            return $response;
        }

        $normalized = self::normalizeDirectUpload($response);
        if (empty($normalized['upload_url']) || empty($normalized['id'])) {
            return new \WP_Error('upload_url_missing', __('Gumlet did not return an upload URL', 'fluent-player-pro'));
        }

        $put = $client->putFile($normalized['upload_url'], $filePath);
        if (is_wp_error($put)) {
            return $put;
        }

        // Bytes are in Gumlet's storage; the block polls transcode status by id.
        return ['id' => $normalized['id']];
    }

    /**
     * @param string $title
     * @param array  $settings
     * @return array Empty when no workspace/collection is configured.
     */
    protected static function buildDirectUploadBody($title, $settings)
    {
        $workspaceId = Arr::get($settings, 'workspace_id', '');
        if (empty($workspaceId)) {
            $workspaceId = Arr::get($settings, 'collection_id', '');
        }
        if (empty($workspaceId)) {
            return [];
        }

        $body = [
            'workspace_id' => $workspaceId,
            'format'       => 'ABR',
        ];

        $title = trim((string) $title);
        if ($title !== '') {
            $body['title'] = $title;
        }

        return $body;
    }

    /**
     * @param array $response
     * @return array ['id' => assetId, 'upload_url' => presignedUrl]
     */
    protected static function normalizeDirectUpload($response)
    {
        return [
            'id'         => (string) Arr::get($response, 'asset_id', Arr::get($response, 'id', '')),
            'upload_url' => (string) Arr::get($response, 'upload_url', ''),
        ];
    }

    /**
     * Poll transcode status for the block editor progress UI.
     *
     * @param string $assetId
     * @return array|\WP_Error normalized asset (status/progress/ready/error/playback_url)
     */
    public function getAssetStatus($assetId)
    {
        return $this->getVideo($assetId);
    }

    /**
     * @param string $assetId
     * @param string $title
     * @return array|\WP_Error
     */
    public function renameVideo($assetId, $title)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->updateAsset($assetId, ['title' => $title]);
        if (is_wp_error($response)) {
            return $response;
        }

        return is_array($response) ? $this->normalizeAsset($response) : ['success' => true];
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function deleteVideo($assetId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->deleteAsset($assetId);
        if (is_wp_error($response)) {
            return $response;
        }

        return ['success' => true];
    }

    // ─── Live streaming ──────────────────────────────────────────────

    const LIVE_DEFAULT_RESOLUTION = ['720p'];
    const ALLOWED_LIVE_RESOLUTIONS = ['240p', '360p', '480p', '540p', '720p', '1080p'];

    /**
     * Create a live stream. The live source comes from integration settings
     * (a Gumlet "live video source" — distinct from the VOD collection).
     *
     * @param array $params ['title' => string, 'resolution' => string[]]
     * @return array|\WP_Error normalized live asset
     */
    public function createLiveStream($params = [])
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $sourceId = (string) Arr::get($result['settings'], 'live_source_id', '');
        if ($sourceId === '') {
            return new \WP_Error(
                'missing_live_source',
                __('A Gumlet Live Source ID is required. Add it in the Gumlet integration settings.', 'fluent-player-pro')
            );
        }

        $body = self::buildLiveBody($sourceId, (array) Arr::get($params, 'resolution', []), (string) Arr::get($params, 'title', ''));
        if (empty($body)) {
            return new \WP_Error('invalid_live_request', __('Could not build the live stream request', 'fluent-player-pro'));
        }

        $response = $result['client']->createLiveAsset($body);
        if (is_wp_error($response)) {
            return $response;
        }

        // Activate the RTMP ingest immediately so the encoder (OBS) can connect —
        // Gumlet won't accept a broadcast until the stream is started. Fall back
        // to the created (un-started) asset if start fails, so the caller still
        // gets the connection details.
        $assetId = (string) Arr::get($response, 'live_asset_id', '');
        if ($assetId !== '') {
            $started = $result['client']->startLiveStream($assetId);
            if (!is_wp_error($started) && is_array($started)) {
                $response = $started;
            }
        }

        return $this->normalizeLiveAsset($response);
    }

    /**
     * @param string $liveAssetId
     * @return array|\WP_Error
     */
    public function getLiveStatus($liveAssetId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getLiveAsset($liveAssetId);
        if (is_wp_error($response)) {
            return $response;
        }

        return $this->normalizeLiveAsset($response);
    }

    /**
     * @param string $liveAssetId
     * @return array|\WP_Error
     */
    public function deleteLiveStream($liveAssetId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        /** @var Gumlet $client */
        $client = $result['client'];

        $response = $client->deleteLiveAsset($liveAssetId);
        if (!is_wp_error($response)) {
            return ['success' => true];
        }

        // A started stream (preparing/live) cannot be deleted until it is
        // completed (ended). End it, then retry the delete so the single
        // per-account live slot is freed.
        $client->completeLiveStream($liveAssetId);
        $retry = $client->deleteLiveAsset($liveAssetId);
        if (is_wp_error($retry)) {
            return $retry;
        }

        return ['success' => true];
    }

    /**
     * Build the create-live-asset request body. Pure (no HTTP) so the contract
     * is unit-testable. Resolution falls back to a sensible default; title is
     * omitted when blank.
     *
     * @param string   $sourceId
     * @param string[] $resolution
     * @param string   $title
     * @return array Empty when the live source is missing.
     */
    protected static function buildLiveBody($sourceId, $resolution, $title)
    {
        $sourceId = trim((string) $sourceId);
        if ($sourceId === '') {
            return [];
        }

        $resolution = array_values(array_filter((array) $resolution, function ($r) {
            return in_array($r, self::ALLOWED_LIVE_RESOLUTIONS, true);
        }));
        if (empty($resolution)) {
            $resolution = self::LIVE_DEFAULT_RESOLUTION;
        }

        $body = [
            'live_source_id' => $sourceId,
            'resolution'     => $resolution,
        ];

        $title = trim((string) $title);
        if ($title !== '') {
            $body['title'] = $title;
        }

        return $body;
    }

    /**
     * When a live broadcast has completed, point playback at the recording (VOD)
     * instead of the stale live URL. Pure (given a fetched status) so it is
     * unit-testable.
     *
     * @param array      $settings
     * @param array|null $liveStatus normalized live asset (status, recording_playback_url)
     * @return array
     */
    protected static function applyLiveRecordingSwap($settings, $liveStatus)
    {
        if (!is_array($liveStatus)) {
            return $settings;
        }

        $completed = in_array((string) Arr::get($liveStatus, 'status', ''), ['complete', 'completed', 'ended'], true);
        $recordingUrl = (string) Arr::get($liveStatus, 'recording_playback_url', '');

        if ($completed && $recordingUrl !== '') {
            $settings['src'] = $recordingUrl;
            $settings['streamType'] = 'on-demand';
        }

        return $settings;
    }

    /**
     * Fetch live-asset status with a short transient cache so render doesn't hit
     * the API on every load. A completed stream is cached longer (its recording
     * URL is stable); a running stream briefly.
     *
     * @param string $liveAssetId
     * @return array|null
     */
    protected function getCachedLiveStatus($liveAssetId)
    {
        $cacheKey = 'flp_gumlet_live_' . md5($liveAssetId);
        $cached = get_transient($cacheKey);
        if (is_array($cached)) {
            return $cached;
        }

        $status = $this->getLiveStatus($liveAssetId);
        if (is_wp_error($status)) {
            return null;
        }

        $completed = in_array((string) Arr::get($status, 'status', ''), ['complete', 'completed', 'ended'], true);
        set_transient($cacheKey, $status, $completed ? DAY_IN_SECONDS : 30);

        return $status;
    }

    /**
     * Flatten a Gumlet live-asset response into a block-friendly record.
     *
     * @param array $asset
     * @return array
     */
    protected function normalizeLiveAsset($asset)
    {
        $status = (string) Arr::get($asset, 'status', '');
        // Gumlet reports "created"/"disconnected" when idle; a connected encoder
        // shows "connected"/"active"/"live".
        $isLive = in_array($status, ['connected', 'active', 'live', 'ready'], true);

        // Gumlet's ingest URL is rtmp://<host>/app/<stream_key>. OBS wants the
        // Server (everything up to /app) and the Stream Key separately.
        $streamUrl = (string) Arr::get($asset, 'stream_url', '');
        $rtmpServerUrl = '';
        if ($streamUrl !== '' && ($pos = strrpos($streamUrl, '/')) !== false) {
            $rtmpServerUrl = substr($streamUrl, 0, $pos);
        }

        return [
            'live_asset_id'          => (string) Arr::get($asset, 'live_asset_id', ''),
            'live_source_id'         => (string) Arr::get($asset, 'live_video_source_id', ''),
            'stream_url'             => $streamUrl,
            'rtmp_server_url'        => $rtmpServerUrl,
            'stream_key'             => (string) Arr::get($asset, 'stream_key', ''),
            'playback_url'           => (string) Arr::get($asset, 'output.playback_url', ''),
            'recording_playback_url' => (string) Arr::get($asset, 'output.recording_playback_url', ''),
            'vod_asset_id'           => (string) Arr::get($asset, 'vod_asset_id', ''),
            'status'                 => $status,
            'is_live'                => $isLive,
            'title'                  => (string) Arr::get($asset, 'input.title', Arr::get($asset, 'title', '')),
            'resolution'             => (array) Arr::get($asset, 'input.resolution', []),
        ];
    }

    // ─── Normalization ───────────────────────────────────────────────

    /**
     * Flatten a Gumlet asset (list or get shape) into a block-friendly record.
     *
     * @param array $asset
     * @return array
     */
    protected function normalizeAsset($asset)
    {
        $status = (string) Arr::get($asset, 'status', '');
        $isReady = ($status === 'ready');
        $isError = in_array($status, ['errored', 'error', 'failed'], true);

        $isPrivate = (Arr::get($asset, 'access_control', '') === 'private')
            || (bool) Arr::get($asset, 'access_controls.private', false);

        $thumbnails = Arr::get($asset, 'output.thumbnail_url', []);
        $thumbnail = '';
        if (is_array($thumbnails) && !empty($thumbnails)) {
            $thumbnail = (string) $thumbnails[0];
        } elseif (is_string($thumbnails)) {
            $thumbnail = $thumbnails;
        }

        $error = null;
        if ($isError) {
            $error = (string) Arr::get(
                $asset,
                'error_message',
                __('Video processing failed on Gumlet. Check that the source is reachable and valid.', 'fluent-player-pro')
            );
        }

        // Gumlet transcodes audio-only sources with no video renditions. Its own
        // metadata is the authoritative signal here (the extension-less HLS carries
        // none), so the list/re-select path can render audio without depending on
        // the source MIME captured only at upload time.
        $isAudio = (bool) Arr::get($asset, 'input.transformations.audio_only', false);
        if (!$isAudio) {
            $videoRenditions = Arr::get($asset, 'output.storage_details.video', []);
            $audioRenditions = Arr::get($asset, 'output.storage_details.audio', []);
            $isAudio = empty($videoRenditions) && !empty($audioRenditions);
        }

        return [
            'id'           => (string) Arr::get($asset, 'asset_id', ''),
            'title'        => (string) Arr::get($asset, 'input.title', Arr::get($asset, 'title', '')),
            'status'       => $status,
            'progress'     => intval(Arr::get($asset, 'progress', $isReady ? 100 : 0)),
            'duration'     => floatval(Arr::get($asset, 'input.duration', Arr::get($asset, 'duration', 0))),
            'thumbnail'    => $thumbnail,
            'playback_url' => (string) Arr::get($asset, 'output.playback_url', ''),
            'is_private'   => $isPrivate,
            'is_audio'     => $isAudio,
            'ready'        => $isReady,
            'error'        => $error,
        ];
    }

    // ─── Render-time URL rewriting ───────────────────────────────────

    /**
     * Hooked on fluent_player/player_settings. For public Gumlet assets the
     * stored src (the public m3u8) is already correct, so this is a passthrough.
     * Private assets are signed here so unsigned URLs never reach page JS.
     *
     * @param array $settings
     * @return array
     */
    public static function filterPlayerSettings($settings)
    {
        $provider = Arr::get($settings, 'provider', '');
        if ($provider !== 'gumlet' && $provider !== 'gumlet_live') {
            return $settings;
        }

        static $service = null;
        if ($service === null) {
            $service = new self();
        }

        // Live: once the broadcast has ended, Gumlet keeps the (stale) live URL
        // serving but the real content is the recording (VOD). Swap the src to
        // the recording so the frontend plays the finished video, not the dead
        // live stream.
        if ($provider === 'gumlet_live') {
            $liveAssetId = (string) Arr::get($settings, 'gumlet.asset_id', '');
            if ($liveAssetId !== '') {
                $status = $service->getCachedLiveStatus($liveAssetId);
                $settings = self::applyLiveRecordingSwap($settings, $status);
                // A swapped-in recording plays as a normal VOD.
                if (Arr::get($settings, 'streamType') === 'on-demand') {
                    $provider = 'gumlet';
                }
            }
        }

        // Only private assets need signing.
        if (!Arr::isTrue($settings, 'gumlet.is_private')) {
            return $settings;
        }

        $integrationSettings = $service->getSettings();

        if (!Arr::isTrue($integrationSettings, 'enable_signed_urls')) {
            return $settings;
        }
        $secret = (string) Arr::get($integrationSettings, 'signing_secret', '');
        if ($secret === '') {
            return $settings;
        }

        // Token must outlive the video; give a generous buffer over the duration.
        $duration = floatval(Arr::get($settings, 'gumlet.duration', Arr::get($settings, 'duration', 0)));
        $expires = time() + max(7200, (int) ceil($duration) + 3600);

        return self::applySignedUrls($settings, $secret, $expires);
    }

    /**
     * Sign the src (HLS manifest) and posterSrc for a private Gumlet asset.
     * Pure (given a secret + expiry) so it is unit-testable. Non-Gumlet URLs are
     * left untouched. Requesting the signed main.m3u8 makes Gumlet propagate
     * valid tokens to the child playlists/segments automatically.
     *
     * @param array  $settings
     * @param string $secretB64
     * @param int    $expires   Unix timestamp (seconds).
     * @return array
     */
    protected static function applySignedUrls($settings, $secretB64, $expires)
    {
        $src = (string) Arr::get($settings, 'src', '');
        if (self::isGumletPlaybackUrl($src)) {
            $signed = self::signPlaybackUrl($src, $secretB64, $expires);
            if ($signed !== '') {
                $settings['src'] = $signed;
            }
        }

        $poster = (string) Arr::get($settings, 'posterSrc', '');
        if (self::isGumletPlaybackUrl($poster)) {
            $signedPoster = self::signPlaybackUrl($poster, $secretB64, $expires);
            if ($signedPoster !== '') {
                $settings['posterSrc'] = $signedPoster;
            }
        }

        return $settings;
    }

    /**
     * @param string $url
     * @return bool
     */
    protected static function isGumletPlaybackUrl($url)
    {
        return is_string($url) && $url !== ''
            && (strpos($url, 'video.gumlet.io') !== false || strpos($url, 'stream.gumlet.io') !== false);
    }

    /**
     * Generate a Gumlet signed playback URL.
     *
     * Matches Gumlet's documented algorithm verbatim (Video Protection / signed
     * URLs — PHP equivalent):
     *   $key   = base64_decode($signSecret);
     *   $token = hash_hmac('sha1', $url_slice23 . $expires, $key);   // path + expires
     *   $url   . '?token=' . $token . '&expires=' . $expires;
     * (url.slice(23) strips "https://video.gumlet.io" → the path.)
     *
     * key     = base64_decode(signSecret)
     * message = <path> . <expires>   (path = URL without scheme/host/query)
     * token   = HMAC-SHA1(key, message) hex
     * result  = <url without query> ?token=<token>&expires=<expires>
     *
     * @param string $url
     * @param string $secretB64 Base64-encoded signing secret from Gumlet.
     * @param int    $expires   Unix timestamp (seconds).
     * @return string Empty string when url/secret is missing or the secret is not valid base64.
     */
    public static function signPlaybackUrl($url, $secretB64, $expires)
    {
        $url = preg_replace('/[?#].*$/', '', (string) $url);
        if ($url === '' || (string) $secretB64 === '') {
            return '';
        }

        $parts = wp_parse_url($url);
        $path = isset($parts['path']) ? $parts['path'] : '';
        if ($path === '') {
            return '';
        }

        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Gumlet signing secret is base64-encoded per their spec
        $key = base64_decode($secretB64, true);
        if ($key === false || $key === '') {
            return '';
        }

        $token = hash_hmac('sha1', $path . $expires, $key);

        return $url . '?token=' . $token . '&expires=' . $expires;
    }
}
