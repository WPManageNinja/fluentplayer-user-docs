<?php

namespace FluentPlayerPro\App\Services;

if (!defined('ABSPATH')) exit;

use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Integrations\CloudflareStreamIntegration;
use FluentPlayerPro\App\Libraries\CloudflareStream;

/**
 * Business logic for the Cloudflare Stream provider: create browser-direct
 * uploads, poll transcode status, list/normalise videos. Pure helpers
 * (buildHlsUrl, normalizeVideo) are network-free and unit-tested; the rest wrap
 * the CloudflareStream client with the saved integration settings.
 */
class CloudflareStreamService
{
    /** Adaptive-HLS manifest URL for a video uid on the account's customer subdomain. */
    public static function buildHlsUrl($uid, $customerSubdomain)
    {
        $uid = trim((string) $uid);
        $sub = rtrim(trim((string) $customerSubdomain), '/');
        if ($uid === '' || $sub === '') {
            return '';
        }
        return 'https://' . $sub . '/' . $uid . '/manifest/video.m3u8';
    }

    /** Map a Cloudflare Stream video object to the fields the editor/media needs. */
    public static function normalizeVideo($video, $customerSubdomain = '')
    {
        $uid = (string) Arr::get($video, 'uid', '');
        $hls = Arr::get($video, 'playback.hls');
        if (!$hls) {
            $hls = self::buildHlsUrl($uid, $customerSubdomain);
        }

        $state = (string) Arr::get($video, 'status.state', Arr::get($video, 'readyToStream') ? 'ready' : 'queued');

        return [
            'uid'                 => $uid,
            'name'                => (string) Arr::get($video, 'meta.name', ''),
            'hls'                 => $hls,
            'thumbnail'           => (string) Arr::get($video, 'thumbnail', ''),
            'duration'            => (float) Arr::get($video, 'duration', 0),
            'ready'               => Arr::get($video, 'readyToStream') === true,
            'require_signed_urls' => Arr::get($video, 'requireSignedURLs') === true,
            'status'              => $state,
            // Transcode progress (0–100) + failure surface for the upload poll.
            'pct'                 => (float) Arr::get($video, 'status.pctComplete', 0),
            'error'               => $state === 'error',
            'error_reason'        => (string) Arr::get($video, 'status.errorReasonText', ''),
        ];
    }

    // ── client-backed (live) ────────────────────────────────────────

    public static function getSettings()
    {
        return (new CloudflareStreamIntegration())->getSettings();
    }

    /** @return CloudflareStream */
    public static function client($settings = null)
    {
        $settings = $settings ?: self::getSettings();
        return new CloudflareStream(Arr::get($settings, 'account_id'), Arr::get($settings, 'api_token'));
    }

    /**
     * Create a one-time Direct Creator Upload URL. Applies requireSignedURLs from
     * the integration settings so private accounts mint private videos.
     * @return array|\WP_Error  { uploadURL, uid }
     */
    public static function createDirectUpload($opts = [])
    {
        // requireSignedURLs is a per-video choice managed in Cloudflare Stream, not
        // an account default — callers may pass it explicitly in $opts.
        return self::client()->createDirectUpload($opts);
    }

    /** Fetch + normalise a single video's status. @return array|\WP_Error */
    public static function getVideoStatus($uid)
    {
        $settings = self::getSettings();
        $result = self::client($settings)->getVideo($uid);
        if (is_wp_error($result)) {
            return $result;
        }
        return self::normalizeVideo($result, Arr::get($settings, 'customer_subdomain', ''));
    }

    /** List + normalise account videos (browse picker). @return array|\WP_Error */
    public static function listVideos($params = [])
    {
        $settings = self::getSettings();
        $result = self::client($settings)->listVideos($params);
        if (is_wp_error($result)) {
            return $result;
        }
        $sub = Arr::get($settings, 'customer_subdomain', '');
        return array_map(function ($v) use ($sub) {
            $n = self::normalizeVideo($v, $sub);
            // Private videos need a signed thumbnail (token in path) or the picker
            // <img> 401s. Token is cached per uid, so this is cheap on re-list.
            if (!empty($n['require_signed_urls']) && $n['thumbnail'] !== '' && $n['uid'] !== '') {
                $token = self::getSignedToken($n['uid'], 3600);
                if ($token !== '') {
                    $n['thumbnail'] = self::signHlsUrl($n['thumbnail'], $n['uid'], $token);
                }
            }
            return $n;
        }, is_array($result) ? $result : []);
    }

    /** Stream a WP media-library attachment to Cloudflare. @return array|\WP_Error */
    public static function uploadFromAttachment($attachmentId)
    {
        $attachmentId = absint($attachmentId);
        if (!$attachmentId) {
            return new \WP_Error('cloudflare_stream_error', __('Invalid attachment.', 'fluent-player-pro'));
        }
        $filePath = get_attached_file($attachmentId);
        $result = self::client()->uploadFile($filePath, $filePath ? basename($filePath) : '');
        if (is_wp_error($result)) {
            return $result;
        }
        return self::normalizeVideo($result, Arr::get(self::getSettings(), 'customer_subdomain', ''));
    }

    /** Rename a video (updates its Cloudflare meta.name). @return array|\WP_Error */
    public static function renameVideo($uid, $name)
    {
        $result = self::client()->updateVideo($uid, ['meta' => ['name' => sanitize_text_field($name)]]);
        if (is_wp_error($result)) {
            return $result;
        }
        return self::normalizeVideo($result, Arr::get(self::getSettings(), 'customer_subdomain', ''));
    }

    // ── Signed / private delivery (per-video, API-minted token) ─────

    /**
     * Get a playback token for a private video, minted by Cloudflare via
     * POST /stream/{uid}/token (server-signed with the API token — no local signing
     * key). Cached per-uid to avoid an API call + rate limiting on every render.
     *
     * @return string  the token, or '' if it could not be minted
     */
    public static function getSignedToken($uid, $ttl = 3600)
    {
        $uid = (string) $uid;
        if ($uid === '') {
            return '';
        }

        $cacheKey = 'flp_cf_stream_tok_' . md5($uid);
        $cached = get_transient($cacheKey);
        if (is_string($cached) && $cached !== '') {
            return $cached;
        }

        $token = self::client()->createSignedToken($uid, $ttl);
        if (is_wp_error($token) || !is_string($token) || $token === '') {
            return '';
        }

        // Refresh a little before Cloudflare expires the token.
        set_transient($cacheKey, $token, max(60, $ttl - 300));
        return $token;
    }

    /**
     * Render-time hook (fluent_player/player_settings): for a PER-VIDEO private
     * cloudflare_stream video, mint + append a playback token to the HLS src.
     * Public videos and other providers pass through untouched.
     */
    public static function filterPlayerSettings($settings)
    {
        if (Arr::get($settings, 'provider') !== 'cloudflare_stream') {
            return $settings;
        }
        if (!Arr::isTrue($settings, 'stream.require_signed_urls')) {
            return $settings; // public video — no token needed
        }

        $uid = (string) Arr::get($settings, 'stream.uid', '');
        if ($uid === '') {
            return $settings;
        }

        // Token expiry must exceed the video duration or playback cuts off.
        $duration = floatval(Arr::get($settings, 'duration', 0));
        $ttl = max(3600, intval(ceil($duration)) + 3600);

        $token = self::getSignedToken($uid, $ttl);
        if ($token === '') {
            return $settings;
        }

        $signed = self::signHlsUrl((string) Arr::get($settings, 'src', ''), $uid, $token);
        if ($signed !== '') {
            $settings['src'] = $signed;
            if (!isset($settings['stream']) || !is_array($settings['stream'])) {
                $settings['stream'] = [];
            }
            $settings['stream']['playback_token'] = $token;
        }

        // The poster/thumbnail of a private video also needs signing, or it 401s.
        $poster = (string) Arr::get($settings, 'posterSrc', '');
        if ($poster !== '') {
            $signedPoster = self::signHlsUrl($poster, $uid, $token);
            if ($signedPoster !== '') {
                $settings['posterSrc'] = $signedPoster;
            }
        }

        return $settings;
    }

    /**
     * Build a Cloudflare signed HLS URL. The token goes in the URL PATH, replacing
     * the segment before /manifest/ (the uid, or a previously-embedded token) — a
     * ?token= query param is rejected with 401. Any existing query string is
     * dropped first, so a src persisted with a stale token self-heals each render
     * instead of accumulating tokens.
     *
     * @param string $base   the stored HLS URL (may carry a stale token)
     * @param string $uid    the video uid (kept for call-site clarity)
     * @param string $token  the freshly minted signed token
     * @return string        the signed URL, or '' if inputs are unusable
     */
    public static function signHlsUrl($base, $uid, $token)
    {
        $base = preg_replace('/[?#].*$/', '', (string) $base);
        if ($base === '' || (string) $token === '') {
            return '';
        }
        // https://<host>/<segment>/<rest> — replace <segment> with the token.
        if (preg_match('#^(https?://[^/]+/)([^/]+)(/.*)$#', $base, $m)) {
            return $m[1] . $token . $m[3];
        }
        return '';
    }

    // ── Webhooks + captions ─────────────────────────────────────────

    /**
     * Verify a Cloudflare Stream webhook. Header: `time=<unix>,sig1=<hex hmac>`,
     * HMAC-SHA256 over `<time>.<body>` with the webhook secret. Constant-time.
     */
    public static function verifyWebhookSignature($body, $header, $secret)
    {
        $secret = (string) $secret;
        if ($secret === '' || !is_string($header) || $header === '') {
            return false;
        }

        $parts = [];
        foreach (explode(',', $header) as $kv) {
            $piece = explode('=', trim($kv), 2);
            if (count($piece) === 2) {
                $parts[$piece[0]] = $piece[1];
            }
        }

        $time = isset($parts['time']) ? $parts['time'] : '';
        $sig  = isset($parts['sig1']) ? $parts['sig1'] : '';
        if ($time === '' || $sig === '') {
            return false;
        }

        $expected = hash_hmac('sha256', $time . '.' . (string) $body, $secret);
        return hash_equals($expected, $sig);
    }

    /**
     * Apply a webhook payload (transcode ready) to the matching media: update its
     * ready/status, HLS src, poster and duration. @return array
     */
    public static function handleWebhookEvent($payload)
    {
        $uid = (string) Arr::get($payload, 'uid', '');
        if ($uid === '') {
            return ['handled' => false, 'reason' => 'no_uid'];
        }

        $mediaId = self::findMediaByStreamUid($uid);
        if (!$mediaId) {
            return ['handled' => false, 'reason' => 'media_not_found'];
        }

        $normalized = self::normalizeVideo($payload, Arr::get(self::getSettings(), 'customer_subdomain', ''));

        $settings = get_post_meta($mediaId, 'settings', true);
        if (!is_array($settings)) {
            $settings = [];
        }
        if (!isset($settings['stream']) || !is_array($settings['stream'])) {
            $settings['stream'] = [];
        }
        $settings['stream']['uid']    = $uid;
        $settings['stream']['ready']  = $normalized['ready'];
        $settings['stream']['status'] = $normalized['status'];
        if (!empty($normalized['hls'])) {
            $settings['src'] = $normalized['hls'];
        }
        if (!empty($normalized['thumbnail'])) {
            $settings['posterSrc'] = $normalized['thumbnail'];
        }
        if (!empty($normalized['duration'])) {
            $settings['duration'] = $normalized['duration'];
        }

        update_post_meta($mediaId, 'settings', $settings);

        return ['handled' => true, 'media_id' => $mediaId, 'ready' => $normalized['ready']];
    }

    /** Find a fluent_player_media whose stored settings reference this Stream uid. */
    public static function findMediaByStreamUid($uid)
    {
        global $wpdb;
        $uid = sanitize_text_field($uid);
        if ($uid === '') {
            return 0;
        }
        $like = '%' . $wpdb->esc_like($uid) . '%';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- webhook media lookup by provider uid
        $id = $wpdb->get_var($wpdb->prepare(
            "SELECT p.ID FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID
             WHERE p.post_type = %s AND m.meta_key = 'settings' AND m.meta_value LIKE %s
             LIMIT 1",
            \FluentPlayer\App\Models\Media::$postType,
            $like
        ));
        return (int) $id;
    }

    /**
     * Best-effort: subscribe our webhook URL with Cloudflare and persist the secret
     * Cloudflare returns (used to verify transcode-ready notifications). Idempotent.
     * @return bool
     */
    public static function ensureWebhookSubscribed()
    {
        $notifyUrl = rest_url('fluent-player/v2/cloudflare-stream/webhook');
        $res = self::client()->subscribeWebhook($notifyUrl);
        if (is_wp_error($res)) {
            return false;
        }
        $secret = (string) Arr::get($res, 'secret', '');
        if ($secret === '') {
            return false;
        }
        self::storeWebhookSecret($secret);
        return true;
    }

    /** Persist the Cloudflare-issued webhook secret into the integration settings. */
    private static function storeWebhookSecret($secret)
    {
        $key = \FluentPlayer\App\Integrations\AbstractIntegration::INTEGRATIONS_SETTINGS_KEY;
        $all = json_decode(get_option($key), true);
        if (!is_array($all) || !isset($all['cloudflare_stream'])) {
            return;
        }
        $all['cloudflare_stream']['webhook_secret'] = sanitize_text_field($secret);
        update_option($key, json_encode($all));
    }
}
