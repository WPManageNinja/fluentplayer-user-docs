<?php

namespace FluentPlayerPro\App\Services;

if (!defined('ABSPATH')) exit;

use FluentPlayer\App\Helpers\BulkActionHelper;
use FluentPlayer\App\Models\Media;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Models\Playlist;

class BulkActionService
{
    /**
     * Handle the Pro media bulk actions dispatched from Free via filter.
     *
     * @param mixed  $response Default response when unhandled.
     * @param int[]  $ids
     * @return array{affected_ids: int[], failed_ids: int[], message?: string}|mixed
     */
    public static function handleMediaBulkAction($response, $action, $ids, $request)
    {
        // Guard against a newer Pro paired with an outdated free build (no shared helper).
        // The user-facing nag is handled at boot by FreeDependencyNotice; here we just bail safely.
        if (!class_exists(BulkActionHelper::class)) {
            return $response;
        }

        $ids = BulkActionHelper::sanitizeIds($ids);

        // Prime once so the per-item type/status checks (incl. the add-to-playlist filter) are cache hits.
        if (!empty($ids)) {
            _prime_post_caches($ids, false, false);
        }

        switch ($action) {
            case 'add_tags':
                return self::bulkAddTags($ids, $request->get('tags'));
            case 'remove_tags':
                return self::bulkRemoveTags($ids, $request->get('tags'));
            case 'add_to_playlist':
                return self::bulkAddToPlaylist($ids, $request);
        }

        return $response;
    }

    /**
     * Attach tags (existing or newly created) to non-trashed media.
     *
     * @param int[] $ids
     * @param mixed $tags
     * @return array{affected_ids: int[], failed_ids: int[], message?: string}
     */
    protected static function bulkAddTags($ids, $tags)
    {
        $tags = self::sanitizeTags($tags);

        if (empty($tags)) {
            return ['affected_ids' => [], 'failed_ids' => $ids, 'message' => __('No valid tags provided', 'fluent-player-pro')];
        }

        return BulkActionHelper::run($ids, function ($id) use ($tags) {
            if (get_post_type($id) !== Media::$postType || get_post_status($id) === 'trash') {
                return false;
            }
            $res = wp_set_object_terms($id, $tags, 'flp_media_tag', true);
            return !is_wp_error($res);
        });
    }

    /**
     * Detach the named tags from media (existing tags only).
     *
     * @param int[] $ids
     * @param mixed $tags
     * @return array{affected_ids: int[], failed_ids: int[], message?: string}
     */
    protected static function bulkRemoveTags($ids, $tags)
    {
        $tags = self::sanitizeTags($tags);

        if (empty($tags)) {
            return ['affected_ids' => [], 'failed_ids' => $ids, 'message' => __('No valid tags provided', 'fluent-player-pro')];
        }

        return BulkActionHelper::run($ids, function ($id) use ($tags) {
            if (get_post_type($id) !== Media::$postType) {
                return false;
            }
            wp_remove_object_terms($id, $tags, 'flp_media_tag');
            return true;
        });
    }

    /**
     * Add non-trashed media to an existing playlist, or create a new draft playlist with them.
     *
     * @param int[] $ids
     * @return array{affected_ids: int[], failed_ids: int[], message?: string}
     */
    protected static function bulkAddToPlaylist($ids, $request)
    {
        $eligible = array_values(array_filter($ids, function ($id) {
            return get_post_type($id) === Media::$postType && get_post_status($id) !== 'trash';
        }));
        $failed = array_values(array_diff($ids, $eligible));

        if (empty($eligible)) {
            return ['affected_ids' => [], 'failed_ids' => $ids, 'message' => __('No eligible media to add', 'fluent-player-pro')];
        }

        $playlistId = absint($request->get('playlist_id'));
        $newTitle   = sanitize_text_field((string) $request->get('new_playlist_title'));

        if ($playlistId) {
            $playlist = Playlist::find($playlistId);
            if (!$playlist) {
                return ['affected_ids' => [], 'failed_ids' => $ids, 'message' => __('Playlist not found', 'fluent-player-pro')];
            }

            $settings = is_array($playlist->settings) ? $playlist->settings : [];
            $existing = array_map('intval', Arr::get($settings, 'medias', []));
            $settings['medias'] = array_values(array_unique(array_merge($existing, $eligible)));
            update_post_meta($playlistId, 'settings', $settings);

            // translators: 1: number of items, 2: playlist title.
            $message = sprintf(__('Added %1$d item(s) to "%2$s"', 'fluent-player-pro'), count($eligible), $playlist->post_title);
            return ['affected_ids' => $eligible, 'failed_ids' => $failed, 'message' => $message];
        }

        $title = $newTitle !== '' ? $newTitle : Playlist::generateDefaultTitle();
        $settings = PlaylistSettingsHelper::sanitizeAndValidate(['title' => $title]);
        $settings['title']  = $title;
        $settings['medias'] = $eligible;

        $playlist = new Playlist();
        $playlist->title    = $title;
        $playlist->settings = $settings;
        $saved = $playlist->save();

        if (!$saved) {
            return ['affected_ids' => [], 'failed_ids' => $ids, 'message' => __('Failed to create playlist', 'fluent-player-pro')];
        }

        wp_update_post(['ID' => $saved->ID, 'post_status' => 'draft']);

        // translators: 1: number of items, 2: playlist title.
        $message = sprintf(__('Created "%2$s" with %1$d item(s)', 'fluent-player-pro'), count($eligible), $title);
        return ['affected_ids' => $eligible, 'failed_ids' => $failed, 'message' => $message];
    }

    /**
     * Sanitize tag names; trim, drop empties, dedupe by slug.
     *
     * @return string[]
     */
    protected static function sanitizeTags($tags)
    {
        if (is_string($tags)) {
            $decoded = json_decode($tags, true);
            $tags = is_array($decoded) ? $decoded : [$tags];
        }
        if (!is_array($tags)) {
            return [];
        }

        $seen = [];
        $out = [];
        foreach ($tags as $raw) {
            $tag = trim(sanitize_text_field((string) $raw));
            if ($tag === '') {
                continue;
            }
            $slug = sanitize_title($tag);
            if ($slug === '' || isset($seen[$slug])) {
                continue;
            }
            $seen[$slug] = true;
            $out[] = $tag;
        }
        return $out;
    }
}
