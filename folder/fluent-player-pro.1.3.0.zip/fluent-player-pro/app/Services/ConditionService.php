<?php

namespace FluentPlayerPro\App\Services;

if (!defined('ABSPATH')) exit;

use FluentPlayer\App\EmailProviders\FluentCRMProvider;
use FluentPlayer\App\Models\EmailCollection;
use FluentPlayer\Framework\Support\Arr;

class ConditionService
{
    const MATCH_ALL = 'all';
    const MATCH_ANY = 'any';

    /**
     * Supported condition definitions.
     *
     * @return array
     */
    protected static function getFieldDefinitions()
    {
        return [
            'viewer.is_logged_in' => [
                'type'        => 'boolean',
                'operators'   => ['=', '!='],
                'server_side' => true,
            ],
            'viewer.is_crm_contact' => [
                'type'        => 'boolean',
                'operators'   => ['=', '!='],
                'server_side' => true,
            ],
            'viewer.crm_tag' => [
                'type'        => 'string',
                'operators'   => ['=', '!='],
                'server_side' => true,
            ],
            'viewer.crm_list' => [
                'type'        => 'string',
                'operators'   => ['=', '!='],
                'server_side' => true,
            ],
            'viewer.email_submitted' => [
                'type'        => 'boolean',
                'operators'   => ['=', '!='],
                'server_side' => true,
            ],
            'page.query' => [
                'type'         => 'string',
                'operators'    => ['=', '!=', 'contains'],
                'server_side'  => true,
                'requires_key' => true,
            ],
            'layer.seen' => [
                'type'        => 'boolean',
                'operators'   => ['=', '!='],
                'server_side' => false,
            ],
            'layer.completed' => [
                'type'        => 'boolean',
                'operators'   => ['=', '!='],
                'server_side' => false,
            ],
        ];
    }

    /**
     * Default condition payload.
     *
     * @return array
     */
    public static function getDefaultConditionals()
    {
        return [
            'enabled' => false,
            'match'   => self::MATCH_ALL,
            'rules'   => [],
        ];
    }

    /**
     * Normalize and validate a condition definition payload.
     *
     * Assumes value-level sanitization already happened in SettingsSanitizer.
     *
     * @param mixed $conditionals
     * @return array
     */
    public static function normalizeConditionals($conditionals)
    {
        $defaults = self::getDefaultConditionals();
        if (!is_array($conditionals)) {
            return $defaults;
        }

        $match = (string) Arr::get($conditionals, 'match', self::MATCH_ALL);
        if (!in_array($match, [self::MATCH_ALL, self::MATCH_ANY], true)) {
            $match = self::MATCH_ALL;
        }

        $rules = [];
        $rawRules = Arr::get($conditionals, 'rules', []);

        if (is_array($rawRules)) {
            foreach ($rawRules as $rule) {
                $normalizedRule = self::normalizeRule($rule);
                if ($normalizedRule) {
                    $rules[] = $normalizedRule;
                }
            }
        }

        return [
            'enabled' => !empty($rules) && !empty($conditionals['enabled']),
            'match'   => $match,
            'rules'   => $rules,
        ];
    }

    /**
     * Build the trusted server-side context for the requested settings.
     *
     * @param array $settings
     * @return array
     */
    public static function buildConditionState($settings, $mediaId = 0, $relevantMediaIds = [])
    {
        return self::buildStateFromUsage(self::collectSettingsConditions($settings), $mediaId, $relevantMediaIds);
    }

    /**
     * Build trusted condition state and apply server-side visibility when needed.
     *
     * @param array $settings
     * @return array
     */
    public static function maybePrepareConditionState($settings, $mediaId = 0, $relevantMediaIds = [])
    {
        if (!is_array($settings)) {
            return [];
        }

        $state = self::buildConditionState($settings, $mediaId, $relevantMediaIds);
        $settings = self::applyConditionVisibility($settings, $state);

        if (!empty($state)) {
            $settings['condition_state'] = $state;
        }

        return $settings;
    }

    /**
     * Filter out features that are fully resolved server-side and should not render.
     *
     * @param array $settings
     * @param array $state
     * @return array
     */
    public static function applyConditionVisibility($settings, $state)
    {
        if (!is_array($settings) || empty($state)) {
            return $settings;
        }

        if (!empty($settings['email_capture']) && is_array($settings['email_capture'])) {
            if (self::shouldSkipServerRender(Arr::get($settings, 'email_capture.conditionals', []), $state)) {
                $settings['email_capture']['enabled'] = false;
            }
        }

        if (!empty($settings['cta']) && is_array($settings['cta'])) {
            if (self::shouldSkipServerRender(Arr::get($settings, 'cta.conditionals', []), $state)) {
                $settings['cta']['enabled'] = false;
            }
        }

        if (!empty($settings['layers']) && is_array($settings['layers'])) {
            $settings['layers'] = array_values(array_filter($settings['layers'], function ($layer) use ($state) {
                return !self::shouldSkipServerRender(Arr::get($layer, 'conditionals', []), $state);
            }));
        }

        return $settings;
    }

    /**
     * Determine whether a normalized condition set can be resolved fully in PHP.
     *
     * @param mixed $conditionals
     * @return bool
     */
    public static function isFullyServerResolvable($conditionals)
    {
        if (!is_array($conditionals) || empty($conditionals['enabled']) || empty($conditionals['rules']) || !is_array($conditionals['rules'])) {
            return false;
        }

        foreach ($conditionals['rules'] as $rule) {
            $definition = self::getFieldDefinition($rule['field']);
            if (!$definition || empty($definition['server_side'])) {
                return false;
            }
        }

        return true;
    }

    /**
     * Returns true when a condition set should skip frontend render in PHP.
     *
     * @param mixed $conditionals
     * @param array $context
     * @return bool
     */
    public static function shouldSkipServerRender($conditionals, $context)
    {
        if (!self::isFullyServerResolvable($conditionals)) {
            return false;
        }

        return !self::evaluateConditionals($conditionals, $context);
    }

    /**
     * Evaluate a normalized condition set.
     *
     * @param mixed $conditionals
     * @param array $context
     * @return bool
     */
    public static function evaluateConditionals($conditionals, $context)
    {
        if (!is_array($conditionals) || empty($conditionals['enabled']) || empty($conditionals['rules']) || !is_array($conditionals['rules'])) {
            return true;
        }

        $results = [];
        foreach ($conditionals['rules'] as $rule) {
            $actual = self::resolveContextValue($rule, $context);
            $results[] = self::compareValues($actual, $rule['operator'], $rule['value'], $rule['field']);
        }

        if (Arr::get($conditionals, 'match') === self::MATCH_ANY) {
            return in_array(true, $results, true);
        }

        return !in_array(false, $results, true);
    }

    /**
     * Collect only the server-side fields used by the settings.
     *
     * @param array $settings
     * @return array
     */
    protected static function collectSettingsConditions($settings)
    {
        $usage = [
            'viewer' => [
                'is_logged_in'   => false,
                'is_crm_contact' => false,
                'crm_tag'        => false,
                'crm_list'       => false,
                'email_submitted' => false,
            ],
            'page' => [
                'query_keys' => [],
            ],
        ];

        if (!is_array($settings)) {
            return $usage;
        }

        self::collectConditionUsage(Arr::get($settings, 'email_capture.conditionals', []), $usage);
        self::collectConditionUsage(Arr::get($settings, 'cta.conditionals', []), $usage);

        $layers = Arr::get($settings, 'layers', []);
        if (is_array($layers)) {
            foreach ($layers as $layer) {
                self::collectConditionUsage(Arr::get($layer, 'conditionals', []), $usage);
            }
        }

        return $usage;
    }

    /**
     * Build the server-side context from a usage map.
     *
     * @param array $usage
     * @return array
     */
    protected static function buildStateFromUsage($usage, $mediaId = 0, $relevantMediaIds = [])
    {
        $context = [];

        if (
            Arr::get($usage, 'viewer.is_logged_in') ||
            Arr::get($usage, 'viewer.is_crm_contact') ||
            Arr::get($usage, 'viewer.crm_tag') ||
            Arr::get($usage, 'viewer.crm_list') ||
            Arr::get($usage, 'viewer.email_submitted')
        ) {
            $context['viewer'] = [];
        }

        if (Arr::get($usage, 'viewer.is_logged_in')) {
            $context['viewer']['is_logged_in'] = is_user_logged_in();
        }

        if (Arr::get($usage, 'viewer.is_crm_contact')) {
            $context['viewer']['is_crm_contact'] = FluentCRMProvider::isCurrentUserContact();
        }

        if (Arr::get($usage, 'viewer.crm_tag') || Arr::get($usage, 'viewer.crm_list')) {
            $contact = FluentCRMProvider::getCurrentContact();

            if ($contact) {
                if (Arr::get($usage, 'viewer.crm_tag')) {
                    $context['viewer']['crm_tags'] = self::getFluentCrmRelationValues($contact, 'tags');
                }

                if (Arr::get($usage, 'viewer.crm_list')) {
                    $context['viewer']['crm_lists'] = self::getFluentCrmRelationValues($contact, 'lists');
                }
            }
        }

        if (Arr::get($usage, 'viewer.email_submitted')) {
            $context['viewer']['email_submitted'] = self::resolveEmailSubmittedState($mediaId, $relevantMediaIds);
        }

        $queryKeys = array_values(array_unique(array_filter((array) Arr::get($usage, 'page.query_keys', []))));
        if (!empty($queryKeys)) {
            $context['page'] = [
                'query' => [],
            ];

            foreach ($queryKeys as $queryKey) {
                $context['page']['query'][$queryKey] = self::getQueryValue($queryKey);
            }
        }

        return $context;
    }

    /**
     * Normalize and validate an individual rule.
     *
     * @param mixed $rule
     * @return array|null
     */
    protected static function normalizeRule($rule)
    {
        if (!is_array($rule)) {
            return null;
        }

        $field = (string) Arr::get($rule, 'field', '');
        $definition = self::getFieldDefinition($field);
        if (!$definition) {
            return null;
        }

        $operator = (string) Arr::get($rule, 'operator', '=');
        if (!in_array($operator, $definition['operators'], true)) {
            return null;
        }

        $normalizedRule = [
            'field'    => $field,
            'operator' => $operator,
            'value'    => self::normalizeRuleValue(Arr::get($rule, 'value'), $definition['type']),
        ];

        if (!empty($definition['requires_key'])) {
            $key = self::normalizeRuleKey(Arr::get($rule, 'key', ''));
            if ($key === '') {
                return null;
            }
            $normalizedRule['key'] = $key;
        }

        return $normalizedRule;
    }

    /**
     * Resolve a saved rule against the current context.
     *
     * @param array $rule
     * @param array $context
     * @return mixed
     */
    protected static function resolveContextValue($rule, $context)
    {
        switch ($rule['field']) {
            case 'viewer.is_logged_in':
                return (bool) Arr::get($context, 'viewer.is_logged_in', false);
            case 'viewer.is_crm_contact':
                return (bool) Arr::get($context, 'viewer.is_crm_contact', false);
            case 'viewer.crm_tag':
                return Arr::get($context, 'viewer.crm_tags', []);
            case 'viewer.crm_list':
                return Arr::get($context, 'viewer.crm_lists', []);
            case 'viewer.email_submitted':
                return (bool) Arr::get($context, 'viewer.email_submitted', false);
            case 'layer.seen':
                return (bool) Arr::get($context, 'layer.seen', false);
            case 'layer.completed':
                return (bool) Arr::get($context, 'layer.completed', false);
            case 'page.query':
                return Arr::get($context, 'page.query.' . Arr::get($rule, 'key', ''), null);
            default:
                return null;
        }
    }

    /**
     * Compare actual and expected values for a rule.
     *
     * @param mixed  $actual
     * @param string $operator
     * @param mixed  $expected
     * @param string $field
     * @return bool
     */
    protected static function compareValues($actual, $operator, $expected, $field)
    {
        $definition = self::getFieldDefinition($field);
        $type = $definition ? $definition['type'] : 'string';

        if ($type === 'boolean') {
            $actual = (bool) $actual;
            $expected = (bool) $expected;
        } elseif (is_array($actual)) {
            $actual = array_values(array_filter(array_map(function ($value) {
                return is_scalar($value) ? sanitize_text_field((string) $value) : '';
            }, $actual), function ($value) {
                return $value !== '';
            }));
            $expected = is_scalar($expected) ? sanitize_text_field((string) $expected) : '';
        } else {
            $actual = is_scalar($actual) ? sanitize_text_field((string) $actual) : '';
            $expected = is_scalar($expected) ? sanitize_text_field((string) $expected) : '';
        }

        switch ($operator) {
            case '=':
                if (is_array($actual)) {
                    return in_array($expected, $actual, true);
                }
                return $actual === $expected;
            case '!=':
                if (is_array($actual)) {
                    return !in_array($expected, $actual, true);
                }
                return $actual !== $expected;
            case 'contains':
                if ($actual === '' || $expected === '') {
                    return false;
                }
                return strpos(strtolower((string) $actual), strtolower((string) $expected)) !== false;
            default:
                return false;
        }
    }

    /**
     * Attach usage info from one condition set to the shared usage map.
     *
     * @param mixed $conditionals
     * @param array $usage
     * @return void
     */
    protected static function collectConditionUsage($conditionals, &$usage)
    {
        if (!is_array($conditionals) || empty($conditionals['enabled']) || empty($conditionals['rules']) || !is_array($conditionals['rules'])) {
            return;
        }

        foreach ($conditionals['rules'] as $rule) {
            switch ($rule['field']) {
                case 'viewer.is_logged_in':
                    $usage['viewer']['is_logged_in'] = true;
                    break;
                case 'viewer.is_crm_contact':
                    $usage['viewer']['is_crm_contact'] = true;
                    break;
                case 'viewer.crm_tag':
                    $usage['viewer']['crm_tag'] = true;
                    break;
                case 'viewer.crm_list':
                    $usage['viewer']['crm_list'] = true;
                    break;
                case 'viewer.email_submitted':
                    $usage['viewer']['email_submitted'] = true;
                    break;
                case 'page.query':
                    if (!empty($rule['key'])) {
                        $usage['page']['query_keys'][] = $rule['key'];
                    }
                    break;
            }
        }
    }

    /**
     * Get a supported field definition.
     *
     * @param string $field
     * @return array|null
     */
    protected static function getFieldDefinition($field)
    {
        $definitions = self::getFieldDefinitions();
        return isset($definitions[$field]) ? $definitions[$field] : null;
    }

    /**
     * Normalize a rule value for the relevant type.
     *
     * @param mixed  $value
     * @param string $type
     * @return mixed
     */
    protected static function normalizeRuleValue($value, $type)
    {
        if ($type === 'boolean') {
            return rest_sanitize_boolean($value);
        }

        if ($value === null || is_array($value) || is_object($value)) {
            return '';
        }

        return (string) $value;
    }

    /**
     * Normalize a query key without changing case.
     *
     * @param mixed $value
     * @return string
     */
    protected static function normalizeRuleKey($value)
    {
        if ($value === null || is_array($value) || is_object($value)) {
            return '';
        }

        $key = trim((string) $value);
        if ($key === '') {
            return '';
        }

        return substr($key, 0, 64);
    }

    /**
     * Read and sanitize a query param value.
     *
     * @param string $key
     * @return string|null
     */
    protected static function getQueryValue($key)
    {
        if (!isset($_GET[$key])) {
            return null;
        }

        $value = wp_unslash($_GET[$key]);
        if (is_array($value)) {
            return null;
        }

        return sanitize_text_field((string) $value);
    }

    /**
     * Build a normalized lookup list from a FluentCRM contact relation.
     *
     * @param mixed  $contact
     * @param string $relation
     * @return array
     */
    protected static function getFluentCrmRelationValues($contact, $relation)
    {
        if (empty($contact) || !is_object($contact)) {
            return [];
        }

        $contactId = (int) Arr::get((array) $contact, 'id');
        static $relationCache = [];
        if ($contactId > 0 && isset($relationCache[$contactId][$relation])) {
            return $relationCache[$contactId][$relation];
        }

        $items = $contact->{$relation} ?? [];
        if (!$items && method_exists($contact, $relation)) {
            try {
                $items = $contact->{$relation}()->get();
            } catch (\Exception $e) {
                return [];
            }
        }

        $values = [];
        foreach ($items as $item) {
            if (!is_object($item)) {
                continue;
            }

            foreach (['id', 'title', 'slug'] as $key) {
                if (!isset($item->{$key}) || $item->{$key} === '') {
                    continue;
                }

                $values[] = sanitize_text_field((string) $item->{$key});
            }
        }

        $values = array_values(array_unique(array_filter($values)));

        if ($contactId > 0) {
            if (!isset($relationCache[$contactId])) {
                $relationCache[$contactId] = [];
            }

            $relationCache[$contactId][$relation] = $values;
        }

        return $values;
    }

    /**
     * Resolve whether the current identifiable viewer has previously submitted email for this media.
     *
     * @param int|string $mediaId
     * @return bool
     */
    protected static function resolveEmailSubmittedState($mediaId, $relevantMediaIds = [])
    {
        static $cache = [];

        $mediaId = (int) $mediaId;
        if ($mediaId <= 0) {
            return false;
        }

        $userId = (int) get_current_user_id();
        $viewerEmail = self::getCurrentViewerEmail();
        $cacheKey = self::getEmailSubmissionCacheKey($userId, $viewerEmail);

        if ($cacheKey === '') {
            return false;
        }

        $scopedMediaIds = $relevantMediaIds ?: [$mediaId];
        $scopedCacheKey = $cacheKey . '|media_' . md5(wp_json_encode($scopedMediaIds));

        if (!array_key_exists($scopedCacheKey, $cache)) {
            $cache[$scopedCacheKey] = self::loadSubmittedMediaIds($userId, $viewerEmail, $scopedMediaIds);
        }

        return isset($cache[$scopedCacheKey][$mediaId]);
    }

    /**
     * Get the current viewer email from WordPress user or FluentCRM secure-cookie contact.
     *
     * @return string
     */
    protected static function getCurrentViewerEmail()
    {
        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            if (!empty($user->user_email)) {
                return sanitize_email($user->user_email);
            }
        }

        return FluentCRMProvider::getCurrentContactEmail();
    }

    /**
     * Build a stable request cache key for the current viewer.
     *
     * @param int $userId
     * @param string $viewerEmail
     * @return string
     */
    protected static function getEmailSubmissionCacheKey($userId, $viewerEmail)
    {
        if ($userId > 0) {
            return 'user_' . $userId;
        }

        if ($viewerEmail !== '') {
            return 'email_' . md5($viewerEmail);
        }

        return '';
    }

    /**
     * Load all media IDs that the current identifiable viewer has already submitted email for.
     *
     * @param int $userId
     * @param string $viewerEmail
     * @return array
     */
    protected static function loadSubmittedMediaIds($userId, $viewerEmail, $mediaIds = [])
    {
        if (!$userId && $viewerEmail === '') {
            return [];
        }

        if (empty($mediaIds)) {
            return [];
        }

        $query = EmailCollection::query()
            ->whereNotNull('media_id')
            ->whereIn('media_id', $mediaIds);

        if ($userId > 0 && $viewerEmail !== '') {
            $query->where(function ($subQuery) use ($userId, $viewerEmail) {
                $subQuery->where('user_id', $userId)->orWhere('email', $viewerEmail);
            });
        } elseif ($userId > 0) {
            $query->where('user_id', $userId);
        } else {
            $query->where('email', $viewerEmail);
        }

        $mediaIds = $query
            ->distinct()
            ->pluck('media_id')
            ->all();

        $submittedMediaIds = [];
        foreach ($mediaIds as $submittedMediaId) {
            $submittedMediaId = (int) $submittedMediaId;
            if ($submittedMediaId > 0) {
                $submittedMediaIds[$submittedMediaId] = true;
            }
        }

        return $submittedMediaIds;
    }
}
