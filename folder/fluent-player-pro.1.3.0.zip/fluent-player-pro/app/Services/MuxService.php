<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Libraries\Mux;

class MuxService
{
    /**
     * @var \FluentPlayerPro\App\Integrations\MuxIntegration|\WP_Error|null
     */
    private $cachedIntegration = null;

    /**
     * @return \FluentPlayerPro\App\Integrations\MuxIntegration|\WP_Error
     */
    protected function getIntegration()
    {
        if ($this->cachedIntegration !== null) {
            return $this->cachedIntegration;
        }

        $integrationClass = apply_filters('fluent_player/integrations', [])['mux'] ?? null; // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Base plugin hook

        if (!$integrationClass || !class_exists($integrationClass)) {
            $this->cachedIntegration = new \WP_Error('integration_not_found', __('Mux integration not found', 'fluent-player-pro'));
            return $this->cachedIntegration;
        }

        $this->cachedIntegration = new $integrationClass();
        return $this->cachedIntegration;
    }

    /**
     * @return array|\WP_Error ['client' => Mux]
     */
    protected function validateAndGetClient()
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return $integration;
        }

        if (!$integration->isEnabled()) {
            return new \WP_Error('disabled', __('Mux integration is not enabled', 'fluent-player-pro'));
        }

        $client = $integration->getClient();
        if (is_wp_error($client)) {
            return $client;
        }

        return ['client' => $client];
    }

    // ─── Assets ──────────────────────────────────────────────────────

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function getAssets($params = [])
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        /** @var Mux $client */
        $client = $result['client'];
        $response = $client->getAssets($params);

        if (is_wp_error($response)) {
            return $response;
        }

        // Enrich assets with playback URLs
        $assets = Arr::get($response, 'data', []);
        foreach ($assets as &$asset) {
            $this->enrichAsset($asset);
        }
        unset($asset);

        return [
            'items'      => $assets,
            'totalItems' => count($assets),
        ];
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function getAsset($assetId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getAsset($assetId);
        if (is_wp_error($response)) {
            return $response;
        }

        $asset = Arr::get($response, 'data', []);
        $this->enrichAsset($asset);

        return $asset;
    }

    /**
     * @param array $input
     * @param array $params
     * @return array|\WP_Error
     */
    public function createAsset($input, $params = [])
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        // Auto-generate subtitles if enabled in integration settings
        // Mux requires generated_subtitles inside each input item
        $autoCaptions = $this->getAutoCaptionSettings();
        if ($autoCaptions) {
            if (is_array($input)) {
                foreach ($input as &$inputItem) {
                    if (is_array($inputItem)) {
                        $inputItem['generated_subtitles'] = $autoCaptions;
                    }
                }
                unset($inputItem);
            }
        }

        $response = $result['client']->createAsset($input, $params);
        if (is_wp_error($response)) {
            return $response;
        }

        $asset = Arr::get($response, 'data', []);
        $this->enrichAsset($asset);

        return $asset;
    }

    /**
     * @param string $assetId
     * @param array $data
     * @return array|\WP_Error
     */
    public function updateAsset($assetId, $data)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->updateAsset($assetId, $data);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function deleteAsset($assetId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->deleteAsset($assetId);
        if (is_wp_error($response)) {
            return $response;
        }

        return ['message' => 'Asset deleted successfully'];
    }

    /**
     * @param string $assetId
     * @param string $support
     * @return array|\WP_Error
     */
    public function updateMp4Support($assetId, $support)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->updateMp4Support($assetId, $support);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    // ─── Direct Uploads ──────────────────────────────────────────────

    /**
     * @param string $corsOrigin
     * @return array|\WP_Error
     */
    /** Whether a MIME type is an audio source. */
    public static function isAudioMime($mime)
    {
        return strpos((string) $mime, 'audio/') === 0;
    }

    /** Whether a MIME type is an uploadable media source (video or audio). */
    public static function isUploadableMime($mime)
    {
        $mime = (string) $mime;
        return strpos($mime, 'video/') === 0 || strpos($mime, 'audio/') === 0;
    }

    /**
     * Server-side upload of a WordPress attachment to Mux (the wp.media flow, mirroring
     * BunnyCDNStorageService::uploadVideo). Creates a Mux direct upload, then streams the
     * attachment file straight to the upload URL (constant memory via CURLOPT_INFILE).
     *
     * @param int    $attachmentId
     * @param string $passthrough  Asset title / passthrough.
     * @return array|\WP_Error  ['id' => uploadId, 'upload_id' => uploadId] or WP_Error.
     */
    public function uploadAttachment($attachmentId, $passthrough = '')
    {
        $filePath = get_attached_file($attachmentId);
        if (!$filePath || !file_exists($filePath)) {
            return new \WP_Error('file_not_found', __('WordPress attachment file not found', 'fluent-player-pro'));
        }

        $fileSize = filesize($filePath);
        if ($fileSize === false || $fileSize === 0) {
            return new \WP_Error('empty_file', __('File is empty or cannot be read', 'fluent-player-pro'));
        }

        $upload = $this->createDirectUpload('', $passthrough);
        if (is_wp_error($upload)) {
            return $upload;
        }

        $uploadUrl = Arr::get($upload, 'url', '');
        $uploadId  = Arr::get($upload, 'id', '');
        if (empty($uploadUrl) || empty($uploadId)) {
            return new \WP_Error('upload_url_failed', __('Failed to create Mux upload URL', 'fluent-player-pro'));
        }

        $put = self::streamFileToUrl($uploadUrl, $filePath, $fileSize);
        if (is_wp_error($put)) {
            return $put;
        }

        return ['id' => $uploadId, 'upload_id' => $uploadId];
    }

    /**
     * PUT a local file to a signed upload URL, streaming from disk (constant memory).
     *
     * @param string $url
     * @param string $filePath
     * @param int    $fileSize
     * @return true|\WP_Error
     */
    protected static function streamFileToUrl($url, $filePath, $fileSize)
    {
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        $fileHandle = fopen($filePath, 'r');
        if (!$fileHandle) {
            return new \WP_Error('read_error', __('Could not open file for reading', 'fluent-player-pro'));
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
        $ch = curl_init();
        // phpcs:disable WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_PUT, true);
        curl_setopt($ch, CURLOPT_INFILE, $fileHandle);
        curl_setopt($ch, CURLOPT_INFILESIZE, $fileSize);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Bounded (not 0/unlimited) so a very large/slow upload can't hold a PHP worker
        // indefinitely; matches the Gumlet upload timeout.
        curl_setopt($ch, CURLOPT_TIMEOUT, 900);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/octet-stream']);
        // phpcs:enable WordPress.WP.AlternativeFunctions.curl_curl_setopt

        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
        curl_exec($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_error
        $curlError = curl_error($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
        curl_close($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($fileHandle);

        if ($curlError !== '') {
            return new \WP_Error('mux_upload_transport', $curlError);
        }
        if ($httpCode < 200 || $httpCode >= 300) {
            /* translators: %d: HTTP status code */
            return new \WP_Error('mux_upload_failed', sprintf(__('Mux upload failed (HTTP %d)', 'fluent-player-pro'), $httpCode));
        }

        return true;
    }

    public function createDirectUpload($corsOrigin = '', $passthrough = '')
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $newAssetSettings = [
            'playback_policy' => [$this->isSignedUrlsEnabled() ? 'signed' : 'public'],
        ];

        if (!empty($passthrough)) {
            $newAssetSettings['passthrough'] = $passthrough;
            $newAssetSettings['meta'] = [
                'title' => $passthrough,
            ];
        }

        // Auto-generate subtitles if enabled in integration settings
        // Mux requires generated_subtitles inside inputs[] for direct uploads
        $autoCaptions = $this->getAutoCaptionSettings();
        if ($autoCaptions) {
            $newAssetSettings['inputs'] = [
                [
                    'generated_subtitles' => $autoCaptions,
                ],
            ];
        }

        $params = [
            'new_asset_settings' => $newAssetSettings,
            'cors_origin' => $corsOrigin ?: site_url(),
        ];

        $response = $result['client']->createUpload($params);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    /**
     * @param string $uploadId
     * @return array|\WP_Error
     */
    public function getUploadStatus($uploadId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getUpload($uploadId);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    // ─── Tracks ──────────────────────────────────────────────────────

    /**
     * @param string $assetId
     * @param array $data
     * @return array|\WP_Error
     */
    public function createTrack($assetId, $data)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->createTrack($assetId, $data);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    /**
     * @param string $assetId
     * @param string $trackId
     * @return array|\WP_Error
     */
    public function deleteTrack($assetId, $trackId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        return $result['client']->deleteTrack($assetId, $trackId);
    }

    /**
     * @param string $assetId
     * @param string $trackId
     * @param array $params
     * @return array|\WP_Error
     */
    public function generateSubtitles($assetId, $trackId, $params)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->generateSubtitles($assetId, $trackId, $params);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    // ─── Live Streams ────────────────────────────────────────────────

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function createLiveStream($params)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->createLiveStream($params);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function getLiveStreams($params = [])
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getLiveStreams($params);
        if (is_wp_error($response)) {
            return $response;
        }

        $items = Arr::get($response, 'data', []);
        // Strip stream keys from list responses for security
        foreach ($items as &$item) {
            unset($item['stream_key']);
        }
        unset($item);

        return [
            'items' => $items,
        ];
    }

    /**
     * @param string $liveStreamId
     * @return array|\WP_Error
     */
    public function getLiveStream($liveStreamId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getLiveStream($liveStreamId);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    /**
     * @param string $liveStreamId
     * @return array|\WP_Error
     */
    public function deleteLiveStream($liveStreamId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->deleteLiveStream($liveStreamId);
        if (is_wp_error($response)) {
            return $response;
        }

        return ['message' => 'Live stream deleted successfully'];
    }

    /**
     * @param string $liveStreamId
     * @return array|\WP_Error
     */
    public function resetStreamKey($liveStreamId)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->resetStreamKey($liveStreamId);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    // ─── Playback Restrictions ───────────────────────────────────────

    /**
     * @param array $data
     * @return array|\WP_Error
     */
    public function createPlaybackRestriction($data)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->createPlaybackRestriction($data);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    /**
     * @return array|\WP_Error
     */
    public function getPlaybackRestrictions()
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getPlaybackRestrictions();
        if (is_wp_error($response)) {
            return $response;
        }

        return [
            'items' => Arr::get($response, 'data', []),
        ];
    }

    /**
     * @param string $id
     * @return array|\WP_Error
     */
    public function deletePlaybackRestriction($id)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->deletePlaybackRestriction($id);
        if (is_wp_error($response)) {
            return $response;
        }

        return ['message' => 'Playback restriction deleted successfully'];
    }

    // ─── Delivery Usage ──────────────────────────────────────────────

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function getDeliveryUsage($params = [])
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getDeliveryUsage($params);
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    // ─── Signing Keys ────────────────────────────────────────────────

    /**
     * @return array|\WP_Error
     */
    public function createSigningKey()
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->createSigningKey();
        if (is_wp_error($response)) {
            return $response;
        }

        return Arr::get($response, 'data', $response);
    }

    /**
     * @return array|\WP_Error
     */
    public function getSigningKeys()
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->getSigningKeys();
        if (is_wp_error($response)) {
            return $response;
        }

        return [
            'items' => Arr::get($response, 'data', []),
        ];
    }

    /**
     * @param string $id
     * @return array|\WP_Error
     */
    public function deleteSigningKey($id)
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->deleteSigningKey($id);
        if (is_wp_error($response)) {
            return $response;
        }

        return ['message' => 'Signing key deleted successfully'];
    }

    // ─── JWT Signed URLs ────────────────────────────────────────────

    /**
     * Generate a signed JWT token for Mux playback
     *
     * @param string $playbackId
     * @param string $audience v=video, t=thumbnail, s=storyboard, g=gif, d=drm-license
     * @param int $expMinutes
     * @return string|null JWT token or null if signing not configured
     */
    public function generateSignedToken($playbackId, $audience = 'v', $expMinutes = 120, $params = [])
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return null;
        }

        $settings = $integration->getSettings();
        $keyId = Arr::get($settings, 'signing_key_id', '');
        $privateKeyBase64 = Arr::get($settings, 'signing_private_key', '');

        if (empty($keyId) || empty($privateKeyBase64)) {
            return null;
        }

        $privateKey = base64_decode($privateKeyBase64); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode

        $payload = [
            'sub' => $playbackId,
            'aud' => $audience,
            'exp' => time() + ($expMinutes * 60),
            'kid' => $keyId,
        ];

        // Signed URLs must use token as the only query param.
        // Thumbnail/storyboard params belong as top-level JWT claims (not a nested `params` object).
        if (!empty($params)) {
            $reserved = ['sub', 'aud', 'exp', 'kid'];
            foreach ($params as $key => $value) {
                if (!in_array($key, $reserved, true)) {
                    $payload[$key] = $value;
                }
            }
        }

        return self::encodeRs256($payload, $privateKey, $keyId);
    }

    /**
     * Encode an RS256 JWT (sign-only; Mux verifies server-side) using OpenSSL,
     * so the plugin does not bundle a JWT library it would only use to sign.
     *
     * @param array  $payload
     * @param string $privateKey PEM-encoded private key.
     * @param string $keyId      Mux signing key id, set as the JWT header `kid`.
     * @return string|null Null when signing fails (e.g. an invalid key).
     */
    private static function encodeRs256(array $payload, $privateKey, $keyId)
    {
        $headerJson = json_encode([
            'typ' => 'JWT',
            'alg' => 'RS256',
            'kid' => $keyId,
        ]);
        $bodyJson = json_encode($payload);
        // Bail rather than sign an empty segment (json_encode returns false on
        // e.g. invalid UTF-8 in a claim), which would emit a structurally broken
        // token Mux rejects. The caller degrades to an unsigned URL on null.
        if ($headerJson === false || $bodyJson === false) {
            return null;
        }

        $signingInput = self::base64UrlEncode($headerJson) . '.' . self::base64UrlEncode($bodyJson);

        $signature = '';
        if (!openssl_sign($signingInput, $signature, $privateKey, OPENSSL_ALGO_SHA256)) {
            return null;
        }

        return $signingInput . '.' . self::base64UrlEncode($signature);
    }

    private static function base64UrlEncode($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Get a signed HLS playback URL
     *
     * @param string $playbackId
     * @return string
     */
    public function getSignedPlaybackUrl($playbackId, $expMinutes = 120)
    {
        $token = $this->generateSignedToken($playbackId, 'v', $expMinutes);
        $url = Mux::getPlaybackUrl($playbackId);

        return $token ? $url . '?token=' . $token : $url;
    }

    /**
     * Get a signed thumbnail URL
     *
     * @param string $playbackId
     * @param array $params
     * @param bool $allowUnsignedFallback When false and signing is unavailable, returns empty string (no broken image for signed-only assets).
     * @return string
     */
    public function getSignedThumbnailUrl($playbackId, $params = [], $allowUnsignedFallback = true)
    {
        // For signed URLs, params must be embedded in JWT claims, not as query params
        $token = $this->generateSignedToken($playbackId, 't', 120, $params);
        $url = Mux::getThumbnailUrl($playbackId); // No query params for signed URLs

        if ($token) {
            return $url . '?token=' . $token;
        }

        return $allowUnsignedFallback ? Mux::getThumbnailUrl($playbackId, $params) : '';
    }

    /**
     * Get a signed storyboard URL
     *
     * @param string $playbackId
     * @param bool $allowUnsignedFallback When false and signing is unavailable, returns empty string.
     * @return string
     */
    public function getSignedStoryboardUrl($playbackId, $allowUnsignedFallback = true)
    {
        $token = $this->generateSignedToken($playbackId, 's');
        $url = Mux::getStoryboardUrl($playbackId);

        if ($token) {
            return $url . '?token=' . $token;
        }

        return $allowUnsignedFallback ? $url : '';
    }

    /**
     * Get a signed animated GIF URL
     *
     * @param string $playbackId
     * @param array $params
     * @param bool $allowUnsignedFallback When false and signing is unavailable, returns empty string.
     * @return string
     */
    public function getSignedAnimatedGifUrl($playbackId, $params = [], $allowUnsignedFallback = true)
    {
        $token = $this->generateSignedToken($playbackId, 'g', 120, $params);
        $url = Mux::getAnimatedGifUrl($playbackId);

        if ($token) {
            return $url . '?token=' . $token;
        }

        return $allowUnsignedFallback ? Mux::getAnimatedGifUrl($playbackId, $params) : '';
    }

    /**
     * Get a signed DRM license token
     *
     * @param string $playbackId
     * @return string|null
     */
    public function getDrmToken($playbackId)
    {
        return $this->generateSignedToken($playbackId, 'd', 60);
    }

    /**
     * Check if signed URLs are enabled and configured
     *
     * @return bool
     */
    public function isSignedUrlsEnabled()
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return false;
        }

        $settings = $integration->getSettings();

        return Arr::isTrue($settings, 'enable_signed_urls')
            && !empty(Arr::get($settings, 'signing_key_id'))
            && !empty(Arr::get($settings, 'signing_private_key'));
    }

    /**
     * Create a signing key and store it in integration settings
     *
     * @return array|\WP_Error
     */
    public function createAndStoreSigningKey()
    {
        $result = $this->validateAndGetClient();
        if (is_wp_error($result)) {
            return $result;
        }

        $response = $result['client']->createSigningKey();
        if (is_wp_error($response)) {
            return $response;
        }

        $keyData = Arr::get($response, 'data', []);
        $keyId = Arr::get($keyData, 'id', '');
        $privateKey = Arr::get($keyData, 'private_key', '');

        if (empty($keyId) || empty($privateKey)) {
            return new \WP_Error('invalid_key', __('Failed to generate signing key', 'fluent-player-pro'));
        }

        // Store the key in integration settings
        $integration = $this->getIntegration();
        if (!is_wp_error($integration)) {
            $settings = $integration->getSettings();
            $settings['signing_key_id'] = $keyId;
            $settings['signing_private_key'] = $privateKey;
            $integration->saveSettings($settings);
        }

        return [
            'key_id'  => $keyId,
            'message' => __('Signing key generated and saved successfully', 'fluent-player-pro'),
        ];
    }

    // ─── Auto Captions ──────────────────────────────────────────────

    /**
     * Get captions/subtitles from a Mux asset
     *
     * @param string $assetId
     * @return array|\WP_Error Array of subtitle tracks
     */
    public function getAssetCaptions($assetId)
    {
        $asset = $this->getAsset($assetId);
        if (is_wp_error($asset)) {
            return $asset;
        }

        $tracks = Arr::get($asset, 'tracks', []);
        $subtitles = [];

        foreach ($tracks as $track) {
            $type = Arr::get($track, 'type');
            if ($type !== 'text') {
                continue;
            }

            $textType = Arr::get($track, 'text_type');
            if (!in_array($textType, ['subtitles', 'captions'], true)) {
                continue;
            }

            $playbackId = Arr::get($asset, 'public_playback_id', '');
            $trackId = Arr::get($track, 'id', '');

            $subtitles[] = [
                'label'      => Arr::get($track, 'name', Arr::get($track, 'language_code', 'Unknown')),
                'language'   => Arr::get($track, 'language_code', 'en'),
                'url'        => $playbackId && $trackId
                    ? 'https://stream.mux.com/' . $playbackId . '/text/' . $trackId . '.vtt'
                    : '',
                'is_default' => Arr::get($track, 'status') === 'ready',
                'track_id'   => $trackId,
            ];
        }

        return $subtitles;
    }

    // ─── Webhook Processing ─────────────────────────────────────────

    /**
     * Verify a Mux webhook signature
     *
     * @param string $rawBody
     * @param string $signature Mux-Signature header value
     * @return bool
     */
    public function verifyWebhookSignature($rawBody, $signature)
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return false;
        }

        $settings = $integration->getSettings();
        $secret = Arr::get($settings, 'webhook_secret', '');

        if (empty($secret)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Error logging for debugging
                error_log('Fluent Player: Mux webhook secret is not configured. Webhooks will be rejected.');
            }
            return false;
        }

        // Mux-Signature format: t=timestamp,v1=signature
        $parts = [];
        foreach (explode(',', $signature) as $part) {
            $kv = explode('=', $part, 2);
            if (count($kv) === 2) {
                $parts[$kv[0]] = $kv[1];
            }
        }

        $timestamp = $parts['t'] ?? '';
        $v1Signature = $parts['v1'] ?? '';

        if (empty($timestamp) || empty($v1Signature)) {
            return false;
        }

        // Verify timestamp is within 5 minutes
        if (abs(time() - intval($timestamp)) > 300) {
            return false;
        }

        $payload = $timestamp . '.' . $rawBody;
        $expectedSignature = hash_hmac('sha256', $payload, $secret);

        return hash_equals($expectedSignature, $v1Signature);
    }

    /**
     * Handle a webhook event from Mux
     *
     * @param array $payload
     * @return array
     */
    public function handleWebhookEvent($payload)
    {
        $type = Arr::get($payload, 'type', '');
        $data = Arr::get($payload, 'data', []);

        switch ($type) {
            case 'video.asset.ready':
                return $this->onAssetReady($data);
            case 'video.asset.errored':
                return $this->onAssetErrored($data);
            case 'video.upload.asset_created':
                return $this->onUploadAssetCreated($data);
            case 'video.asset.track.ready':
                return $this->onTrackReady($data);
            case 'video.asset.static_rendition.ready':
                return $this->onStaticRenditionReady($data);
            default:
                do_action('fluent_player/mux_webhook', $type, $data);
                return ['handled' => false, 'type' => $type];
        }
    }

    /**
     * Handle asset.ready webhook — update media status and metadata
     *
     * @param array $data
     * @return array
     */
    protected function onAssetReady($data)
    {
        $assetId = Arr::get($data, 'id', '');
        $passthrough = Arr::get($data, 'passthrough', '');
        $duration = Arr::get($data, 'duration', 0);

        $mediaId = $this->findMediaByMuxAsset($assetId, $passthrough);

        if ($mediaId) {
            $media = \FluentPlayer\App\Models\Media::find($mediaId);
            if ($media) {
                $settings = $media->settings;
                $settings['mux']['status'] = sanitize_text_field('ready');
                $settings['mux']['duration'] = floatval($duration);

                // Get playback ID and keep src in sync
                $playbackIds = Arr::get($data, 'playback_ids', []);
                foreach ($playbackIds as $pid) {
                    if (Arr::get($pid, 'policy') === 'public' || Arr::get($pid, 'policy') === 'signed') {
                        $newPlaybackId = sanitize_text_field(Arr::get($pid, 'id', ''));
                        $settings['mux']['playback_id'] = $newPlaybackId;
                        if ($newPlaybackId) {
                            $settings['src'] = 'https://stream.mux.com/' . $newPlaybackId . '.m3u8';
                            $settings['posterSrc'] = 'https://image.mux.com/' . $newPlaybackId . '/thumbnail.jpg?width=1280&fit_mode=smartcrop';
                        }
                        break;
                    }
                }

                // Store max resolution and aspect ratio
                $maxResolution = Arr::get($data, 'max_stored_resolution', '');
                $aspectRatio = Arr::get($data, 'aspect_ratio', '');
                if ($maxResolution) {
                    $settings['mux']['max_resolution'] = sanitize_text_field($maxResolution);
                }
                if ($aspectRatio) {
                    $settings['mux']['aspect_ratio'] = sanitize_text_field($aspectRatio);
                }

                $media->settings = $settings;
                $media->save();
                update_post_meta($mediaId, '_flp_mux_asset_id', sanitize_text_field(Arr::get($data, 'id', '')));
            }
        }

        do_action('fluent_player/mux_asset_ready', $assetId, $data, $mediaId);

        return ['handled' => true, 'asset_id' => $assetId, 'media_id' => $mediaId];
    }

    /**
     * Handle asset.errored webhook
     *
     * @param array $data
     * @return array
     */
    protected function onAssetErrored($data)
    {
        $assetId = Arr::get($data, 'id', '');
        $passthrough = Arr::get($data, 'passthrough', '');

        $mediaId = $this->findMediaByMuxAsset($assetId, $passthrough);

        if ($mediaId) {
            $media = \FluentPlayer\App\Models\Media::find($mediaId);
            if ($media) {
                $settings = $media->settings;
                $settings['mux']['status'] = sanitize_text_field('errored');
                $media->settings = $settings;
                $media->save();
            }
        }

        do_action('fluent_player/mux_asset_errored', $assetId, $data, $mediaId);

        return ['handled' => true, 'asset_id' => $assetId];
    }

    /**
     * Handle upload.asset_created webhook — link upload to media
     *
     * @param array $data
     * @return array
     */
    protected function onUploadAssetCreated($data)
    {
        $assetId = Arr::get($data, 'new_asset_id', Arr::get($data, 'asset_id', ''));
        $passthrough = Arr::get($data, 'passthrough', '');

        $mediaId = $this->findMediaByMuxAsset('', $passthrough);

        if ($mediaId && $assetId) {
            $media = \FluentPlayer\App\Models\Media::find($mediaId);
            if ($media) {
                $settings = $media->settings;
                $settings['mux']['asset_id'] = sanitize_text_field($assetId);
                $settings['mux']['status'] = sanitize_text_field('preparing');
                $media->settings = $settings;
                $media->save();
                if ($assetId) {
                    update_post_meta($mediaId, '_flp_mux_asset_id', sanitize_text_field($assetId));
                }
            }
        }

        do_action('fluent_player/mux_upload_asset_created', $assetId, $data, $mediaId);

        return ['handled' => true, 'asset_id' => $assetId];
    }

    /**
     * Handle track.ready webhook — auto-caption finished
     *
     * @param array $data
     * @return array
     */
    protected function onTrackReady($data)
    {
        $assetId = Arr::get($data, 'asset_id', '');
        $trackData = Arr::get($data, 'track', $data);
        $trackId = Arr::get($trackData, 'id', '');
        $textType = Arr::get($trackData, 'text_type', '');

        if (!in_array($textType, ['subtitles', 'captions'], true)) {
            return ['handled' => false, 'reason' => 'not a text track'];
        }

        $mediaId = $this->findMediaByMuxAsset($assetId, '');

        if ($mediaId) {
            $media = \FluentPlayer\App\Models\Media::find($mediaId);
            if ($media) {
                $settings = $media->settings;
                $playbackId = Arr::get($settings, 'mux.playback_id', '');

                if ($playbackId && $trackId) {
                    $subtitles = Arr::get($settings, 'subtitles', []);

                    // Check for duplicate
                    foreach ($subtitles as $existing) {
                        if (isset($existing['track_id']) && $existing['track_id'] === $trackId) {
                            return ['handled' => true, 'asset_id' => $assetId, 'track_id' => $trackId, 'duplicate' => true];
                        }
                    }

                    $sanitizedPlaybackId = sanitize_text_field($playbackId);
                    $sanitizedTrackId = sanitize_text_field($trackId);

                    $subtitles[] = [
                        'label'      => sanitize_text_field(Arr::get($trackData, 'name', Arr::get($trackData, 'language_code', 'Auto'))),
                        'language'   => sanitize_text_field(Arr::get($trackData, 'language_code', 'en')),
                        'url'        => 'https://stream.mux.com/' . $sanitizedPlaybackId . '/text/' . $sanitizedTrackId . '.vtt',
                        'is_default' => empty($subtitles),
                        'track_id'   => $sanitizedTrackId,
                    ];
                    $settings['subtitles'] = $subtitles;
                    $media->settings = $settings;
                    $media->save();
                }
            }
        }

        do_action('fluent_player/mux_track_ready', $assetId, $trackData, $mediaId);

        return ['handled' => true, 'asset_id' => $assetId, 'track_id' => $trackId];
    }

    /**
     * Handle static_rendition.ready webhook — MP4 available
     *
     * @param array $data
     * @return array
     */
    protected function onStaticRenditionReady($data)
    {
        $assetId = Arr::get($data, 'id', Arr::get($data, 'asset_id', ''));

        do_action('fluent_player/mux_static_rendition_ready', $assetId, $data);

        return ['handled' => true, 'asset_id' => $assetId];
    }

    /**
     * Find a WordPress media post by Mux asset ID or passthrough value
     *
     * @param string $assetId
     * @param string $passthrough
     * @return int|null
     */
    protected function findMediaByMuxAsset($assetId, $passthrough = '')
    {
        // If passthrough is a numeric value, it's likely the WP media ID
        if (!empty($passthrough) && is_numeric($passthrough)) {
            $media = \FluentPlayer\App\Models\Media::find(intval($passthrough));
            if ($media) {
                return $media->ID;
            }
        }

        if (empty($assetId)) {
            return null;
        }

        $posts = get_posts([
            'post_type'  => 'fluent_player_media',
            'meta_key'   => '_flp_mux_asset_id',
            'meta_value' => $assetId,
            'numberposts' => 1,
            'fields'     => 'ids',
        ]);

        return !empty($posts) ? intval($posts[0]) : null;
    }

    // ─── Mux Data ───────────────────────────────────────────────────

    /**
     * Get the Mux Data environment key if configured
     *
     * @return string
     */
    public function getMuxDataEnvKey()
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return '';
        }

        return Arr::get($integration->getSettings(), 'mux_data_env_key', '');
    }

    // ─── Player Settings Filter ────────────────────────────────────

    /**
     * Filter player settings to inject signed URLs, DRM tokens, and Mux Data env key
     *
     * @param array $settings
     * @return array
     */
    public static function filterPlayerSettings($settings)
    {
        $provider = Arr::get($settings, 'provider', '');
        if ($provider !== 'mux' && $provider !== 'mux_stream') {
            return $settings;
        }

        $playbackId = Arr::get($settings, 'mux.playback_id', '');
        if (empty($playbackId)) {
            return $settings;
        }

        static $muxService = null;
        if ($muxService === null) {
            $muxService = new self();
        }

        $playbackPolicy = (string) Arr::get($settings, 'mux.playback_policy', '');
        $storedToken = (string) Arr::get($settings, 'mux.playback_token', '');
        // Public playback works without JWT. Wrapping with a global signing key breaks playback when
        // the asset is public on Mux or keys do not match this playback ID.
        $useMuxSigning = ($playbackPolicy === 'signed')
            || ($playbackPolicy !== 'public' && $storedToken !== '');

        // Signed URLs
        if ($muxService->isSignedUrlsEnabled() && $useMuxSigning) {
            // Token expiry must exceed video duration, otherwise playback cuts off mid-stream
            $duration = floatval(Arr::get($settings, 'mux.duration', 0));
            $expMinutes = max(120, intval(ceil($duration / 60)) + 60); // duration + 1 hour buffer

            $signedSrc = $muxService->getSignedPlaybackUrl($playbackId, $expMinutes);
            $settings['src'] = $signedSrc;

            $playbackToken = null;
            if (is_string($signedSrc) && preg_match('/[?&]token=([^&]+)/', $signedSrc, $m)) {
                $playbackToken = $m[1];
            }

            $posterSrc = Arr::get($settings, 'posterSrc', '');
            if (!empty($posterSrc) && strpos($posterSrc, 'image.mux.com') !== false) {
                $settings['posterSrc'] = $muxService->getSignedThumbnailUrl($playbackId, ['width' => 1280, 'fit_mode' => 'smartcrop']);
            }

            $thumbnails = Arr::get($settings, 'thumbnails', '');
            if (!empty($thumbnails) && strpos($thumbnails, 'image.mux.com') !== false) {
                $settings['thumbnails'] = $muxService->getSignedStoryboardUrl($playbackId);
            }

            // DRM token for Widevine/FairPlay
            $drmToken = $muxService->getDrmToken($playbackId);
            if ($drmToken) {
                $settings['drm'] = [
                    'mux_token' => $drmToken,
                ];
            }

            // Text tracks use the same playback JWT as HLS when signed URLs are enabled
            if ($playbackToken) {
                $subtitles = Arr::get($settings, 'subtitles', []);
                if (!empty($subtitles) && is_array($subtitles)) {
                    foreach ($subtitles as $i => $sub) {
                        if (!is_array($sub)) {
                            continue;
                        }
                        $url = Arr::get($sub, 'url', '');
                        if ($url && strpos($url, 'stream.mux.com') !== false && strpos($url, 'token=') === false) {
                            $sep = strpos($url, '?') !== false ? '&' : '?';
                            $settings['subtitles'][$i]['url'] = $url . $sep . 'token=' . $playbackToken;
                        }
                    }
                }
            }
        }

        $muxDataEnvKey = $muxService->getMuxDataEnvKey();
        if (!empty($muxDataEnvKey)) {
            $muxData = [
                'env_key'   => $muxDataEnvKey,
                'page_type' => 'watchpage',
            ];

            // cohort by site host so multisite installs segment automatically
            $host = parse_url((string) home_url(), PHP_URL_HOST);
            if (is_string($host) && $host !== '') {
                $muxData['sub_property_id'] = $host;
            }

            $userId = get_current_user_id();
            if ($userId > 0) {
                // Hash with wp_salt so raw WP user IDs are never sent to Mux; salt rotation
                // intentionally invalidates the cross-session ID (privacy-positive).
                $hash = substr(hash('sha256', $userId . '|' . wp_salt()), 0, 32);

                /**
                 * Filter the Mux Data viewer_user_id. Return empty/null to disable viewer
                 * tracking — consent plugins (GDPR/CCPA) should hook here.
                 *
                 * @param string $hash   32-char SHA-256 hex of the WP user ID + wp_salt.
                 * @param int    $userId Raw WP user ID (do NOT send this directly).
                 */
                $viewerId = apply_filters('fluent_player/mux_data_viewer_id', $hash, $userId);
                if (is_string($viewerId) && $viewerId !== '') {
                    $muxData['viewer_user_id'] = $viewerId;
                }
            }

            /**
             * Filter the Mux Data payload before it is sent to the player.
             * Add or override fields such as `experiment_name`, `custom_1`..`custom_5`,
             * `sub_property_id`, or `viewer_user_id` for richer cohort slicing.
             *
             * Note: per-instance fields (`video_id`, `video_title`, `video_duration`,
             * `video_source_url`, `player_name`, `player_init_time`, `video_cdn`)
             * are set by the player and override any value returned here.
             *
             * @param array $muxData  Payload merged into mux.monitor() data.
             * @param array $settings Player settings for the current media.
             */
            $filtered = apply_filters('fluent_player/mux_data', $muxData, $settings);
            if (!is_array($filtered)) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- diagnostic for misbehaving filter
                error_log('Fluent Player: fluent_player/mux_data filter returned non-array; ignoring. Got: ' . gettype($filtered));
                $filtered = $muxData;
            }
            $settings['mux_data'] = $filtered;
        }

        return $settings;
    }

    // ─── Auto Captions Helper ───────────────────────────────────────

    /**
     * Get auto-caption settings for Mux asset creation
     * Returns the array for `generated_subtitles` param, or null if disabled
     *
     * @return array|null
     */
    protected function getAutoCaptionSettings()
    {
        $integration = $this->getIntegration();
        if (is_wp_error($integration)) {
            return null;
        }

        $settings = $integration->getSettings();

        if (!Arr::isTrue($settings, 'enable_auto_captions')) {
            return null;
        }

        $language = Arr::get($settings, 'auto_caption_language', 'en');

        return [
            [
                'name'          => $this->getLanguageName($language),
                'language_code' => $language,
            ],
        ];
    }

    // ─── Helpers ─────────────────────────────────────────────────────

    /**
     * Get the full language name from a language code
     *
     * @param string $code ISO 639-1 language code
     * @return string
     */
    protected function getLanguageName($code)
    {
        $languages = static::getSupportedCaptionLanguages();

        return $languages[$code] ?? strtoupper($code);
    }

    /**
     * Get Mux-supported auto-caption languages
     *
     * @return array Language code => name mapping
     */
    public static function getSupportedCaptionLanguages()
    {
        return [
            // Stable
            'en' => 'English',
            'es' => 'Spanish',
            'it' => 'Italian',
            'pt' => 'Portuguese',
            'de' => 'German',
            'fr' => 'French',
        ];
    }

    /**
     * Enrich an asset with playback and thumbnail URLs
     *
     * @param array &$asset
     */
    protected function enrichAsset(&$asset)
    {
        $playbackIds = Arr::get($asset, 'playback_ids', []);
        if (empty($playbackIds)) {
            return;
        }

        $publicId = null;
        $signedId = null;
        $firstId = Arr::get($playbackIds, '0.id');

        foreach ($playbackIds as $pid) {
            $policy = Arr::get($pid, 'policy');
            $id = Arr::get($pid, 'id');
            if (!$id) {
                continue;
            }
            if ($policy === 'public') {
                $publicId = $id;
            } elseif ($policy === 'signed') {
                $signedId = $signedId ?: $id;
            }
        }

        // Prefer public playback for URLs that work without a JWT in the block editor.
        $playbackId = $publicId ?: $signedId ?: $firstId;
        $playbackPolicy = $publicId ? 'public' : ($signedId ? 'signed' : null);

        if ($playbackId) {
            $asset['public_playback_id'] = $playbackId;
            $asset['playback_policy'] = $playbackPolicy;
            $asset['has_public_playback'] = (bool) $publicId;

            $asset['playback_url'] = Mux::getPlaybackUrl($playbackId);

            // Signed playback IDs require JWT on image.mux.com (audience t). Do not fall back to unsigned URLs (broken).
            if ($playbackPolicy === 'signed') {
                $asset['thumbnail_url'] = $this->getSignedThumbnailUrl($playbackId, [
                    'width'    => 640,
                    'fit_mode' => 'smartcrop',
                ], false);
                $asset['storyboard_url'] = $this->getSignedStoryboardUrl($playbackId, false);
                $asset['animated_gif_url'] = $this->getSignedAnimatedGifUrl($playbackId, [], false);
            } else {
                $asset['thumbnail_url'] = Mux::getThumbnailUrl($playbackId);
                $asset['storyboard_url'] = Mux::getStoryboardUrl($playbackId);
                $asset['animated_gif_url'] = Mux::getAnimatedGifUrl($playbackId);
            }
        }
    }
}
