<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayer\Framework\Support\Arr;

class TagService
{
    public static function registerTaxonomy()
    {
        register_taxonomy('flp_media_tag', 'fluent_player_media', [
            'labels' => [
                'name'          => __('Tags', 'fluent-player-pro'),
                'singular_name' => __('Tag', 'fluent-player-pro'),
            ],
            'public'       => false,
            'show_ui'      => false,
            'show_in_rest' => false,
            'hierarchical' => false,
            'rewrite'      => false,
        ]);
    }

    public static function onSaveMedia($mediaId, $data)
    {
        $tags = \FluentPlayer\Framework\Support\Arr::get($data, 'tags');
        if ($tags === null) {
            return;
        }
        self::syncTags($mediaId, $tags);
    }

    public static function filterQuery($query, $args)
    {
        if (Arr::get($args, 'tags_query_applied')) {
            return $query;
        }

        $tag = sanitize_title(Arr::get($args, 'tag', ''));
        $tags = Arr::get($args, 'tags', []);

        if (is_string($tags)) {
            $tags = explode(',', $tags);
        }

        if (!is_array($tags)) {
            $tags = [];
        }

        $tags = array_values(array_filter(array_map('sanitize_title', $tags)));
        if ($tag && !in_array($tag, $tags, true)) {
            $tags[] = $tag;
        }

        if (empty($tags)) {
            return $query;
        }

        $terms = get_terms([
            'taxonomy'   => 'flp_media_tag',
            'hide_empty' => false,
            'slug'       => $tags,
        ]);

        if (is_wp_error($terms) || empty($terms)) {
            return $query->where('ID', 0);
        }

        $termIds = array_map(function ($term) {
            return (int) $term->term_taxonomy_id;
        }, $terms);

        $query->whereExists(function ($subQuery) use ($termIds) {
            $subQuery->selectRaw('1')
                ->from('term_relationships')
                ->whereColumn('term_relationships.object_id', '=', 'posts.ID')
                ->whereIn('term_relationships.term_taxonomy_id', $termIds);
        });

        return $query;
    }

    public static function getTagsBundle($withCounts = false)
    {
        $terms = get_terms([
            'taxonomy'   => 'flp_media_tag',
            'hide_empty' => false,
        ]);

        if (is_wp_error($terms)) {
            $terms = [];
        }

        $tags = $withCounts
            ? array_values(array_map(function ($term) {
                return [
                    'name'  => $term->name,
                    'count' => (int) $term->count,
                ];
            }, $terms))
            : wp_list_pluck($terms, 'name');

        $tagOptions = array_values(array_map(function ($term) {
            return [
                'name' => $term->name,
                'slug' => $term->slug,
            ];
        }, $terms));

        return [
            'tags'       => $tags,
            'tagOptions' => $tagOptions,
        ];
    }

    public static function createTag($tagName)
    {
        $existing = get_term_by('name', $tagName, 'flp_media_tag');
        if ($existing) {
            return new \WP_Error('duplicate', __('A tag with that name already exists', 'fluent-player-pro'));
        }

        return wp_insert_term($tagName, 'flp_media_tag');
    }

    public static function renameTag($oldName, $newName)
    {
        $term = get_term_by('name', $oldName, 'flp_media_tag');
        if (!$term) {
            return new \WP_Error('not_found', __('Tag not found', 'fluent-player-pro'));
        }

        $existing = get_term_by('name', $newName, 'flp_media_tag');
        if ($existing && $existing->term_id !== $term->term_id) {
            return new \WP_Error('duplicate', __('A tag with that name already exists', 'fluent-player-pro'));
        }

        return wp_update_term($term->term_id, 'flp_media_tag', ['name' => $newName]);
    }

    public static function deleteTag($tagName)
    {
        $term = get_term_by('name', $tagName, 'flp_media_tag');
        if (!$term) {
            return new \WP_Error('not_found', __('Tag not found', 'fluent-player-pro'));
        }

        return wp_delete_term($term->term_id, 'flp_media_tag');
    }

    public static function syncTags($mediaId, $tags)
    {
        if (!is_array($tags)) {
            $tags = [];
        }
        $tags = array_filter(array_map('sanitize_text_field', $tags));
        wp_set_object_terms((int) $mediaId, $tags, 'flp_media_tag');
    }
}
