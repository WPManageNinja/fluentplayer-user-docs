<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayerPro\App\Layouts\PlaylistLayoutFactory;

/**
 * Centralized settings management for playlist layouts
 * Handles data preparation, validation, and default settings
 */
class PlaylistSettingsHelper
{
    /**
     * Read playlist settings from playlist object or array shape.
     *
     * @param mixed $playlist
     * @return array
     */
    public static function getPlaylistSettings($playlist)
    {
        if (is_array($playlist)) {
            $settings = Arr::get($playlist, 'settings', []);
            return is_array($settings) ? $settings : [];
        }

        if (is_object($playlist) && isset($playlist->settings) && is_array($playlist->settings)) {
            return $playlist->settings;
        }

        return [];
    }

    /**
     * Default settings for all playlist layouts
     */
    const DEFAULT_SETTINGS = [
        'layout'     => [
            'type'          => 'standard',
            'position'      => 'right',
            'showHeader'    => true,
            'headerPosition' => 'top',
            'sidebarWidth'  => 40,
            'spacing'       => [
                'padding' => ['top' => 20, 'right' => 20, 'bottom' => 20, 'left' => 20, 'unit' => 'px'],
                'margin'  => ['top' => 0, 'right' => 0, 'bottom' => 0, 'left' => 0, 'unit' => 'px']
            ]
        ],
        'appearance' => [
            'backgroundColor' => '#ffffff',
            'textColor'       => '#333333',
            'primaryColor'    => '#007bff',
            'borderRadius'    => ['value' => 8, 'unit' => 'px'],
            'separator'       => ['type' => 'line', 'size' => ['value' => 1, 'unit' => 'px']],
            'boxShadow'       => [
                'enabled'    => true,
                'horizontal' => 0,
                'vertical'   => 2,
                'blur'       => 8,
                'spread'     => 0,
                'color'      => '#000000',
                'position'   => 'outline'
            ]
        ],
        'behavior'   => [
            'showThumbnails'         => true,
            'thumbnailGridLayout'    => false,
            'showThumbnailInfo'      => true,
            'titlePosition'          => 'overlay',
            'autoplay'               => false,
            'continuousPlay'         => false,
            'loop'                   => false,
            'showNavButtons'         => true,
            'showPlaylistMenuToggle' => true,
            'keyboardControls'       => true,
            'touchGestures'          => true
        ],
        'typography' => [
            'enabled'    => false,
            'fontSize'   => ['value' => 14, 'unit' => 'px'],
            'fontWeight' => 400,
            'lineHeight' => 1.4,
            'fontFamily' => 'inherit'
        ],
        'grid'       => [
            'columns'              => 3,
            'itemsPerPage'         => 12,
            'enableSearch'         => true,
            'enableFilters'        => true,
            'displayMode'          => 'inline',
            'enableModalPlayback'  => true,
            'enableFullscreenMode' => true,
            'modalLayout'          => 'centered',
            'modalShowInfo'        => true
        ]
    ];
    
    /**
     * Validation constraints
     */
    const VALIDATION_RULES = [
        'grid'       => [
            'columns'      => ['min' => 2, 'max' => 6],
            'itemsPerPage' => ['min' => 6, 'max' => 50]
        ],
        'learning'   => [
            'completionThreshold' => ['min' => 1, 'max' => 100]
        ],
        'typography' => [
            'fontSize'   => ['min' => 8, 'max' => 72],
            'lineHeight' => ['min' => 0.8, 'max' => 3.0],
            'fontWeight' => [100, 200, 300, 400, 500, 600, 700, 800, 900]
        ],
        'appearance' => [
            'units'              => ['px', 'em', 'rem'],
            'boxShadowPositions' => ['outline', 'inset'],
        ]
    ];
    
    /**
     * Prepare playlist data for rendering
     */
    public static function preparePlaylistData(
        $playlist,
        $medias,
        $defaultSettings,
        $playlistId,
        $playlistVarName
    ) {
        $settings = self::sanitizeAndValidate(Arr::get($playlist, 'settings', []));
        $preparedMedias = self::prepareMediaData($medias);
        
        return [
            'playlist'        => $playlist,
            'medias'          => $preparedMedias,
            'settings'        => $settings,
            'playlistId'      => $playlistId,
            'playlistVarName' => $playlistVarName
        ];
    }
    
    /**
     * Merge settings with defaults using WordPress function
     */
    public static function mergeSettings(array $defaults, array $custom)
    {
        return array_replace_recursive($defaults, $custom);
    }

    /**
     * Generate a stable synthetic ID for playlist-by-tags renders.
     *
     * @param array $tags
     * @param array $query
     * @param array $settings
     * @return string
     */
    public static function generateTagPlaylistId(array $tags, array $query, array $settings)
    {
        $hashTags = array_values($tags);
        sort($hashTags, SORT_STRING);

        $config = [
            'tags'     => $hashTags,
            'query'    => [
                'limit'   => (int) Arr::get($query, 'limit', 20),
                'orderby' => (string) Arr::get($query, 'orderby', 'date'),
                'order'   => (string) Arr::get($query, 'order', 'DESC'),
            ],
            'settings' => $settings,
        ];

        return 'tag_' . substr(sha1(wp_json_encode($config)), 0, 12);
    }
    
    /**
     * Sanitize and validate all playlist settings
     * Single source of truth for processing settings
     */
    public static function sanitizeAndValidate($settings)
    {
        if (!is_array($settings)) {
            $settings = [];
        }

        // 1. Sanitize the data using the framework's sanitizer and our defined rules.
        $rules = self::getAllSanitizationRules();
        $sanitizedSettings = Sanitizer::sanitize($settings, $rules);

        // 2. Merge with defaults recursively to preserve nested setting defaults.
        $settingsWithDefaults = self::mergeSettings(self::DEFAULT_SETTINGS, $sanitizedSettings);
        
        // 3. Run final validation checks on the clean, sanitized, and defaulted data.
        return self::runFinalValidation($settingsWithDefaults);
    }
    
    /**
     * Get all sanitization rules
     */
    private static function getAllSanitizationRules()
    {
        return array_merge(
            self::getCommonRules(),
            self::getAppearanceRules(),
            self::getLayoutRules(),
            self::getBehaviorRules(),
            self::getTypographyRules(),
            self::getGridRules(),
            self::getLearningRules()
        );
    }
    
    /**
     * Run final validation checks
     */
    private static function runFinalValidation(array $settings)
    {
        $settings = self::validateAppearanceSettings($settings);
        $settings = self::validateBehaviorSettings($settings);
        $settings = self::validateTypographySettings($settings);

        $validPositions = ['top', 'bottom', 'left', 'right'];
        $position = Arr::get($settings, 'layout.position', 'right');
        if (!in_array($position, $validPositions, true)) {
            if (!isset($settings['layout']) || !is_array($settings['layout'])) {
                $settings['layout'] = [];
            }
            $settings['layout']['position'] = 'right';
        }

        $layoutType = Arr::get($settings, 'layout.type', 'standard');

        if (!array_key_exists($layoutType, PlaylistLayoutFactory::LAYOUT_TYPES)) {
            $settings['layout']['type'] = 'standard';
            $layoutType = 'standard';
        }

        switch ($layoutType) {
            case 'grid':
                $settings = self::validateGridSettings($settings);
                break;
            case 'learning':
                $settings = self::validateLearningSettings($settings);
                break;
        }
        
        return $settings;
    }
    
    /**
     * Validate appearance settings
     */
    private static function validateAppearanceSettings(array $settings)
    {
        $appearance = &$settings['appearance'];

        if (isset($appearance['borderRadius'])) {
            $appearance['borderRadius']['unit'] = self::validateUnit($appearance['borderRadius']['unit']);
        }

        if (isset($appearance['boxShadow'])) {
            $boxShadow = &$appearance['boxShadow'];
            $boxShadow['blur'] = max(0, $boxShadow['blur']);
            $boxShadow['position'] = in_array($boxShadow['position'], self::VALIDATION_RULES['appearance']['boxShadowPositions'])
                ? $boxShadow['position'] : 'outline';
            if (isset($boxShadow['color'])) {
                $boxShadow['color'] = self::colorToHex($boxShadow['color']);
            }
        }

        return $settings;
    }

    private static function colorToHex($color)
    {
        if (empty($color) || !is_string($color)) {
            return '#000000';
        }
        $color = trim($color);
        if (preg_match('/^#([0-9a-fA-F]{6})([0-9a-fA-F]{2})?$/', $color, $m)) {
            $hex = '#' . strtolower($m[1]);
            if (isset($m[2])) {
                $hex .= strtolower($m[2]);
            }
            return $hex;
        }
        if (preg_match('/^rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([\d.]+))?\s*\)/', $color, $m)) {
            $r = min(255, max(0, (int) $m[1]));
            $g = min(255, max(0, (int) $m[2]));
            $b = min(255, max(0, (int) $m[3]));
            $a = isset($m[4]) ? min(1, max(0, (float) $m[4])) : 1;
            $aHex = sprintf('%02x', (int) round($a * 255));
            return sprintf('#%02x%02x%02x%s', $r, $g, $b, $aHex);
        }
        return '#000000';
    }
    
    /**
     * Validate behavior settings
     */
    private static function validateBehaviorSettings(array $settings)
    {
        $behavior = &$settings['behavior'];

        // Ensure autoplay is a boolean
        if (isset($behavior['autoplay'])) {
            $behavior['autoplay'] = rest_sanitize_boolean($behavior['autoplay']);
        }

        return $settings;
    }
    
    /**
     * Validate typography settings
     */
    private static function validateTypographySettings(array $settings)
    {
        $typography = &$settings['typography'];

        if ($typography['enabled']) {
            $rules = self::VALIDATION_RULES['typography'];
            if (isset($typography['fontSize'])) {
                $typography['fontSize']['value'] = max($rules['fontSize']['min'], min($rules['fontSize']['max'], $typography['fontSize']['value']));
                $typography['fontSize']['unit'] = self::validateUnit($typography['fontSize']['unit']);
            }

            if (isset($typography['fontWeight'])) {
                $typography['fontWeight'] = in_array($typography['fontWeight'], $rules['fontWeight']) ? $typography['fontWeight'] : 400;
            }

            if (isset($typography['lineHeight'])) {
                $typography['lineHeight'] = max($rules['lineHeight']['min'], min($rules['lineHeight']['max'], $typography['lineHeight']));
            }
        }

        return $settings;
    }
    
    /**
     * Validate grid-specific settings
     */
    private static function validateGridSettings(array $settings)
    {
        if (isset($settings['grid'])) {
            $rules = self::VALIDATION_RULES['grid'];
            $grid = &$settings['grid'];
            $grid['columns'] = max($rules['columns']['min'], min($rules['columns']['max'], $grid['columns']));
            $grid['itemsPerPage'] = max($rules['itemsPerPage']['min'], min($rules['itemsPerPage']['max'], $grid['itemsPerPage']));
        }

        // Grid renders the playlist as a page-level grid — there is no collapsible
        // menu for the player-controls toggle to hide/reveal. Force the setting
        // off so a stale "on" value (carried over from another layout) never
        // implies a toggle exists for grid. See GridPlaylistLayout::supportsPlaylistMenuToggle().
        if (!isset($settings['behavior']) || !is_array($settings['behavior'])) {
            $settings['behavior'] = [];
        }
        $settings['behavior']['showPlaylistMenuToggle'] = false;

        return $settings;
    }
    
    /**
     * Validate learning-specific settings
     */
    private static function validateLearningSettings(array $settings)
    {
        if (isset($settings['learning'])) {
            $learning = &$settings['learning'];
            $rules = self::VALIDATION_RULES['learning'];
            
            $learning['completionThreshold'] = max($rules['completionThreshold']['min'],
                min($rules['completionThreshold']['max'], absint(Arr::get($learning, 'completionThreshold', 80))));
            
            // Boolean fields using WordPress sanitizer
            $learning['enableProgress'] = rest_sanitize_boolean(Arr::get($learning, 'enableProgress', true));
            $learning['enableChapters'] = rest_sanitize_boolean(Arr::get($learning, 'enableChapters', true));
            $learning['showLockedContent'] = rest_sanitize_boolean(Arr::get($learning, 'showLockedContent', true));
        }
        return $settings;
    }
    
    /**
     * Prepare media data for rendering
     */
    public static function prepareMediaData(array $medias)
    {
        return array_map(function ($media) {
            if (!isset($media->settings)) {
                $media->settings = [];
            }
            
            $media->computed = [
                'duration_formatted' => self::formatDuration(Arr::get($media->settings, 'duration', 0)),
                'has_poster'         => !empty(Arr::get($media->settings, 'posterSrc')),
                'is_video'           => Arr::get($media->settings, 'mediaType', 'video') === 'video'
            ];
            
            return $media;
        }, $medias);
    }
    
    /**
     * Get layout classes for CSS
     */
    public static function getLayoutClasses(array $settings): string
    {
        $classes = ['fluent-playlist'];
        $layoutType = sanitize_html_class(Arr::get($settings, 'layout.type', 'standard'));
        $position = sanitize_html_class(Arr::get($settings, 'layout.position', 'right'));
        
        $classes[] = 'playlist-' . $layoutType;
        
        $validPositions = ['left', 'bottom', 'top'];
        if (in_array($position, $validPositions)) {
            $classes[] = 'playlist-' . $position;
        }
        
        // Use WordPress function to join classes
        return esc_attr(implode(' ', array_filter($classes)));
    }
    
    /**
     * Get CSS variables for dynamic styling
     */
    public static function getCssVariables(array $settings)
    {
        $variables = [];
        $appearance = Arr::get($settings, 'appearance', []);
        
        // Basic appearance variables with WordPress escaping
        $variables['--fp-playlist-background-color'] = esc_attr($appearance['backgroundColor'] ?? '#ffffff');
        $variables['--fp-playlist-text-color'] = esc_attr($appearance['textColor'] ?? '#333333');
        $variables['--fp-playlist-brand-color'] = esc_attr($appearance['primaryColor'] ?? '#007bff');
        
        // Border radius
        $borderRadius = Arr::get($appearance, 'borderRadius', []);
        if (!empty($borderRadius['value'])) {
            $variables['--fp-playlist-border-radius'] = esc_attr($borderRadius['value'] . ($borderRadius['unit'] ?? 'px'));
        }
        
        // Box shadow
        $boxShadow = Arr::get($appearance, 'boxShadow', []);
        if (!empty($boxShadow['enabled'])) {
            $shadowParts = [
                $boxShadow['position'] === 'inset' ? 'inset' : '',
                absint($boxShadow['horizontal'] ?? 0) . 'px',
                absint($boxShadow['vertical'] ?? 2) . 'px',
                absint($boxShadow['blur'] ?? 8) . 'px',
                absint($boxShadow['spread'] ?? 0) . 'px',
                esc_attr($boxShadow['color'] ?? '#000000')
            ];
            $variables['--fp-playlist-box-shadow'] = esc_attr(trim(implode(' ', array_filter($shadowParts))));
        }
        
        // Typography
        $typography = Arr::get($settings, 'typography', []);
        if (!empty($typography['enabled'])) {
            if (!empty($typography['fontSize'])) {
                $variables['--fp-playlist-font-size'] = esc_attr($typography['fontSize']['value'] . ($typography['fontSize']['unit'] ?? 'px'));
            }
            $variables['--fp-playlist-font-weight'] = esc_attr($typography['fontWeight'] ?? 400);
            $variables['--fp-playlist-line-height'] = esc_attr($typography['lineHeight'] ?? 1.4);
        }
        
        return $variables;
    }
    
    /**
     * Validate color value using WordPress functions first, fallback to custom
     */
    private static function validateColor(string $color): string
    {
        // Try WordPress hex color sanitizer first
        $hexColor = sanitize_hex_color($color);
        if ($hexColor) {
            return $hexColor;
        }
        
        // Fallback to custom validation for rgba, hsla, etc.
        if (preg_match('/^rgb[a]?\(/', $color) || preg_match('/^hsl[a]?\(/', $color)) {
            return sanitize_text_field($color);
        }
        
        return '#ffffff';
    }
    
    /**
     * Validate CSS unit
     */
    private static function validateUnit(string $unit): string
    {
        $unit = sanitize_key($unit);
        return in_array($unit, self::VALIDATION_RULES['appearance']['units']) ? $unit : 'px';
    }
    
    /**
     * Format duration for display as HH:MM:SS
     */
    private static function formatDuration($seconds): string
    {
        if (!is_numeric($seconds) || $seconds < 0) {
            return '0:00:00';
        }
        $secs = (int) floor((float) $seconds);
        $hours = (int) floor($secs / 3600);
        $minutes = (int) floor(($secs % 3600) / 60);
        $s = $secs % 60;
        return sprintf('%d:%02d:%02d', $hours, $minutes, $s);
    }
    
    // Sanitization rule methods - now using more WordPress functions
    private static function getCommonRules()
    {
        return [
            'title'                   => 'sanitize_text_field',
            'description'             => 'wp_kses_post',
            'medias.*'                => 'intval',
            'preset_source_media_id'  => 'absint',
        ];
    }

    private static function getAppearanceRules()
    {
        return [
            'appearance.primaryColor'         => 'sanitize_text_field',
            'appearance.backgroundColor'      => 'sanitize_text_field',
            'appearance.textColor'            => 'sanitize_text_field',
            'appearance.accentColor'          => 'sanitize_text_field',
            'appearance.borderColor'          => 'sanitize_text_field',
            'appearance.borderWidth.value'    => 'absint',
            'appearance.borderWidth.unit'     => 'sanitize_key',
            'appearance.separator.type'       => 'sanitize_key',
            'appearance.separator.size.value' => 'absint',
            'appearance.separator.size.unit'  => 'sanitize_key',
            'appearance.borderRadius.value'   => 'absint',
            'appearance.borderRadius.unit'    => 'sanitize_key',
            'appearance.brandColor.mode'      => 'sanitize_key',
            'appearance.brandColor.value'     => 'sanitize_text_field',
            'appearance.boxShadow.enabled'    => 'rest_sanitize_boolean',
            'appearance.boxShadow.horizontal' => 'intval',
            'appearance.boxShadow.vertical'   => 'intval',
            'appearance.boxShadow.blur'       => 'absint',
            'appearance.boxShadow.spread'     => 'intval',
            'appearance.boxShadow.color'      => 'sanitize_text_field',
            'appearance.boxShadow.position'   => 'sanitize_key',
        ];
    }
    
    private static function getLayoutRules()
    {
        return [
            'layout.spacing'        => 'rest_sanitize_boolean',
            'layout.maxWidth'       => 'sanitize_text_field',
            'layout.aspectRatio'    => 'sanitize_text_field',
            'layout.position'       => 'sanitize_key',
            'layout.type'           => 'sanitize_key',
            'layout.showHeader'     => 'rest_sanitize_boolean',
            'layout.headerPosition' => 'sanitize_key',
            'layout.sidebarWidth'   => 'absint',
            'layout.padding.top'    => 'absint',
            'layout.padding.right'  => 'absint',
            'layout.padding.bottom' => 'absint',
            'layout.padding.left'   => 'absint',
            'layout.padding.unit'   => 'sanitize_key',
            'layout.padding.linked' => 'rest_sanitize_boolean',
            'layout.margin.top'     => 'intval',
            'layout.margin.right'   => 'intval',
            'layout.margin.bottom'  => 'intval',
            'layout.margin.left'    => 'intval',
            'layout.margin.unit'    => 'sanitize_key',
            'layout.margin.linked'  => 'rest_sanitize_boolean',
            'layout.thumbnailRatio' => 'sanitize_text_field',
        ];
    }
    
    private static function getBehaviorRules()
    {
        return [
            'behavior.shuffle'             => 'rest_sanitize_boolean',
            'behavior.continuousPlay'      => 'rest_sanitize_boolean',
            'behavior.showProgress'        => 'rest_sanitize_boolean',
            'behavior.showDuration'        => 'rest_sanitize_boolean',
            'behavior.showThumbnails'      => 'rest_sanitize_boolean',
            'behavior.thumbnailGridLayout' => 'rest_sanitize_boolean',
            'behavior.showThumbnailInfo'   => 'rest_sanitize_boolean',
            'behavior.titlePosition'       => 'sanitize_key',
            'behavior.loop'                   => 'rest_sanitize_boolean',
            'behavior.showNavButtons'         => 'rest_sanitize_boolean',
            'behavior.showPlaylistMenuToggle' => 'rest_sanitize_boolean',
            'behavior.clickToPlay'         => 'rest_sanitize_boolean',
            'behavior.keyboardControls'    => 'rest_sanitize_boolean',
            'behavior.touchGestures'       => 'rest_sanitize_boolean',
            'behavior.autoplay'            => 'rest_sanitize_boolean',
            'behavior.muted.mode'          => 'sanitize_key',
            'behavior.muted.value'         => 'rest_sanitize_boolean',
            'behavior.volume.mode'         => 'sanitize_key',
            'behavior.volume.value'        => 'absint',
            'behavior.playbackRate.mode'   => 'sanitize_key',
            'behavior.playbackRate.value'  => 'absint'
        ];
    }
    
    private static function getTypographyRules()
    {
        return [
            'typography.enabled'             => 'rest_sanitize_boolean',
            'typography.fontFamily'          => 'sanitize_text_field',
            'typography.fontWeight'          => 'absint',
            'typography.textTransform'       => 'sanitize_key',
            'typography.fontStyle'           => 'sanitize_key',
            'typography.textDecoration'      => 'sanitize_key',
            'typography.lineHeight'          => 'sanitize_text_field',
            'typography.fontSize.value'      => 'absint',
            'typography.fontSize.unit'       => 'sanitize_key',
            'typography.letterSpacing.value' => 'intval',
            'typography.letterSpacing.unit'  => 'sanitize_key',
        ];
    }
    
    private static function getGridRules()
    {
        return [
            'grid.columns'             => 'absint',
            'grid.itemsPerPage'        => 'absint',
            'grid.enableSearch'        => 'rest_sanitize_boolean',
            'grid.enableFilters'       => 'rest_sanitize_boolean',
            'grid.displayMode'         => 'sanitize_key',
            'grid.showPlayerOnTop'     => 'rest_sanitize_boolean',
            'grid.modalLayout'         => 'sanitize_key',
            'grid.modalShowInfo'       => 'rest_sanitize_boolean',
        ];
    }
    
    private static function getLearningRules()
    {
        return [
            'learning.enableProgress'      => 'rest_sanitize_boolean',
            'learning.enableChapters'      => 'rest_sanitize_boolean',
            'learning.completionThreshold' => 'absint',
            'learning.showLockedContent'   => 'rest_sanitize_boolean',
        ];
    }
}
