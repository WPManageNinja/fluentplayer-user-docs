<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayer\App\Integrations\AbstractIntegration;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Integrations\R2Integration;
use FluentPlayerPro\App\Libraries\CloudStorage\S3;

/**
 * Storage operations for the Cloudflare R2 provider: server-proxied upload,
 * public delivery-URL building, and listing/normalizing bucket objects for the
 * "browse existing" picker. Delivery is public-only (a Public URL is required);
 * the SigV4 presign helpers are retained only for a future browser-direct
 * upload mode.
 */
class R2Service
{
    const REGION  = 'auto';
    const SERVICE = 's3';

    /** Video extensions treated as playable media in the browse list. */
    const VIDEO_EXTENSIONS = ['mp4', 'webm', 'mov', 'm4v', 'ogv'];

    /**
     * Presigned PUT URL for a browser-direct upload.
     *
     * NOTE: uploads currently go through the server-proxied streamed path
     * (R2Controller::uploadVideo → uploadFile). This is retained for a future
     * browser-direct/multipart upload mode and is covered by unit tests.
     *
     * @param string     $key      Object key inside the bucket.
     * @param int        $ttl      Lifetime in seconds.
     * @param array|null $settings R2 settings; resolved from the integration if null.
     * @return string
     */
    public static function presignUpload($key, $ttl = 900, $settings = null)
    {
        return self::presignedUrl('PUT', $key, $ttl, $settings);
    }

    /**
     * Build a SigV4 query-string presigned URL (UNSIGNED-PAYLOAD, host-only
     * signed headers — works for browser PUT/GET with bucket CORS).
     *
     * @param string     $method
     * @param string     $key
     * @param int        $ttl
     * @param array|null $settings
     * @param array      $extraQuery Additional query params to sign (e.g. multipart partNumber/uploadId).
     * @return string
     */
    public static function presignedUrl($method, $key, $ttl, $settings = null, $extraQuery = [])
    {
        $settings = self::resolveSettings($settings);

        $accountId = Arr::get($settings, 'account_id');
        $accessKey = Arr::get($settings, 'access_key');
        $secretKey = Arr::get($settings, 'secret_key');
        $bucket    = Arr::get($settings, 'bucket');

        $host = $bucket . '.' . $accountId . '.r2.cloudflarestorage.com';

        $timestamp = gmdate('Ymd\THis\Z');
        $date      = substr($timestamp, 0, 8);
        $scope     = $date . '/' . self::REGION . '/' . self::SERVICE . '/aws4_request';

        // Keep '/' as path separators, encode everything else (spaces -> %20).
        $canonicalUri = '/' . str_replace('%2F', '/', rawurlencode($key));

        $query = array_merge([
            'X-Amz-Algorithm'     => 'AWS4-HMAC-SHA256',
            'X-Amz-Credential'    => $accessKey . '/' . $scope,
            'X-Amz-Date'          => $timestamp,
            'X-Amz-Expires'       => (string) $ttl,
            'X-Amz-SignedHeaders' => 'host',
        ], $extraQuery);
        ksort($query);

        $canonicalQuery = http_build_query($query, '', '&', PHP_QUERY_RFC3986);

        $canonicalRequest = implode("\n", [
            $method,
            $canonicalUri,
            $canonicalQuery,
            'host:' . $host,
            '',
            'host',
            'UNSIGNED-PAYLOAD',
        ]);

        $stringToSign = implode("\n", [
            'AWS4-HMAC-SHA256',
            $timestamp,
            $scope,
            hash('sha256', $canonicalRequest),
        ]);

        $kDate    = hash_hmac('sha256', $date, 'AWS4' . $secretKey, true);
        $kRegion  = hash_hmac('sha256', self::REGION, $kDate, true);
        $kService = hash_hmac('sha256', self::SERVICE, $kRegion, true);
        $kSigning = hash_hmac('sha256', 'aws4_request', $kService, true);
        $signature = hash_hmac('sha256', $stringToSign, $kSigning);

        return 'https://' . $host . $canonicalUri . '?' . $canonicalQuery . '&X-Amz-Signature=' . $signature;
    }

    /** Video MIME types by extension (for the stored object Content-Type). */
    const VIDEO_MIME = [
        'mp4'  => 'video/mp4',
        'm4v'  => 'video/x-m4v',
        'webm' => 'video/webm',
        'mov'  => 'video/quicktime',
        'ogv'  => 'video/ogg',
    ];

    /**
     * Resolve the Content-Type to store for an object key by its extension. Audio
     * objects need a real audio type so browsers range-stream them; the audio ext → MIME
     * mapping is owned by the free Helper (single source).
     */
    public static function contentTypeForKey($key)
    {
        $ext = strtolower(pathinfo((string) $key, PATHINFO_EXTENSION));
        if (isset(self::VIDEO_MIME[$ext])) {
            return self::VIDEO_MIME[$ext];
        }
        $audioMime = self::audioMimeType($ext);
        if ($audioMime !== '') {
            return $audioMime;
        }
        return 'application/octet-stream';
    }

    /**
     * Audio Content-Type via the free Helper (single source). method_exists guards the
     * version-skew case (pro updated before free) — an older free returns '' → the
     * caller falls back to application/octet-stream, which is fine since audio isn't
     * supported on that free version anyway.
     *
     * @param string $ext
     * @return string
     */
    protected static function audioMimeType($ext)
    {
        if (method_exists(\FluentPlayer\App\Helpers\Helper::class, 'audioMimeType')) {
            return \FluentPlayer\App\Helpers\Helper::audioMimeType($ext);
        }
        return '';
    }

    /**
     * Audio file extensions recognised in the browse list — sourced from the free
     * plugin's filterable list (fluent_player/audio_extensions) so third-party
     * additions apply here too.
     *
     * @return string[]
     */
    protected static function audioExtensions()
    {
        // method_exists (not class_exists): the free Helper class always exists, but an
        // older free version won't have this method — guard against a fatal if pro is
        // updated before free.
        if (method_exists(\FluentPlayer\App\Helpers\Helper::class, 'audioExtensions')) {
            return \FluentPlayer\App\Helpers\Helper::audioExtensions();
        }
        return [];
    }

    /**
     * File extensions accepted for upload to R2: video + audio, hardened against
     * scriptable/executable types via the shared upload sanitizer.
     *
     * @return string[]
     */
    public static function allowedUploadExtensions()
    {
        $all = array_merge(self::VIDEO_EXTENSIONS, self::audioExtensions());

        if (method_exists(\FluentPlayer\App\Helpers\Helper::class, 'sanitizeUploadExtensions')) {
            return \FluentPlayer\App\Helpers\Helper::sanitizeUploadExtensions($all);
        }

        return array_values(array_unique(array_map('strtolower', $all)));
    }

    /**
     * Server-proxied streamed upload (the bunny structure): stream a local file
     * straight to R2 via cURL (constant memory, no whole-file-in-RAM). Returns
     * the object key or WP_Error.
     *
     * @param string     $localPath Absolute path to the source file (e.g. a WP attachment).
     * @param string     $key       Target object key.
     * @param array|null $settings  R2 connection settings.
     * @return string|\WP_Error
     */
    public static function uploadFile($localPath, $key, $settings = null)
    {
        if (!is_string($localPath) || $localPath === '' || !file_exists($localPath) || !is_readable($localPath)) {
            return new \WP_Error('r2_file_not_found', __('Upload source file not found or not readable', 'fluent-player-pro'));
        }

        $settings = self::resolveSettings($settings);
        $bucket = self::configureS3($settings);

        // Upload duration is bounded by the S3 request timeout, not PHP's cap.
        // (Self-hosted nginx may still need a higher fastcgi_read_timeout.)
        if (function_exists('set_time_limit')) {
            @set_time_limit(0);
        }

        try {
            $input = S3::inputFile($localPath);
            if (!$input) {
                return new \WP_Error('r2_file_not_found', __('Could not read the upload source file', 'fluent-player-pro'));
            }

            // The vendored S3 lib declares @return boolean but returns a response object or false.
            /** @var object|false $response */
            $response = S3::putObject(
                $input,
                $bucket,
                $key,
                'private',
                [],
                ['Content-Type' => self::contentTypeForKey($key)]
            );

            if (!$response || (isset($response->code) && $response->code !== 200) || (isset($response->error) && $response->error)) {
                return new \WP_Error('r2_upload_failed', __('Failed to upload the file to R2', 'fluent-player-pro'));
            }
        } catch (\Exception $e) {
            return new \WP_Error('r2_upload_failed', $e->getMessage());
        }

        return $key;
    }

    /**
     * List objects under a prefix and normalize into folders + files.
     *
     * @param string     $prefix
     * @param array|null $settings
     * @return array{folders: array, files: array, prefix: string}|\WP_Error
     */
    /** Object-browser page size; the UI shows a truncation notice at this cap. */
    const MAX_LIST_OBJECTS = 1000;

    /** Cap sync folder delete/rename so one request can't fan out unbounded S3 calls. */
    const MAX_SYNC_FOLDER_OBJECTS = 1000;

    public static function listObjects($prefix = '', $settings = null)
    {
        $settings = self::resolveSettings($settings);

        $bucket = Arr::get($settings, 'bucket');

        self::configureS3($settings);

        try {
            $raw = S3::getBucket($bucket, $prefix, null, self::MAX_LIST_OBJECTS, '/', true);
        } catch (\Exception $e) {
            return new \WP_Error('r2_list_failed', $e->getMessage());
        }

        if ($raw === false) {
            return new \WP_Error('r2_list_failed', __('Failed to list R2 objects', 'fluent-player-pro'));
        }

        $normalized = self::normalizeObjectList($raw);
        $normalized['prefix'] = $prefix;
        // Signal when the listing hit the page cap so the UI can tell the user
        // only the first N items are shown.
        $normalized['truncated'] = is_array($raw) && count($raw) >= self::MAX_LIST_OBJECTS;
        return $normalized;
    }

    /**
     * Normalize an S3::getBucket() result (keyed by object key) into a
     * folders list (CommonPrefixes + zero-byte placeholder keys) and a files
     * list (real objects, flagged playable by extension).
     *
     * @param array $raw
     * @return array{folders: array, files: array}
     */
    public static function normalizeObjectList($raw)
    {
        $folders = [];
        $files = [];

        foreach ($raw as $key => $item) {
            // CommonPrefixes entries carry a 'prefix' and no size.
            if (isset($item['prefix'])) {
                $folders[] = ['prefix' => $item['prefix'], 'name' => self::folderLabel($item['prefix'])];
                continue;
            }

            // Zero-byte folder-placeholder keys ("folder 1/") are not files.
            if (substr($key, -1) === '/') {
                $folders[] = ['prefix' => $key, 'name' => self::folderLabel($key)];
                continue;
            }

            $extension = strtolower(pathinfo($key, PATHINFO_EXTENSION));
            $files[] = [
                'key'           => $key,
                'name'          => basename($key),
                'size'          => isset($item['size']) ? (int) $item['size'] : 0,
                'last_modified' => isset($item['time']) ? (int) $item['time'] : 0,
                'is_video'      => in_array($extension, self::VIDEO_EXTENSIONS, true),
                'is_audio'      => in_array($extension, self::audioExtensions(), true),
            ];
        }

        return ['folders' => $folders, 'files' => $files];
    }

    /**
     * Build the public delivery URL for an object key: the configured Public URL
     * (r2.dev or a custom domain) + the rawurl-encoded key. Empty when no Public
     * URL is set.
     */
    public static function publicUrl($key, $settings = null)
    {
        $settings = self::resolveSettings($settings);
        $base = rtrim((string) Arr::get($settings, 'public_url'), '/');
        if (!$base) {
            return '';
        }
        return $base . '/' . str_replace('%2F', '/', rawurlencode($key));
    }

    /**
     * Build a path-safe object key for an upload. Strips directory components
     * (no traversal), sanitizes unsafe characters, and applies an optional
     * sub-folder prefix. The bucket root can never be escaped.
     *
     * @param string $filename Original filename from the browser.
     * @param string $folder   Optional bucket sub-folder.
     * @return string
     */
    public static function buildUploadKey($filename, $folder = '')
    {
        // Spaces and ordinary punctuation are valid in S3 keys — preserve them.
        // Only strip what's genuinely unsafe: path components, control chars,
        // and traversal.
        $base = basename(str_replace('\\', '/', (string) $filename));
        $base = self::sanitizeKeySegment($base);
        if ($base === '') {
            $base = 'file';
        }

        // The folder is an existing bucket prefix (may legitimately contain
        // spaces); use it as-is, only normalizing slashes. Traversal in the
        // prefix is stripped by the controller.
        $folder = trim((string) $folder, '/');

        return $folder !== '' ? $folder . '/' . $base : $base;
    }

    /**
     * Sanitize a single key segment (folder name or filename): drop control
     * chars and traversal while preserving spaces and ordinary characters.
     */
    private static function sanitizeKeySegment($value)
    {
        $value = (string) $value;
        $value = preg_replace('/[\x00-\x1F\x7F]+/u', '', $value); // control chars / NUL
        $value = str_replace('..', '', $value);                  // no traversal
        return trim($value, " \t.");                             // trim space/dot ends
    }

    /**
     * Resolve the playback src for an `r2` media item from its stored key + the
     * connection's public URL (R2 delivery is public-only). Re-derived at render
     * so it always reflects the current Public URL.
     *
     * @param array $mediaSettings      The media's settings (expects settings.r2.key).
     * @param array $connectionSettings The R2 integration settings.
     * @return string
     */
    public static function resolvePlaybackSrc($mediaSettings, $connectionSettings)
    {
        $r2 = Arr::get($mediaSettings, 'r2', []);
        $key = is_array($r2) ? Arr::get($r2, 'key', '') : '';
        if (!$key) {
            return '';
        }

        return self::publicUrl($key, $connectionSettings);
    }

    /**
     * `fluent_player/player_settings` filter: set the R2 public src from the
     * stored key + current Public URL. No-op for non-R2 media and when R2 is
     * not connected.
     *
     * @param array $settings
     * @return array
     */
    public static function filterPlayerSettings($settings)
    {
        if (Arr::get($settings, 'provider') !== 'cloudflare_r2') {
            return $settings;
        }

        $connection = (new R2Integration())->getSettings();
        if (!Arr::isTrue($connection, 'enabled')) {
            return $settings;
        }

        $src = self::resolvePlaybackSrc($settings, $connection);
        if ($src) {
            $settings['src'] = $src;
        }

        return $settings;
    }

    /**
     * The URL the editor uses to preview/probe an object. Public-only, so this
     * is an alias of publicUrl(); kept as a distinct field in browse/upload
     * responses so the response shape stays stable for the block UI.
     *
     * @param string     $key
     * @param array|null $settings
     * @return string
     */
    public static function previewUrl($key, $settings = null)
    {
        return self::publicUrl($key, self::resolveSettings($settings));
    }

    private static function folderLabel($prefix)
    {
        return basename(rtrim($prefix, '/'));
    }

    // ── folder CRUD ─────────────────────────────────────────────────

    /**
     * Build a path-safe folder key (trailing slash) under an optional prefix.
     * Slashes and unsafe chars in the name are collapsed — a folder name can't
     * contain separators or escape its parent.
     */
    public static function buildFolderKey($name, $prefix = '')
    {
        // Preserve spaces; a folder name is a single segment, so path separators
        // collapse to a space rather than creating sub-paths.
        $name = preg_replace('#[/\\\\]+#', ' ', (string) $name);
        $name = preg_replace('/\s+/', ' ', $name);
        $name = self::sanitizeKeySegment($name);
        if ($name === '') {
            $name = 'folder';
        }

        $prefix = trim((string) $prefix, '/');
        $prefix = $prefix !== '' ? $prefix . '/' : '';

        return $prefix . $name . '/';
    }

    /**
     * Rebase an object key from one folder prefix to another (for rename).
     */
    public static function renameTargetKey($key, $from, $to)
    {
        if ($from !== '' && strpos($key, $from) === 0) {
            return $to . substr($key, strlen($from));
        }
        return $key;
    }

    /**
     * Create an (empty placeholder) folder. Returns the folder key or WP_Error.
     */
    public static function createFolder($name, $prefix = '', $settings = null)
    {
        $settings = self::resolveSettings($settings);
        $bucket = self::configureS3($settings);
        $key = self::buildFolderKey($name, $prefix);

        try {
            // The vendored S3 lib declares @return boolean but returns a response object or false.
            /** @var object|false $response */
            $response = S3::putObjectString('', $bucket, $key);
            if (!$response || (isset($response->code) && $response->code !== 200)) {
                return new \WP_Error('r2_folder_create_failed', __('Failed to create the folder', 'fluent-player-pro'));
            }
        } catch (\Exception $e) {
            return new \WP_Error('r2_folder_create_failed', $e->getMessage());
        }

        return $key;
    }

    /**
     * Delete a single object.
     */
    public static function deleteObject($key, $settings = null)
    {
        if ($key === '' || $key === null) {
            return new \WP_Error('r2_missing_key', __('Object key is required', 'fluent-player-pro'));
        }

        $settings = self::resolveSettings($settings);
        $bucket = self::configureS3($settings);

        try {
            S3::deleteObject($bucket, $key);
        } catch (\Exception $e) {
            return new \WP_Error('r2_delete_failed', $e->getMessage());
        }

        return true;
    }

    /**
     * Recursively delete every object under a folder prefix (incl. the
     * placeholder). Returns the number of objects removed or WP_Error.
     */
    public static function deleteFolder($prefix, $settings = null)
    {
        $prefix = trim((string) $prefix, '/');
        if ($prefix === '') {
            return new \WP_Error('r2_missing_prefix', __('A folder is required', 'fluent-player-pro'));
        }
        $prefix .= '/';

        $settings = self::resolveSettings($settings);
        $bucket = self::configureS3($settings);

        try {
            // Bound the sync operation: fetch one past the cap so we can detect a
            // folder larger than the limit and refuse, rather than fan out an
            // unbounded number of delete calls inside a single request.
            $objects = S3::getBucket($bucket, $prefix, null, self::MAX_SYNC_FOLDER_OBJECTS + 1);
            if ($objects === false) {
                return new \WP_Error('r2_list_failed', __('Failed to list folder contents', 'fluent-player-pro'));
            }
            if (count($objects) > self::MAX_SYNC_FOLDER_OBJECTS) {
                return new \WP_Error('r2_folder_too_large', sprintf(
                    /* translators: %d: maximum object count */
                    __('This folder has more than %d items. Delete it from the Cloudflare dashboard instead.', 'fluent-player-pro'),
                    self::MAX_SYNC_FOLDER_OBJECTS
                ));
            }
            $count = 0;
            foreach ($objects as $key => $info) {
                S3::deleteObject($bucket, $key);
                $count++;
            }
            // Remove the placeholder itself if it wasn't listed.
            S3::deleteObject($bucket, $prefix);
        } catch (\Exception $e) {
            return new \WP_Error('r2_folder_delete_failed', $e->getMessage());
        }

        return $count;
    }

    /**
     * Rename a folder: copy every object under $from to $to, then delete the
     * originals (S3 has no native rename). Returns the moved count or WP_Error.
     */
    public static function renameFolder($from, $to, $settings = null)
    {
        $from = trim((string) $from, '/');
        if ($from === '') {
            return new \WP_Error('r2_missing_prefix', __('A source folder is required', 'fluent-player-pro'));
        }
        $from .= '/';

        // $to is a new folder name within the same parent as $from.
        $parent = trim(dirname(rtrim($from, '/')), '/.');
        $to = self::buildFolderKey($to, $parent === '' ? '' : $parent);
        if ($to === $from) {
            return 0;
        }

        $settings = self::resolveSettings($settings);
        $bucket = self::configureS3($settings);

        try {
            $objects = S3::getBucket($bucket, $from, null, self::MAX_SYNC_FOLDER_OBJECTS + 1);
            if ($objects === false) {
                return new \WP_Error('r2_list_failed', __('Failed to list folder contents', 'fluent-player-pro'));
            }
            if (count($objects) > self::MAX_SYNC_FOLDER_OBJECTS) {
                return new \WP_Error('r2_folder_too_large', sprintf(
                    /* translators: %d: maximum object count */
                    __('This folder has more than %d items. Rename it from the Cloudflare dashboard instead.', 'fluent-player-pro'),
                    self::MAX_SYNC_FOLDER_OBJECTS
                ));
            }
            $moved = 0;
            foreach ($objects as $key => $info) {
                $target = self::renameTargetKey($key, $from, $to);
                S3::copyObject($bucket, $key, $bucket, $target);
                S3::deleteObject($bucket, $key);
                $moved++;
            }
            return $moved;
        } catch (\Exception $e) {
            return new \WP_Error('r2_folder_rename_failed', $e->getMessage());
        }
    }

    /**
     * Configure the static S3 client for the connection. Endpoint is the account
     * host WITHOUT the bucket — S3Request prepends it (virtual-hosted style).
     *
     * @return string The bucket name.
     */
    private static function configureS3($settings)
    {
        new S3(
            Arr::get($settings, 'access_key'),
            Arr::get($settings, 'secret_key'),
            true,
            Arr::get($settings, 'account_id') . '.r2.cloudflarestorage.com',
            self::REGION
        );
        return Arr::get($settings, 'bucket');
    }

    /**
     * Resolve settings from the R2 integration when not explicitly provided.
     *
     * @param array|null $settings
     * @return array
     */
    private static function resolveSettings($settings)
    {
        if (is_array($settings)) {
            return $settings;
        }
        return (new R2Integration())->getSettings();
    }
}
