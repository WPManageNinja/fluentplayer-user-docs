<?php

namespace FluentPlayerPro\App\Services;

use FluentPlayer\App\Services\SettingsService;
use FluentPlayer\Framework\Support\Arr;


/**
 * Playlist CSS Generator
 *
 * Handles dynamic CSS generation for playlists based on appearance settings.
 * Organized by appearance sections for better maintainability.
 *
 * Features:
 * - Separation of concerns from Helper class
 * - Organized by appearance setting sections
 * - Easily testable and maintainable
 * - Proper dependency injection support
 */
class PlaylistCssGenerator
{
    /**
     * Create a new instance of the CSS generator
     *
     * @return static
     */
    public static function create()
    {
        return new static();
    }
    /**
     * Generate complete CSS for a specific playlist
     *
     * @param int $playlistId The playlist ID for CSS targeting
     * @param array $settings Playlist appearance settings from the admin
     * @return string Generated CSS ready for wp_add_inline_style()
     *
     * @example
     * $generator = PlaylistCssGenerator::create();
     * $css = $generator->generatePlaylistCss(123, [
     *     'brandColor' => '#007cba',
     *     'backgroundColor' => '#ffffff',
     *     'borderRadius' => ['value' => 8, 'unit' => 'px']
     * ]);
     */
    public function generatePlaylistCss($playlistId, $settings)
    {
        $css = '';
        
        /* ========================================
           CSS VARIABLES (Colors, Typography, Layout)
           ======================================== */
        $cssVars = $this->buildCssVariables($settings);
        if (!empty($cssVars)) {
            $css .= $this->generateCssVariablesBlock($playlistId, $cssVars);
        }
        
        /* ========================================
           MEDIA PLAYER SPECIFIC STYLES
           ======================================== */
        // Aspect ratio for video player
        $css .= $this->generateAspectRatioCss($playlistId, $settings);

        /* ========================================
           GRID MODE SPECIFIC STYLES
           ======================================== */
        // Padding adjustments when grid mode is off
        $css .= $this->generateGridModeStyles($playlistId, $settings);

        return $css;
    }

    /**
     * Build CSS variables array from settings - organized by appearance sections
     *
     * @param array $settings Playlist appearance settings
     * @return array CSS variables array
     */
    private function buildCssVariables($settings)
    {
        $cssVars = [];
        
        /* ========================================
           COLOR SETTINGS
           ======================================== */
        $cssVars = array_merge($cssVars, $this->buildColorVariables($settings));
        
        /* ========================================
           TYPOGRAPHY SETTINGS
           ======================================== */
        $cssVars = array_merge($cssVars, $this->buildTypographyVariables($settings));
        
        /* ========================================
           BORDER RADIUS SETTINGS
           ======================================== */
        $cssVars = array_merge($cssVars, $this->buildBorderRadiusVariables($settings));
        
        /* ========================================
           SPACING SETTINGS (Padding & Margin)
           ======================================== */
        $cssVars = array_merge($cssVars, $this->buildSpacingVariables($settings));
        
        /* ========================================
           BOX SHADOW SETTINGS
           ======================================== */
        $cssVars = array_merge($cssVars, $this->buildBoxShadowVariables($settings));
        
        /* ========================================
           GRID LAYOUT (--grid-columns when layout is grid)
           ======================================== */
        if (Arr::get($settings, 'layoutType') === 'grid') {
            $columns = (int) Arr::get($settings, 'gridColumns', 3);
            $columns = $columns >= 2 && $columns <= 6 ? $columns : 3;
            $cssVars[] = '--grid-columns: ' . $columns;
        }
        
        return $cssVars;
    }

    /**
     * Build color-related CSS variables
     *
     * @param array $settings
     * @return array
     */
    private function buildColorVariables($settings)
    {
        $cssVars = [];

        // Determine the final brand color, following the logic in PlaylistEditor.vue
        $brandColorSetting = Arr::get($settings, 'brandColor');
        $finalBrandColor = null;

        if (is_string($brandColorSetting) && $brandColorSetting !== '') {
            $finalBrandColor = $brandColorSetting;
        } elseif (is_array($brandColorSetting) && !empty($brandColorSetting['mode'])) {
            if ($brandColorSetting['mode'] === 'custom' && !empty($brandColorSetting['value'])) {
                $finalBrandColor = $brandColorSetting['value'];
            } elseif ($brandColorSetting['mode'] === 'global') {
                $finalBrandColor = SettingsService::getSetting('branding.brand_color');
            }
        }

        if (!$finalBrandColor) {
            $finalBrandColor = '#007cba';
        }

        $cssVars[] = '--media-brand: ' . esc_attr($finalBrandColor);
        $cssVars[] = '--fp-playlist-brand-color: ' . esc_attr($finalBrandColor);

        // Handle other colors
        $otherColorSettings = [
            'backgroundColor' => '--fp-playlist-background-color',
            'textColor' => '--fp-playlist-text-color',
        ];

        foreach ($otherColorSettings as $settingKey => $cssProperty) {
            $value = Arr::get($settings, $settingKey);
            if (!empty($value)) {
                $cssVars[] = $cssProperty . ': ' . esc_attr($value);
            }
        }

        // Active state text color - automatically determine based on brand color
        $activeTextColor = $this->getContrastTextColor($finalBrandColor);
        $cssVars[] = '--fp-playlist-active-text-color: ' . esc_attr($activeTextColor);

        return $cssVars;
    }

    /**
     * Build typography-related CSS variables
     *
     * @param array $settings
     * @return array
     */
    private function buildTypographyVariables($settings)
    {
        $cssVars = [];
        
        $typographySettings = [
            'typography.fontSize' => '--fp-playlist-font-size',
            'typography.fontWeight' => '--fp-playlist-font-weight',
            'typography.lineHeight' => '--fp-playlist-line-height',
        ];
        
        foreach ($typographySettings as $settingKey => $cssProperty) {
            $value = Arr::get($settings, $settingKey);
            if (!empty($value)) {
                $cssVars[] = $cssProperty . ': ' . esc_attr($value);
            }
        }
        
        return $cssVars;
    }

    /**
     * Build border radius-related CSS variables
     *
     * @param array $settings
     * @return array
     */
    private function buildBorderRadiusVariables($settings)
    {
        $cssVars = [];
        
        $borderRadius = Arr::get($settings, 'borderRadius');
        if (isset($borderRadius)) { // Use isset to handle 0 values
            if (is_array($borderRadius)) {
                $value = Arr::get($borderRadius, 'value', '');
                if ($value !== '') { // Check for empty string, allow 0
                    // Main container border radius
                    $cssVars[] = '--fp-playlist-border-radius: ' . esc_attr($value) . 'px';
                    // Playlist items - full border radius (pill-shaped)
                    $cssVars[] = '--fp-playlist-item-border-radius: ' . esc_attr($value) . 'px';
                    // Player container - right side only
                    $cssVars[] = '--fp-playlist-player-border-radius: 0 ' . esc_attr($value) . 'px ' . esc_attr($value) . 'px 0';
                }
            } else {
                // Fallback for simple string values
                $cssVars[] = '--fp-playlist-border-radius: ' . esc_attr($borderRadius);
                $cssVars[] = '--fp-playlist-item-border-radius: ' . esc_attr($borderRadius);
                $cssVars[] = '--fp-playlist-player-border-radius: 0 ' . esc_attr($borderRadius) . ' ' . esc_attr($borderRadius) . ' 0';
            }
        }
        
        return $cssVars;
    }

    /**
     * Build spacing-related CSS variables (padding and margin)
     *
     * @param array $settings
     * @return array
     */
    private function buildSpacingVariables($settings)
    {
        $cssVars = [];
        
        // Padding
        $padding = Arr::get($settings, 'padding');
        if (!empty($padding) && is_array($padding)) {
            $top = Arr::get($padding, 'top', 0);
            $right = Arr::get($padding, 'right', 0);
            $bottom = Arr::get($padding, 'bottom', 0);
            $left = Arr::get($padding, 'left', 0);
            $unit = Arr::get($padding, 'unit', 'px');
            $cssVars[] = '--fp-playlist-padding: ' . esc_attr("{$top}{$unit} {$right}{$unit} {$bottom}{$unit} {$left}{$unit}");
        }
        
        // Margin
        $margin = Arr::get($settings, 'margin');
        if (!empty($margin) && is_array($margin)) {
            $top = Arr::get($margin, 'top', 0);
            $right = Arr::get($margin, 'right', 0);
            $bottom = Arr::get($margin, 'bottom', 0);
            $left = Arr::get($margin, 'left', 0);
            $unit = Arr::get($margin, 'unit', 'px');
            $cssVars[] = '--fp-playlist-margin: ' . esc_attr("{$top}{$unit} {$right}{$unit} {$bottom}{$unit} {$left}{$unit}");
        }
        
        return $cssVars;
    }

    /**
     * Build box shadow-related CSS variables
     *
     * @param array $settings
     * @return array
     */
    private function buildBoxShadowVariables($settings)
    {
        $cssVars = [];
        
        $boxShadow = Arr::get($settings, 'boxShadow');
        if (!empty($boxShadow) && is_array($boxShadow) && Arr::get($boxShadow, 'enabled')) {
            $horizontal = Arr::get($boxShadow, 'horizontal', 0);
            $vertical = Arr::get($boxShadow, 'vertical', 4);
            $blur = Arr::get($boxShadow, 'blur', 10);
            $spread = Arr::get($boxShadow, 'spread', 0);
            $color = Arr::get($boxShadow, 'color', '#000000');
            $position = Arr::get($boxShadow, 'position', 'outline');
            
            $shadowValue = $position === 'inset' ? 'inset ' : '';
            $shadowValue .= "{$horizontal}px {$vertical}px {$blur}px {$spread}px {$color}";
            $cssVars[] = '--fp-playlist-box-shadow: ' . esc_attr($shadowValue);
        }
        
        return $cssVars;
    }

    /**
     * Generate CSS variables block
     *
     * @param int $playlistId
     * @param array $cssVars
     * @return string
     */
    private function generateCssVariablesBlock($playlistId, $cssVars)
    {
        $css = "#fluent_playlist_{$playlistId} {\n";
        $css .= "    " . implode(";\n    ", $cssVars) . ";\n";
        $css .= "}\n";

        return $css;
    }

    /**
     * Generate aspect ratio CSS for media player
     *
     * @param int $playlistId
     * @param array $settings
     * @return string
     */
    private function generateAspectRatioCss($playlistId, $settings)
    {
        $aspectRatio = Arr::get($settings, 'aspectRatio');

        // If aspect ratio is set and not 'original', use it directly
        if (!empty($aspectRatio) && $aspectRatio !== 'original') {
            // Normalize aspect ratio format: convert '16:9' to '16 / 9' for CSS
            $cssAspectRatio = str_replace(':', ' / ', $aspectRatio);

            return "#fluent_playlist_{$playlistId} media-player[data-view-type='video'] {\n    aspect-ratio: " . esc_attr($cssAspectRatio) . ";\n}\n";
        }

        // For 'original' or empty aspect ratio, use 16:9 as default to prevent layout shifts
        // This provides a stable container while the video loads
        // Once video loads, it can override with its natural aspect ratio
        $css = "#fluent_playlist_{$playlistId} media-player[data-view-type='video'] {\n";
        $css .= "    aspect-ratio: 16 / 9;\n";
        $css .= "}\n\n";
        $css .= "/* Allow video to override with its natural aspect ratio once loaded */\n";
        $css .= "#fluent_playlist_{$playlistId} media-player[data-view-type='video'].can-play {\n";
        $css .= "    aspect-ratio: auto;\n";
        $css .= "}\n";

        return $css;
    }

    /**
     * Generate grid mode specific styles
     *
     * @param int $playlistId
     * @param array $settings
     * @return string
     */
    private function generateGridModeStyles($playlistId, $settings)
    {
        // Check if thumbnail grid layout is disabled
        $thumbnailGridLayout = Arr::get($settings, 'behavior.thumbnailGridLayout', false);

        // If grid mode is off, add padding 0 to ul and playlist items
        if (!$thumbnailGridLayout) {
            $css = "/* Grid mode off - Remove padding */\n";
            $css .= "#fluent_playlist_{$playlistId} .playlist-items:not(.playlist-thumbnail-grid) {\n";
            $css .= "    padding: 0;\n";
            $css .= "}\n";

            return $css;
        }

        return '';
    }

    /**
     * Determine the appropriate text color (white or black) based on background color
     *
     * @param string $backgroundColor Hex color code
     * @return string Either '#ffffff' for dark backgrounds or '#000000' for light backgrounds
     */
    private function getContrastTextColor($backgroundColor)
    {
        $backgroundColor = $backgroundColor !== null ? (string) $backgroundColor : '';
        // Remove # if present
        $backgroundColor = ltrim($backgroundColor, '#');

        // Convert to RGB
        if (strlen($backgroundColor) === 3) {
            // Convert 3-digit hex to 6-digit
            $backgroundColor = $backgroundColor[0] . $backgroundColor[0] .
                              $backgroundColor[1] . $backgroundColor[1] .
                              $backgroundColor[2] . $backgroundColor[2];
        }

        if (strlen($backgroundColor) !== 6) {
            // Invalid color, default to white text
            return '#ffffff';
        }

        $r = hexdec(substr($backgroundColor, 0, 2));
        $g = hexdec(substr($backgroundColor, 2, 2));
        $b = hexdec(substr($backgroundColor, 4, 2));

        // Calculate relative luminance using WCAG formula
        $luminance = (0.299 * $r + 0.587 * $g + 0.114 * $b) / 255;

        // Return white text for dark backgrounds, black text for light backgrounds
        return $luminance > 0.5 ? '#000000' : '#ffffff';
    }
}
