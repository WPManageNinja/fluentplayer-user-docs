<?php

namespace FluentPlayerPro\App\Layouts;

use FluentPlayer\App\Helpers\Helper;
use FluentPlayer\Framework\Support\Arr;

/**
 * Grid Playlist Layout - Netflix-style grid with thumbnails.
 * Features responsive grid, search, filters, and lazy loading.
 */
class GridPlaylistLayout extends BasePlaylistLayout
{
    protected function getLayoutTemplate()
    {
        return 'layouts/grid';
    }

    /**
     * Grid renders the playlist as the page-level grid; there's no collapsible
     * panel for the player controls' toggle button to hide or reveal.
     */
    protected function supportsPlaylistMenuToggle()
    {
        return false;
    }

    protected function getLayoutData()
    {
        return [
            'layoutClasses'       => $this->getLayoutClasses(),
            'playlistId'          => $this->playlistId,
            'playlistVarName'     => $this->playlistVarName,
            'playlistDeepLinkRef' => $this->getPlaylistDeepLinkRef(),
            'styleAttributes'     => $this->buildCssStyleAttribute(),
            'playerHtml'          => $this->renderPlayer($this->getPresetSourceMedia()),
            'contentHtml'         => $this->renderContent(),
        ];
    }

    // ─── Section renderers ───────────────────────────────────────────

    protected function renderPlayer($media)
    {
        $displayMode = Arr::get($this->settings, 'grid.displayMode', 'inline');
        if ($displayMode !== 'inline') {
            return '';
        }

        return $this->renderView('partials/player-container', [
            'containerOpen'   => $this->openPlayerContainer($media, 'grid-player-inline'),
            'mediaPlayerHtml' => $this->renderMediaPlayer($media),
        ]);
    }

    protected function renderContent()
    {
        $itemsPerPage     = Arr::get($this->settings, 'grid.itemsPerPage', 12) ?: 12;
        $totalVideos      = count($this->medias);
        $displayMode      = Arr::get($this->settings, 'grid.displayMode', 'inline');
        $modalLayout      = Arr::get($this->settings, 'grid.modalLayout', 'centered');
        $showThumbnailInfo = Arr::get($this->settings, 'behavior.showThumbnailInfo', true);
        $titlePosition    = Arr::get($this->settings, 'behavior.titlePosition', 'below');

        $items = [];
        foreach ($this->medias as $index => $media) {
            $duration = Arr::get($media->settings, 'duration', 0);
            $items[] = [
                'media'             => $media,
                'index'             => $index,
                'deepLinkRef'       => $this->getMediaDeepLinkRef($media),
                'duration'          => $duration,
                'durationFormatted' => ($duration !== '' && $duration !== null)
                    ? Helper::formatDuration((float) $duration) : '',
                'isWatched'         => $this->isVideoWatched($media),
                'loadingStrategy'   => ($index < $itemsPerPage) ? 'eager' : 'lazy',
                'isActive'          => $index === 0,
                'progress'          => $this->getVideoProgress($media),
            ];
        }

        return $this->renderView('grid/content', [
            'columns'           => Arr::get($this->settings, 'grid.columns', 3) ?: 3,
            'itemsPerPage'      => $itemsPerPage,
            'lazyLoad'          => Arr::get($this->settings, 'grid.lazyLoad', true),
            'playlistTitle'     => $this->getPlaylistTitle(),
            'totalVideos'       => $totalVideos,
            'videoText'         => $totalVideos === 1 ? __('video', 'fluent-player-pro') : __('videos', 'fluent-player-pro'),
            'showThumbnailInfo' => $showThumbnailInfo,
            'titlePosition'     => $titlePosition,
            'displayMode'       => $displayMode,
            'modalLayout'       => $modalLayout,
            'items'             => $items,
            'showPagination'    => ($itemsPerPage > 0 && $totalVideos > $itemsPerPage),
            'totalPages'        => ceil($totalVideos / $itemsPerPage),
            'showModal'         => $this->shouldRenderModal(),
            'modalHtml'         => $this->shouldRenderModal() ? $this->renderModal() : '',
        ]);
    }

    // ─── Modal ───────────────────────────────────────────────────────

    protected function shouldRenderModal()
    {
        return Arr::get($this->settings, 'grid.displayMode', 'inline') !== 'inline';
    }

    protected function renderModal()
    {
        $isAudio    = $this->isAllAudio();
        $displayMode = Arr::get($this->settings, 'grid.displayMode', 'inline');

        $modalOverlayClass = 'grid-modal-overlay';
        if ($displayMode === 'fullscreen') {
            $modalOverlayClass .= ' grid-fullscreen';
        }

        $modalPlayerClass = 'grid-modal-player';
        if ($isAudio) {
            $modalPlayerClass .= ' fp-audio';
        }

        $modalPlayerStyle = '';
        if ($isAudio) {
            $posterSrc = Arr::get($this->medias[0]->settings ?? [], 'posterSrc', '');
            if ($posterSrc) {
                $modalPlayerStyle = "background-image:url('" . esc_url($posterSrc) . "');background-size:cover;background-position:center";
            }
        }

        return $this->renderView('grid/modal', [
            'modalOverlayClass' => $modalOverlayClass,
            'modalPlayerClass'  => $modalPlayerClass,
            'modalPlayerStyle'  => $modalPlayerStyle,
            'isAudio'           => $isAudio,
            'isMixed'           => $this->isMixed(),
            'medias'            => $this->medias,
            'presetSourceMedia' => $this->getPresetSourceMedia(),
            'defaultSettings'   => $this->defaultSettings,
            'showNavButtons'    => count($this->medias) > Arr::get($this->settings, 'grid.itemsPerPage', 12),
            'layout'            => $this,
        ]);
    }

    // ─── Layout classes ──────────────────────────────────────────────

    public function getLayoutClasses()
    {
        $classes = parent::getLayoutClasses();
        $columns = intval(Arr::get($this->settings, 'grid.columns', 3));
        $classes .= ' grid-columns-' . $columns;

        if (!$this->shouldRenderModal()) {
            $showPlayerOnTop = Arr::get($this->settings, 'grid.showPlayerOnTop', true);
            $classes .= $showPlayerOnTop ? ' grid-player-top' : ' grid-player-bottom';
        }

        return $classes;
    }

    // ─── Helpers ─────────────────────────────────────────────────────

    private function isVideoWatched($media)
    {
        return false;
    }

    private function getVideoProgress($media)
    {
        return 0;
    }

    public static function getMetadata()
    {
        return [
            'name'             => 'Grid View',
            'description'      => 'Netflix-style grid layout with search and filters',
            'icon'             => 'grid',
            'default_position' => 'bottom',
            'features'         => ['grid', 'search', 'filters', 'pagination', 'lazy-loading'],
        ];
    }
}
