<?php

namespace FluentPlayerPro\App\Layouts;

use FluentPlayer\Framework\Support\Arr;

/**
 * Learning Playlist Layout - Educational layout with progress tracking.
 * Features chapter navigation, locked content, and progress indicators.
 */
class LearningPlaylistLayout extends BasePlaylistLayout
{
    protected function getLayoutTemplate()
    {
        return 'layouts/learning';
    }

    protected function getLayoutData()
    {
        return [
            'layoutClasses'       => $this->getLayoutClasses(),
            'playlistId'          => $this->playlistId,
            'playlistVarName'     => $this->playlistVarName,
            'playlistDeepLinkRef' => $this->getPlaylistDeepLinkRef(),
            'playerHtml'          => $this->renderPlayer($this->getPresetSourceMedia()),
            'headerHtml'          => $this->renderHeader(),
            'contentHtml'         => $this->renderContent(),
            'footerHtml'          => $this->renderFooter(),
        ];
    }

    // ─── Section renderers ───────────────────────────────────────────

    protected function renderHeader()
    {
        $totalVideos         = count($this->medias);
        $completedVideos     = $this->getCompletedVideosCount();
        $progressPercentage  = $totalVideos > 0 ? round(($completedVideos / $totalVideos) * 100) : 0;

        return $this->renderView('learning/header', [
            'playlistTitle'      => $this->getPlaylistTitle(),
            'totalVideos'        => $totalVideos,
            'completedVideos'    => $completedVideos,
            'progressPercentage' => $progressPercentage,
        ]);
    }

    protected function renderPlayer($media)
    {
        return $this->renderView('learning/player', [
            'containerOpen'   => $this->openPlayerContainer($media),
            'mediaPlayerHtml' => $this->renderMediaPlayer($media),
            'lessonNumber'    => $this->getCurrentLessonNumber(),
            'lessonTitle'     => $media->post_title,
            'lessonProgress'  => $this->getLessonProgress($media),
        ]);
    }

    protected function renderContent()
    {
        $items = [];
        foreach ($this->medias as $index => $media) {
            $items[] = [
                'media'       => $media,
                'index'       => $index,
                'deepLinkRef' => $this->getMediaDeepLinkRef($media),
                'isCompleted' => $this->isLessonCompleted($media),
                'isLocked'    => $this->isLessonLocked($index),
                'progress'    => $this->getLessonProgress($media),
            ];
        }

        return $this->renderView('learning/content', [
            'hasChapters'    => $this->hasChapters(),
            'chaptersNavHtml' => $this->renderChaptersNavigation(),
            'items'          => $items,
        ]);
    }

    protected function renderFooter()
    {
        $currentIndex = $this->getCurrentLessonNumber() - 1;

        return $this->renderView('learning/footer', [
            'hasPrevious'    => $currentIndex > 0,
            'hasNext'        => $currentIndex < count($this->medias) - 1,
            'currentMediaId' => $this->medias[$currentIndex]->ID ?? '',
        ]);
    }

    // ─── Private helpers ─────────────────────────────────────────────

    private function getCompletedVideosCount()
    {
        $completedIds = $this->getUserCompletedIds();
        if (!$completedIds) {
            return 0;
        }

        $count = 0;
        foreach ($this->medias as $media) {
            if (in_array((int) $media->ID, $completedIds, true)) {
                $count++;
            }
        }
        return $count;
    }

    private function getCurrentLessonNumber()
    {
        $completedIds = $this->getUserCompletedIds();
        foreach ($this->medias as $index => $media) {
            if (!in_array((int) $media->ID, $completedIds, true)) {
                return $index + 1;
            }
        }
        return 1;
    }

    private function isLessonCompleted($media)
    {
        $completedIds = $this->getUserCompletedIds();
        return in_array((int) $media->ID, $completedIds, true);
    }

    private function getFirstIncompleteIndex()
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }
        $cached = count($this->medias);
        foreach ($this->medias as $i => $media) {
            if (!$this->isLessonCompleted($media)) {
                $cached = $i;
                break;
            }
        }
        return $cached;
    }

    private function isLessonLocked($index)
    {
        $showLockedContent = Arr::get($this->settings, 'learning.showLockedContent', true);
        if (!$showLockedContent) {
            return false;
        }
        return $index > $this->getFirstIncompleteIndex();
    }

    private function getLessonProgress($media)
    {
        return 0;
    }

    private function getUserCompletedIds()
    {
        static $cache = [];

        $playlistId = 0;
        if (isset($this->playlist) && isset($this->playlist->ID)) {
            $playlistId = (int) $this->playlist->ID;
        } elseif (isset($this->playlistId)) {
            $playlistId = (int) $this->playlistId;
        }

        if (!$playlistId) {
            return [];
        }

        if (isset($cache[$playlistId])) {
            return $cache[$playlistId];
        }

        $userId = get_current_user_id();

        if ($userId) {
            $key = 'fluent_player_completed_' . $playlistId;
            $existing = get_user_meta($userId, $key, true);
            if (is_array($existing)) {
                $cache[$playlistId] = array_values(array_unique(array_map('intval', $existing)));
                return $cache[$playlistId];
            }
        }

        $cache[$playlistId] = [];
        return $cache[$playlistId];
    }

    private function hasChapters()
    {
        return Arr::get($this->settings, 'learning.enableChapters', true);
    }

    private function renderChaptersNavigation()
    {
        return '';
    }

    public static function getMetadata()
    {
        return [
            'name'             => 'Learning Mode',
            'description'      => 'Educational layout with progress tracking and chapter navigation',
            'icon'             => 'graduation-cap',
            'default_position' => 'right',
            'features'         => ['progress', 'chapters', 'locked-content', 'completion-tracking'],
        ];
    }
}
