<?php

namespace FluentPlayerPro\App\Layouts;

use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Services\PlaylistSettingsHelper;

/**
 * Factory class for creating playlist layout instances
 * Handles layout instantiation and provides metadata for admin interface
 */
class PlaylistLayoutFactory
{
    /**
     * Available layout types
     */
    const LAYOUT_TYPES = [
        'standard' => StandardPlaylistLayout::class,
        // 'learning' => LearningPlaylistLayout::class, // TODO: enable when admin UI supports learning layout - next version
        'grid'     => GridPlaylistLayout::class
    ];
    
    /**
     * Default settings for each layout type.
     */
    const DEFAULT_LAYOUT_SETTINGS = [
        'standard' => [
            'behavior' => [
                'showThumbnails'      => true,
                'thumbnailGridLayout' => false,
                'showThumbnailInfo'   => true
            ]
        ],
        // 'learning' => [
        //     'learning' => [
        //         'enableProgress'      => true,
        //         'enableChapters'      => true,
        //         'completionThreshold' => 80,
        //         'showLockedContent'   => true
        //     ]
        // ],
        'grid'     => [
            'grid' => [
                'columns'       => 3,
                'itemsPerPage'  => 12,
                'enableSearch'  => true,
                'enableFilters' => true,
            
            ]
        ]
    ];
    
    /**
     * Create a layout instance based on settings
     *
     * @param object $playlist
     * @param array $medias
     * @param array $defaultSettings
     * @param int $playlistId
     * @param string $playlistVarName
     *
     * @return BasePlaylistLayout
     */
    public static function create($playlist, $medias, $defaultSettings, $playlistId, $playlistVarName)
    {
        $settings = array_merge($defaultSettings, PlaylistSettingsHelper::getPlaylistSettings($playlist));
        $layoutType = Arr::get($settings, 'layout.type', 'standard');
        
        // Validate layout type
        if (!array_key_exists($layoutType, self::LAYOUT_TYPES)) {
            $layoutType = 'standard'; // Fallback to standard
        }
        
        $layoutClass = self::LAYOUT_TYPES[$layoutType];
        
        // Ensure the class exists
        if (!class_exists($layoutClass)) {
            throw new \InvalidArgumentException(sprintf('Layout class %s does not exist', \esc_html($layoutClass)));
        }
        
        return new $layoutClass($playlist, $medias, $defaultSettings, $playlistId, $playlistVarName);
    }
    
    /**
     * Get all available layouts
     * @return array
     */
    public static function getAvailableLayouts()
    {
        return array_keys(self::LAYOUT_TYPES);
    }
    
    /**
     * Get layout metadata for admin interface
     * @return array
     */
    public static function getLayoutMetadata()
    {
        $allMetadata = [];
        foreach (self::LAYOUT_TYPES as $type => $class) {
            if (class_exists($class) && method_exists($class, 'getMetadata')) {
                $allMetadata[$type] = $class::getMetadata();
            }
        }
        return $allMetadata;
    }
    
    /**
     * Get metadata for a specific layout
     *
     * @param string $layoutType
     *
     * @return array|null
     */
    public static function getLayoutMetadataByType($layoutType)
    {
        if (array_key_exists($layoutType, self::LAYOUT_TYPES)) {
            $class = self::LAYOUT_TYPES[$layoutType];
            if (class_exists($class) && method_exists($class, 'getMetadata')) {
                return $class::getMetadata();
            }
        }
        return null;
    }
    
    /**
     * Validate layout settings
     *
     * @param array $settings
     *
     * @return array Validated settings
     */
    public static function validateLayoutSettings($settings)
    {
        $layoutType = Arr::get($settings, 'layout.type', 'standard');
        
        // Validate layout type
        if (!array_key_exists($layoutType, self::LAYOUT_TYPES)) {
            $settings['layout']['type'] = 'standard';
            $layoutType = 'standard'; // Update layoutType for subsequent checks
        }
        
        // Set default position if not set
        if (!isset($settings['layout']['position'])) {
            $metadata = self::getLayoutMetadataByType($layoutType);
            $settings['layout']['position'] = $metadata ? Arr::get($metadata, 'default_position', 'right') : 'right';
        }
        
        // Apply default settings for the layout type
        $defaultLayoutSettings = Arr::get(self::DEFAULT_LAYOUT_SETTINGS, $layoutType, []);
        $settings = array_replace_recursive($defaultLayoutSettings, $settings);
        
        
        return $settings;
    }
    
    /**
     * Get default settings for a layout type
     *
     * @param string $layoutType
     *
     * @return array
     */
    public static function getDefaultSettingsForLayout($layoutType)
    {
        $metadata = self::getLayoutMetadataByType($layoutType);
        $defaultPosition = Arr::get($metadata, 'default_position', 'right');
        
        $defaults = [
            'layout' => [
                'type'     => $layoutType,
                'position' => $defaultPosition
            ]
        ];
        
        // Merge with specific default settings from the constant
        $defaults = array_replace_recursive($defaults, Arr::get(self::DEFAULT_LAYOUT_SETTINGS, $layoutType, []));
        
        return $defaults;
    }
}
