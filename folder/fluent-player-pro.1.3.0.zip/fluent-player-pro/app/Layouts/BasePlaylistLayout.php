<?php

namespace FluentPlayerPro\App\Layouts;

use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Services\PlaylistSettingsHelper;

/**
 * Abstract base class for playlist layouts.
 *
 * Subclasses prepare data; templates handle markup.
 * HTML lives in app/Views/playlist/ — not in PHP classes.
 */
abstract class BasePlaylistLayout
{
    protected $playlist;
    protected $medias;
    protected $defaultSettings;
    protected $playlistId;
    protected $playlistVarName;
    protected $settings;

    public function __construct($playlist, $medias, $defaultSettings, $playlistId, $playlistVarName)
    {
        $this->playlist = $playlist;
        $this->medias = $medias;
        $this->defaultSettings = $defaultSettings;
        $this->playlistId = $playlistId;
        $this->playlistVarName = $playlistVarName;
        $this->settings = $this->prepareSettings();
    }

    // ─── Abstract contracts ──────────────────────────────────────────

    /**
     * Template path relative to app/Views/playlist/ (without .php).
     */
    abstract protected function getLayoutTemplate();

    /**
     * Data array passed to the layout template.
     */
    abstract protected function getLayoutData();

    /**
     * Layout-specific metadata (name, icon, features).
     */
    abstract public static function getMetadata();

    // ─── Rendering ───────────────────────────────────────────────────

    /**
     * Render the complete playlist layout.
     *
     * Subclasses no longer override this — they implement
     * getLayoutTemplate() and getLayoutData() instead.
     */
    public function render()
    {
        if (empty($this->medias)) {
            return '';
        }

        $html = $this->renderView($this->getLayoutTemplate(), $this->getLayoutData());

        // Embed playlist config as a data attribute on the outer container so that
        // fluent-playlist.js can initialize correctly in async contexts (e.g.
        // FluentCommunity lesson pages) where wp_localize_script never fires.
        $encodedConfig = esc_attr(wp_json_encode($this->buildFrontendConfig()));
        $varName       = esc_attr($this->playlistVarName);
        $html          = str_replace(
            'data-var_name="' . $varName . '"',
            'data-var_name="' . $varName . '" data-fp-config="' . $encodedConfig . '"',
            $html
        );

        return $html;
    }

    /**
     * Build the frontend config array that JS needs to initialize the playlist.
     */
    private function buildFrontendConfig()
    {
        $medias = [];
        foreach ($this->medias as $media) {
            $medias[] = [
                'ID'            => $media->ID,
                'post_title'    => $media->post_title,
                'settings'      => $media->settings ?? [],
                'deep_link_ref' => $this->getMediaDeepLinkRef($media),
            ];
        }

        return [
            'playlist' => [
                'ID'            => $this->playlist->ID,
                'post_title'    => $this->playlist->post_title ?? '',
                'post_name'     => $this->playlist->post_name ?? '',
                'settings'      => $this->playlist->settings ?? [],
                'deep_link_ref' => $this->getPlaylistDeepLinkRef(),
            ],
            'medias'          => $medias,
            'defaultSettings' => $this->defaultSettings,
        ];
    }

    /**
     * Include a template file with extracted data (Laravel-style).
     *
     * @param string $template Path relative to app/Views/playlist/ (no .php).
     * @param array  $data     Variables extracted into template scope.
     * @return string Rendered HTML.
     */
    protected function renderView($template, array $data = [])
    {
        $file = FLUENT_PLAYER_PRO_DIR_PATH . 'app/Views/playlist/' . $template . '.php';

        if (!file_exists($file)) {
            return '';
        }

        // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- Intentional: clean template variable injection
        extract($data, EXTR_SKIP);

        ob_start();
        include $file;
        return ob_get_clean();
    }

    // ─── Section renderers (override in subclasses as needed) ────────

    protected function renderHeader()
    {
        return '';
    }

    protected function renderPlayer($media)
    {
        return '';
    }

    protected function renderContent()
    {
        return '';
    }

    protected function renderFooter()
    {
        return '';
    }

    // ─── Shared helpers ──────────────────────────────────────────────

    protected function prepareSettings()
    {
        return array_merge($this->defaultSettings, $this->getPlaylistSettings());
    }

    /**
     * Resolve which media's preset/skin/controls should drive the player chrome.
     *
     * The player HTML is rendered once at server time; we cannot swap presets
     * per-track at runtime. This picks one media as the source of truth and
     * falls back to the first media if the configured one is missing.
     */
    protected function getPresetSourceMedia()
    {
        $configuredId = absint(Arr::get($this->settings, 'preset_source_media_id', 0));

        if ($configuredId) {
            foreach ($this->medias as $media) {
                if (absint($media->ID ?? 0) === $configuredId) {
                    return $media;
                }
            }
        }

        return $this->medias[0] ?? null;
    }

    /**
     * Resolve the playlist's brand color from the appearance.brandColor mode.
     *
     * - `auto`   (default for new playlists): match the preset source media's
     *            standalone brand resolution; fall back to global.
     * - `global`: plugin's global branding.brand_color.
     * - `custom`: explicit value picked by the author.
     */
    protected function resolveBrandColor(array $appearance)
    {
        $defaultBrandColor = '#DD1F13';
        $brandColorSetting = Arr::get($appearance, 'brandColor');
        $mode = is_array($brandColorSetting) ? Arr::get($brandColorSetting, 'mode') : null;

        if ($mode === 'custom') {
            return Arr::get($brandColorSetting, 'value', $defaultBrandColor);
        }

        if ($mode === 'auto') {
            $presetSourceMedia = $this->getPresetSourceMedia();
            if ($presetSourceMedia && !empty($presetSourceMedia->settings)) {
                $sourceDefaults = \FluentPlayer\App\Services\SettingsService::getMediaDefaultSettings($presetSourceMedia->settings);
                $sourceBrand = Arr::get($sourceDefaults, 'brandColor');
                if (!empty($sourceBrand)) {
                    return $sourceBrand;
                }
            }
        }

        $globalSettings = \FluentPlayer\App\Services\SettingsService::getSettings();
        return Arr::get($globalSettings, 'branding.brand_color', $defaultBrandColor);
    }

    /**
     * Read playlist settings from array or object playlist shape.
     *
     * @return array
     */
    protected function getPlaylistSettings()
    {
        return PlaylistSettingsHelper::getPlaylistSettings($this->playlist);
    }

    protected function getPlaylistDeepLinkRef()
    {
        $playlistId = is_scalar($this->playlistId) ? (string) $this->playlistId : '';
        $playlistId = preg_replace('/[^A-Za-z0-9_-]/', '', $playlistId);

        return 'flpp_' . ($playlistId !== '' ? $playlistId : '0');
    }

    protected function getMediaDeepLinkRef($media)
    {
        return 'fpm_' . absint($media->ID ?? 0);
    }

    /**
     * Resolve playlist title with settings override support.
     *
     * @return string
     */
    protected function getPlaylistTitle()
    {
        $title = Arr::get($this->settings, 'title', '');
        if (is_string($title) && $title !== '') {
            return $title;
        }

        if (is_object($this->playlist) && !empty($this->playlist->post_title)) {
            return (string) $this->playlist->post_title;
        }

        if (is_array($this->playlist)) {
            $postTitle = Arr::get($this->playlist, 'post_title', '');
            if (is_string($postTitle) && $postTitle !== '') {
                return $postTitle;
            }
        }

        return __('Playlist', 'fluent-player-pro');
    }

    /**
     * Build a CSS custom-properties style attribute string.
     * Used by Standard and Grid layouts.
     *
     * @return string  e.g. ' style="--fp-playlist-bg: #fff; ..."' or empty.
     */
    protected function buildCssStyleAttribute()
    {
        $cssVariables = $this->getCssVariables();
        if (empty($cssVariables)) {
            return '';
        }

        $parts = [];
        foreach ($cssVariables as $key => $value) {
            if (!empty($value)) {
                $parts[] = esc_attr($key) . ': ' . esc_attr($value);
            }
        }

        return !empty($parts)
            ? ' style="' . implode('; ', $parts) . '"'
            : '';
    }

    /**
     * Build the opening <div> tag for the player container.
     * Adds audio class + background styles when playlist is audio-only.
     *
     * @param object $media      Media object (for poster fallback).
     * @param string $extraClass Additional CSS class(es).
     * @return string Opening <div> tag.
     */
    protected function openPlayerContainer($media, $extraClass = '')
    {
        // Base the initial audio styling on the FIRST/initial media, not the
        // whole-playlist isAllAudio() — a mixed playlist that opens on an audio
        // item must start in audio mode; the runtime toggles fp-audio per item.
        $isAudio = Arr::get($media->settings, 'viewType', 'video') === 'audio';
        $posterSrc = Arr::get($media->settings, 'posterSrc', '');

        $classes = 'playlist-player-container';
        if ($extraClass) {
            $classes .= ' ' . $extraClass;
        }
        if ($isAudio) {
            $classes .= ' fp-audio';
        }

        $style = '';
        if ($isAudio) {
            $styleParts = ['height:auto'];
            if ($posterSrc) {
                $styleParts[] = "background-image:url('" . esc_url($posterSrc) . "')";
                $styleParts[] = 'background-size:cover';
                $styleParts[] = 'background-position:center';
            }
            $style = implode(';', $styleParts);
        }

        return '<div class="' . esc_attr($classes) . '"'
            . ($style ? ' style="' . esc_attr($style) . '"' : '')
            . '>';
    }

    /**
     * Get layout-specific CSS classes.
     */
    public function getLayoutClasses()
    {
        $classes = ['fluent-playlist', 'fluent-playlist-container'];

        $position = Arr::get($this->settings, 'layout.position', 'right');
        if ($position === 'left') {
            $classes[] = 'playlist-left';
        } elseif ($position === 'bottom') {
            $classes[] = 'playlist-bottom';
        } elseif ($position === 'top') {
            $classes[] = 'playlist-top';
        } elseif ($position === 'right') {
            $classes[] = 'playlist-right';
        }

        $layoutType = sanitize_html_class(Arr::get($this->settings, 'layout.type', 'standard'));
        $classes[] = 'playlist-' . $layoutType;

        if ($this->isAllAudio()) {
            $classes[] = 'fp-playlist-audio';
        }

        return apply_filters(
            'fluent_player/playlist_layout_classes',
            implode(' ', $classes)
        );
    }

    /**
     * Check if every media item in the playlist is audio.
     */
    public function isAllAudio()
    {
        foreach ($this->medias as $media) {
            if (Arr::get($media->settings, 'viewType', 'video') !== 'audio') {
                return false;
            }
        }
        return !empty($this->medias);
    }

    /**
     * Whether the playlist mixes audio and video items. Such a playlist must
     * render BOTH control skins so the runtime can switch per item.
     */
    public function isMixed()
    {
        $hasAudio = false;
        $hasVideo = false;
        foreach ($this->medias as $media) {
            if (Arr::get($media->settings, 'viewType', 'video') === 'audio') {
                $hasAudio = true;
            } else {
                $hasVideo = true;
            }
            if ($hasAudio && $hasVideo) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get player attributes for the media player element.
     */
    public function getPlayerAttributes($media)
    {
        $settings = $media->settings;

        // YouTube Privacy-Enhanced Mode for the embed host is handled at runtime via the
        // Vidstack provider's `cookies` flag (resources/js/utils/videoSrc.js → applyYouTubePrivacyMode,
        // wired in FluentPlaylist.js). Vidstack ignores the host in the source URL — it
        // extracts the video id and rebuilds the embed host from `cookies` — so rewriting
        // the src host here had no effect. The src stays the original watch URL.
        $videoSrc = Arr::get($settings, 'src', '');

        $attributes = [
            'title'           => esc_attr(Arr::get($settings, 'title', '')),
            'src'             => esc_url($videoSrc),
            'crossorigin'     => '',
            'media-type'      => esc_attr(Arr::get($settings, 'mediaType', 'video')),
            'view-type'       => esc_attr(Arr::get($settings, 'viewType', 'video')),
            'google-cast'     => 'false',
            'remote-playback' => 'false'
        ];

        if (Arr::get($settings, 'playsInline')) {
            $attributes['playsinline'] = '';
        }

        if (Arr::get($settings, 'muted') || Arr::get($settings, 'mutedAutoplay')) {
            $attributes['muted'] = '';
        }

        if ($this->shouldAutoPlay($settings)) {
            $attributes['autoplay'] = '';
            if (!Arr::get($settings, 'muted') && !Arr::get($settings, 'mutedAutoplay')) {
                $attributes['muted'] = '';
            }
        }

        return $attributes;
    }

    protected function shouldAutoPlay($mediaSettings)
    {
        $playlistAutoplay = Arr::get($this->settings, 'behavior.autoplay', false);
        return is_bool($playlistAutoplay) && $playlistAutoplay === true;
    }

    /**
     * Whether this layout meaningfully supports the playlist-menu toggle button
     * in the player controls. Layouts without a collapsible playlist menu should
     * return false.
     */
    protected function supportsPlaylistMenuToggle()
    {
        return true;
    }

    /**
     * Renders the core <media-player> component.
     * Reusable by all layout classes.
     */
    public function renderMediaPlayer($media)
    {
        if (!$media) {
            return '';
        }

        ob_start();
        ?>
        <media-player
            <?php
            foreach ($this->getPlayerAttributes($media) as $attr => $value) {
                if ($value === '') {
                    echo esc_attr($attr) . ' ';
                } else {
                    echo esc_attr($attr) . '="' . esc_attr($value) . '" ';
                }
            }
            ?>
        >
            <?php
            $settings = $media->settings;
            $media_id = $media->ID;
            $default_settings = $this->defaultSettings;
            ?>

            <media-provider>
                <?php
                // Render the poster for video items, and ALWAYS for a mixed
                // playlist (a mixed playlist that opens on an audio item still
                // needs a poster element for its video items after switching).
                if (Arr::get($media->settings, 'viewType', 'video') !== 'audio' || $this->isMixed()): ?>
                <media-poster
                        src="<?php echo esc_url(Arr::get($media->settings, 'posterSrc', '')); ?>"
                        alt="<?php echo esc_attr(Arr::get($media->settings, 'title', '')); ?>"
                ></media-poster>
                <?php endif; ?>

                <?php if (Arr::get($media->settings, 'chapters')): ?>
                    <?php include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/chapters-track.php'; ?>
                <?php endif; ?>

                <?php
                $subtitleTracksPath = FLUENT_PLAYER_DIR_PATH . 'app/Views/player/subtitle-tracks.php';
                if (file_exists($subtitleTracksPath)) {
                    include $subtitleTracksPath;
                }
                ?>
            </media-provider>

            <?php $this->renderPerVideoFeatures($media); ?>
            <?php include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/gestures.php'; ?>
            <?php include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/captions.php'; ?>

            <?php
            $skin = Arr::get($media->settings, 'skin', 'modern');
            $controls = Arr::get($media->settings, 'controls', []);
            $behaviors = Arr::get($media->settings, 'behaviors', []);
            $isAudio = Arr::get($media->settings, 'viewType', 'video') === 'audio';

            // Playlist render context — gates the previous/next track buttons
            // inside Free's bottom-controls.php skins. The variable name is
            // deliberately specific so it doesn't collide with the grid modal's
            // own $showNavButtons (which controls grid pagination).
            $isPlaylist = true;
            $showPlaylistNavButtons = (bool) Arr::get($this->settings, 'behavior.showNavButtons', true);
            $showPlaylistMenuToggle = $this->supportsPlaylistMenuToggle()
                && (bool) Arr::get($this->settings, 'behavior.showPlaylistMenuToggle', true);

            // A mixed audio+video playlist renders BOTH skins in the one player;
            // the runtime shows the right one per item via data-view-type. Pure
            // playlists render only their own skin (unchanged).
            $isMixedPlaylist = $this->isMixed();
            $renderAudioSkin = $isMixedPlaylist || $isAudio;
            $renderVideoSkin = $isMixedPlaylist || !$isAudio;

            if ($renderAudioSkin):
                if (!Arr::isTrue($behaviors, 'hide_bottom_controls')):
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/bottom-controls-audio.php';
                endif;
            endif;

            if ($renderVideoSkin):
                if ($skin !== 'minimal' && !Arr::isTrue($behaviors, 'hide_top_controls')):
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/top-controls.php';
                endif;

                if ($skin === 'minimal' || !Arr::isTrue($behaviors, 'hide_center_controls')):
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/center-controls.php';
                endif;

                if ($skin !== 'minimal' && !Arr::isTrue($behaviors, 'hide_bottom_controls')):
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/bottom-controls.php';
                endif;
            endif;
            ?>
        </media-player>
        <?php
        return ob_get_clean();
    }

    /**
     * Render per-video feature overlays inside the media player.
     */
    protected function renderPerVideoFeatures($activeMedia)
    {
        $mode            = $this->settings['feature_mode'] ?? 'per_video';
        $selectedMediaId = isset($this->settings['feature_video_id'])
                           ? absint($this->settings['feature_video_id'])
                           : 0;

        foreach ($this->medias as $featureMedia) {
            $mediaId = absint($featureMedia->ID);

            if ($mode === 'selected_video' && $mediaId !== $selectedMediaId) {
                continue;
            }

            $isActive = ($mediaId === absint($activeMedia->ID));
            $classes  = 'fp-per-video-features' . ($isActive ? '' : ' fp-features-hidden');

            echo '<div class="' . esc_attr($classes) . '" data-media-id="' . esc_attr($mediaId) . '">';

            $settings         = $featureMedia->settings;
            $media_id         = $featureMedia->ID;
            $default_settings = $this->defaultSettings;

            include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/email-capture.php';
            include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/cta-overlay.php';
            include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/action-bar-overlay.php';
            include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/overlays.php';
            include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/logo.php';
            include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/youtube-subscribe.php';

            if (!empty($featureMedia->settings['layers'])
                && class_exists('FluentPlayer\App\Views\Layers\LayerRenderer')
            ) {
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                echo \FluentPlayer\App\Views\Layers\LayerRenderer::renderLayersData(
                    $featureMedia->settings,
                    $mediaId
                );
            }

            echo '</div>';
        }
    }

    // ─── CSS variable helpers ────────────────────────────────────────

    public function getCssVariables()
    {
        $appearance = Arr::get($this->settings, 'appearance', []);
        $layout = Arr::get($this->settings, 'layout', []);

        $brandColor = $this->resolveBrandColor($appearance);

        $typographyEnabled = Arr::get($this->settings, 'typography.enabled', false);

        $separator     = Arr::get($appearance, 'separator', ['type' => 'line', 'size' => ['value' => 1, 'unit' => 'px']]);
        $separatorType = Arr::get($separator, 'type', 'line');
        $separatorSize = $this->formatCssValue(Arr::get($separator, 'size', ['value' => 1, 'unit' => 'px']));

        $variables = [
            '--fp-playlist-background-color' => Arr::get($appearance, 'backgroundColor', '#ffffff'),
            '--fp-playlist-text-color'       => Arr::get($appearance, 'textColor', '#333333'),
            '--fp-playlist-brand-color'      => $brandColor,
            '--media-brand'                  => $brandColor,
            '--fp-playlist-border-color'     => Arr::get($appearance, 'borderColor', '#e1e5e9'),
            '--fp-playlist-border-width'     => $this->formatCssValue(Arr::get($appearance, 'borderWidth', ['value' => 0, 'unit' => 'px'])),
            '--fp-playlist-divider-width'    => $separatorType === 'line' ? $separatorSize : '0',
            '--fp-playlist-divider-gap'      => $separatorType === 'space' ? $separatorSize : '0',
            '--fp-playlist-border-radius'    => $this->formatCssValue(Arr::get($appearance, 'borderRadius')),
            '--fp-playlist-box-shadow'       => $this->formatBoxShadow(Arr::get($appearance, 'boxShadow')),
            '--fp-playlist-gap'              => $this->formatCssValue(Arr::get($layout, 'containerGap', ['value' => 0, 'unit' => 'px'])),
            '--fp-playlist-sidebar-width'    => Arr::get($layout, 'sidebarWidth', '40') . '%',
            '--fp-playlist-item-spacing'     => $this->formatCssValue(Arr::get($layout, 'itemSpacing', ['value' => 8, 'unit' => 'px'])),
            '--fp-playlist-thumbnail-ratio'  => $this->formatAspectRatio(Arr::get($layout, 'thumbnailRatio', '16/9')),
            '--fp-playlist-font-size'        => $this->formatCssValue(Arr::get($this->settings, 'typography.fontSize')),
            '--fp-playlist-font-weight'      => Arr::get($this->settings, 'typography.fontWeight', '400'),
            '--fp-playlist-line-height'      => Arr::get($this->settings, 'typography.lineHeight', '1.4'),
        ];

        if ($typographyEnabled) {
            $variables['--fp-playlist-font-size'] = $this->formatCssValue(Arr::get($this->settings, 'typography.fontSize'));
            $variables['--fp-playlist-font-weight'] = Arr::get($this->settings, 'typography.fontWeight', 400);
            $variables['--fp-playlist-line-height'] = Arr::get($this->settings, 'typography.lineHeight', 1.4);
        }

        return $variables;
    }

    protected function formatLayoutLength($value, $default = '0')
    {
        if ($value === null || $value === '') {
            return $default;
        }
        if (is_array($value) && isset($value['value']) && isset($value['unit'])) {
            return $value['value'] . $value['unit'];
        }
        return is_numeric($value) ? $value . 'px' : (string) $value;
    }

    protected function formatLayoutSidebarWidth($value)
    {
        if ($value === null || $value === '') {
            return '40%';
        }
        if (is_array($value) && isset($value['value']) && isset($value['unit'])) {
            return $value['value'] . $value['unit'];
        }
        return is_numeric($value) ? $value . '%' : (string) $value;
    }

    protected function formatAspectRatio($value)
    {
        if (!$value || $value === 'auto') {
            return 'auto';
        }
        $value = str_replace([':', '/'], '/', trim($value));
        $parts = explode('/', $value);
        if (count($parts) === 2 && is_numeric(trim($parts[0])) && is_numeric(trim($parts[1]))) {
            return trim($parts[0]) . ' / ' . trim($parts[1]);
        }
        return '16 / 9';
    }

    protected function formatCssValue($value)
    {
        if (is_array($value) && isset($value['value']) && isset($value['unit'])) {
            return $value['value'] . $value['unit'];
        }
        return $value;
    }

    protected function formatBoxShadow($boxShadow)
    {
        if (!$boxShadow || !Arr::get($boxShadow, 'enabled', false)) {
            return 'none';
        }

        $horizontal = Arr::get($boxShadow, 'horizontal', 0);
        $vertical = Arr::get($boxShadow, 'vertical', 2);
        $blur = Arr::get($boxShadow, 'blur', 8);
        $spread = Arr::get($boxShadow, 'spread', 0);
        $color = Arr::get($boxShadow, 'color', '#000000');
        $position = Arr::get($boxShadow, 'position', 'inset') === 'outline' ? '' : 'inset';

        return trim("{$position} {$horizontal}px {$vertical}px {$blur}px {$spread}px {$color}");
    }
}
