<?php

namespace FluentPlayerPro\App\Layouts;

use FluentPlayer\App\Helpers\Helper;
use FluentPlayer\Framework\Support\Arr;

/**
 * Standard Playlist Layout - Classic sidebar layout (backward compatible).
 * Displays playlist items in a vertical sidebar with thumbnails and navigation.
 */
class StandardPlaylistLayout extends BasePlaylistLayout
{
    protected function getLayoutTemplate()
    {
        return 'layouts/standard';
    }

    protected function getLayoutData()
    {
        $position = Arr::get($this->settings, 'layout.position', 'right');

        return [
            'layoutClasses'       => $this->getLayoutClasses(),
            'playlistId'          => $this->playlistId,
            'playlistVarName'     => $this->playlistVarName,
            'playlistDeepLinkRef' => $this->getPlaylistDeepLinkRef(),
            'styleAttributes'     => $this->buildCssStyleAttribute(),
            'positionClass'       => $this->getPositionClass(),
            'separatorClass'      => 'fp-separator-' . sanitize_html_class(Arr::get($this->settings, 'appearance.separator.type', 'line')),
            'position'            => $position,
            'playerHtml'          => $this->renderPlayer($this->getPresetSourceMedia()),
            'contentHtml'         => $this->renderContent(),
        ];
    }

    // ─── Section renderers ───────────────────────────────────────────

    protected function renderPlayer($media)
    {
        return $this->renderView('partials/player-container', [
            'containerOpen'  => $this->openPlayerContainer($media),
            'mediaPlayerHtml' => $this->renderMediaPlayer($media),
        ]);
    }

    protected function renderContent()
    {
        $showThumbnails      = Arr::get($this->settings, 'behavior.showThumbnails', true);
        $thumbnailGridLayout = Arr::get($this->settings, 'behavior.thumbnailGridLayout', false);
        $showThumbnailInfo   = Arr::get($this->settings, 'behavior.showThumbnailInfo', true);
        $titlePosition       = Arr::get($this->settings, 'behavior.titlePosition', 'overlay');
        $headerPosition      = Arr::get($this->settings, 'layout.headerPosition', 'top');
        $showHeader          = Arr::get($this->settings, 'layout.showHeader', true);
        $position            = Arr::get($this->settings, 'layout.position', 'right');

        $items = [];
        foreach ($this->medias as $index => $media) {
            $duration = isset($media->settings['duration']) ? $media->settings['duration'] : '';
            $items[] = [
                'media'             => $media,
                'index'             => $index,
                'deepLinkRef'       => $this->getMediaDeepLinkRef($media),
                'durationRaw'       => (string) ($duration !== '' ? (float) $duration : ''),
                'durationFormatted' => ($duration !== '' ? Helper::formatDuration($duration) : ''),
            ];
        }

        return $this->renderView('standard/sidebar', [
            'position'            => $position,
            'headerPosition'      => $headerPosition,
            'showHeader'          => $showHeader,
            'showThumbnails'      => $showThumbnails,
            'thumbnailGridLayout' => $thumbnailGridLayout,
            'showThumbnailInfo'   => $showThumbnailInfo,
            'titlePosition'       => $titlePosition,
            'sidebarHeaderHtml'   => $this->renderSidebarHeader($showHeader),
            'items'               => $items,
        ]);
    }

    // ─── Helpers ─────────────────────────────────────────────────────

    protected function renderSidebarHeader($showHeader = true)
    {
        $totalVideos = count($this->medias);
        $videoText   = $totalVideos === 1
            ? __('video', 'fluent-player-pro')
            : __('videos', 'fluent-player-pro');
        $videoText   = apply_filters('fluent_player/playlist_video_text', $videoText, $totalVideos, $this->playlist);

        $headerPosition = Arr::get($this->settings, 'layout.headerPosition', 'top');

        return $this->renderView('standard/sidebar-header', [
            'playlistTitle'  => $this->getPlaylistTitle(),
            'totalVideos'    => $totalVideos,
            'videoText'      => $videoText,
            'headerPosition' => $headerPosition,
            'positionClass'  => $headerPosition === 'bottom' ? 'fp-playlist-header-bottom' : 'fp-playlist-header-top',
            'hiddenClass'    => $showHeader ? '' : ' fp-playlist-header--hidden',
        ]);
    }

    protected function getPositionClass()
    {
        $position = Arr::get($this->settings, 'layout.position', 'right');

        if ($position === 'left') {
            return 'playlist-left';
        } elseif ($position === 'bottom') {
            return 'playlist-bottom';
        } elseif ($position === 'top') {
            return 'playlist-top';
        }

        return 'playlist-right';
    }

    public static function getMetadata()
    {
        return [
            'name'             => 'Standard Layout',
            'description'      => 'Classic sidebar layout with vertical playlist navigation',
            'icon'             => 'list',
            'default_position' => 'right',
            'features'         => ['sidebar', 'thumbnails', 'progress'],
        ];
    }
}
