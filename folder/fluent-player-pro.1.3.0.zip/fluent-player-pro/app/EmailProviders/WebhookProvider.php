<?php

namespace FluentPlayerPro\App\EmailProviders;

use FluentPlayer\App\EmailProviders\AbstractEmailProvider;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayer\Framework\Validator\Validator;
use FluentPlayerPro\App\Utils\Provider\Webhook;

class WebhookProvider extends AbstractEmailProvider
{
    protected $provider = 'webhook';
    protected $name = 'Webhook';
    protected $description = 'Send collected emails to any external service via webhooks.';
    protected $logo = 'webhook.svg';

    protected $defaultSettings = [
        'enabled' => false,
        'items'   => []
    ];
    
    protected static $emailProvidersCache = null;

    /**
     * Validate settings before saving
     * @param array $settings
     * @return array|\WP_Error
     */
    public function validateSettings($settings)
    {
        $validation = Validator::make($settings, [
            'items.*.method' => 'required|in:GET,POST,PUT',
            'items.*.url'    => 'required|url',
            'items.*.name'   => 'required'
        ]);
        if ($validation->fails()) {
            return new \WP_Error('validation_failed', __('Validation failed', 'fluent-player-pro'));
        }
        return $settings;
    }

    /**
     * Sanitize settings before saving
     * @param array $settings
     * @return array
     */
    public function sanitizeSettings($settings)
    {
        $sanitized = Sanitizer::sanitize($settings, [
            'enabled' => 'rest_sanitize_boolean'
        ]);

        // Sanitize webhook items
        if ($items = Arr::get($settings, 'items')) {
            $sanitizedItems = [];
            foreach ($items as $id => $item) {
                $sanitizedItem = Sanitizer::sanitize($item, [
                    'name' => 'sanitizeTextField',
                    'url'  => 'escUrlRaw',
                    'email_name' => 'sanitizeTextField',
                ]);

                $sanitizedItem['method'] = Arr::get($item, 'method', 'POST');
                if (!in_array($sanitizedItem['method'], ['GET', 'POST', 'PUT'])) {
                    $sanitizedItem['method'] = 'POST';
                }
                if (!Arr::get($item, 'email_name')) {
                    $sanitizedItem['email_name'] = 'email'; // Default field name
                }

                // Sanitize headers
                if ($headers = Arr::get($item, 'headers')) {
                    $sanitizedHeaders = [];
                    foreach ($headers as $header) {
                        $header = Sanitizer::sanitize($header, [
                            'name'  => 'sanitizeTextField',
                            'value' => 'sanitizeTextField'
                        ]);
                        if (!empty($header['name']) && !empty($header['value'])) {
                            // Format header name (replace spaces with dashes) & trim lading/trailing dashes
                            $header['name'] = trim(str_replace(' ', '-', $header['name']), '-');
                            if (!empty($header['name'])) {
                                $sanitizedHeaders[] = $header;
                            }
                        }
                    }
                    $sanitizedItem['headers'] = $sanitizedHeaders;
                } else {
                    $sanitizedItem['headers'] = [];
                }

                $sanitizedItems[$id] = $sanitizedItem;
            }
            $sanitized['items'] = $sanitizedItems;
        } else {
            $sanitized['items'] = [];
        }
        return $sanitized;
    }

    /**
     * Get provider settings fields configuration
     * @return array
     */
    public function getSettingsFields()
    {
        return [
            [
                'key'     => 'enabled',
                'type'    => 'switch',
                'label'   => __('Enable Webhooks', 'fluent-player-pro'),
                'help'    => __('Enable webhook integration to send email submissions to external URLs', 'fluent-player-pro'),
                'context' => 'settings'
            ],
            [
                'key'         => 'items',
                'type'        => 'complex_array',
                'label'       => __('Webhook Configurations', 'fluent-player-pro'),
                'help'        => __('Configure webhook endpoints to send email data', 'fluent-player-pro'),
                'button_text' => __('Add Webhook', 'fluent-player-pro'),
                'item_label'  => 'name',
                'fields'      => [
                    [
                        'key'         => 'name',
                        'type'        => 'text',
                        'label'       => __('Webhook Name', 'fluent-player-pro'),
                        'placeholder' => __('Enter a name for this webhook', 'fluent-player-pro'),
                        'required'    => true
                    ],
                    [
                        'key'         => 'url',
                        'type'        => 'text',
                        'label'       => __('Request URL', 'fluent-player-pro'),
                        'placeholder' => __('https://your-webhook-endpoint.com', 'fluent-player-pro'),
                        'required'    => true
                    ],
                    [
                        'key'     => 'method',
                        'type'    => 'select',
                        'label'   => __('Request Method', 'fluent-player-pro'),
                        'options' => [
                            ['id' => 'GET', 'name' => 'GET'],
                            ['id' => 'POST', 'name' => 'POST'],
                            ['id' => 'PUT', 'name' => 'PUT']
                        ],
                        'default' => 'POST'
                    ],
                    [
                        'key'         => 'email_name',
                        'type'        => 'text',
                        'label'       => __('Email Field Name', 'fluent-player-pro'),
                        'default'     => 'email',
                        'help'        => __('The name of the field that will contain the email address in the request', 'fluent-player-pro')
                    ],
                    [
                        'key'         => 'headers',
                        'type'        => 'array',
                        'label'       => __('Headers', 'fluent-player-pro'),
                        'button_text' => __('Add Header', 'fluent-player-pro'),
                        'fields'      => [
                            [
                                'key'   => 'name',
                                'type'  => 'text',
                                'label' => __('Header Name', 'fluent-player-pro')
                            ],
                            [
                                'key'   => 'value',
                                'type'  => 'text',
                                'label' => __('Header Value', 'fluent-player-pro')
                            ]
                        ]
                    ],
                ],
                'context' => 'settings'
            ],
            [
                'key'         => 'webhook_id',
                'type'        => 'select',
                'label'       => __('Select Webhook', 'fluent-player-pro'),
                'required'    => true,
                'placeholder' => __('Select a webhook endpoint', 'fluent-player-pro'),
                'help'        => __('Choose a webhook to send data to', 'fluent-player-pro'),
                'async'       => true,
                'endpoint'    => 'email-providers/webhook/lists',
                'context'     => 'preset_editor'
            ]
        ];
    }

    /**
     * Subscribe an email address using webhook
     * @param string $email
     * @param array $data Additional data
     * @param array $settings Provider settings
     * @return array|\WP_Error
     */
    public function subscribe($email, $data, $settings)
    {
        try {
            // Get the webhook ID from settings
            $webhookId = Arr::get($settings, 'webhook_id');

            // Get all configured webhooks
            $webhooks = Arr::get($this->getProviderSettings(), 'items', []);

            // If a specific webhook ID is provided, only use that one
            if (!empty($webhookId) && isset($webhooks[$webhookId])) {
                $webhooks = [$webhookId => $webhooks[$webhookId]];
            }

            // Return early if no webhooks are configured
            if (empty($webhooks)) {
                return new \WP_Error('no_webhooks', __('No webhooks are configured', 'fluent-player-pro'));
            }

            $results = [];
            $success = true;
            $failedHooks = [];

            // Process all webhooks
            foreach ($webhooks as $id => $webhook) {
                $url = Arr::get($webhook, 'url');
                $method = Arr::get($webhook, 'method', 'POST');
                $fieldName = Arr::get($webhook, 'email_name', 'email');
                $headers = Arr::get($webhook, 'headers', []);
                $webhookName = Arr::get($webhook, 'name', "Webhook {$id}");

                if (empty($url)) {
                    $failedHooks[] = $webhookName;
                    $success = false;
                    $results[$id] = [
                        'success' => false,
                        'message' => __('Webhook URL is not configured', 'fluent-player-pro')
                    ];
                    continue; // Skip this webhook but continue with others
                }

                // Pass the webhook ID to the handler
                $webhookHandler = new Webhook($url, $method, $fieldName, $headers, $email);
                $webhookHandler->setWebhookId($id);
                $result = $webhookHandler->send();

                // Store the result
                $results[$id] = $result;

                // Track failed webhooks
                if (!Arr::isTrue($result, 'success')) {
                    $failedHooks[] = $webhookName;
                    $success = false;
                }
            }

            // Determine the overall status
            if (!$success) {
                if (count($failedHooks) === count($webhooks)) {
                    // All webhooks failed
                    return new \WP_Error(
                        'all_webhooks_failed',
                        __('All webhook requests failed', 'fluent-player-pro'),
                        ['results' => $results]
                    );
                } else {
                    // Some webhooks succeeded, some failed
                    return [
                        'success' => true,
                        'message' => sprintf(
                            // translators: %s: comma-separated list of failed webhook names
                            __('Some webhooks failed: %s', 'fluent-player-pro'),
                            implode(', ', $failedHooks)
                        ),
                        'results' => $results,
                        'partial_failure' => true
                    ];
                }
            }

            // All webhooks succeeded
            return [
                'success' => true,
                'message' => __('All webhooks sent successfully', 'fluent-player-pro'),
                'results' => $results
            ];

        } catch (\Exception $e) {
            return new \WP_Error('webhook_exception', $e->getMessage());
        }
    }

    /**
     * Check if provider is properly configured
     * @param array $settings
     * @return bool
     */
    public function isConfigured($settings)
    {
        return !empty($settings['enabled']) && !empty($settings['items']);
    }

    /**
     * Handle provider-specific actions
     * @param string $action
     * @param array $settings
     * @param array $data
     * @return array|\WP_Error
     */
    public function handleAction($action, $settings, $data = [])
    {
        if ($action === 'lists') {
            return $this->getWebhooksItems($settings);
        }

        return parent::handleAction($action, $settings, $data);
    }

    /**
     * Get webhooks for select field
     * @param array $settings
     * @return array
     */
    protected function getWebhooksItems($settings)
    {
        $webhooks = Arr::get($settings, 'items', []);
        $items = [];

        foreach ($webhooks as $id => $webhook) {
            $items[] = [
                'value' => $id,
                'label' => Arr::get($webhook, 'name', 'Unnamed Webhook') . ' (' . Arr::get($webhook, 'url', '') . ')'
            ];
        }

        return [
            'success' => true,
            'lists' => $items
        ];
    }
    
    /**
     * Get current provider settings
     * @return array
     */
    protected function getProviderSettings()
    {
        if (self::$emailProvidersCache !== null) {
            $settings = self::$emailProvidersCache;
            return $settings[$this->provider] ?? $this->defaultSettings;
        }
        
        $allSettings = get_option('fluent_player_email_providers', '');
        if ($allSettings) {
            $settings = json_decode($allSettings, true);
            self::$emailProvidersCache = is_array($settings) ? $settings : [];
            return self::$emailProvidersCache[$this->provider] ?? $this->defaultSettings;
        }
        
        self::$emailProvidersCache = [];
        return $this->defaultSettings;
    }
    
    public static function clearCache()
    {
        self::$emailProvidersCache = null;
    }
}