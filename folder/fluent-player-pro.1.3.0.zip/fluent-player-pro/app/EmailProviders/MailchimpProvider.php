<?php

namespace FluentPlayerPro\App\EmailProviders;

use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Utils\Provider\Mailchimp;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayer\App\EmailProviders\AbstractEmailProvider;

class MailchimpProvider extends AbstractEmailProvider
{
    protected $provider = 'mailchimp';
    protected $name = 'Mailchimp';
    protected $description = 'Connect FluentPlayer with Mailchimp to add email subscribers to your lists.';
    protected $logo = 'mailchimp.svg';

    protected $defaultSettings = [
        'enabled' => false,
        'api_key' => '',
        'list_id' => ''
    ];

    /**
     * Validate settings before saving
     * @param array $settings
     * @return array|\WP_Error
     */
    public function validateSettings($settings)
    {
        if (Arr::isTrue($settings, 'enabled') && empty(Arr::get($settings, 'api_key'))) {
            return new \WP_Error('validation_failed', __('API key is required for Mailchimp', 'fluent-player-pro'));
        }

        return $settings;
    }

    /**
     * Sanitize settings before saving
     * @param array $settings
     * @return array
     */
    public function sanitizeSettings($settings)
    {
        return Sanitizer::sanitize($settings, [
            'enabled' => 'rest_sanitize_boolean',
            'api_key' => 'sanitizeTextField',
            'list_id' => 'sanitizeTextField',
            'tags'    => 'sanitizeTextField'
        ]);
    }

    /**
     * Get provider settings fields configuration
     * @return array
     */
    public function getSettingsFields()
    {
        return [
            [
                'key' => 'api_key',
                'type' => 'password',
                'label' => __('API Key', 'fluent-player-pro'),
                'required' => true,
                'placeholder' => __('Enter your Mailchimp API key', 'fluent-player-pro'),
                'help' => __('You can create a new key on your Mailchimp account page.', 'fluent-player-pro'),
                'link' => 'https://us11.admin.mailchimp.com/account/api/',
                'link_text' => __('Get My API Key', 'fluent-player-pro'),
                'validate_on_save' => true,
            ],
            [
                'key' => 'list_id',
                'type' => 'select',
                'label' => __('Mailing List', 'fluent-player-pro'),
                'required' => true,
                'placeholder' => __('Select a list', 'fluent-player-pro'),
                'async' => true,
                'endpoint' => 'email-providers/mailchimp/lists',
                'depends_on' => 'api_key',
                'context' => 'preset_editor'
            ],
            [
                'key' => 'tags',
                'type' => 'text',
                'label' => __('Tags', 'fluent-player-pro'),
                'placeholder' => __('tag1, tag2, tag3', 'fluent-player-pro'),
                'help' => __('Enter comma-separated tags to apply to new subscribers', 'fluent-player-pro'),
                'depends_on' => 'list_id',
                'context' => 'preset_editor'
            ]
        ];
    }

    /**
     * Subscribe an email address to Mailchimp
     * @param string $email
     * @param array $data Additional data
     * @param array $settings Provider settings
     * @return array|\WP_Error
     */
    public function subscribe($email, $data, $settings)
    {
        if (empty($settings['api_key']) || empty($settings['list_id'])) {
            return new \WP_Error('missing_config', __('Mailchimp configuration is incomplete', 'fluent-player-pro'));
        }

        try {
            $mailchimp = new Mailchimp($settings['api_key']);

            // Process tags if provided
            $tags = [];
            if (!empty($settings['tags'])) {
                // Split the comma-separated tags and trim whitespace
                $tags = array_map('trim', explode(',', $settings['tags']));
            }

            // Add merge fields if provided in the data
            $mergeFields = [];
            if (!empty($data['name'])) {
                $mergeFields['FNAME'] = $data['name'];
            }

            $response = $mailchimp->addSubscriber($email, $settings['list_id'], $tags, $mergeFields);

            return $response;
        } catch (\Exception $e) {
            return new \WP_Error('subscription_failed', $e->getMessage());
        }
    }

    /**
     * Check if provider is properly configured
     * @param array $settings
     * @return bool
     */
    public function isConfigured($settings)
    {
        return !empty($settings['enabled']) && !empty($settings['api_key']);
    }

    /**
     * Handle provider-specific actions
     * @param string $action
     * @param array $settings
     * @param array $data
     * @return array|\WP_Error
     */
    public function handleAction($action, $settings, $data = [])
    {
        if ($action === 'lists') {
            return $this->getLists($settings);
        }

        if ($action === 'tags') {
            $listId = isset($data['list_id']) ? $data['list_id'] : null;

            if (!$listId) {
                return [
                    'success' => false,
                    'message' => __('List ID is required to fetch tags', 'fluent-player-pro'),
                    'tags' => []
                ];
            }

            return $this->getTags($settings, $listId);
        }

        return parent::handleAction($action, $settings, $data);
    }

    /**
     * Get Mailchimp lists
     * @param array $settings
     * @return array
     */
    protected function getLists($settings)
    {
        if (empty($settings['api_key'])) {
            return [
                'success' => false,
                'message' => __('Mailchimp API key not configured', 'fluent-player-pro'),
                'lists' => []
            ];
        }

        try {
            $mailchimp = new Mailchimp($settings['api_key']);
            $response = $mailchimp->getLists();

            if (!$response['success']) {
                return [
                    'success' => false,
                    'message' => $response['message'] ?? __('Failed to retrieve Mailchimp lists', 'fluent-player-pro'),
                    'lists' => []
                ];
            }

            $lists = [];
            if (isset($response['data']['lists'])) {
                foreach ($response['data']['lists'] as $list) {
                    $lists[] = [
                        'id' => $list['id'],
                        'name' => $list['name']
                    ];
                }
            }

            return [
                'success' => true,
                'message' => __('Mailchimp lists retrieved successfully', 'fluent-player-pro'),
                'lists' => $lists
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'lists' => []
            ];
        }
    }

    /**
     * Get Mailchimp tags for a list
     * @param array $settings
     * @param string $listId
     * @return array
     */
    protected function getTags($settings, $listId)
    {
        if (empty($settings['api_key'])) {
            return [
                'success' => false,
                'message' => __('Mailchimp API key not configured', 'fluent-player-pro'),
                'tags' => []
            ];
        }

        try {
            $mailchimp = new Mailchimp($settings['api_key']);
            $response = $mailchimp->makeRequest("lists/{$listId}/segments", ['type' => 'static', 'count' => 1000], 'GET');

            if (!$response['success']) {
                return [
                    'success' => false,
                    'message' => $response['message'] ?? __('Failed to retrieve Mailchimp tags', 'fluent-player-pro'),
                    'tags' => []
                ];
            }

            $tags = [];
            if (isset($response['data']['segments'])) {
                foreach ($response['data']['segments'] as $tag) {
                    $tags[] = [
                        'id' => $tag['id'],
                        'name' => $tag['name']
                    ];
                }
            }

            return [
                'success' => true,
                'message' => __('Mailchimp tags retrieved successfully', 'fluent-player-pro'),
                'tags' => $tags
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'tags' => []
            ];
        }
    }
    
    /**
     * Validate a specific field value
     * @param string $field Field key
     * @param mixed $value Field value
     * @return array|\WP_Error
     */
    public function validateField($field, $value)
    {
        if ($field === 'api_key') {
            return $this->validateApiKey($value);
        }

        return parent::validateField($field, $value);
    }

    /**
     * Validate Mailchimp API key
     * @param string $apiKey
     * @return array|\WP_Error
     */
    protected function validateApiKey($apiKey)
    {
        if (empty($apiKey)) {
            return new \WP_Error('validation_failed', __('API key is required for Mailchimp', 'fluent-player-pro'));
        }

        try {
            $mailchimp = new Mailchimp($apiKey);
            $response = $mailchimp->ping();

            if (!$response['success']) {
                return new \WP_Error('invalid_api_key', __('Invalid Mailchimp API key', 'fluent-player-pro'));
            }

            return [
                'success' => true,
                'message' => __('Mailchimp API key is valid', 'fluent-player-pro')
            ];
        } catch (\Exception $e) {
            return new \WP_Error('invalid_api_key', $e->getMessage());
        }
    }
}

