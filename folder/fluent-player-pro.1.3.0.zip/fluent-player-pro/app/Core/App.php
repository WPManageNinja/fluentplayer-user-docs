<?php

namespace FluentPlayerPro\App\Core;

use FluentPlayerPro\App\Core\AppTrait;

class App
{   
    use AppTrait;
}
