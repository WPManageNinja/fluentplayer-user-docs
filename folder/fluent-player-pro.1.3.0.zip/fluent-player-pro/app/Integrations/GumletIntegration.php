<?php

namespace FluentPlayerPro\App\Integrations;

use FluentPlayer\App\Integrations\AbstractIntegration;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Libraries\Gumlet;

class GumletIntegration extends AbstractIntegration
{
    /**
     * @var string
     */
    protected $integration = 'gumlet';

    /**
     * @var string
     */
    protected $name = 'Gumlet';

    /**
     * @var string
     */
    protected $description = 'Stream video with Gumlet - adaptive HLS/DASH, live streaming, and secure signed playback';

    /**
     * @var string
     */
    protected $logo = 'gumlet.svg';

    /**
     * @var array
     */
    protected $defaultSettings = [
        'enabled'            => false,
        'api_key'            => '',
        'workspace_id'       => '',
        'live_source_id'     => '',
        'enable_signed_urls' => false,
        'signing_secret'     => '',
    ];

    /**
     * @param array $settings
     * @return bool|\WP_Error
     */
    public function validateSettings($settings)
    {
        if (Arr::isTrue($settings, 'enabled')) {
            if (empty($settings['api_key'])) {
                return new \WP_Error('missing_api_key', __('API Key is required', 'fluent-player-pro'));
            }
            if (empty($settings['workspace_id'])) {
                return new \WP_Error('missing_workspace_id', __('Workspace ID is required', 'fluent-player-pro'));
            }
        }

        if (Arr::isTrue($settings, 'enable_signed_urls') && empty($settings['signing_secret'])) {
            return new \WP_Error(
                'missing_signing_secret',
                __('Signing Secret is required when signed URLs are enabled.', 'fluent-player-pro')
            );
        }

        return true;
    }

    /**
     * @return array
     */
    public function getSettingsFields()
    {
        return [
            [
                'key'          => 'setup_instructions',
                'type'         => 'setup_instructions',
                'label'        => __('Setup Instructions', 'fluent-player-pro'),
                'instructions' => [
                    'title' => __('Gumlet Setup Guide', 'fluent-player-pro'),
                    'steps' => [
                        [
                            'title'   => __('Step 1: Create Gumlet Account', 'fluent-player-pro'),
                            'content' => __('If you don\'t have a Gumlet account yet, visit the Gumlet website and sign up.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'link'    => [
                                'url'  => 'https://www.gumlet.com/',
                                'text' => __('Sign up for Gumlet', 'fluent-player-pro'),
                            ],
                        ],
                        [
                            'title'   => __('Step 2: Generate an API Key', 'fluent-player-pro'),
                            'content' => __('In the Gumlet dashboard go to Developers > API Keys and create a key with the "Video Admin" role.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'note'    => __('Keep your API Key secure and never share it publicly.', 'fluent-player-pro'),
                        ],
                        [
                            'title'   => __('Step 3: Copy your Collection ID', 'fluent-player-pro'),
                            'content' => __('Open your Video collection in the dashboard and copy its ID (also shown as the Workspace / Source ID). It is used to list and upload videos.', 'fluent-player-pro'),
                            'type'    => 'text',
                        ],
                        [
                            'title'   => __('Step 4: Configure & Test', 'fluent-player-pro'),
                            'content' => __('Enter your API Key and Collection ID below, enable the integration, save, then use "Test Connection".', 'fluent-player-pro'),
                            'type'    => 'text',
                        ],
                    ],
                ],
            ],
            [
                'key'         => 'enabled',
                'type'        => 'checkbox',
                'label'       => __('Enable Gumlet', 'fluent-player-pro'),
                'description' => __('Enable Gumlet integration for video hosting, streaming, and live', 'fluent-player-pro'),
            ],
            [
                'key'         => 'api_key',
                'type'        => 'password',
                'label'       => __('API Key', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('Your Gumlet API Key from Developers > API Keys (Video Admin role).', 'fluent-player-pro'),
                'placeholder' => __('Enter your Gumlet API Key', 'fluent-player-pro'),
            ],
            [
                'key'         => 'workspace_id',
                'type'        => 'text',
                'label'       => __('Collection ID', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('Your Gumlet Video collection ID (also shown as the Workspace / Source ID). Used to list and upload videos.', 'fluent-player-pro'),
                'placeholder' => __('e.g. 6a4cdf8a752204b8a639acef', 'fluent-player-pro'),
            ],
            [
                'key'         => 'live_source_id',
                'type'        => 'text',
                'label'       => __('Live Source ID', 'fluent-player-pro'),
                'description' => __('Optional. Only needed for Live streaming — the Live video source ID from your Gumlet dashboard.', 'fluent-player-pro'),
                'placeholder' => __('Optional — for Live streaming', 'fluent-player-pro'),
            ],
            [
                'key'         => 'enable_signed_urls',
                'type'        => 'checkbox',
                'label'       => __('Enable Signed URLs', 'fluent-player-pro'),
                'description' => __('Use secure signed URLs for private/protected video playback.', 'fluent-player-pro'),
            ],
            [
                'key'         => 'signing_secret',
                'type'        => 'password',
                'label'       => __('Signing Secret', 'fluent-player-pro'),
                'description' => __('The signing secret from your Gumlet workspace Video Protection settings. Used to mint short-lived playback tokens for private assets.', 'fluent-player-pro'),
                'placeholder' => __('Paste your signing secret', 'fluent-player-pro'),
                'depends_on'  => 'enable_signed_urls',
            ],
        ];
    }

    /**
     * @param array|null $settings
     * @return bool|\WP_Error
     */
    public function testConnection($settings = null)
    {
        $settings = $settings ?: $this->getSettings();

        if (!Arr::isTrue($settings, 'enabled')) {
            return true;
        }

        $apiKey = Arr::get($settings, 'api_key');
        $workspaceId = Arr::get($settings, 'workspace_id');

        if (empty($apiKey) || empty($workspaceId)) {
            return new \WP_Error('missing_credentials', __('API Key and Workspace ID are required', 'fluent-player-pro'));
        }

        try {
            $client = new Gumlet($apiKey);
            $result = $client->listAssets($workspaceId, ['offset' => 0, 'size' => 1]);

            if (is_wp_error($result)) {
                return new \WP_Error('connection_failed', __('Could not connect to Gumlet. Please check your API Key and Workspace ID.', 'fluent-player-pro'));
            }

            return true;
        } catch (\Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Error logging for debugging
                error_log('Fluent Player Gumlet connection error: ' . $e->getMessage());
            }
            return new \WP_Error('connection_error', __('Could not connect to Gumlet. Please check your credentials.', 'fluent-player-pro'));
        }
    }

    /**
     * @return Gumlet|\WP_Error
     */
    public function getClient()
    {
        if (!$this->isEnabled()) {
            return new \WP_Error('disabled', __('Gumlet integration is not enabled', 'fluent-player-pro'));
        }

        $apiKey = Arr::get($this->getSettings(), 'api_key');

        if (empty($apiKey)) {
            return new \WP_Error('missing_credentials', __('Gumlet credentials are not configured', 'fluent-player-pro'));
        }

        return new Gumlet($apiKey);
    }
}
