<?php

namespace FluentPlayerPro\App\Integrations;

if (!defined('ABSPATH')) exit;

use FluentPlayer\App\Integrations\AbstractIntegration;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Libraries\CloudflareStream;
use FluentPlayerPro\App\Services\CloudflareStreamService;

/**
 * Cloudflare Stream provider — the managed video platform (upload → transcode →
 * adaptive HLS, per-video signed delivery). Auth is only Account ID + a Cloudflare
 * API Token (Bearer); there are no S3 keys, no local signing key, and no manual
 * webhook secret:
 *  - Private delivery is a PER-VIDEO flag (requireSignedURLs); playback tokens are
 *    minted on demand via POST /stream/{uid}/token using the API token.
 *  - Captions come from Cloudflare (embedded in the HLS manifest) — nothing to toggle.
 *  - The webhook secret is issued by Cloudflare when we subscribe our webhook URL.
 */
class CloudflareStreamIntegration extends AbstractIntegration
{
    protected $integration = 'cloudflare_stream';

    protected $name = 'Cloudflare Stream';

    protected $description = 'Stream video with Cloudflare Stream — upload, adaptive HLS, and per-video signed delivery.';

    protected $logo = 'cloudflare-stream.svg';

    protected $defaultSettings = [
        'enabled'        => 'no',
        'account_id'     => '',
        'api_token'      => '',
        // Internal — issued by Cloudflare when we subscribe the webhook (not user-entered).
        'webhook_secret' => '',
    ];

    public function validateSettings($settings)
    {
        if (!Arr::isTrue($settings, 'enabled')) {
            return true;
        }

        if (empty($settings['account_id'])) {
            return new \WP_Error('missing_account_id', __('Cloudflare Account ID is required', 'fluent-player-pro'));
        }

        if (empty($settings['api_token'])) {
            return new \WP_Error('missing_api_token', __('Cloudflare API Token is required', 'fluent-player-pro'));
        }

        return true;
    }

    public function testConnection($settings = null)
    {
        $settings = $settings ?: $this->getSettings();

        if (!Arr::isTrue($settings, 'enabled')) {
            return true;
        }

        $accountId = Arr::get($settings, 'account_id');
        $apiToken  = Arr::get($settings, 'api_token');

        if (empty($accountId) || empty($apiToken)) {
            return new \WP_Error('missing_credentials', __('Account ID and API Token are required', 'fluent-player-pro'));
        }

        $client = new CloudflareStream($accountId, $apiToken);
        $result = $client->listVideos(['limit' => 1]);

        if (is_wp_error($result)) {
            return new \WP_Error('connection_failed', __('Could not connect to Cloudflare Stream. Please check your Account ID and API Token.', 'fluent-player-pro'));
        }

        return true;
    }

    /**
     * After a successful save, best-effort subscribe our webhook so transcode-ready
     * events are received; Cloudflare returns the signing secret which we persist.
     */
    public function saveSettings($settings)
    {
        $result = parent::saveSettings($settings);
        if (is_wp_error($result)) {
            return $result;
        }
        if (Arr::isTrue($settings, 'enabled')) {
            CloudflareStreamService::ensureWebhookSubscribed();
        }
        return $result;
    }

    public function getSettingsFields()
    {
        return [
            [
                'key'   => 'setup_instructions',
                'type'  => 'setup_instructions',
                'label' => __('Setup Instructions', 'fluent-player-pro'),
                'instructions' => [
                    'title' => __('Cloudflare Stream Setup Guide', 'fluent-player-pro'),
                    'steps' => [
                        [
                            'title'   => __('Step 1: Create an API Token', 'fluent-player-pro'),
                            'content' => __('In the Cloudflare dashboard: Manage Account → Account API Tokens → Create Token → give the token a name → set Policy to "Entire Account" → search for "Stream" → grant Read and Write access → create the token.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'link'    => [
                                'url'  => 'https://dash.cloudflare.com/?to=/:account/api-tokens',
                                'text' => __('Open Account API Tokens', 'fluent-player-pro'),
                            ],
                            'note'    => __('The token is shown only once — copy it now.', 'fluent-player-pro'),
                        ],
                        [
                            'title'   => __('Step 2: Paste your Account ID + API Token below', 'fluent-player-pro'),
                            'content' => __('Copy your Account ID (shown in the Stream page sidebar of the Cloudflare dashboard) and the API Token you just created, then paste both into the fields below.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'link'    => [
                                'url'  => 'https://dash.cloudflare.com/?to=/:account/stream',
                                'text' => __('Open Cloudflare Stream', 'fluent-player-pro'),
                            ],
                        ],
                    ],
                ],
            ],
            [
                'key'         => 'enabled',
                'type'        => 'checkbox',
                'label'       => __('Enable Cloudflare Stream', 'fluent-player-pro'),
                'description' => __('Enable Cloudflare Stream for video hosting and adaptive streaming', 'fluent-player-pro'),
            ],
            [
                'key'         => 'account_id',
                'type'        => 'password',
                'label'       => __('Cloudflare Account ID', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('Found on the Stream page sidebar in your Cloudflare dashboard.', 'fluent-player-pro'),
                'placeholder' => __('Enter your Account ID', 'fluent-player-pro'),
            ],
            [
                'key'         => 'api_token',
                'type'        => 'password',
                'label'       => __('Cloudflare API Token', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('An API Token with Stream Read + Edit permissions. Also used to mint playback tokens for private videos.', 'fluent-player-pro'),
                'placeholder' => __('Enter your API Token', 'fluent-player-pro'),
            ],
        ];
    }
}
