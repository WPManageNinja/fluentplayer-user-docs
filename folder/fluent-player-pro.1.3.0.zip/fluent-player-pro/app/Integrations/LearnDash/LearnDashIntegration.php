<?php

namespace FluentPlayerPro\App\Integrations\LearnDash;

use FluentPlayer\Framework\Support\Arr;

if (!defined('ABSPATH')) exit;

/**
 * Drives LearnDash video progression from a Fluent Player block.
 *
 * Behavioural integration (not an AbstractIntegration): it hooks into another
 * plugin's runtime rather than storing credentials. All LearnDash-specific
 * knowledge lives here — delete this class and every LearnDash coupling goes
 * with it.
 *
 * Completion is server-authoritative: the client flushes raw watched segments
 * to the free fluent_player_progression endpoint, which recomputes coverage and
 * fires fluent_player/watch_recorded; onWatchRecorded() marks the step complete
 * when auto-complete is on. Manual mode only unlocks LearnDash's button on the
 * client, so the learner still clicks.
 */
class LearnDashIntegration
{
    const PROVIDER = 'fluent-player';

    const STEP_POST_TYPES = ['sfwd-lessons', 'sfwd-topic'];

    const SETTING_ENABLE    = 'lesson_use_fluent_player_video';
    const SETTING_THRESHOLD = 'lesson_fluent_player_threshold';
    const SETTING_NO_SKIP   = 'lesson_fluent_player_no_skip';
    const SETTING_MAX_SPEED = 'lesson_fluent_player_max_speed';

    const DEFAULT_THRESHOLD = 90;

    // Our settings ride LearnDash's own lesson_video_url field, encoded as a
    // sentinel: (fluent-player-<threshold>-<noSkip>-<maxSpeed>). That field is
    // the one place LearnDash reliably persists (its block-editor save map is a
    // hardcoded allow-list that excludes any field added via the settings
    // filter). Presto uses the same field with its own (presto-id) tag. The
    // admin JS writes the sentinel; we read it back with learndash_get_setting.

    public function register()
    {
        // Registered late (Pro boots on fluent_player/loaded, after plugins_loaded),
        // so LearnDash is already loaded — hook directly rather than deferring.
        if (!self::isLearnDashActive()) {
            return $this;
        }

        add_filter('learndash_settings_fields', [$this, 'settingsFields'], 30, 2);
        add_filter('ld_video_provider', [$this, 'claimProvider'], 10, 2);
        add_filter('fluent_player/progression/policy', [$this, 'policyForStep'], 10, 4);
        add_filter('fluent_player/external_tracked_media', [$this, 'preventDuplicateAnalyticsView']);
        add_action('fluent_player/watch_recorded', [$this, 'onWatchRecorded'], 10, 3);
        // Footer: LearnDash registers its video script during content render —
        // enqueueing earlier declares an unregistered dep (_doing_it_wrong).
        add_action('wp_footer', [$this, 'enqueueAssets'], 5);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);

        return $this;
    }

    public static function isLearnDashActive()
    {
        return defined('LEARNDASH_VERSION');
    }

    public static function isStep($post)
    {
        return $post && in_array($post->post_type, self::STEP_POST_TYPES, true);
    }

    /**
     * Pure: does this lesson_video_url carry our sentinel?
     */
    public static function claimsProvider($lessonVideoUrl)
    {
        return is_string($lessonVideoUrl) && strpos($lessonVideoUrl, '(' . self::PROVIDER) !== false;
    }

    /**
     * Pure completion gate. The server call is scoped to auto-complete ON;
     * manual mode is a client-side button unlock only, so the instructor's
     * "require manual completion" choice is never overridden here.
     */
    public static function shouldMarkComplete(array $verdict, array $policy, array $context)
    {
        return !empty($verdict['complete'])
            && !empty($policy['autoComplete'])
            && !empty($context['step_id']);
    }

    /**
     * Encode our settings into the lesson_video_url sentinel. Keep it in sync
     * with the JS encoder in admin-settings.js and the parser below.
     */
    public static function encodeSentinel($threshold, $noSkip, $maxSpeed)
    {
        return '(' . self::PROVIDER . '-' . (int) $threshold . '-' . ($noSkip ? 1 : 0) . '-' . self::floatStr($maxSpeed) . ')';
    }

    /**
     * Parse the lesson_video_url sentinel back into our settings. A bare
     * (fluent-player) with no params counts as enabled with defaults.
     *
     * @return array{enabled: bool, threshold: int, no_skip: bool, max_speed: float}
     */
    public static function parseSentinel($url)
    {
        $out = ['enabled' => false, 'threshold' => self::DEFAULT_THRESHOLD, 'no_skip' => false, 'max_speed' => 0.0];
        if (!is_string($url) || strpos($url, '(' . self::PROVIDER) === false) {
            return $out;
        }
        $out['enabled'] = true;
        if (preg_match('/\(' . preg_quote(self::PROVIDER, '/') . '-(\d+)-([01])-([\d.]+)\)/', $url, $m)) {
            $out['threshold']  = (int) $m[1];
            $out['no_skip']    = $m[2] === '1';
            $out['max_speed']  = (float) $m[3];
        }
        return $out;
    }

    /**
     * Format a speed as a compact string: 0 → "0", 1.5 → "1.5", 2 → "2".
     */
    public static function floatStr($value)
    {
        $value = (float) $value;
        return rtrim(rtrim(sprintf('%.2f', $value), '0'), '.');
    }

    public function claimProvider($provider, $stepSettings)
    {
        $url = isset($stepSettings['lesson_video_url']) ? $stepSettings['lesson_video_url'] : '';
        return self::claimsProvider($url) ? self::PROVIDER : $provider;
    }

    /**
     * Pure reads over a step's settings array (keyed by the SETTING_*
     * constants), as built by ourSettings().
     */
    public static function isEngaged(array $ldSettings)
    {
        return isset($ldSettings[self::SETTING_ENABLE]) && $ldSettings[self::SETTING_ENABLE] === 'on';
    }

    public static function threshold(array $ldSettings)
    {
        $pct = (isset($ldSettings[self::SETTING_THRESHOLD]) && $ldSettings[self::SETTING_THRESHOLD] !== '')
            ? (float) $ldSettings[self::SETTING_THRESHOLD]
            : (float) self::DEFAULT_THRESHOLD;
        $pct = max(1.0, min($pct, 100.0));
        return $pct / 100.0;
    }

    public static function noSkip(array $ldSettings)
    {
        return isset($ldSettings[self::SETTING_NO_SKIP]) && $ldSettings[self::SETTING_NO_SKIP] === 'on';
    }

    public static function maxSpeed(array $ldSettings)
    {
        $speed = isset($ldSettings[self::SETTING_MAX_SPEED]) ? (float) $ldSettings[self::SETTING_MAX_SPEED] : 0.0;
        return $speed > 0 ? $speed : 0.0; // 0 = no cap
    }

    /**
     * Add the Fluent Player progression controls under LearnDash's Video
     * Progression section — an explicit toggle (like Presto's) whose help text
     * names the detected video, plus threshold and anti-gaming controls.
     */
    public function settingsFields($fields, $metaBoxKey)
    {
        if (!in_array($metaBoxKey, ['learndash-lesson-display-content-settings', 'learndash-topic-display-content-settings'], true)) {
            return $fields;
        }

        // LearnDash renders each field from its 'value' (loaded before this
        // filter runs), so we must seed 'value' from the saved setting — else
        // the toggle always shows off and its child fields stay hidden.
        $post = get_post();
        if (!self::isStep($post) && isset($_GET['post'])) {
            $post = get_post(absint($_GET['post'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        }
        $saved = self::isStep($post) ? self::ourSettings($post->ID) : [];
        $savedVal = function ($key, $default = '') use ($saved) {
            return (isset($saved[$key]) && $saved[$key] !== '') ? $saved[$key] : $default;
        };

        $detected = $this->detectedVideoTitle();
        $enableHelp = $detected
            ? sprintf(
                /* translators: %s: detected Fluent Player video title */
                esc_html__('The Fluent Player video "%s" in this lesson will drive progression — watched coverage is verified on the server.', 'fluent-player-pro'),
                $detected
            )
            : esc_html__('Add a Fluent Player block to this lesson, then enable this to drive progression from it.', 'fluent-player-pro');

        $ours = [
            self::SETTING_ENABLE => [
                'name'           => self::SETTING_ENABLE,
                'label'          => esc_html__('Use Fluent Player Video', 'fluent-player-pro'),
                'type'           => 'checkbox-switch',
                'help_text'      => $enableHelp,
                'default'        => '',
                'value'          => $savedVal(self::SETTING_ENABLE),
                'child_section_state' => self::isEngaged($saved) ? 'open' : 'closed',
                'options'        => [
                    'on' => esc_html__('The Fluent Player video in this lesson will be used for progression.', 'fluent-player-pro'),
                    ''   => '',
                ],
                // Sits under LearnDash's Video Progression (like Presto's "Use
                // Presto Video"). Our settings persist in lesson_video_url, which
                // LearnDash only keeps while Video Progression is on — so this
                // belongs inside that section, not above it.
                'parent_setting' => 'lesson_video_enabled',
            ],
            self::SETTING_THRESHOLD => [
                'name'           => self::SETTING_THRESHOLD,
                'label'          => esc_html__('Required watched %', 'fluent-player-pro'),
                'type'           => 'select',
                'help_text'      => esc_html__('How much distinct coverage must be watched to complete. Seeking to the end will not satisfy it.', 'fluent-player-pro'),
                'default'        => (string) self::DEFAULT_THRESHOLD,
                'value'          => $savedVal(self::SETTING_THRESHOLD, (string) self::DEFAULT_THRESHOLD),
                'options'        => ['50' => '50%', '75' => '75%', '80' => '80%', '90' => '90%', '95' => '95%', '100' => '100%'],
                'parent_setting' => self::SETTING_ENABLE,
            ],
            self::SETTING_NO_SKIP => [
                'name'           => self::SETTING_NO_SKIP,
                'label'          => esc_html__('Prevent skipping ahead', 'fluent-player-pro'),
                'type'           => 'checkbox-switch',
                'help_text'      => esc_html__('Learners cannot seek past what they have watched. Completion stays server-verified regardless.', 'fluent-player-pro'),
                'default'        => '',
                'value'          => $savedVal(self::SETTING_NO_SKIP),
                'options'        => [
                    'on' => esc_html__('Disable seeking ahead of watched content.', 'fluent-player-pro'),
                    ''   => '',
                ],
                'parent_setting' => self::SETTING_ENABLE,
            ],
            self::SETTING_MAX_SPEED => [
                'name'           => self::SETTING_MAX_SPEED,
                'label'          => esc_html__('Maximum playback speed', 'fluent-player-pro'),
                'type'           => 'select',
                'help_text'      => esc_html__('Cap playback speed so learners cannot rush the video.', 'fluent-player-pro'),
                'default'        => '0',
                'value'          => $savedVal(self::SETTING_MAX_SPEED, '0'),
                'options'        => ['0' => esc_html__('No limit', 'fluent-player-pro'), '1' => '1×', '1.5' => '1.5×', '2' => '2×'],
                'parent_setting' => self::SETTING_ENABLE,
            ],
        ];

        return self::arrayInsertBefore($fields, $ours, 'lesson_video_url');
    }

    public static function arrayInsertBefore(array $array, array $insert, $beforeKey)
    {
        if (!array_key_exists($beforeKey, $array)) {
            return array_merge($array, $insert);
        }
        $result = [];
        foreach ($array as $key => $val) {
            if ($key === $beforeKey) {
                foreach ($insert as $ik => $iv) {
                    $result[$ik] = $iv;
                }
            }
            $result[$key] = $val;
        }
        return $result;
    }

    protected function detectedVideoTitle()
    {
        $post = get_post();
        // On the edit screen global $post is not always the lesson while the
        // metabox fields are being built; fall back to the edited post id.
        if (!self::isStep($post) && isset($_GET['post'])) {
            $post = get_post(absint($_GET['post'])); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        }
        if (!self::isStep($post)) {
            return '';
        }
        $mediaId = $this->findMediaId($post);
        return $mediaId ? get_the_title($mediaId) : '';
    }

    /**
     * Find the Fluent Player media id embedded in a step's content.
     */
    public function findMediaId($post)
    {
        static $cache = [];
        if (!$post) {
            return 0;
        }
        $id = is_object($post) ? (int) $post->ID : (int) $post;
        if (array_key_exists($id, $cache)) {
            return $cache[$id];
        }

        $found = 0;
        if (!empty($post->post_content) && has_block('fluent-player/media', $post)) {
            foreach (parse_blocks($post->post_content) as $block) {
                if (($block['blockName'] ?? '') === 'fluent-player/media') {
                    $found = absint($block['attrs']['mediaId'] ?? 0);
                    break;
                }
            }
        }
        return $cache[$id] = $found;
    }

    /**
     * Map the LearnDash step's own settings onto the progression policy:
     * auto-complete comes from LearnDash; the coverage threshold is ours.
     */
    public function policyForStep($policy, $mediaId, $userId, $context)
    {
        $stepId = absint($context['step_id'] ?? 0);
        if (!$stepId || !function_exists('learndash_get_setting')) {
            return $policy;
        }

        $step = get_post($stepId);
        if (!self::isStep($step)) {
            return $policy;
        }

        $our = self::ourSettings($stepId);
        if (!self::isEngaged($our)) {
            return $policy;
        }

        $ldSettings = (array) learndash_get_setting($step);
        $policy['threshold'] = self::threshold($our);
        $policy['autoComplete'] = !empty($ldSettings['lesson_video_auto_complete'])
            && $ldSettings['lesson_video_auto_complete'] === 'on';
        // Accumulate watched coverage across sessions so a learner can finish a
        // lesson video over multiple sittings without re-watching from scratch.
        $policy['accumulate'] = true;

        return $policy;
    }

    /**
     * Enqueue the client adapter on a LearnDash step that embeds a Fluent
     * Player block. Depends on LearnDash's own video script so the localized
     * learndash_video_data (provider, cookie key) is present when we run.
     */
    public function enqueueAssets()
    {
        if (!is_singular(self::STEP_POST_TYPES)) {
            return;
        }

        // The progression endpoint is login-only, so a guest would get the adapter,
        // have Mark Complete disabled, then never unlock it (every flush 401s). Skip
        // entirely for guests — completion is per-user and meaningless without one.
        if (!is_user_logged_in()) {
            return;
        }

        // Absent = LearnDash didn't engage video progression for this step;
        // the adapter would be inert, so skip instead of declaring a missing dep.
        if (!wp_script_is('learndash_video_script_js', 'registered')) {
            return;
        }

        $post = get_post();
        $mediaId = $this->findMediaId($post);
        if (!$mediaId) {
            return;
        }

        $our = self::ourSettings($post->ID);
        if (!self::isEngaged($our)) {
            return;
        }

        $courseId = function_exists('learndash_get_course_id') ? absint(learndash_get_course_id($post->ID)) : 0;
        $ldSettings = function_exists('learndash_get_setting') ? (array) learndash_get_setting($post) : [];
        $autoComplete = (!empty($ldSettings['lesson_video_auto_complete']) && $ldSettings['lesson_video_auto_complete'] === 'on');

        wp_enqueue_script(
            'fluent-player-learndash',
            FLUENT_PLAYER_PRO_URL . 'app/Integrations/LearnDash/assets/progression.js',
            ['learndash_video_script_js'],
            FLUENT_PLAYER_PRO_VERSION,
            true
        );

        wp_localize_script('fluent-player-learndash', 'fluentPlayerLearnDash', [
            'ajaxUrl'       => admin_url('admin-ajax.php'),
            'nonce'         => wp_create_nonce('fluent_player_frontend'),
            'mediaId'       => $mediaId,
            'courseId'      => $courseId,
            'stepId'        => (int) $post->ID,
            'noSkip'        => self::noSkip($our) ? 1 : 0,
            'maxSpeed'      => self::maxSpeed($our),
            'autoComplete'  => $autoComplete ? 1 : 0,
        ]);
    }

    /**
     * Stop this lesson's video from being counted twice in analytics.
     *
     * On a LearnDash lesson we track watching two different ways:
     *   1. The progression tracker (this integration) — sends the watched
     *      segments to the server for completion, and that same flow ALSO saves
     *      an analytics view for the watch (via WatchProgressBridge).
     *   2. The free player's own analytics beacon — the normal way every Fluent
     *      Player video reports a view.
     *
     * If both ran, one watch of one video would be recorded as two views. So we
     * add this video's id to the "already tracked elsewhere" list the free
     * player reads, and it skips its own beacon for this video. Analytics still
     * gets the view — just once, from the progression flow.
     *
     * @param int[] $mediaIds ids other flows already report; we append ours.
     * @return int[]
     */
    public function preventDuplicateAnalyticsView($mediaIds)
    {
        if (!is_singular(self::STEP_POST_TYPES)) {
            return $mediaIds;
        }

        $post = get_post();
        $mediaId = $this->findMediaId($post);
        if (!$mediaId || !self::isEngaged(self::ourSettings($post->ID))) {
            return $mediaIds;
        }

        $mediaIds[] = $mediaId;
        return $mediaIds;
    }

    /**
     * On the lesson/topic edit screen, hide LearnDash's own video-progression
     * controls that only drive its native player once "Use Fluent Player Video"
     * is on — they don't affect the Fluent Player video.
     */
    public function enqueueAdminAssets($hook)
    {
        if ($hook !== 'post.php' && $hook !== 'post-new.php') {
            return;
        }

        $screen = get_current_screen();
        if (!$screen || !in_array($screen->post_type, self::STEP_POST_TYPES, true)) {
            return;
        }

        wp_enqueue_script(
            'fluent-player-learndash-admin',
            FLUENT_PLAYER_PRO_URL . 'app/Integrations/LearnDash/assets/admin-settings.js',
            [],
            FLUENT_PLAYER_PRO_VERSION,
            true
        );
    }

    /**
     * Our four settings, keyed by the SETTING_* names the read helpers expect,
     * decoded from LearnDash's own lesson_video_url sentinel (the field LD
     * reliably persists). Written by admin-settings.js.
     */
    public static function ourSettings($stepId)
    {
        $step = get_post((int) $stepId);
        if (!self::isStep($step) || !function_exists('learndash_get_setting')) {
            return [self::SETTING_ENABLE => '', self::SETTING_THRESHOLD => '', self::SETTING_NO_SKIP => '', self::SETTING_MAX_SPEED => ''];
        }

        $url = (string) Arr::get((array) learndash_get_setting($step), 'lesson_video_url', '');
        $p = self::parseSentinel($url);

        return [
            self::SETTING_ENABLE    => $p['enabled'] ? 'on' : '',
            self::SETTING_THRESHOLD => (string) $p['threshold'],
            self::SETTING_NO_SKIP   => $p['no_skip'] ? 'on' : '',
            self::SETTING_MAX_SPEED => self::floatStr($p['max_speed']),
        ];
    }

    /**
     * Server-authoritative completion. Only marks complete for auto-complete
     * steps; defers all gating (prerequisites, quizzes) to LearnDash itself.
     */
    public function onWatchRecorded($mediaId, $userId, $payload)
    {
        $context = Arr::get($payload, 'context', []);
        $verdict = Arr::get($payload, 'verdict', []);
        $policy  = Arr::get($payload, 'policy', []);

        if (!self::shouldMarkComplete($verdict, $policy, $context)) {
            return;
        }

        // Server-authoritative completion must rest on a server-owned duration.
        // A client-supplied one lets a learner forge coverage=1 (see
        // ProgressionService::pickDuration); never auto-complete on it.
        if (Arr::get($payload, 'durationSource') !== 'server') {
            return;
        }

        $stepId = absint(Arr::get($context, 'step_id'));
        $courseId = absint(Arr::get($context, 'course_id', 0));

        if (function_exists('sfwd_lms_has_access') && !sfwd_lms_has_access($courseId, $userId)) {
            return;
        }

        if (function_exists('learndash_process_mark_complete')) {
            learndash_process_mark_complete($userId, $stepId, false, $courseId);
            do_action('fluent_player/learndash/completed', $userId, $stepId, $courseId, $payload);
        }
    }
}
