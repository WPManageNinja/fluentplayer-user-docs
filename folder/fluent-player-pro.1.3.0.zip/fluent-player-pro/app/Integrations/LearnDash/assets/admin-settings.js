/**
 * Fluent Player → LearnDash lesson/topic settings screen.
 *
 * Persistence rides LearnDash's OWN fields — the only ones LearnDash reliably
 * saves (its block-editor save map is a hardcoded allow-list that drops any
 * field added via the settings filter, exactly as Presto works around). When
 * our controls change we encode them into LearnDash's `lesson_video_url` as a
 * sentinel — (fluent-player-<threshold>-<noSkip>-<maxSpeed>) — and force
 * `lesson_video_enabled` on (LearnDash blanks the URL on save otherwise). PHP
 * reads it back with learndash_get_setting(). We also hide LearnDash's native
 * video controls while our feature is on, since they drive its player, not ours.
 */
(function () {
    if (typeof document === 'undefined') return;

    var CONTEXTS = ['lesson', 'topic'];
    var ENABLE = 'lesson_use_fluent_player_video';
    var THRESHOLD = 'lesson_fluent_player_threshold';
    var NO_SKIP = 'lesson_fluent_player_no_skip';
    var MAX_SPEED = 'lesson_fluent_player_max_speed';
    var OURS = [ENABLE, THRESHOLD, NO_SKIP, MAX_SPEED];
    var OUR_SUBFIELDS = [THRESHOLD, NO_SKIP, MAX_SPEED];

    // LearnDash-native fields we drive.
    var LD_URL = 'lesson_video_url';
    var LD_VIDEO_ENABLED = 'lesson_video_enabled';
    // Native video controls that only steer LearnDash's own player.
    var INERT = [LD_URL, 'lesson_video_auto_start', 'lesson_video_show_controls', 'lesson_video_focus_pause', 'lesson_video_track_time'];

    function prefix(ctx) {
        return 'learndash-' + ctx + '-display-content-settings_';
    }
    function el(ctx, key) {
        return document.getElementById(prefix(ctx) + key);
    }
    function fieldRow(ctx, key) {
        return document.getElementById(prefix(ctx) + key + '_field');
    }

    // Compact speed: 0 → "0", 1.5 → "1.5", 2 → "2". Mirrors floatStr() in PHP.
    function speedStr(v) {
        var n = parseFloat(v) || 0;
        return String(n);
    }
    function encode(threshold, noSkip, maxSpeed) {
        return '(fluent-player-' + (parseInt(threshold, 10) || 90) + '-' + (noSkip ? 1 : 0) + '-' + speedStr(maxSpeed) + ')';
    }

    function setNative(input, value) {
        if (!input) return;
        input.value = value;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
    }
    function setNativeChecked(input, checked) {
        if (!input || input.checked === checked) return;
        input.checked = checked;
        input.dispatchEvent(new Event('change', { bubbles: true }));
    }

    // Show our sub-settings only when the feature is on (LearnDash's parent/child
    // JS won't reveal them for a custom parent), and hide LearnDash's native video
    // controls while ours is on.
    function syncVisibility(ctx) {
        var toggle = el(ctx, ENABLE);
        if (!toggle) return;
        var on = toggle.checked;
        INERT.forEach(function (key) {
            var row = fieldRow(ctx, key);
            if (row) row.style.display = on ? 'none' : '';
        });
        OUR_SUBFIELDS.forEach(function (key) {
            var row = fieldRow(ctx, key);
            if (row) row.style.display = on ? '' : 'none';
        });
    }

    // Encode our controls into LearnDash's own fields so LearnDash saves them.
    function persist(ctx) {
        var enable = el(ctx, ENABLE);
        if (!enable) return;
        var urlField = el(ctx, LD_URL);
        var videoEnabled = el(ctx, LD_VIDEO_ENABLED);

        if (enable.checked) {
            var threshold = el(ctx, THRESHOLD);
            var noSkip = el(ctx, NO_SKIP);
            var maxSpeed = el(ctx, MAX_SPEED);
            // LearnDash blanks lesson_video_url on save unless video progression is on.
            setNativeChecked(videoEnabled, true);
            setNative(urlField, encode(
                threshold ? threshold.value : 90,
                noSkip && noSkip.checked,
                maxSpeed ? maxSpeed.value : 0
            ));
        } else if (urlField && urlField.value.indexOf('(fluent-player') !== -1) {
            // Only clear when the URL is ours — never wipe a real LearnDash video.
            setNative(urlField, '');
        }
    }

    function init() {
        CONTEXTS.forEach(function (ctx) {
            var toggle = el(ctx, ENABLE);
            if (!toggle) return;
            syncVisibility(ctx);
            OURS.forEach(function (key) {
                var f = el(ctx, key);
                if (f) f.addEventListener('change', function () { persist(ctx); syncVisibility(ctx); });
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
