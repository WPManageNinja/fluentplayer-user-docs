/**
 * Fluent Player → LearnDash video progression (client adapter).
 *
 * Runs only on a LearnDash step whose video provider resolved to
 * 'fluent-player'. Tracks raw watched intervals off the Vidstack <media-player>
 * DOM events and flushes them to the server, which is authoritative: it merges,
 * clamps against the real duration, recomputes coverage and returns the verdict.
 * On a complete verdict we unlock LearnDash's Mark Complete button.
 *
 * Fail-open: if the adapter cannot attach, it re-enables LearnDash's button
 * rather than leaving the learner trapped. Every LearnDash global is guarded.
 *
 * createProgressionTracker is dependency-injected (flush) and exported for
 * unit tests; the browser bootstrap at the bottom wires the real fetch/unlock.
 */
(function (root) {
    function createProgressionTracker(player, opts) {
        var flush = opts.flush;
        var segments = [];
        var startTime = null;
        var lastTime = 0;
        var seekPending = false;
        var completed = false;
        var flushing = false;

        function now() { return Number(player.currentTime) || 0; }
        function total() { return Number(player.duration) || 0; }

        function markSegment(forcedEnd) {
            if (startTime === null) return;
            var end = (typeof forcedEnd === 'number') ? forcedEnd : now();
            if (end > startTime) {
                segments.push({ start: startTime, end: end });
            }
            startTime = end;
        }

        function trigger(isEnded) {
            if (flushing || completed || !segments.length) return;
            flushing = true;
            flush(
                { segments: segments.slice(), duration: total(), ended: !!isEnded },
                function done(isComplete) {
                    flushing = false;
                    if (isComplete) completed = true;
                }
            );
        }

        player.addEventListener('play', function () { startTime = now(); lastTime = startTime; });
        player.addEventListener('time-update', function () { if (!seekPending) lastTime = now(); });
        player.addEventListener('seeking', function () {
            // currentTime already reports the seek TARGET here (HTMLMediaElement
            // spec) — closing at now() would credit the jumped-over span as watched.
            markSegment(lastTime);
            startTime = null;
            seekPending = true;
        });
        player.addEventListener('seeked', function () {
            seekPending = false;
            startTime = now();
            lastTime = startTime;
        });
        player.addEventListener('pause', function () { markSegment(); trigger(false); });
        player.addEventListener('ended', function () {
            // Some providers (notably YouTube via Vidstack) report currentTime as 0
            // at 'ended', which would drop the final watched chunk and leave coverage
            // below threshold. Close the segment at the real duration instead.
            var dur = total();
            markSegment(dur > 0 ? dur : now());
            trigger(true);
        });

        return {
            markSegment: markSegment,
            trigger: trigger,
            getSegments: function () { return segments; },
            isCompleted: function () { return completed; }
        };
    }

    // Pure enforcement helpers (unit-tested). A forward seek past the furthest
    // watched point is snapped back; a playback rate above the cap is lowered.
    function clampSeek(target, maxAllowed, tolerance) {
        return target > maxAllowed + (tolerance || 0) ? maxAllowed : target;
    }
    function clampSpeed(rate, maxSpeed) {
        return (maxSpeed > 0 && rate > maxSpeed) ? maxSpeed : rate;
    }

    // Anti-gaming enforcement, layered on the server's authoritative coverage
    // check — client-side only, purely UX. Completion is never decided here.
    function enforcePlaybackRules(player, opts) {
        var maxAllowed = 0;
        var seeking = false;
        var cur = function () { return Number(player.currentTime) || 0; };

        if (opts.noSkip) {
            player.addEventListener('seeking', function () { seeking = true; });
            player.addEventListener('time-update', function () {
                if (!seeking) { var t = cur(); if (t > maxAllowed) maxAllowed = t; }
            });
            player.addEventListener('seeked', function () {
                var t = cur();
                var clamped = clampSeek(t, maxAllowed, 1);
                if (clamped < t) { try { player.currentTime = clamped; } catch (e) {} }
                seeking = false;
            });
        }

        if (opts.maxSpeed > 0) {
            var applyCap = function () {
                var r = Number(player.playbackRate) || 1;
                var clamped = clampSpeed(r, opts.maxSpeed);
                if (clamped !== r) { try { player.playbackRate = clamped; } catch (e) {} }
            };
            player.addEventListener('rate-change', applyCap);
            player.addEventListener('ratechange', applyCap);
            player.addEventListener('play', applyCap);
            applyCap();
        }
    }

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = {
            createProgressionTracker: createProgressionTracker,
            clampSeek: clampSeek,
            clampSpeed: clampSpeed
        };
    }
    root.__fluentPlayerCreateProgressionTracker = createProgressionTracker;
    root.__fluentPlayerClampSeek = clampSeek;
    root.__fluentPlayerClampSpeed = clampSpeed;

    // ---- Browser bootstrap ----
    if (typeof window === 'undefined' || typeof document === 'undefined') return;

    var cfg = window.fluentPlayerLearnDash;
    var ld = window.learndash_video_data;
    if (!cfg || !ld || ld.videos_found_provider !== 'fluent-player') return;

    // LearnDash's localized flag defaults TRUE in BEFORE mode (the instructor's
    // setting is only read in AFTER mode), and watchPlayersEnd() auto-submits
    // Mark Complete whenever it is truthy — overwrite with the real setting.
    ld.videos_auto_complete = Number(cfg.autoComplete) ? true : false;

    // Unlock WITHOUT watchPlayersEnd() — that signals "video finished" and
    // would auto-complete the lesson unwatched (admin bypass, fail-open).
    function unlockButton() {
        try {
            if (typeof window.LearnDash_disable_assets === 'function') window.LearnDash_disable_assets(false);
        } catch (e) { /* fail-open: never trap the learner */ }
    }

    function signalVideoComplete() {
        unlockButton();
        try {
            if (typeof window.LearnDash_watchPlayersEnd === 'function') window.LearnDash_watchPlayersEnd();
        } catch (e) { /* fail-open */ }
    }

    // LearnDash exempts admins (video_admin_bypass): let them navigate and
    // complete freely — no watch tracking, no seek clamp, no speed cap. Just
    // keep the button open so they are never blocked.
    if (ld.video_admin_bypass) {
        unlockButton();
        return;
    }

    function throttle(fn, wait) {
        var last = 0;
        return function () { var t = Date.now(); if (t - last >= wait) { last = t; fn(); } };
    }

    var reflected = false;

    function realFlush(payload, done) {
        var body = new FormData();
        body.append('action', 'fluent_player_progression');
        body.append('nonce', cfg.nonce);
        body.append('media_id', cfg.mediaId);
        body.append('course_id', cfg.courseId);
        body.append('step_id', cfg.stepId);
        body.append('duration', payload.duration);
        body.append('ended', payload.ended ? '1' : '0');
        body.append('segments', JSON.stringify(payload.segments));

        var settled = false;
        var finish = function (complete) {
            if (settled) return;
            settled = true;
            done(complete);
        };
        // Fail-open: a hung request must not wedge `flushing` true forever, or
        // the completing flush could never retry and the button never unlocks.
        var timer = setTimeout(function () { finish(false); }, 10000);

        // keepalive lets the request survive a page navigation / tab close, so a
        // flush fired on leave still reaches the server.
        fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', keepalive: true, body: body })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                clearTimeout(timer);
                var complete = !!(res && res.success && res.data && res.data.verdict && res.data.verdict.complete);
                finish(complete);
                if (complete) {
                    // Manual mode only unlocks — the learner still clicks.
                    if (Number(cfg.autoComplete)) {
                        signalVideoComplete();
                        // Reflect completion in the UI once the video has
                        // actually finished (don't interrupt mid-watch).
                        if (payload.ended && !reflected) {
                            reflected = true;
                            window.location.reload();
                        }
                    } else {
                        unlockButton();
                    }
                }
            })
            .catch(function () { clearTimeout(timer); finish(false); });
    }

    try {
        var players = document.querySelectorAll('.fluent-player media-player');
        if (!players.length) { unlockButton(); return; }

        // A lesson can hold several Fluent Player blocks; only the media tied to
        // this step's progression (cfg.mediaId) should report, or coverage for
        // one video would be credited from watching another.
        var trackers = [];
        Array.prototype.forEach.call(players, function (player) {
            var host = player.closest('[data-media-id]');
            if (!host || String(host.getAttribute('data-media-id')) !== String(cfg.mediaId)) {
                return;
            }
            var tracker = createProgressionTracker(player, { flush: realFlush });
            trackers.push(tracker);
            // Server-authoritative heartbeat: while THIS progression video is
            // actually playing, flush at most every 15s. time-update only fires
            // during playback and we're scoped to cfg.mediaId above, so requests
            // go out only for the video being watched — never other players on
            // the page. The paused guard is belt-and-suspenders. Terminal flushes
            // (pause / ended / tab-leave) catch the tail, so a slow heartbeat
            // loses nothing while cutting request volume ~3x vs 5s.
            player.addEventListener('time-update', throttle(function () {
                if (player.paused) { return; }
                tracker.markSegment();
                tracker.trigger(false);
            }, 15000));
            enforcePlaybackRules(player, { noSkip: !!Number(cfg.noSkip), maxSpeed: Number(cfg.maxSpeed) || 0 });
        });

        // Fail-open: the progression media isn't on the page → don't trap the learner.
        if (!trackers.length) { unlockButton(); return; }

        // LearnDash leaves gating to the provider bridge: disable up front,
        // re-enable on completion — without this nothing is ever gated.
        try {
            if (typeof window.LearnDash_disable_assets === 'function') window.LearnDash_disable_assets(true);
        } catch (e) { /* fail-open */ }

        // Flush the accumulated coverage when the learner backgrounds or leaves the
        // tab, so watching enough completes even without playing to the last frame.
        var flushOnLeave = function () {
            trackers.forEach(function (t) { t.markSegment(); t.trigger(false); });
        };
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'hidden') { flushOnLeave(); }
        });
        window.addEventListener('pagehide', flushOnLeave);
    } catch (e) {
        unlockButton();
    }
})(typeof window !== 'undefined' ? window : globalThis);
