<?php

namespace FluentPlayerPro\App\Integrations;

use FluentPlayer\App\Integrations\AbstractIntegration;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Libraries\BunnyCDN;

class BunnyCDNStreamIntegration extends AbstractIntegration
{
    /**
     * Integration identifier
     * @var string
     */
    protected $integration = 'bunnycdn_stream';

    /**
     * Integration display name
     * @var string
     */
    protected $name = 'Bunny Stream';

    /**
     * Integration description
     * @var string
     */
    protected $description = 'Connect to Bunny Stream for video hosting and streaming with global CDN delivery.';

    /**
     * Integration icon
     * @var string
     */
    protected $logo = 'bunnycdn.svg';

    /**
     * Default settings
     * @var array
     */
    protected $defaultSettings = [
        'enabled' => false,
        'api_key' => '',
        'library_id' => '',
        'libraries' => []
    ];

    /**
     * Validate settings before saving
     * @param array $settings
     * @return bool|\WP_Error
     */
    public function validateSettings($settings)
    {
        if (Arr::isTrue($settings, 'enabled')) {
            if (empty($settings['api_key'])) {
                return new \WP_Error('missing_api_key', __('API Key is required', 'fluent-player-pro'));
            }
        }

        return true;
    }

    /**
     * Get integration settings fields configuration
     * @return array
     */
    public function getSettingsFields()
    {
        return [
            [
                'key' => 'setup_instructions',
                'type' => 'setup_instructions',
                'label' => __('Setup Instructions', 'fluent-player-pro'),
                'instructions' => [
                    'title' => __('BunnyCDN Stream Setup Guide', 'fluent-player-pro'),
                    'steps' => [
                        [
                            'title' => __('Step 1: Create BunnyCDN Account', 'fluent-player-pro'),
                            'content' => __('If you don\'t have a BunnyCDN account yet, visit the BunnyCDN website and create a new account.', 'fluent-player-pro'),
                            'type' => 'text',
                            'link' => [
                                'url' => 'https://bunny.net',
                                'text' => __('Visit BunnyCDN', 'fluent-player-pro')
                            ]
                        ],
                        [
                            'title' => __('Step 2: Access Account Settings', 'fluent-player-pro'),
                            'content' => __('Once logged in, navigate to your account settings to find the API section.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('Click on profile icon of the top left and select Account Settings then API Key from the menu in your BunnyCDN dashboard.', 'fluent-player-pro'),
                            'link' => [
                                'url' => 'https://dash.bunny.net/account/api-key',
                                'text' => __('Get API Key', 'fluent-player-pro')
                            ]
                        ],
                        [
                            'title' => __('Step 3: Copy API Key', 'fluent-player-pro'),
                            'content' => __('In the API section, generate a new API key or copy your existing one. This key will be used to authenticate API requests.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('Keep this API key secure and never share it publicly.', 'fluent-player-pro')
                        ],
                        [
                            'title' => __('Step 4: Create Stream Library', 'fluent-player-pro'),
                            'content' => __('Create a new Stream library in your BunnyCDN dashboard if you haven\'t already. This is where your videos will be stored.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('You can create multiple libraries for different projects or purposes.', 'fluent-player-pro')
                        ],
                        [
                            'title' => __('Step 5: Configure Integration', 'fluent-player-pro'),
                            'content' => __('Enter your API key in the field below and enable the integration. The system will automatically test the connection.', 'fluent-player-pro'),
                            'type' => 'text'
                        ],
                        [
                            'title' => __('Step 6: Secure Your Videos (Optional)', 'fluent-player-pro'),
                            'content' => __('To protect your videos with signed URLs, enable Token Authentication on your Stream library in the BunnyCDN dashboard. FluentPlayer will automatically sign all video requests.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('Go to Stream → Your Library → Security → Enable "Token Authentication".', 'fluent-player-pro')
                        ],
                        [
                            'title' => __('Step 7: Configure Allowed Referrers', 'fluent-player-pro'),
                            'content' => __('If you enable "Block None Referrer" on your Stream library, you must add your website domain to the Allowed Referrers list, otherwise all video requests will be blocked.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('Go to Stream → Your Library → Security → Allowed Referrers → Add your domain (e.g., yourdomain.com).', 'fluent-player-pro')
                        ],
                        [
                            'title' => __('Step 8: Test Connection', 'fluent-player-pro'),
                            'content' => __('After saving your settings, use the "Test Connection" button to verify that the integration is working correctly.', 'fluent-player-pro'),
                            'type' => 'text'
                        ],
                    ]
                ]
            ],
            [
                'key' => 'enabled',
                'type' => 'checkbox',
                'label' => __('Enable BunnyCDN Stream', 'fluent-player-pro'),
                'description' => __('Enable BunnyCDN Stream integration for video hosting', 'fluent-player-pro')
            ],
            [
                'key' => 'api_key',
                'type' => 'password',
                'label' => __('API Key', 'fluent-player-pro'),
                'required' => true,
                'description' => __('Your BunnyCDN API key from the account settings', 'fluent-player-pro'),
                'placeholder' => __('Enter your BunnyCDN API key', 'fluent-player-pro')
            ]
        ];
    }

    /**
     * Test connection with provided settings
     * @param array $settings Optional settings to test
     * @return bool|\WP_Error
     */
    public function testConnection($settings = null)
    {
        $settings = $settings ?: $this->getSettings();

        // Skip test if not enabled
        if (!Arr::get($settings, 'enabled')) {
            return true;
        }

        $apiKey = Arr::get($settings, 'api_key');
        if (empty($apiKey)) {
            return new \WP_Error('missing_api_key', __('API Key is required', 'fluent-player-pro'));
        }

        try {
            $bunnycdn = new BunnyCDN($apiKey);
            $isValid = $bunnycdn->testApiKey();

            if (!$isValid) {
                return new \WP_Error('invalid_api_key', __('Invalid API key. Please check your BunnyCDN credentials.', 'fluent-player-pro'));
            }

            return true;
        } catch (\Exception $e) {
            return new \WP_Error('connection_error', $e->getMessage());
        }
    }

    /**
     * Handle integration-specific actions
     * @param string $action
     * @param array $data
     * @return mixed
     */
    public function handleAction($action, $data = [])
    {
        if (!$this->isEnabled()) {
            return new \WP_Error('integration_disabled', __('BunnyCDN Stream integration is not enabled', 'fluent-player-pro'));
        }

        $settings = $this->getSettings();
        $apiKey = Arr::get($settings, 'api_key');

        if (empty($apiKey)) {
            return new \WP_Error('missing_api_key', __('API Key is not configured', 'fluent-player-pro'));
        }

        $client = new BunnyCDN($apiKey);

        switch ($action) {
            case 'libraries':
                return $this->getLibraries($client);

            case 'videos':
                $libraryId = Arr::get($data, 'library_id', $settings['library_id']);
                return $this->getVideos($client, $libraryId, $data);

            case 'video':
                $libraryId = Arr::get($data, 'library_id', $settings['library_id']);
                $videoId = Arr::get($data, 'video_id');
                return $this->getVideo($client, $libraryId, $videoId);

            case 'upload':
                $libraryId = Arr::get($data, 'library_id', $settings['library_id']);
                $fileData = Arr::get($data, 'file');
                $title = Arr::get($data, 'title');
                return $this->uploadVideo($client, $libraryId, $fileData, $title);

            case 'delete':
                $libraryId = Arr::get($data, 'library_id', $settings['library_id']);
                $videoId = Arr::get($data, 'video_id');
                return $this->deleteVideo($client, $libraryId, $videoId);

            case 'update':
                $libraryId = Arr::get($data, 'library_id', $settings['library_id']);
                $videoId = Arr::get($data, 'video_id');
                $videoData = Arr::get($data, 'video_data', []);
                return $this->updateVideo($client, $libraryId, $videoId, $videoData);

            case 'create_video':
                $libraryId = Arr::get($data, 'library_id', $settings['library_id']);
                $videoData = Arr::get($data, 'video_data', []);
                return $this->createVideo($client, $libraryId, $videoData);
        }

        return new \WP_Error('invalid_action', __('Invalid action', 'fluent-player-pro'));
    }

    /**
     * Get BunnyCDN client instance
     * @return BunnyCDN|\WP_Error
     */
    public function getClient()
    {
        if (!$this->isEnabled()) {
            return new \WP_Error('disabled', __('BunnyCDN Stream integration is not enabled', 'fluent-player-pro'));
        }

        $settings = $this->getSettings();
        $apiKey = Arr::get($settings, 'api_key');

        if (empty($apiKey)) {
            return new \WP_Error('missing_api_key', __('API Key is not configured', 'fluent-player-pro'));
        }

        return new BunnyCDN($apiKey);
    }

    /**
     * Get library API key from stored settings
     * @param string $libraryId
     * @param array $libraries
     * @return string
     */
    protected function getLibraryApiKey($libraryId, $libraries = null)
    {
        $settings = $this->getSettings();
        $libraries = $libraries ?: Arr::get($settings, 'libraries', []);

        foreach ($libraries as $library) {
            if (Arr::get($library, 'Id') == $libraryId) {
                return Arr::get($library, 'ApiKey', '');
            }
        }

        return '';
    }

    /**
     * Get BunnyCDN libraries
     * @param BunnyCDN $client
     * @return array|\WP_Error
     */
    protected function getLibraries($client)
    {
        try {
            $libraries = $client->getLibraries();

            if (is_wp_error($libraries)) {
                return $libraries;
            }

            // Update settings with library data including API keys
            $settings = $this->getSettings();
            $settings['libraries'] = $libraries;
            $this->saveSettings($settings);

            $options = [];
            foreach ($libraries as $library) {
                $options[] = [
                    'value' => $library['id'],
                    'label' => $library['name']
                ];
            }

            return [
                'success' => true,
                'items' => $options
            ];
        } catch (\Exception $e) {
            return new \WP_Error('api_error', $e->getMessage());
        }
    }

    /**
     * Get videos from a library
     * @param BunnyCDN $client
     * @param string $libraryId
     * @param array $data
     * @return array|\WP_Error
     */
    protected function getVideos($client, $libraryId, $data = [])
    {
        try {
            if (empty($libraryId)) {
                return new \WP_Error('missing_library_id', __('Library ID is required', 'fluent-player-pro'));
            }

            $page = Arr::get($data, 'page', 1);
            $perPage = Arr::get($data, 'per_page', 20);
            $search = Arr::get($data, 'search', '');
            $collection = Arr::get($data, 'collection', '');

            // Get library API key
            $settings = $this->getSettings();
            $libraries = Arr::get($settings, 'libraries', []);
            $libraryApiKey = $this->getLibraryApiKey($libraryId, $libraries);

            if (empty($libraryApiKey)) {
                return new \WP_Error('no_library_key', __('Library API key not found. Please refresh your BunnyCDN settings.', 'fluent-player-pro'));
            }

            $params = [
                'page' => $page,
                'per_page' => $perPage,
                'search' => $search
            ];

            if (!empty($collection)) {
                $params['collection'] = $collection;
            }

            $videos = $client->getVideos($libraryId, $libraryApiKey, $params);

            if (is_wp_error($videos)) {
                return $videos;
            }

            return [
                'success' => true,
                'videos' => $videos['items'] ?? [],
                'pagination' => [
                    'total' => $videos['totalItems'] ?? 0,
                    'current_page' => $page,
                    'per_page' => $perPage
                ]
            ];
        } catch (\Exception $e) {
            return new \WP_Error('api_error', $e->getMessage());
        }
    }

    /**
     * Get a single video from BunnyCDN
     * @param BunnyCDN $client
     * @param string $libraryId
     * @param string $videoId
     * @return array|\WP_Error
     */
    protected function getVideo($client, $libraryId, $videoId)
    {
        try {
            if (empty($libraryId)) {
                return new \WP_Error('missing_library_id', __('Library ID is required', 'fluent-player-pro'));
            }

            if (empty($videoId)) {
                return new \WP_Error('missing_video_id', __('Video ID is required', 'fluent-player-pro'));
            }

            // Get library API key
            $settings = $this->getSettings();
            $libraries = Arr::get($settings, 'libraries', []);
            $libraryApiKey = $this->getLibraryApiKey($libraryId, $libraries);

            if (empty($libraryApiKey)) {
                return new \WP_Error('no_library_key', __('Library API key not found. Please refresh your BunnyCDN settings.', 'fluent-player-pro'));
            }

            $video = $client->getVideo($libraryId, $libraryApiKey, $videoId);

            if (is_wp_error($video)) {
                return $video;
            }

            return [
                'success' => true,
                'video' => $video
            ];
        } catch (\Exception $e) {
            return new \WP_Error('api_error', $e->getMessage());
        }
    }

    /**
     * Upload a video to BunnyCDN
     * @param BunnyCDN $client
     * @param string $libraryId
     * @param array $fileData
     * @param string $title
     * @return array|\WP_Error
     */
    protected function uploadVideo($client, $libraryId, $fileData, $title = '')
    {
        try {
            if (empty($libraryId)) {
                return new \WP_Error('missing_library_id', __('Library ID is required', 'fluent-player-pro'));
            }

            if (empty($fileData) || empty($fileData['tmp_name'])) {
                return new \WP_Error('missing_file', __('No file was uploaded', 'fluent-player-pro'));
            }

            // Get library API key
            $settings = $this->getSettings();
            $libraries = Arr::get($settings, 'libraries', []);
            $libraryApiKey = $this->getLibraryApiKey($libraryId, $libraries);

            if (empty($libraryApiKey)) {
                return new \WP_Error('no_library_key', __('Library API key not found. Please refresh your BunnyCDN settings.', 'fluent-player-pro'));
            }

            // Create video record first
            $videoData = [
                'title' => $title ?: basename($fileData['name'])
            ];

            $collection = Arr::get($fileData, 'collection');
            if ($collection) {
                $videoData['collectionId'] = $collection;
            }

            $videoResponse = $client->createVideo($libraryId, $libraryApiKey, $videoData);

            if (is_wp_error($videoResponse)) {
                return $videoResponse;
            }

            $videoId = Arr::get($videoResponse, 'guid');

            if (empty($videoId)) {
                return new \WP_Error('video_creation_failed', __('Failed to create video record', 'fluent-player-pro'));
            }

            // Now upload the actual file
            $uploadResponse = $client->uploadVideo($libraryId, $libraryApiKey, $videoId, $fileData['tmp_name']);

            if (is_wp_error($uploadResponse)) {
                return $uploadResponse;
            }

            return [
                'success' => true,
                'video' => $videoResponse,
                'upload' => $uploadResponse
            ];
        } catch (\Exception $e) {
            return new \WP_Error('upload_error', $e->getMessage());
        }
    }

    /**
     * Delete a video from BunnyCDN
     * @param BunnyCDN $client
     * @param string $libraryId
     * @param string $videoId
     * @return array|\WP_Error
     */
    protected function deleteVideo($client, $libraryId, $videoId)
    {
        try {
            if (empty($libraryId)) {
                return new \WP_Error('missing_library_id', __('Library ID is required', 'fluent-player-pro'));
            }

            if (empty($videoId)) {
                return new \WP_Error('missing_video_id', __('Video ID is required', 'fluent-player-pro'));
            }

            // Get library API key
            $settings = $this->getSettings();
            $libraries = Arr::get($settings, 'libraries', []);
            $libraryApiKey = $this->getLibraryApiKey($libraryId, $libraries);

            if (empty($libraryApiKey)) {
                return new \WP_Error('no_library_key', __('Library API key not found. Please refresh your BunnyCDN settings.', 'fluent-player-pro'));
            }

            $result = $client->deleteVideo($libraryId, $libraryApiKey, $videoId);

            if (is_wp_error($result)) {
                return $result;
            }

            return [
                'success' => true,
                'message' => __('Video deleted successfully', 'fluent-player-pro')
            ];
        } catch (\Exception $e) {
            return new \WP_Error('delete_error', $e->getMessage());
        }
    }

    /**
     * Update a video in BunnyCDN
     * @param BunnyCDN $client
     * @param string $libraryId
     * @param string $videoId
     * @param array $videoData
     * @return array|\WP_Error
     */
    protected function updateVideo($client, $libraryId, $videoId, $videoData)
    {
        try {
            if (empty($libraryId)) {
                return new \WP_Error('missing_library_id', __('Library ID is required', 'fluent-player-pro'));
            }

            if (empty($videoId)) {
                return new \WP_Error('missing_video_id', __('Video ID is required', 'fluent-player-pro'));
            }

            // Get library API key
            $settings = $this->getSettings();
            $libraries = Arr::get($settings, 'libraries', []);
            $libraryApiKey = $this->getLibraryApiKey($libraryId, $libraries);

            if (empty($libraryApiKey)) {
                return new \WP_Error('no_library_key', __('Library API key not found. Please refresh your BunnyCDN settings.', 'fluent-player-pro'));
            }

            $result = $client->updateVideo($libraryId, $libraryApiKey, $videoId, $videoData);

            if (is_wp_error($result)) {
                return $result;
            }

            return [
                'success' => true,
                'video' => $result
            ];
        } catch (\Exception $e) {
            return new \WP_Error('update_error', $e->getMessage());
        }
    }

    /**
     * Create a new video record in BunnyCDN
     * @param BunnyCDN $client
     * @param string $libraryId
     * @param array $videoData
     * @return array|\WP_Error
     */
    protected function createVideo($client, $libraryId, $videoData)
    {
        try {
            if (empty($libraryId)) {
                return new \WP_Error('missing_library_id', __('Library ID is required', 'fluent-player-pro'));
            }

            // Get library API key
            $settings = $this->getSettings();
            $libraries = Arr::get($settings, 'libraries', []);
            $libraryApiKey = $this->getLibraryApiKey($libraryId, $libraries);

            if (empty($libraryApiKey)) {
                return new \WP_Error('no_library_key', __('Library API key not found. Please refresh your BunnyCDN settings.', 'fluent-player-pro'));
            }

            $result = $client->createVideo($libraryId, $libraryApiKey, $videoData);

            if (is_wp_error($result)) {
                return $result;
            }

            return [
                'success' => true,
                'video' => $result
            ];
        } catch (\Exception $e) {
            return new \WP_Error('create_error', $e->getMessage());
        }
    }
}
