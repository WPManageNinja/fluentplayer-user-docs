<?php

namespace FluentPlayerPro\App\Integrations;

use FluentPlayer\App\Integrations\AbstractIntegration;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Libraries\CloudStorage\CloudFlareDriver;

class R2Integration extends AbstractIntegration
{
    /**
     * Integration identifier
     * @var string
     */
    protected $integration = 'cloudflare_r2';

    /**
     * Integration display name
     * @var string
     */
    protected $name = 'Cloudflare R2';

    /**
     * Integration description
     * @var string
     */
    protected $description = 'Connect to Cloudflare R2 (S3-compatible object storage) to host and stream your videos with zero egress fees.';

    /**
     * Integration icon
     * @var string
     */
    protected $logo = 'cloudflare-r2.svg';

    /**
     * Sentinel returned to the browser in place of the stored secret. When the
     * admin re-submits it unchanged we keep the previously stored secret.
     */
    const SECRET_MASK = '__FLP_R2_SECRET_KEPT__';

    /**
     * Prefix marking an at-rest encrypted secret value.
     */
    const CIPHER_PREFIX = 'flp1:';

    /**
     * Default settings
     * @var array
     */
    protected $defaultSettings = [
        'enabled'    => false,
        'account_id' => '',
        'access_key' => '',
        'secret_key' => '',
        'bucket'     => '',
        'public_url' => '',
        'sub_folder' => '',
    ];

    /**
     * Validate settings before saving.
     *
     * @param array $settings
     * @return bool|\WP_Error
     */
    public function validateSettings($settings)
    {
        if (!Arr::isTrue($settings, 'enabled')) {
            return true;
        }

        $required = [
            'account_id' => __('Account ID is required', 'fluent-player-pro'),
            'access_key' => __('Access Key ID is required', 'fluent-player-pro'),
            'secret_key' => __('Secret Access Key is required', 'fluent-player-pro'),
            'bucket'     => __('Bucket name is required', 'fluent-player-pro'),
            'public_url' => __('Public URL is required — enable the bucket\'s Public Development URL or attach a custom domain.', 'fluent-player-pro'),
        ];

        foreach ($required as $key => $message) {
            if (empty($settings[$key])) {
                return new \WP_Error('missing_' . $key, $message);
            }
        }

        // Account ID + bucket are interpolated into the S3 request host, so they
        // must not contain characters that could redirect it to another origin.
        if (!preg_match('/^[A-Za-z0-9]+$/', (string) $settings['account_id'])) {
            return new \WP_Error('invalid_account_id', __('Account ID may only contain letters and numbers.', 'fluent-player-pro'));
        }
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9.\-]*$/', (string) $settings['bucket'])) {
            return new \WP_Error('invalid_bucket', __('Bucket name may only contain letters, numbers, dots and hyphens.', 'fluent-player-pro'));
        }

        // The Public URL is the playback origin — require a well-formed http(s)
        // URL so a malformed/unsafe value can't reach the page src.
        $publicUrl = (string) $settings['public_url'];
        $scheme = strtolower((string) parse_url($publicUrl, PHP_URL_SCHEME));
        if (!filter_var($publicUrl, FILTER_VALIDATE_URL) || !in_array($scheme, ['http', 'https'], true)) {
            return new \WP_Error('invalid_public_url', __('Public URL must be a valid http(s) URL.', 'fluent-player-pro'));
        }

        return true;
    }

    /**
     * Get integration settings fields configuration.
     *
     * @return array
     */
    public function getSettingsFields()
    {
        return [
            [
                'key'   => 'setup_instructions',
                'type'  => 'setup_instructions',
                'label' => __('Setup Instructions', 'fluent-player-pro'),
                'instructions' => [
                    'title' => __('Cloudflare R2 Setup Guide', 'fluent-player-pro'),
                    'steps' => [
                        [
                            'title'   => __('Step 1: Create an R2 Bucket', 'fluent-player-pro'),
                            'content' => __('In your Cloudflare dashboard open R2 and create a bucket for your videos.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'link'    => [
                                'url'  => 'https://dash.cloudflare.com/?to=/:account/r2',
                                'text' => __('Open Cloudflare R2', 'fluent-player-pro'),
                            ],
                        ],
                        [
                            'title'   => __('Step 2: Create an R2 API Token', 'fluent-player-pro'),
                            'content' => __('Create an R2 API token with Object Read & Write permission. Copy the Access Key ID and Secret Access Key.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'note'    => __('The Secret Access Key is shown only once — store it safely.', 'fluent-player-pro'),
                        ],
                        [
                            'title'   => __('Step 3: Find your Account ID', 'fluent-player-pro'),
                            'content' => __('Your Account ID is in the R2 overview; the S3 endpoint is https://<account-id>.r2.cloudflarestorage.com.', 'fluent-player-pro'),
                            'type'    => 'text',
                        ],
                        [
                            'title'   => __('Step 4: Enable public delivery (required)', 'fluent-player-pro'),
                            'content' => __('Videos are served from a public URL. Enable the bucket\'s Public Development URL (https://pub-xxxx.r2.dev) or attach a custom domain, then enter it as the Public URL below.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'link'    => [
                                'url'  => 'https://developers.cloudflare.com/r2/buckets/public-buckets/',
                                'text' => __('R2 public bucket docs', 'fluent-player-pro'),
                            ],
                        ],
                        [
                            'title'   => __('Step 5: Allow browser uploads (CORS)', 'fluent-player-pro'),
                            'content' => __('To upload from the editor, add a CORS policy on the bucket allowing PUT from your site origin.', 'fluent-player-pro'),
                            'type'    => 'text',
                        ],
                    ],
                ],
            ],
            [
                'key'         => 'enabled',
                'type'        => 'checkbox',
                'label'       => __('Enable Cloudflare R2', 'fluent-player-pro'),
                'description' => __('Enable Cloudflare R2 for video hosting', 'fluent-player-pro'),
            ],
            [
                'key'         => 'account_id',
                'type'        => 'text',
                'label'       => __('Cloudflare Account ID', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('Found in the Cloudflare dashboard under R2 → Overview → Account Details.', 'fluent-player-pro'),
                'placeholder' => __('Enter your Cloudflare Account ID', 'fluent-player-pro'),
            ],
            [
                'key'         => 'access_key',
                'type'        => 'text',
                'label'       => __('Cloudflare Access Key', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('The Access Key ID from your R2 API token (Object Read & Write).', 'fluent-player-pro'),
                'placeholder' => __('Enter your R2 Access Key', 'fluent-player-pro'),
            ],
            [
                'key'         => 'secret_key',
                'type'        => 'password',
                'label'       => __('Cloudflare Secret Key', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('The Secret Access Key from your R2 API token (shown only once). Stored encrypted.', 'fluent-player-pro'),
                'placeholder' => __('Enter your R2 Secret Key', 'fluent-player-pro'),
            ],
            [
                'key'         => 'bucket',
                'type'        => 'text',
                'label'       => __('Cloudflare Bucket Name', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('The R2 bucket that holds your videos.', 'fluent-player-pro'),
                'placeholder' => __('e.g. fluent-player', 'fluent-player-pro'),
            ],
            [
                'key'         => 'public_url',
                'type'        => 'text',
                'label'       => __('Cloudflare Bucket Public URL', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('Required. Enable the bucket\'s Public Development URL (https://pub-xxxx.r2.dev) or attach a custom domain — videos are served from here.', 'fluent-player-pro'),
                'placeholder' => __('https://pub-xxxxxxxx.r2.dev', 'fluent-player-pro'),
            ],
            [
                'key'         => 'sub_folder',
                'type'        => 'text',
                'label'       => __('Bucket Sub-Folder (Optional)', 'fluent-player-pro'),
                'required'    => false,
                'description' => __('Restrict uploads/browsing to a folder prefix inside the bucket.', 'fluent-player-pro'),
                'placeholder' => __('e.g. videos', 'fluent-player-pro'),
            ],
        ];
    }

    /**
     * Current settings with the secret decrypted for internal use.
     *
     * @return array
     */
    public function getSettings()
    {
        return $this->decryptSecrets(parent::getSettings());
    }

    /**
     * Settings for the admin form: defaults applied, secret masked for display.
     *
     * @return array
     */
    public function getSettingsWithDefaults()
    {
        $real = wp_parse_args($this->getSettings(), $this->getDefaultSettings());
        return $this->maskSecrets($real);
    }

    /**
     * Save settings: resolve a masked secret, validate, test, then store with
     * the secret encrypted at rest. Returns masked settings for the response.
     *
     * @param array $settings
     * @return array|\WP_Error
     */
    public function saveSettings($settings)
    {
        $allSettings = $this->getAllSettings();
        $isEnabled = isset($settings['enabled']) && $settings['enabled'] === 'yes';
        $settings['enabled'] = $isEnabled ? 'yes' : 'no';

        if (!$isEnabled) {
            unset($allSettings[$this->integration]);
            update_option(self::INTEGRATIONS_SETTINGS_KEY, json_encode($allSettings));
            return [];
        }

        // Preserve the stored secret when the masked sentinel is re-submitted.
        $settings = $this->resolveMaskedSecrets($settings, $this->getSettings());

        $validation = $this->validateSettings($settings);
        if (is_wp_error($validation)) {
            return $validation;
        }

        $test = $this->testConnection($settings);
        if (is_wp_error($test)) {
            return $test;
        }

        $allSettings[$this->integration] = $this->encryptSecrets($settings);
        update_option(self::INTEGRATIONS_SETTINGS_KEY, json_encode($allSettings));

        return $this->maskSecrets($settings);
    }

    /**
     * Test the connection against R2 by listing the bucket.
     *
     * @param array|null $settings
     * @return bool|\WP_Error
     */
    public function testConnection($settings = null)
    {
        if ($settings === null) {
            $settings = $this->getSettings();
        } else {
            $settings = $this->resolveMaskedSecrets($settings, $this->getSettings());
        }

        if (!Arr::isTrue($settings, 'enabled')) {
            return true;
        }

        foreach (['account_id', 'access_key', 'secret_key', 'bucket'] as $key) {
            if (empty($settings[$key])) {
                return new \WP_Error('missing_credentials', __('All R2 credentials are required', 'fluent-player-pro'));
            }
        }

        $driver = $this->makeDriver($settings);

        try {
            $result = $driver->testConnection();
            if (is_wp_error($result)) {
                return new \WP_Error(
                    'connection_failed',
                    __('Failed to connect to Cloudflare R2. Please check your credentials and bucket.', 'fluent-player-pro')
                );
            }
            return true;
        } catch (\Exception $e) {
            return new \WP_Error('connection_error', $e->getMessage());
        }
    }

    /**
     * Build a configured CloudFlare R2 driver from settings.
     *
     * @param array|null $settings
     * @return CloudFlareDriver
     */
    public function makeDriver($settings = null)
    {
        $settings = $settings ?: $this->getSettings();

        $endpointHost = Arr::get($settings, 'account_id') . '.r2.cloudflarestorage.com';

        $driver = new CloudFlareDriver(
            Arr::get($settings, 'access_key'),
            Arr::get($settings, 'secret_key'),
            $endpointHost,
            Arr::get($settings, 'bucket'),
            'auto'
        );

        if ($subFolder = Arr::get($settings, 'sub_folder')) {
            $driver->setSubFolder($subFolder);
        }

        if ($publicUrl = Arr::get($settings, 'public_url')) {
            $driver->setPublicUrl(rtrim($publicUrl, '/'));
        }

        return $driver;
    }

    // ── secret handling ─────────────────────────────────────────────

    /**
     * Encrypt the secret fields of a settings array for storage.
     */
    protected function encryptSecrets($settings)
    {
        if (!empty($settings['secret_key'])) {
            $settings['secret_key'] = $this->encryptSecret($settings['secret_key']);
        }
        return $settings;
    }

    /**
     * Decrypt the secret fields of a stored settings array.
     */
    protected function decryptSecrets($settings)
    {
        if (!empty($settings['secret_key'])) {
            $settings['secret_key'] = $this->decryptSecret($settings['secret_key']);
        }
        return $settings;
    }

    /**
     * Replace secret fields with the display mask.
     */
    protected function maskSecrets($settings)
    {
        if (!empty($settings['secret_key'])) {
            $settings['secret_key'] = self::SECRET_MASK;
        }
        return $settings;
    }

    /**
     * When the masked sentinel (or empty) is submitted, keep the stored secret.
     */
    protected function resolveMaskedSecrets($incoming, $stored)
    {
        $submitted = isset($incoming['secret_key']) ? $incoming['secret_key'] : '';
        if ($submitted === self::SECRET_MASK || $submitted === '') {
            $incoming['secret_key'] = isset($stored['secret_key']) ? $stored['secret_key'] : '';
        }
        return $incoming;
    }

    /**
     * Encrypt a single secret with AES-256-CTR keyed by the site auth salt.
     */
    protected function encryptSecret($plain)
    {
        if ($plain === '' || $plain === null) {
            return '';
        }
        // Already encrypted — leave as-is (idempotent).
        if (strpos($plain, self::CIPHER_PREFIX) === 0) {
            return $plain;
        }

        $iv = function_exists('random_bytes') ? random_bytes(16) : openssl_random_pseudo_bytes(16);
        $cipher = openssl_encrypt($plain, 'aes-256-ctr', $this->encryptionKey(), OPENSSL_RAW_DATA, $iv);

        return self::CIPHER_PREFIX . base64_encode($iv . $cipher);
    }

    /**
     * Decrypt a value produced by encryptSecret(). Plaintext passes through.
     */
    protected function decryptSecret($value)
    {
        if ($value === '' || $value === null) {
            return '';
        }
        if (strpos($value, self::CIPHER_PREFIX) !== 0) {
            return $value; // legacy/plaintext
        }

        $raw = base64_decode(substr($value, strlen(self::CIPHER_PREFIX)));
        if ($raw === false || strlen($raw) <= 16) {
            return '';
        }

        $iv = substr($raw, 0, 16);
        $cipher = substr($raw, 16);

        $plain = openssl_decrypt($cipher, 'aes-256-ctr', $this->encryptionKey(), OPENSSL_RAW_DATA, $iv);

        return $plain === false ? '' : $plain;
    }

    /**
     * 32-byte key derived from the site auth salt.
     */
    protected function encryptionKey()
    {
        $salt = function_exists('wp_salt') ? wp_salt('auth') : 'fluent-player-r2';
        return substr(hash('sha256', $salt, true), 0, 32);
    }
}
