<?php

namespace FluentPlayerPro\App\Integrations;

use FluentPlayer\App\Integrations\AbstractIntegration;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Libraries\Mux;

class MuxIntegration extends AbstractIntegration
{
    /**
     * @var string
     */
    protected $integration = 'mux';

    /**
     * @var string
     */
    protected $name = 'Mux';

    /**
     * @var string
     */
    protected $description = 'Stream video with Mux - HLS streaming, live streams, auto-subtitles, and analytics';

    /**
     * @var string
     */
    protected $logo = 'mux.svg';

    /**
     * @var array
     */
    protected $defaultSettings = [
        'enabled'              => false,
        'token_id'             => '',
        'token_secret'         => '',
        'enable_signed_urls'   => false,
        'signing_key_id'       => '',
        'signing_private_key'  => '',
        'enable_auto_captions' => false,
        'auto_caption_language' => 'en',
        'webhook_secret'       => '',
        'mux_data_env_key'     => '',
    ];

    /**
     * @param array $settings
     * @return bool|\WP_Error
     */
    public function validateSettings($settings)
    {
        if (Arr::isTrue($settings, 'enabled')) {
            if (empty($settings['token_id'])) {
                return new \WP_Error('missing_token_id', __('Token ID is required', 'fluent-player-pro'));
            }
            if (empty($settings['token_secret'])) {
                return new \WP_Error('missing_token_secret', __('Token Secret is required', 'fluent-player-pro'));
            }
        }

        if (Arr::isTrue($settings, 'enable_signed_urls')) {
            if (empty($settings['signing_key_id'])) {
                return new \WP_Error('missing_signing_key_id', __('Signing Key ID is required when signed URLs are enabled.', 'fluent-player-pro'));
            }
            if (empty($settings['signing_private_key'])) {
                return new \WP_Error('missing_signing_private_key', __('Signing Private Key is required when signed URLs are enabled.', 'fluent-player-pro'));
            }
            // Reject a key that cannot sign, at save time, so a misconfiguration
            // surfaces loudly to the admin here rather than as a silent unsigned
            // URL (Mux 403) on the frontend. This validates the same key that
            // MuxService::encodeRs256() will later sign tokens with.
            $decodedSigningKey = base64_decode($settings['signing_private_key'], true); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
            if ($decodedSigningKey === false || openssl_pkey_get_private($decodedSigningKey) === false) {
                return new \WP_Error('invalid_signing_private_key', __('Signing Private Key is not a valid RSA private key. Paste the base64-encoded key from your Mux signing key.', 'fluent-player-pro'));
            }
        }

        return true;
    }

    /**
     * @return array
     */
    public function getSettingsFields()
    {
        return [
            [
                'key'          => 'setup_instructions',
                'type'         => 'setup_instructions',
                'label'        => __('Setup Instructions', 'fluent-player-pro'),
                'instructions' => [
                    'title' => __('Mux Setup Guide', 'fluent-player-pro'),
                    'steps' => [
                        [
                            'title'   => __('Step 1: Create Mux Account', 'fluent-player-pro'),
                            'content' => __('If you don\'t have a Mux account yet, visit the Mux website and sign up.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'link'    => [
                                'url'  => 'https://dashboard.mux.com/signup',
                                'text' => __('Sign up for Mux', 'fluent-player-pro'),
                            ],
                        ],
                        [
                            'title'   => __('Step 2: Generate API Credentials', 'fluent-player-pro'),
                            'content' => __('Go to Settings > API Access Tokens in your Mux dashboard and create a new token with "Mux Video" permissions (Read + Write).', 'fluent-player-pro'),
                            'type'    => 'text',
                        ],
                        [
                            'title'   => __('Step 3: Copy Token ID & Secret', 'fluent-player-pro'),
                            'content' => __('Copy the Token ID and Token Secret shown after creation. The secret is only shown once, so save it securely.', 'fluent-player-pro'),
                            'type'    => 'text',
                            'note'    => __('Keep your Token Secret secure and never share it publicly.', 'fluent-player-pro'),
                        ],
                        [
                            'title'   => __('Step 4: Configure Integration', 'fluent-player-pro'),
                            'content' => __('Enter your Token ID and Token Secret below and enable the integration.', 'fluent-player-pro'),
                            'type'    => 'text',
                        ],
                        [
                            'title'   => __('Step 5: Test Connection', 'fluent-player-pro'),
                            'content' => __('After saving, use the "Test Connection" button to verify everything is working.', 'fluent-player-pro'),
                            'type'    => 'text',
                        ],
                    ],
                ],
            ],
            [
                'key'         => 'enabled',
                'type'        => 'checkbox',
                'label'       => __('Enable Mux', 'fluent-player-pro'),
                'description' => __('Enable Mux integration for video hosting and streaming', 'fluent-player-pro'),
            ],
            [
                'key'         => 'token_id',
                'type'        => 'password',
                'label'       => __('Token ID', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('Your Mux API Token ID from Settings > API Access Tokens', 'fluent-player-pro'),
                'placeholder' => __('Enter your Mux Token ID', 'fluent-player-pro'),
            ],
            [
                'key'         => 'token_secret',
                'type'        => 'password',
                'label'       => __('Token Secret', 'fluent-player-pro'),
                'required'    => true,
                'description' => __('Your Mux API Token Secret', 'fluent-player-pro'),
                'placeholder' => __('Enter your Mux Token Secret', 'fluent-player-pro'),
            ],
            [
                'key'         => 'enable_signed_urls',
                'type'        => 'checkbox',
                'label'       => __('Enable Signed URLs', 'fluent-player-pro'),
                'description' => __('Use signed URLs for private/protected video playback. Requires a signing key to be generated.', 'fluent-player-pro'),
            ],
            [
                'key'         => 'signing_key_id',
                'type'        => 'password',
                'label'       => __('Signing Key ID', 'fluent-player-pro'),
                'description' => __('The Key ID (kid) from your Mux signing key. Create one in the Mux dashboard under Settings → Signing Keys.', 'fluent-player-pro'),
                'placeholder' => __('Paste your signing key ID', 'fluent-player-pro'),
                'depends_on'  => 'enable_signed_urls',
            ],
            [
                'key'         => 'signing_private_key',
                'type'        => 'password',
                'label'       => __('Signing Private Key', 'fluent-player-pro'),
                'description' => __('The RS256 private key (PEM) shown once when the signing key was created. Stored for use when minting playback JWTs for signed streams.', 'fluent-player-pro'),
                'placeholder' => __('Paste your signing private key', 'fluent-player-pro'),
                'depends_on'  => 'enable_signed_urls',
            ],
            [
                'key'         => 'enable_auto_captions',
                'type'        => 'checkbox',
                'label'       => __('Enable Auto Captions', 'fluent-player-pro'),
                'description' => __('Automatically generate captions for uploaded videos using Mux\'s AI transcription.', 'fluent-player-pro'),
            ],
            [
                'key'         => 'auto_caption_language',
                'type'        => 'select',
                'label'       => __('Auto Caption Language', 'fluent-player-pro'),
                'description' => __('Default language for auto-generated captions.', 'fluent-player-pro'),
                'depends_on'  => 'enable_auto_captions',
                'options'     => [
                    ['value' => 'en', 'label' => 'English'],
                    ['value' => 'es', 'label' => 'Spanish'],
                    ['value' => 'it', 'label' => 'Italian'],
                    ['value' => 'pt', 'label' => 'Portuguese'],
                    ['value' => 'de', 'label' => 'German'],
                    ['value' => 'fr', 'label' => 'French'],
                ],
            ],
            [
                'key'         => 'webhook_secret',
                'type'        => 'password',
                'label'       => __('Webhook Secret', 'fluent-player-pro'),
                'description' => sprintf(
                    /* translators: %s: webhook URL */
                    __('Your Mux webhook signing secret. Set your webhook URL in the Mux dashboard to: %s', 'fluent-player-pro'),
                    rest_url('fluent-player/v2/mux/webhook')
                ),
                'placeholder' => __('Enter your Mux webhook signing secret', 'fluent-player-pro'),
            ],
            [
                'key'         => 'mux_data_env_key',
                'type'        => 'text',
                'label'       => __('Mux Data Environment Key', 'fluent-player-pro'),
                'description' => __('Optional. Enable Mux Data playback quality analytics by entering your environment key from the Mux Data dashboard.', 'fluent-player-pro'),
                'placeholder' => __('e.g. abc123def456', 'fluent-player-pro'),
                'link'        => [
                    'url'  => 'https://docs.mux.com/guides/data/find-your-env-key',
                    'text' => __('How to find your Env Key', 'fluent-player-pro'),
                ],
            ],
        ];
    }

    /**
     * @param array|null $settings
     * @return bool|\WP_Error
     */
    public function testConnection($settings = null)
    {
        $settings = $settings ?: $this->getSettings();

        if (!Arr::get($settings, 'enabled')) {
            return true;
        }

        $tokenId = Arr::get($settings, 'token_id');
        $tokenSecret = Arr::get($settings, 'token_secret');

        if (empty($tokenId) || empty($tokenSecret)) {
            return new \WP_Error('missing_credentials', __('Token ID and Token Secret are required', 'fluent-player-pro'));
        }

        try {
            $client = new Mux($tokenId, $tokenSecret);
            $result = $client->getAssets(['limit' => 1]);

            if (is_wp_error($result)) {
                return new \WP_Error('connection_failed', __('Could not connect to Mux. Please check your credentials.', 'fluent-player-pro'));
            }

            return true;
        } catch (\Exception $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Error logging for debugging
                error_log('Fluent Player Mux connection error: ' . $e->getMessage());
            }
            return new \WP_Error('connection_error', __('Could not connect to Mux. Please check your credentials.', 'fluent-player-pro'));
        }
    }

    /**
     * @return Mux|\WP_Error
     */
    public function getClient()
    {
        if (!$this->isEnabled()) {
            return new \WP_Error('disabled', __('Mux integration is not enabled', 'fluent-player-pro'));
        }

        $settings = $this->getSettings();
        $tokenId = Arr::get($settings, 'token_id');
        $tokenSecret = Arr::get($settings, 'token_secret');

        if (empty($tokenId) || empty($tokenSecret)) {
            return new \WP_Error('missing_credentials', __('Mux credentials are not configured', 'fluent-player-pro'));
        }

        return new Mux($tokenId, $tokenSecret);
    }
}
