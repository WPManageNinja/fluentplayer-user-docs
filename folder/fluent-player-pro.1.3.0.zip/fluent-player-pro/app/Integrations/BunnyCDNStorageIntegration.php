<?php

namespace FluentPlayerPro\App\Integrations;

use FluentPlayer\App\Integrations\AbstractIntegration;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Libraries\BunnyCDNStorage;

class BunnyCDNStorageIntegration extends AbstractIntegration
{
    /**
     * Integration identifier
     * @var string
     */
    protected $integration = 'bunnycdn_storage';

    /**
     * Integration display name
     * @var string
     */
    protected $name = 'BunnyCDN Storage';

    /**
     * Integration description
     * @var string
     */
    protected $description = 'Connect to BunnyCDN Storage for video file storage and management with global CDN delivery.';

    /**
     * Integration icon
     * @var string
     */
    protected $logo = 'bunnycdn.svg';

    /**
     * Default settings
     * @var array
     */
    protected $defaultSettings = [
        'enabled' => false,
        'storage_user_name' => '',
        'storage_hostname' => 'storage.bunnycdn.com',
        'storage_password' => '',
        'cdn_hostname' => '',
        'cdn_security_key' => ''
    ];

    /**
     * Validate settings before saving
     * @param array $settings
     * @return bool|\WP_Error
     */
    public function validateSettings($settings)
    {
        if (Arr::isTrue($settings, 'enabled')) {
            if (empty($settings['storage_user_name'])) {
                return new \WP_Error('missing_user_name', __('Storage User Name is required', 'fluent-player-pro'));
            }

            if (empty($settings['storage_hostname'])) {
                return new \WP_Error('missing_hostname', __('Storage Hostname is required', 'fluent-player-pro'));
            }

            if (empty($settings['storage_password'])) {
                return new \WP_Error('missing_password', __('Storage Password is required', 'fluent-player-pro'));
            }
        }

        return true;
    }

    /**
     * Get integration settings fields configuration
     * @return array
     */
    public function getSettingsFields()
    {
        return [
            [
                'key' => 'setup_instructions',
                'type' => 'setup_instructions',
                'label' => __('Setup Instructions', 'fluent-player-pro'),
                'instructions' => [
                    'title' => __('BunnyCDN Storage Setup Guide', 'fluent-player-pro'),
                    'steps' => [
                        [
                            'title' => __('Step 1: Create BunnyCDN Account', 'fluent-player-pro'),
                            'content' => __('If you don\'t have a BunnyCDN account yet, visit the BunnyCDN website and create a new account.', 'fluent-player-pro'),
                            'type' => 'text',
                            'link' => [
                                'url' => 'https://bunny.net',
                                'text' => __('Visit BunnyCDN', 'fluent-player-pro')
                            ]
                        ],
                        [
                            'title' => __('Step 2: Create Storage Zone', 'fluent-player-pro'),
                            'content' => __('In your BunnyCDN dashboard, navigate to Storage and create a new Storage Zone. This will be used to store your video files.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('Choose a region closest to your audience for better performance.', 'fluent-player-pro')
                        ],
                        [
                            'title' => __('Step 3: Get Storage Credentials', 'fluent-player-pro'),
                            'content' => __('After creating the storage zone, you\'ll get the FTP/Storage credentials including username and password.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('These credentials are different from your account login credentials.', 'fluent-player-pro')
                        ],
                        [
                            'title' => __('Step 4: Note the Hostname', 'fluent-player-pro'),
                            'content' => __('The storage hostname is typically "storage.bunnycdn.com" but may vary based on your region.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('If you\'re using a custom pull zone, you\'ll need to use that hostname instead.', 'fluent-player-pro')
                        ],
                        [
                            'title' => __('Step 5: Configure Integration', 'fluent-player-pro'),
                            'content' => __('Enter your storage username, hostname, and password in the fields below and enable the integration.', 'fluent-player-pro'),
                            'type' => 'text'
                        ],
                        [
                            'title' => __('Step 6: Secure Your Videos (Optional)', 'fluent-player-pro'),
                            'content' => __('To protect your videos with signed URLs, enable Token Authentication on your Storage Pull Zone and enter the security key below.', 'fluent-player-pro'),
                            'type' => 'text',
                            'note' => __('Go to CDN → Pull Zones → Your Pull Zone → Security → Enable "Token Authentication" → Copy the Token Authentication Key and paste it in the "CDN Security Key" field below.', 'fluent-player-pro')
                        ],
                        [
                            'title' => __('Step 7: Test Connection', 'fluent-player-pro'),
                            'content' => __('After saving your settings, use the "Test Connection" button to verify that the integration is working correctly.', 'fluent-player-pro'),
                            'type' => 'text'
                        ],
                    ]
                ]
            ],
            [
                'key' => 'enabled',
                'type' => 'checkbox',
                'label' => __('Enable BunnyCDN Storage', 'fluent-player-pro'),
                'description' => __('Enable BunnyCDN Storage integration for video file storage', 'fluent-player-pro')
            ],
            [
                'key' => 'storage_user_name',
                'type' => 'text',
                'label' => __('Storage User Name', 'fluent-player-pro'),
                'required' => true,
                'description' => __('Your BunnyCDN Storage User name', 'fluent-player-pro'),
                'placeholder' => __('Enter your storage user name', 'fluent-player-pro')
            ],
            [
                'key' => 'storage_hostname',
                'type' => 'text',
                'label' => __('Storage Hostname', 'fluent-player-pro'),
                'required' => true,
                'description' => __('Your BunnyCDN Storage hostname (e.g., storage.bunnycdn.com)', 'fluent-player-pro'),
                'placeholder' => __('storage.bunnycdn.com', 'fluent-player-pro'),
                'default' => 'storage.bunnycdn.com'
            ],
            [
                'key' => 'storage_password',
                'type' => 'password',
                'label' => __('Storage Password', 'fluent-player-pro'),
                'required' => true,
                'description' => __('Your BunnyCDN Storage password/API key', 'fluent-player-pro'),
                'placeholder' => __('Enter your storage password', 'fluent-player-pro')
            ],
            [
                'key' => 'cdn_hostname',
                'type' => 'text',
                'label' => __('CDN Hostname (Pull Zone)', 'fluent-player-pro'),
                'required' => false,
                'description' => __('Your linked Pull Zone hostname for public video delivery (e.g., myzone.b-cdn.net). If empty, videos will be served through the WordPress proxy.', 'fluent-player-pro'),
                'placeholder' => __('myzone.b-cdn.net', 'fluent-player-pro')
            ],
            [
                'key' => 'cdn_security_key',
                'type' => 'password',
                'label' => __('CDN Security Key', 'fluent-player-pro'),
                'required' => false,
                'description' => __('The Token Authentication Key from your Pull Zone security settings. Required for signed URLs.', 'fluent-player-pro'),
                'placeholder' => __('Enter your Pull Zone token authentication key', 'fluent-player-pro')
            ],
        ];
    }

    /**
     * Test connection with provided settings
     * @param array $settings Optional settings to test
     * @return bool|\WP_Error
     */
    public function testConnection($settings = null)
    {
        $settings = $settings ?: $this->getSettings();

        // Skip test if not enabled
        if (!Arr::get($settings, 'enabled')) {
            return true;
        }

        $username = Arr::get($settings, 'storage_user_name');
        $hostname = Arr::get($settings, 'storage_hostname');
        $password = Arr::get($settings, 'storage_password');

        if (empty($username) || empty($hostname) || empty($password)) {
            return new \WP_Error('missing_credentials', __('All storage credentials are required', 'fluent-player-pro'));
        }

        try {
            $storage = new BunnyCDNStorage($username, $hostname, $password);
            $result = $storage->getStorageObjects();

            if (is_wp_error($result)) {
                return new \WP_Error('connection_failed', __('Failed to connect to BunnyCDN Storage. Please check your credentials.', 'fluent-player-pro'));
            }

            return true;
        } catch (\Exception $e) {
            return new \WP_Error('connection_error', $e->getMessage());
        }
    }

    /**
     * Handle integration-specific actions
     * @param string $action
     * @param array $data
     * @return mixed
     */
    public function handleAction($action, $data = [])
    {
        if (!$this->isEnabled()) {
            return new \WP_Error('integration_disabled', __('BunnyCDN Storage integration is not enabled', 'fluent-player-pro'));
        }

        $storage = $this->getStorageClient();
        if (is_wp_error($storage)) {
            return $storage;
        }

        switch ($action) {
            case 'list':
                $path = Arr::get($data, 'path', '');
                return $this->listFiles($storage, $path);

            case 'upload':
                $path = Arr::get($data, 'path', '');
                $fileData = Arr::get($data, 'file');
                return $this->uploadFile($storage, $path, $fileData);

            case 'download':
                $path = Arr::get($data, 'path', '');
                return $this->downloadFile($storage, $path);

            case 'delete':
                $path = Arr::get($data, 'path', '');
                return $this->deleteFile($storage, $path);

            case 'create_folder':
                $path = Arr::get($data, 'path', '');
                return $this->createFolder($storage, $path);

            case 'file_info':
                $path = Arr::get($data, 'path', '');
                return $this->getFileInfo($storage, $path);
        }

        return new \WP_Error('invalid_action', __('Invalid action', 'fluent-player-pro'));
    }

    /**
     * Get BunnyCDN Storage client instance
     * @return BunnyCDNStorage|\WP_Error
     */
    public function getStorageClient()
    {
        if (!$this->isEnabled()) {
            return new \WP_Error('disabled', __('BunnyCDN Storage integration is not enabled', 'fluent-player-pro'));
        }

        $settings = $this->getSettings();
        $username = Arr::get($settings, 'storage_user_name');
        $hostname = Arr::get($settings, 'storage_hostname');
        $password = Arr::get($settings, 'storage_password');

        if (empty($username) || empty($hostname) || empty($password)) {
            return new \WP_Error('missing_credentials', __('BunnyCDN storage credentials are not configured', 'fluent-player-pro'));
        }

        return new BunnyCDNStorage($username, $hostname, $password);
    }

    /**
     * List files and folders at a specific path
     * @param BunnyCDNStorage $storage
     * @param string $path
     * @return array|\WP_Error
     */
    protected function listFiles($storage, $path = '')
    {
        try {
            // Ensure path is formatted correctly
            if (!empty($path) && substr($path, -1) !== '/') {
                $path .= '/';
            }

            $items = $storage->getStorageObjects($path);

            if (is_wp_error($items)) {
                return $items;
            }

            $directories = [];
            $files = [];
            $videoExtensions = ['mp4', 'webm', 'mov', 'avi', 'mkv'];

            foreach ($items as $item) {
                if (Arr::isTrue($item, 'IsDirectory')) {
                    $directories[] = [
                        'id' => md5($path . Arr::get($item, 'ObjectName')),
                        'name' => Arr::get($item, 'ObjectName'),
                        'path' => $path . Arr::get($item, 'ObjectName') . '/',
                        'type' => 'directory',
                        'size' => 0,
                        'date' => Arr::get($item, 'LastChanged')
                    ];
                } else {
                    $fileName = Arr::get($item, 'ObjectName');
                    $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                    $isVideo = in_array($extension, $videoExtensions);

                    $files[] = [
                        'id' => md5($path . $fileName),
                        'name' => $fileName,
                        'path' => $path . $fileName,
                        'type' => $isVideo ? 'video' : 'file',
                        'size' => Arr::get($item, 'Length', 0),
                        'date' => Arr::get($item, 'LastChanged'),
                        'url' => $this->getPublicUrl($path . $fileName)
                    ];
                }
            }

            return [
                'success' => true,
                'current_path' => $path,
                'parent_path' => $this->getParentPath($path),
                'directories' => $directories,
                'files' => $files
            ];
        } catch (\Exception $e) {
            return new \WP_Error('list_error', $e->getMessage());
        }
    }

    /**
     * Upload a file to storage
     * @param BunnyCDNStorage $storage
     * @param string $path
     * @param array $fileData
     * @return array|\WP_Error
     */
    protected function uploadFile($storage, $path, $fileData)
    {
        try {
            if (empty($fileData) || empty($fileData['tmp_name'])) {
                return new \WP_Error('missing_file', __('No file was uploaded', 'fluent-player-pro'));
            }

            // Ensure path is formatted correctly
            if (!empty($path) && substr($path, -1) !== '/') {
                $path .= '/';
            }

            $fileName = basename($fileData['name']);
            $filePath = $path . $fileName;

            // Get file content
            $fileContent = file_get_contents($fileData['tmp_name']);
            if ($fileContent === false) {
                return new \WP_Error('read_error', __('Could not read uploaded file', 'fluent-player-pro'));
            }

            // Upload the file
            $result = $storage->uploadFile($filePath, $fileContent);

            if (is_wp_error($result)) {
                return $result;
            }

            return [
                'success' => true,
                'file' => [
                    'name' => $fileName,
                    'path' => $filePath,
                    'url' => $this->getPublicUrl($filePath),
                    'size' => filesize($fileData['tmp_name'])
                ]
            ];
        } catch (\Exception $e) {
            return new \WP_Error('upload_error', $e->getMessage());
        }
    }

    /**
     * Download a file from storage
     * @param BunnyCDNStorage $storage
     * @param string $path
     * @return mixed
     */
    protected function downloadFile($storage, $path)
    {
        try {
            if (empty($path)) {
                return new \WP_Error('missing_path', __('File path is required', 'fluent-player-pro'));
            }

            // For this method, we'll return a public URL rather than streaming the file through PHP
            $url = $this->getPublicUrl($path);

            return [
                'success' => true,
                'url' => $url
            ];
        } catch (\Exception $e) {
            return new \WP_Error('download_error', $e->getMessage());
        }
    }

    /**
     * Delete a file from storage
     * @param BunnyCDNStorage $storage
     * @param string $path
     * @return array|\WP_Error
     */
    protected function deleteFile($storage, $path)
    {
        try {
            if (empty($path)) {
                return new \WP_Error('missing_path', __('File path is required', 'fluent-player-pro'));
            }

            $result = $storage->deleteObject($path);

            if (is_wp_error($result)) {
                return $result;
            }

            return [
                'success' => true,
                'message' => __('File deleted successfully', 'fluent-player-pro')
            ];
        } catch (\Exception $e) {
            return new \WP_Error('delete_error', $e->getMessage());
        }
    }

    /**
     * Create a new folder in storage
     * @param BunnyCDNStorage $storage
     * @param string $path
     * @return array|\WP_Error
     */
    protected function createFolder($storage, $path)
    {
        try {
            if (empty($path)) {
                return new \WP_Error('missing_path', __('Folder path is required', 'fluent-player-pro'));
            }

            // Ensure path ends with a slash
            if (substr($path, -1) !== '/') {
                $path .= '/';
            }

            $result = $storage->createDirectory($path);

            if (is_wp_error($result)) {
                return $result;
            }

            return [
                'success' => true,
                'message' => __('Folder created successfully', 'fluent-player-pro'),
                'path' => $path
            ];
        } catch (\Exception $e) {
            return new \WP_Error('create_folder_error', $e->getMessage());
        }
    }

    /**
     * Get information about a specific file
     * @param BunnyCDNStorage $storage
     * @param string $path
     * @return array|\WP_Error
     */
    protected function getFileInfo($storage, $path)
    {
        try {
            if (empty($path)) {
                return new \WP_Error('missing_path', __('File path is required', 'fluent-player-pro'));
            }

            // Get directory and filename
            $pathInfo = pathinfo($path);
            $dirPath = Arr::get($pathInfo, 'dirname', '');
            if ($dirPath === '.') {
                $dirPath = '';
            } else {
                $dirPath .= '/';
            }

            $fileName = Arr::get($pathInfo, 'basename');

            // Get items in directory
            $items = $storage->getStorageObjects($dirPath);

            if (is_wp_error($items)) {
                return $items;
            }

            // Find the file
            $fileInfo = null;
            foreach ($items as $item) {
                if (Arr::get($item, 'ObjectName') === $fileName) {
                    $fileInfo = $item;
                    break;
                }
            }

            if (!$fileInfo) {
                return new \WP_Error('file_not_found', __('File not found', 'fluent-player-pro'));
            }

            $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            $videoExtensions = ['mp4', 'webm', 'mov', 'avi', 'mkv'];
            $isVideo = in_array($extension, $videoExtensions);

            return [
                'success' => true,
                'file' => [
                    'id' => md5($path),
                    'name' => $fileName,
                    'path' => $path,
                    'type' => $isVideo ? 'video' : 'file',
                    'size' => Arr::get($fileInfo, 'Length', 0),
                    'date' => Arr::get($fileInfo, 'LastChanged'),
                    'url' => $this->getPublicUrl($path)
                ]
            ];
        } catch (\Exception $e) {
            return new \WP_Error('file_info_error', $e->getMessage());
        }
    }

    /**
     * Get public URL for a file
     * @param string $path
     * @return string
     */
    protected function getPublicUrl($path)
    {
        $settings = $this->getSettings();
        $cdnHostname = Arr::get($settings, 'cdn_hostname');

        if (!empty($cdnHostname)) {
            // Remove protocol if user included it
            $cdnHostname = preg_replace('#^https?://#', '', rtrim($cdnHostname, '/'));
            return "https://{$cdnHostname}/{$path}";
        }

        return '';
    }

    /**
     * Get parent path from current path
     * @param string $currentPath
     * @return string
     */
    protected function getParentPath($currentPath)
    {
        if (empty($currentPath)) {
            return '';
        }

        $currentPath = rtrim($currentPath, '/');
        $parts = explode('/', $currentPath);

        // Remove the last part
        array_pop($parts);

        return !empty($parts) ? implode('/', $parts) . '/' : '';
    }
}
