<?php
if (!defined('ABSPATH')) {
    exit;
}

$router->namespace('FluentPlayerPro\App\Http\Controllers')->group(function($router) {
    require_once __DIR__ . '/api.php';
});
