<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * @var $router \FluentPlayer\Framework\Http\Router
 */

// BunnyCDN Pro Routes - These extend the free version's integration system
$router->withPolicy('\FluentPlayer\App\Http\Policies\MediaPolicy')->prefix('bunny/stream')->group(function ($router) {
    $router->get('libraries', 'BunnyCDNController@getLibraries');
    $router->get('videos', 'BunnyCDNController@getVideos');
    $router->post('videos', 'BunnyCDNController@createVideo');
    $router->post('videos/upload', 'BunnyCDNController@uploadVideo');
    $router->put('videos/{id}', 'BunnyCDNController@updateVideo');
    $router->delete('videos/{id}', 'BunnyCDNController@deleteVideo');
    $router->get('collections', 'BunnyCDNController@getCollections');
    $router->post('collections', 'BunnyCDNController@createCollection');
    $router->put('collections/{id}', 'BunnyCDNController@updateCollection');
    $router->delete('collections/{id}', 'BunnyCDNController@deleteCollection');
});

// BunnyCDN Storage Pro Routes
$router->withPolicy('\FluentPlayer\App\Http\Policies\MediaPolicy')->prefix('bunny/storage')->group(function ($router) {
    $router->get('videos', 'FluentPlayerPro\App\Http\Controllers\BunnyCDNStorageController@listVideos');
    $router->post('videos/upload', 'FluentPlayerPro\App\Http\Controllers\BunnyCDNStorageController@uploadVideo');
    $router->delete('videos/delete', 'FluentPlayerPro\App\Http\Controllers\BunnyCDNStorageController@deleteVideo');
    $router->get('video', 'FluentPlayerPro\App\Http\Controllers\BunnyCDNStorageController@getVideo');
    $router->post('directories', 'FluentPlayerPro\App\Http\Controllers\BunnyCDNStorageController@createDirectory');
});

// Public stream endpoint — no auth required; serves video to frontend visitors
$router->get('bunny/storage/stream', 'FluentPlayerPro\App\Http\Controllers\BunnyCDNStorageController@streamVideo');

// Cloudflare R2 Routes — server-proxied upload + browse/CRUD existing objects
$router->withPolicy('\FluentPlayer\App\Http\Policies\MediaPolicy')->prefix('r2')->group(function ($router) {
    $router->post('upload', 'FluentPlayerPro\App\Http\Controllers\R2Controller@uploadVideo');
    $router->get('objects', 'FluentPlayerPro\App\Http\Controllers\R2Controller@listObjects');
    $router->post('folder', 'FluentPlayerPro\App\Http\Controllers\R2Controller@createFolder');
    $router->post('folder/rename', 'FluentPlayerPro\App\Http\Controllers\R2Controller@renameFolder');
    $router->delete('folder', 'FluentPlayerPro\App\Http\Controllers\R2Controller@deleteFolder');
    $router->delete('object', 'FluentPlayerPro\App\Http\Controllers\R2Controller@deleteObject');
});

// Cloudflare Stream Routes — direct-creator upload, status poll, browse existing
$router->withPolicy('\FluentPlayer\App\Http\Policies\MediaPolicy')->prefix('cloudflare-stream')->group(function ($router) {
    $router->post('uploads', 'FluentPlayerPro\App\Http\Controllers\CloudflareStreamController@createUpload');
    $router->post('upload', 'FluentPlayerPro\App\Http\Controllers\CloudflareStreamController@uploadFromWpMedia');
    $router->get('videos', 'FluentPlayerPro\App\Http\Controllers\CloudflareStreamController@listVideos');
    $router->get('videos/{id}', 'FluentPlayerPro\App\Http\Controllers\CloudflareStreamController@getVideoStatus');
    $router->post('videos/{id}/rename', 'FluentPlayerPro\App\Http\Controllers\CloudflareStreamController@renameVideo');
    $router->delete('videos/{id}', 'FluentPlayerPro\App\Http\Controllers\CloudflareStreamController@deleteVideo');
});

// Public Cloudflare Stream webhook endpoint — verified via Webhook-Signature header
$router->post('cloudflare-stream/webhook', 'FluentPlayerPro\App\Http\Controllers\CloudflareStreamController@handleWebhook');

// Mux Routes
$router->withPolicy('\FluentPlayer\App\Http\Policies\MediaPolicy')->prefix('mux')->group(function ($router) {
    // Assets
    $router->get('assets', 'FluentPlayerPro\App\Http\Controllers\MuxController@getAssets');
    $router->get('assets/{id}', 'FluentPlayerPro\App\Http\Controllers\MuxController@getAsset');
    $router->post('assets', 'FluentPlayerPro\App\Http\Controllers\MuxController@createAsset');
    $router->put('assets/{id}', 'FluentPlayerPro\App\Http\Controllers\MuxController@updateAsset');
    $router->delete('assets/{id}', 'FluentPlayerPro\App\Http\Controllers\MuxController@deleteAsset');
    $router->put('assets/{id}/mp4-support', 'FluentPlayerPro\App\Http\Controllers\MuxController@updateMp4Support');

    // Direct uploads
    $router->post('uploads', 'FluentPlayerPro\App\Http\Controllers\MuxController@createUpload');
    // Server-side upload of a WordPress attachment (wp.media flow, like Bunny)
    $router->post('uploads/from-attachment', 'FluentPlayerPro\App\Http\Controllers\MuxController@uploadFromAttachment');
    $router->get('uploads/{id}', 'FluentPlayerPro\App\Http\Controllers\MuxController@getUploadStatus');

    // Tracks (subtitles)
    $router->post('assets/{id}/tracks', 'FluentPlayerPro\App\Http\Controllers\MuxController@createTrack');
    $router->delete('assets/{assetId}/tracks/{trackId}', 'FluentPlayerPro\App\Http\Controllers\MuxController@deleteTrack');
    $router->post('assets/{assetId}/tracks/{trackId}/generate-subtitles', 'FluentPlayerPro\App\Http\Controllers\MuxController@generateSubtitles');

    // Live streams
    $router->get('live-streams', 'FluentPlayerPro\App\Http\Controllers\MuxController@getLiveStreams');
    $router->post('live-streams', 'FluentPlayerPro\App\Http\Controllers\MuxController@createLiveStream');
    $router->get('live-streams/{id}', 'FluentPlayerPro\App\Http\Controllers\MuxController@getLiveStream');
    $router->delete('live-streams/{id}', 'FluentPlayerPro\App\Http\Controllers\MuxController@deleteLiveStream');

    // Delivery usage
    $router->get('delivery-usage', 'FluentPlayerPro\App\Http\Controllers\MuxController@getDeliveryUsage');

    // Auto captions
    $router->get('assets/{id}/captions', 'FluentPlayerPro\App\Http\Controllers\MuxController@getAssetCaptions');
});

// Mux sensitive infrastructure — admin only (manage_options). Signing keys sign
// playback tokens, stream-key reset disrupts a live stream, and playback
// restrictions control who can play. These must NOT fall under the editor-level
// authoring capability that now gates the free MediaPolicy.
$router->withPolicy('\FluentPlayer\App\Http\Policies\SettingsPolicy')->prefix('mux')->group(function ($router) {
    $router->post('signing-keys/generate', 'FluentPlayerPro\App\Http\Controllers\MuxController@createAndStoreSigningKey');
    $router->get('signing-keys', 'FluentPlayerPro\App\Http\Controllers\MuxController@getSigningKeys');
    $router->post('signing-keys', 'FluentPlayerPro\App\Http\Controllers\MuxController@createSigningKey');
    $router->delete('signing-keys/{id}', 'FluentPlayerPro\App\Http\Controllers\MuxController@deleteSigningKey');
    $router->post('live-streams/{id}/reset-stream-key', 'FluentPlayerPro\App\Http\Controllers\MuxController@resetStreamKey');
    $router->get('playback-restrictions', 'FluentPlayerPro\App\Http\Controllers\MuxController@getPlaybackRestrictions');
    $router->post('playback-restrictions', 'FluentPlayerPro\App\Http\Controllers\MuxController@createPlaybackRestriction');
    $router->delete('playback-restrictions/{id}', 'FluentPlayerPro\App\Http\Controllers\MuxController@deletePlaybackRestriction');
});

// Public Mux webhook endpoint — verified via Mux-Signature header
$router->post('mux/webhook', 'FluentPlayerPro\App\Http\Controllers\MuxController@handleWebhook');

// Gumlet (VOD + Live)
$router->withPolicy('\FluentPlayer\App\Http\Policies\MediaPolicy')->prefix('gumlet')->group(function ($router) {
    // Assets (VOD)
    $router->get('assets', 'FluentPlayerPro\App\Http\Controllers\GumletController@getVideos');
    $router->get('assets/{id}', 'FluentPlayerPro\App\Http\Controllers\GumletController@getVideo');
    $router->get('assets/{id}/status', 'FluentPlayerPro\App\Http\Controllers\GumletController@getStatus');
    $router->post('upload', 'FluentPlayerPro\App\Http\Controllers\GumletController@createUpload');
    $router->post('assets/{id}/rename', 'FluentPlayerPro\App\Http\Controllers\GumletController@renameVideo');
    $router->delete('assets/{id}', 'FluentPlayerPro\App\Http\Controllers\GumletController@deleteVideo');

    // Live streaming
    $router->post('live', 'FluentPlayerPro\App\Http\Controllers\GumletController@createLive');
    $router->get('live/{id}', 'FluentPlayerPro\App\Http\Controllers\GumletController@getLiveStatus');
    $router->delete('live/{id}', 'FluentPlayerPro\App\Http\Controllers\GumletController@deleteLive');
});

// Subtitle Pro Routes
$router->withPolicy('\FluentPlayer\App\Http\Policies\MediaPolicy')->prefix('media')->group(function ($router) {
    $router->post('{id}/subtitles', 'FluentPlayerPro\App\Http\Controllers\SubtitleController@uploadSubtitle');
    $router->delete('{id}/subtitles/{subtitleId}', 'FluentPlayerPro\App\Http\Controllers\SubtitleController@removeSubtitle');
    $router->get('{id}/youtube-captions', 'FluentPlayerPro\App\Http\Controllers\SubtitleController@getYouTubeCaptions');
    $router->post('{id}/youtube-captions', 'FluentPlayerPro\App\Http\Controllers\SubtitleController@importYouTubeCaptions');
    $router->post('{id}/youtube-storyboard', 'FluentPlayerPro\App\Http\Controllers\SubtitleController@generateYouTubeStoryboard');
});

$router->prefix('settings/license')
    ->withPolicy('\FluentPlayer\App\Http\Policies\SettingsPolicy')
    ->group(function ($router) {
        $router->get('/', 'FluentPlayerPro\App\Http\Controllers\LicenseController@getLicenseDetails');
        $router->post('/', 'FluentPlayerPro\App\Http\Controllers\LicenseController@activateLicense');
        $router->delete('/', 'FluentPlayerPro\App\Http\Controllers\LicenseController@deactivateLicense');
    });

// Timed Content Pro Routes
$router->withPolicy('\FluentPlayer\App\Http\Policies\MediaPolicy')->prefix('media')->group(function ($router) {
    $router->put('{id}/timed-content', 'FluentPlayerPro\App\Http\Controllers\TimedContentController@updateTimedContent');
});

$router->prefix('presets')->withPolicy('FluentPlayerPro\App\Http\Policies\PresetPolicy')->group(function ($router) {
    $router->post('/', 'FluentPlayerPro\App\Http\Controllers\PresetController@store');
    $router->put('{slug}', 'FluentPlayerPro\App\Http\Controllers\PresetController@update');
    $router->delete('{slug}', 'FluentPlayerPro\App\Http\Controllers\PresetController@delete');
});

// Analytics Routes
$router->prefix('analytics')->withPolicy('FluentPlayerPro\App\Http\Policies\AnalyticsPolicy')->group(function ($router) {
    // Dashboard analytics
    $router->get('/stats', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getStats');
    $router->get('/top-videos', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getTopVideos');
    $router->get('/top-users', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getTopUsers');
    $router->get('/location-breakdown', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getLocationBreakdown');
    $router->get('/new-returning-viewers', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getNewReturningViewers');
    $router->get('/performance-over-time/{scope?}/{id?}', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getPerformanceOverTime');
    $router->get('/retention', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getRetention');
    $router->get('/devices', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getDevices');

    // Video-specific analytics
    $router->get('/video/{id}/stats', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getVideoStats');
    $router->get('/video/{id}/retention', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getVideoRetention');
    $router->get('/video/{id}/devices', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getVideoDevices');
    $router->get('/video/{id}/location-breakdown', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getVideoLocationBreakdown');
    $router->get('/video/{id}/top-users', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getVideoTopViewers');

    // User-specific analytics
    $router->get('/user/{id}', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getUser');
    $router->get('/user/{id}/stats', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getUserStats');
    $router->get('/user/{id}/top-videos', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getUserTopVideos');
    $router->get('/user/{id}/retention', 'FluentPlayerPro\App\Http\Controllers\AnalyticsController@getUserRetention');
});

$router->prefix('playlist')->withPolicy('FluentPlayerPro\App\Http\Policies\PlaylistPolicy')->namespace('FluentPlayerPro\App\Http\Controllers')->group(function ($router) {
    $router->get('/', 'PlaylistController@get');
    $router->post('/do-bulk-action', 'PlaylistController@handleBulkActions');
    $router->get('{id}', 'PlaylistController@find');
    $router->post('/', 'PlaylistController@store');
    $router->put('{id}', 'PlaylistController@update');
    $router->put('{id}/restore', 'PlaylistController@restore');
    $router->delete('{id}/force', 'PlaylistController@forceDelete');
    $router->delete('{id}', 'PlaylistController@delete');
});
