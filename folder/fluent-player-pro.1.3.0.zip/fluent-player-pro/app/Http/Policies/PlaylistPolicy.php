<?php

namespace FluentPlayerPro\App\Http\Policies;

use FluentPlayer\App\Helpers\Helper;
use FluentPlayer\Framework\Foundation\Policy;
use FluentPlayer\Framework\Http\Request\Request;

class PlaylistPolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        // Playlists are authored content (a curated collection of media), so they
        // use the same editor-level authoring capability as media — not admin-only.
        // authoringCapability() lives in the free plugin; guard against an older
        // free build that predates it by falling back to the same editor-level
        // default (edit_others_posts) so playlists stay editor-authorable
        // regardless. edit_others_posts (Editor+) excludes Contributors/Authors,
        // matching the free default, because these routes are destructive and
        // have no per-playlist ownership check.
        $capability = method_exists(Helper::class, 'authoringCapability')
            ? Helper::authoringCapability()
            : 'edit_others_posts';

        return current_user_can($capability);
    }
}