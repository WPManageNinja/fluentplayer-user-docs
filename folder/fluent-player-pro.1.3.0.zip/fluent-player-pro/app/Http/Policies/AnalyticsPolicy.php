<?php

namespace FluentPlayerPro\App\Http\Policies;

use FluentPlayer\Framework\Foundation\Policy;
use FluentPlayer\Framework\Http\Request\Request;

class AnalyticsPolicy extends Policy
{
    public function verifyRequest(Request $request)
    {
        return current_user_can('manage_options');
    }
}

