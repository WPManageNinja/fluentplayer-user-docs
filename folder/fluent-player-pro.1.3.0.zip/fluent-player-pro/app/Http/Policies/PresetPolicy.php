<?php

namespace FluentPlayerPro\App\Http\Policies;

use FluentPlayer\Framework\Foundation\Policy;
use FluentPlayer\Framework\Http\Request\Request;

class PresetPolicy extends Policy
{
    /**
     * Check user permission for any method
     * @param  Request $request
     * @return Boolean
     */
    public function verifyRequest(Request $request)
    {
        return current_user_can('manage_options');
    }
}