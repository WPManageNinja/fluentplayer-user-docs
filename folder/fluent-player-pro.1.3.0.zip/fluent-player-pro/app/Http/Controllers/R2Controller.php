<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Integrations\R2Integration;
use FluentPlayerPro\App\Services\R2Service;

/**
 * Storage endpoints for the Cloudflare R2 provider used by the block editor:
 * presign a browser-direct upload, and list/browse existing bucket objects.
 *
 * The media record itself is created via the free `/media` endpoint (the block
 * posts the resulting key as `settings.r2`); this controller never writes posts.
 */
class R2Controller extends Controller
{
    /**
     * Upload a WordPress media-library attachment to R2 (bunny structure): the
     * server streams the local file straight to the bucket. Handles large files
     * with constant memory.
     */
    public function uploadVideo(Request $request)
    {
        $settings = $this->enabledSettings();
        if (is_wp_error($settings)) {
            return $this->sendError(['message' => $settings->get_error_message()], 400);
        }

        $attachmentId = (int) $request->get('attachment_id');
        if (!$attachmentId) {
            return $this->sendError(['message' => __('An attachment is required', 'fluent-player-pro')], 422);
        }

        $localPath = get_attached_file($attachmentId);
        if (!$localPath || !file_exists($localPath)) {
            return $this->sendError(['message' => __('The selected media file could not be found on the server', 'fluent-player-pro')], 404);
        }

        // Only allow video/audio media (hardened against scriptable extensions),
        // keyed off the real on-disk extension.
        $extension = strtolower(pathinfo($localPath, PATHINFO_EXTENSION));
        if (!in_array($extension, R2Service::allowedUploadExtensions(), true)) {
            return $this->sendError([
                'message' => sprintf(
                    /* translators: %s: comma-separated list of allowed file extensions */
                    __('Invalid file format. Allowed formats: %s', 'fluent-player-pro'),
                    implode(', ', R2Service::allowedUploadExtensions())
                ),
            ], 422);
        }

        // Don't use sanitize_file_name() — it collapses spaces to hyphens.
        // buildUploadKey() applies the (space-preserving) key-safe sanitization,
        // and the browse prefix (confined to the sub-folder) is preserved as-is.
        $filename = trim((string) $request->get('filename', basename($localPath)));
        if ($filename === '') {
            $filename = basename($localPath);
        }
        $prefix = $this->safePrefix((string) $request->get('prefix', ''), $settings);
        $key = R2Service::buildUploadKey($filename, $prefix);

        $result = R2Service::uploadFile($localPath, $key, $settings);
        if (is_wp_error($result)) {
            return $this->sendError(['message' => $result->get_error_message()], 400);
        }

        return $this->sendSuccess([
            'message'     => __('Video uploaded to Cloudflare R2', 'fluent-player-pro'),
            'key'         => $key,
            'bucket'      => Arr::get($settings, 'bucket'),
            'public_url'  => R2Service::publicUrl($key, $settings),
            'preview_url' => R2Service::previewUrl($key, $settings),
        ]);
    }

    /**
     * List objects (folders + playable files) for the browse-existing picker.
     */
    public function listObjects(Request $request)
    {
        $integration = new R2Integration();
        if (!$integration->isEnabled()) {
            return $this->sendError(['message' => __('Cloudflare R2 is not connected', 'fluent-player-pro')], 400);
        }

        $settings = $integration->getSettings();

        $prefix = (string) $request->get('prefix', '');
        // Hardening: no traversal, no NUL.
        $prefix = str_replace(['..', "\0"], '', $prefix);
        $prefix = ltrim($prefix, '/');

        // Confine browsing to the configured sub-folder (when set).
        $root = trim((string) Arr::get($settings, 'sub_folder'), '/');
        if ($root !== '') {
            $root .= '/';
            if ($prefix === '' || strpos($prefix, $root) !== 0) {
                $prefix = $root . $prefix;
            }
        }

        $result = R2Service::listObjects($prefix, $settings);
        if (is_wp_error($result)) {
            return $this->sendError(['message' => $result->get_error_message()], 400);
        }

        // Each file exposes its public URL (used as the media src + editor preview).
        foreach ($result['files'] as $i => $file) {
            $result['files'][$i]['public_url'] = R2Service::publicUrl($file['key'], $settings);
            $result['files'][$i]['preview_url'] = R2Service::previewUrl($file['key'], $settings);
        }

        return $this->sendSuccess($result);
    }

    /**
     * Create an (empty placeholder) folder under an optional prefix.
     */
    public function createFolder(Request $request)
    {
        $settings = $this->enabledSettings();
        if (is_wp_error($settings)) {
            return $this->sendError(['message' => $settings->get_error_message()], 400);
        }

        $name = trim(sanitize_text_field((string) $request->get('name', '')));
        if ($name === '') {
            return $this->sendError(['message' => __('A folder name is required', 'fluent-player-pro')], 422);
        }
        $prefix = $this->safePrefix((string) $request->get('prefix', ''), $settings);

        $key = R2Service::createFolder($name, $prefix, $settings);
        if (is_wp_error($key)) {
            return $this->sendError(['message' => $key->get_error_message()], 400);
        }

        return $this->sendSuccess(['message' => __('Folder created', 'fluent-player-pro'), 'key' => $key]);
    }

    /**
     * Delete a single object (file).
     */
    public function deleteObject(Request $request)
    {
        $settings = $this->enabledSettings();
        if (is_wp_error($settings)) {
            return $this->sendError(['message' => $settings->get_error_message()], 400);
        }

        $key = $this->safePrefix((string) $request->get('key', ''), $settings);
        if ($key === '') {
            return $this->sendError(['message' => __('An object key is required', 'fluent-player-pro')], 422);
        }

        $result = R2Service::deleteObject($key, $settings);
        if (is_wp_error($result)) {
            return $this->sendError(['message' => $result->get_error_message()], 400);
        }

        return $this->sendSuccess(['message' => __('File deleted', 'fluent-player-pro')]);
    }

    /**
     * Recursively delete a folder and everything under it.
     */
    public function deleteFolder(Request $request)
    {
        $settings = $this->enabledSettings();
        if (is_wp_error($settings)) {
            return $this->sendError(['message' => $settings->get_error_message()], 400);
        }

        $prefix = $this->safePrefix((string) $request->get('prefix', ''), $settings);
        if ($prefix === '') {
            return $this->sendError(['message' => __('A folder is required', 'fluent-player-pro')], 422);
        }

        $removed = R2Service::deleteFolder($prefix, $settings);
        if (is_wp_error($removed)) {
            return $this->sendError(['message' => $removed->get_error_message()], 400);
        }

        return $this->sendSuccess(['message' => __('Folder deleted', 'fluent-player-pro'), 'removed' => $removed]);
    }

    /**
     * Rename a folder (copy under the new name, delete the originals).
     */
    public function renameFolder(Request $request)
    {
        $settings = $this->enabledSettings();
        if (is_wp_error($settings)) {
            return $this->sendError(['message' => $settings->get_error_message()], 400);
        }

        $from = $this->safePrefix((string) $request->get('from', ''), $settings);
        $to = trim(sanitize_text_field((string) $request->get('to', '')));
        if ($from === '' || $to === '') {
            return $this->sendError(['message' => __('Source folder and new name are required', 'fluent-player-pro')], 422);
        }

        $moved = R2Service::renameFolder($from, $to, $settings);
        if (is_wp_error($moved)) {
            return $this->sendError(['message' => $moved->get_error_message()], 400);
        }

        return $this->sendSuccess(['message' => __('Folder renamed', 'fluent-player-pro'), 'moved' => $moved]);
    }

    /**
     * Return the connection settings if R2 is enabled, else a WP_Error.
     *
     * @return array|\WP_Error
     */
    private function enabledSettings()
    {
        $integration = new R2Integration();
        if (!$integration->isEnabled()) {
            return new \WP_Error('r2_disabled', __('Cloudflare R2 is not connected', 'fluent-player-pro'));
        }
        return $integration->getSettings();
    }

    /**
     * Sanitize a key/prefix from the request: no traversal, no NUL, confined to
     * the configured sub-folder.
     */
    private function safePrefix($value, $settings)
    {
        $value = str_replace(['..', "\0"], '', (string) $value);
        $value = ltrim($value, '/');

        $root = trim((string) Arr::get($settings, 'sub_folder'), '/');
        if ($root !== '' && $value !== '' && strpos($value, $root . '/') !== 0 && $value !== $root) {
            $value = $root . '/' . $value;
        }

        return $value;
    }
}
