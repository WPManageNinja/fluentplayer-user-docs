<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayer\Framework\Validator\Validator;
use FluentPlayerPro\App\Services\MuxService;

class MuxController extends Controller
{
    /**
     * Validate that a Mux resource ID matches the expected format.
     *
     * @param string $id
     * @return bool
     */
    private function isValidMuxId($id)
    {
        return strlen($id) <= 255 && (bool) preg_match('/^[a-zA-Z0-9_-]+$/', $id);
    }

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getAssets(Request $request, MuxService $service)
    {
        try {
            $data = Sanitizer::sanitize($request->all(), [
                'page'  => 'intval',
                'limit' => 'intval',
            ]);

            $params = [];
            if (!empty($data['page'])) {
                $params['page'] = $data['page'];
            }
            if (!empty($data['limit'])) {
                $params['limit'] = $data['limit'];
            }

            $assets = $service->getAssets($params);

            if (is_wp_error($assets)) {
                return $this->sendError(['message' => $assets->get_error_message()], 400);
            }

            return $assets;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getAsset(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('Asset ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $asset = $service->getAsset($id);

            if (is_wp_error($asset)) {
                return $this->sendError(['message' => $asset->get_error_message()], 400);
            }

            return $asset;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function createAsset(Request $request, MuxService $service)
    {
        try {
            $validation = Validator::make($request->all(), [
                'input_url' => 'nullable|url',
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors(),
                ], 400);
            }

            $data = Sanitizer::sanitize($request->all(), [
                'input_url'     => 'escUrlRaw',
                'playback_policy' => 'sanitizeTextField',
            ]);

            $input = [];
            if (!empty($data['input_url'])) {
                $input = [['url' => $data['input_url']]];
            }

            $policy = $data['playback_policy'] ?? 'public';
            if (!in_array($policy, ['public', 'signed'], true)) {
                $policy = 'public';
            }

            $params = [
                'playback_policy' => [$policy],
            ];

            $asset = $service->createAsset($input, $params);

            if (is_wp_error($asset)) {
                return $this->sendError(['message' => $asset->get_error_message()], 400);
            }

            return $asset;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function updateAsset(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $data = Sanitizer::sanitize($request->all(), [
                'passthrough' => 'sanitizeTextField',
            ]);

            // Sync meta.title with passthrough for Mux dashboard display
            if (!empty($data['passthrough'])) {
                $data['meta'] = [
                    'title' => $data['passthrough'],
                ];
            }

            $asset = $service->updateAsset($id, $data);

            if (is_wp_error($asset)) {
                return $this->sendError(['message' => $asset->get_error_message()], 400);
            }

            return $asset;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function deleteAsset(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('Asset ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->deleteAsset($id);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function updateMp4Support(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $data = Sanitizer::sanitize($request->all(), [
                'mp4_support' => 'sanitizeTextField',
            ]);

            $mp4Support = $data['mp4_support'] ?? 'standard';
            $allowedMp4 = ['standard', 'capped-1080p', 'audio-only', 'audio-only,capped-1080p', 'none'];
            if (!in_array($mp4Support, $allowedMp4, true)) {
                $mp4Support = 'standard';
            }

            $result = $service->updateMp4Support($id, $mp4Support);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Direct Uploads ──────────────────────────────────────────────

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function createUpload(Request $request, MuxService $service)
    {
        try {
            $passthrough = sanitize_text_field($request->get('passthrough', ''));
            $result = $service->createDirectUpload('', $passthrough);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * Upload a WordPress media-library attachment to Mux (the wp.media flow, like Bunny):
     * the server streams the attachment file straight to a Mux direct-upload URL. Returns
     * the upload id (to poll) plus is_audio derived from the source MIME.
     *
     * @param Request    $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function uploadFromAttachment(Request $request, MuxService $service)
    {
        try {
            $attachmentId = (int) $request->get('attachment_id');
            if (!$attachmentId) {
                return $this->sendError(['message' => __('An attachment is required', 'fluent-player-pro')], 422);
            }

            $attachment = get_post($attachmentId);
            $mimeType   = (string) get_post_mime_type($attachmentId);
            $isAudio    = MuxService::isAudioMime($mimeType);

            if (!$attachment || 'attachment' !== $attachment->post_type || !MuxService::isUploadableMime($mimeType)) {
                return $this->sendError([
                    'message' => __('Invalid attachment ID or not a supported media file', 'fluent-player-pro'),
                ], 422);
            }

            $passthrough = sanitize_text_field($request->get('passthrough', ''));
            $result = $service->uploadAttachment($attachmentId, $passthrough);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 422);
            }

            if (is_array($result)) {
                $result['is_audio'] = $isAudio;
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to upload to Mux', 'fluent-player-pro')], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getUploadStatus(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('Upload ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->getUploadStatus($id);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Tracks ──────────────────────────────────────────────────────

    /**
     * @param Request $request
     * @param string $id Asset ID
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function createTrack(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $validation = Validator::make($request->all(), [
                'url'           => 'required|url',
                'type'          => 'required|string',
                'text_type'     => 'required|string',
                'language_code' => 'required|string',
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors(),
                ], 400);
            }

            $data = Sanitizer::sanitize($request->all(), [
                'url'           => 'escUrlRaw',
                'type'          => 'sanitizeTextField',
                'text_type'     => 'sanitizeTextField',
                'language_code' => 'sanitizeTextField',
                'name'          => 'sanitizeTextField',
            ]);

            $result = $service->createTrack($id, $data);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $assetId
     * @param string $trackId
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function deleteTrack(Request $request, $assetId, $trackId, MuxService $service)
    {
        try {
            $assetId = sanitize_text_field($assetId);
            $trackId = sanitize_text_field($trackId);
            if (empty($assetId)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (empty($trackId)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($assetId)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($trackId)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->deleteTrack($assetId, $trackId);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return ['message' => 'Track deleted successfully'];
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $assetId
     * @param string $trackId
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function generateSubtitles(Request $request, $assetId, $trackId, MuxService $service)
    {
        try {
            $assetId = sanitize_text_field($assetId);
            $trackId = sanitize_text_field($trackId);
            if (empty($assetId)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (empty($trackId)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($assetId)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($trackId)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $data = Sanitizer::sanitize($request->all(), [
                'language_code' => 'sanitizeTextField',
                'name'          => 'sanitizeTextField',
            ]);

            $languageCode = $data['language_code'] ?? 'en';
            $name = $data['name'] ?? ucfirst($languageCode) . ' CC';

            $result = $service->generateSubtitles($assetId, $trackId, [
                'generated_subtitles' => [
                    [
                        'language_code' => $languageCode,
                        'name'          => $name,
                    ],
                ],
            ]);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Live Streams ────────────────────────────────────────────────

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getLiveStreams(Request $request, MuxService $service)
    {
        try {
            $result = $service->getLiveStreams();

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function createLiveStream(Request $request, MuxService $service)
    {
        try {
            $data = Sanitizer::sanitize($request->all(), [
                'playback_policy'  => 'sanitizeTextField',
                'reconnect_window' => 'intval',
                'latency_mode'     => 'sanitizeTextField',
                'name'             => 'sanitizeTextField',
            ]);

            $playbackPolicy = !empty($data['playback_policy']) ? $data['playback_policy'] : 'public';
            if (!in_array($playbackPolicy, ['public', 'signed'], true)) {
                $playbackPolicy = 'public';
            }

            $params = [
                'playback_policy'  => [$playbackPolicy],
                'new_asset_settings' => [
                    'playback_policy' => [$playbackPolicy],
                ],
            ];

            if (!empty($data['reconnect_window'])) {
                $params['reconnect_window'] = $data['reconnect_window'];
            }
            $allowedLatencyModes = ['low', 'reduced', 'standard'];
            if (!empty($data['latency_mode']) && in_array($data['latency_mode'], $allowedLatencyModes, true)) {
                $params['latency_mode'] = $data['latency_mode'];
            }
            if (!empty($data['name'])) {
                $params['passthrough'] = $data['name'];
            }

            $result = $service->createLiveStream($params);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getLiveStream(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->getLiveStream($id);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function deleteLiveStream(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->deleteLiveStream($id);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function resetStreamKey(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->resetStreamKey($id);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Playback Restrictions ───────────────────────────────────────

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getPlaybackRestrictions(Request $request, MuxService $service)
    {
        try {
            $result = $service->getPlaybackRestrictions();

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function createPlaybackRestriction(Request $request, MuxService $service)
    {
        try {
            $data = Sanitizer::sanitize($request->all(), [
                'allowed_domains' => 'sanitizeTextField',
            ]);

            $result = $service->createPlaybackRestriction($data);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function deletePlaybackRestriction(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->deletePlaybackRestriction($id);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Delivery Usage ──────────────────────────────────────────────

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getDeliveryUsage(Request $request, MuxService $service)
    {
        try {
            $data = Sanitizer::sanitize($request->all(), [
                'timeframe' => 'sanitizeTextField',
            ]);

            $params = [];
            if (!empty($data['timeframe'])) {
                $params['timeframe[]'] = $data['timeframe'];
            }

            $result = $service->getDeliveryUsage($params);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Signing Keys ────────────────────────────────────────────────

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getSigningKeys(Request $request, MuxService $service)
    {
        try {
            $result = $service->getSigningKeys();

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function createSigningKey(Request $request, MuxService $service)
    {
        try {
            $result = $service->createSigningKey();

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function deleteSigningKey(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->deleteSigningKey($id);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Signing Key Management ─────────────────────────────────────

    /**
     * Create a signing key and store it in integration settings
     *
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function createAndStoreSigningKey(Request $request, MuxService $service)
    {
        try {
            $result = $service->createAndStoreSigningKey();

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Auto Captions ──────────────────────────────────────────────

    /**
     * Get captions/subtitles from a Mux asset
     *
     * @param Request $request
     * @param string $id Asset ID
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function getAssetCaptions(Request $request, $id, MuxService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError(['message' => __('ID is required', 'fluent-player-pro')], 400);
            }
            if (!$this->isValidMuxId($id)) {
                return $this->sendError(['message' => __('Invalid ID format', 'fluent-player-pro')], 400);
            }

            $result = $service->getAssetCaptions($id);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return ['items' => $result];
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
            ], 500);
        }
    }

    // ─── Webhook ────────────────────────────────────────────────────

    /**
     * Handle Mux webhook events
     * Public endpoint — verified via Mux-Signature HMAC
     *
     * @param Request $request
     * @param MuxService $service
     * @return array|\WP_REST_Response
     */
    public function handleWebhook(Request $request, MuxService $service)
    {
        try {
            $rawBody = file_get_contents('php://input');
            $signature = $request->server('HTTP_MUX_SIGNATURE', '');

            if (empty($signature)) {
                return $this->sendError(['message' => 'Missing signature'], 401);
            }

            if (!$service->verifyWebhookSignature($rawBody, $signature)) {
                return $this->sendError(['message' => 'Invalid signature'], 401);
            }

            $payload = json_decode($rawBody, true);
            if (empty($payload) || !is_array($payload)) {
                return $this->sendError(['message' => 'Invalid payload'], 400);
            }

            $result = $service->handleWebhookEvent($payload);

            return ['success' => true, 'result' => $result];
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('Webhook processing failed', 'fluent-player-pro'),
            ], 500);
        }
    }
}
