<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Validator\ValidationException;
use FluentPlayerPro\App\Models\Playlist;
use FluentPlayerPro\App\Services\PlaylistService;
use FluentPlayerPro\App\Services\PlaylistSettingsHelper;

class PlaylistController extends Controller
{
    public function get(Request $request)
    {
        return Playlist::paginate($request);
    }

    public function find($id)
    {
        $playlist = Playlist::find($id);

        if (!$playlist) {
            return $this->sendError(['message' => 'Playlist not found'], 404);
        }

        return $this->sendSuccess($playlist);
    }

    public function store(Request $request)
    {
        try {
            $playlist = $this->preparePlaylist($request->all())
                ->save();
            return $this->sendSuccess(['success' => true, 'message' => 'Playlist saved', 'playlist' => $playlist]);
        } catch (ValidationException $e) {
            return $this->sendError($e->errors());
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to save playlist', 'fluent-player-pro')]);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $data = $request->all();
            $data['id'] = $id;
            $playlist = $this->preparePlaylist($data);
            $playlist->save();
            
            $updatedPlaylist = Playlist::find($id);
            return $this->sendSuccess(['success' => true, 'message' => 'Playlist Updated', 'playlist' => $updatedPlaylist]);
        } catch (ValidationException $e) {
            return $this->sendError($e->errors());
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to update playlist', 'fluent-player-pro')]);
        }
    }

    public function delete($id)
    {
        $playlist = Playlist::deleteById($id);

        if (!$playlist) {
            return $this->sendError(['message' => 'Playlist not found'], 404);
        }

        return $this->sendSuccess(['message' => __('Playlist moved to trash', 'fluent-player-pro')]);
    }

    public function restore($id)
    {
        $restored = Playlist::restoreById($id);

        if (!$restored) {
            return $this->sendError(['message' => 'Playlist not found'], 404);
        }

        return $this->sendSuccess(['message' => __('Playlist restored', 'fluent-player-pro')]);
    }

    public function forceDelete($id)
    {
        $deleted = Playlist::forceDeleteById($id);

        if (!$deleted) {
            return $this->sendError(['message' => 'Playlist not found'], 404);
        }

        return $this->sendSuccess(['message' => __('Playlist permanently deleted', 'fluent-player-pro')]);
    }

    /**
     * Apply one bulk action (trash / restore / delete / change status) to many playlists.
     *
     * @return \WP_REST_Response
     */
    public function handleBulkActions(Request $request)
    {
        $result = (new PlaylistService())->manageBulkActions($request);

        if (is_wp_error($result)) {
            $status = (int) ($result->get_error_data()['status'] ?? 422);
            return $this->sendError(['message' => $result->get_error_message()], $status);
        }

        return $this->sendSuccess($result);
    }

    protected function preparePlaylist($data)
    {
        if (!is_array($data)) {
            throw new \InvalidArgumentException('Data must be an array');
        }

        $settings = Arr::get($data, 'settings');
        if ($settings && !is_array($settings)) {
            $data['settings'] = \json_decode($settings, true);
        }

        $settings = Arr::get($data, 'settings', []);
        $data['settings'] = PlaylistSettingsHelper::sanitizeAndValidate($settings);

        // Auto-generate title if empty
        $title = trim(Arr::get($data, 'settings.title', ''));
        if (empty($title)) {
            $data['settings']['title'] = Playlist::generateDefaultTitle();
        }

        // Ensure 'medias' key exists and is an array before validation
        if (!isset($data['settings']['medias']) || !is_array($data['settings']['medias'])) {
            $data['settings']['medias'] = [];
        }

        $validationRules = [
            'settings'        => 'required|array',
            'settings.title'  => 'required|string',
            'settings.medias' => 'required|array',
        ];
        $validationMessages = [
            'settings'                 => 'Settings must be an array',
            'settings.medias.required' => 'The medias field is required.',
            'settings.medias.array'    => 'The medias must be an array.',
            'settings.title.required'  => 'Title is required.',
        ];

        // If request is not form dedicated playlist page, don't have medias
        $createNew = Arr::get($data, 'not_dedicated_page') === 'yes';
        if ($createNew) {
            unset($validationRules['settings.medias']);
            unset($validationMessages['settings.medias.required']);
            unset($validationMessages['settings.medias.array']);
        }

        $data = $this->validate($data, $validationRules, $validationMessages);

        $playlist = new Playlist();
        if ($id = Arr::get($data, 'id')) {
            $playlist->id = $id;
        }
        $playlist->title = Arr::get($data, 'settings.title');
        $playlist->settings = Arr::get($data, 'settings', []);

        return $playlist;
    }
}
