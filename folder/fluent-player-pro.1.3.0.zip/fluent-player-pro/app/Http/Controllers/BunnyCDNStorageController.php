<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Services\BunnyCDNStorageService;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayer\Framework\Validator\Validator;

class BunnyCDNStorageController extends Controller
{
    /**
     * List videos from BunnyCDN Storage
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function listVideos(Request $request)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'path' => 'nullable|string'
            ]);

            if ($validation->fails()) {
                wp_send_json([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors' => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'path' => 'sanitizeTextField'
            ]);
            
            // Get the current directory path from the request
            $currentPath = $data['path'] ?? '';

            // Security: prevent directory traversal
            if (BunnyCDNStorageService::hasPathTraversal($currentPath)) {
                wp_send_json([
                    'message' => __('Invalid file path', 'fluent-player-pro'),
                ], 400);
                return;
            }

            // Call service to list videos
            $result = BunnyCDNStorageService::listVideos($currentPath);
            
            if (is_wp_error($result)) {
                wp_send_json([
                    'message' => $result->get_error_message()
                ], 422);
            }

            wp_send_json([
                'current_path' => $result['current_path'],
                'directories'  => $result['directories'],
                'videos'       => $result['videos'],
                'parent_path'  => $result['parent_path']
            ], 200);
        } catch (\Exception $e) {
            wp_send_json([
                'message' => __('Failed to load Bunny storage videos', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * Upload a video to BunnyCDN Storage
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function uploadVideo(Request $request)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'attachment_id' => 'required|numeric',
                'file_name' => 'required|string',
                'directory' => 'nullable|string'
            ]);

            if ($validation->fails()) {
                wp_send_json([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors' => $validation->errors()
                ], 422);
            }

            $attachmentId = (int) $request->get('attachment_id');
            $fileName = $request->get('file_name');
            if ($fileName !== null && is_string($fileName)) {
                $fileName = str_replace(["\0", "\r", "\n"], '', $fileName);
                $fileName = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $fileName);
                $fileName = trim($fileName);
            }
            if ($fileName === null || $fileName === '') {
                wp_send_json([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors' => ['file_name' => [__('File name is required', 'fluent-player-pro')]]
                ], 422);
                return;
            }
            if (BunnyCDNStorageService::hasPathTraversal($fileName)) {
                wp_send_json([
                    'message' => __('Invalid file path', 'fluent-player-pro'),
                ], 400);
                return;
            }
            $directory = $request->get('directory');
            $directory = is_string($directory) ? trim(sanitize_text_field(wp_unslash($directory))) : '';
            if (BunnyCDNStorageService::hasPathTraversal($directory)) {
                wp_send_json([
                    'message' => __('Invalid file path', 'fluent-player-pro'),
                ], 400);
                return;
            }
            
            // Prepare target filename with directory
            if (!empty($directory)) {
                // Make sure directory has trailing slash but no leading slash
                $directory = trim($directory, '/') . '/';
                $targetFileName = $directory . $fileName;
            } else {
                $targetFileName = $fileName;
            }
            
            // Call service to upload video
            $uploadResult = BunnyCDNStorageService::uploadVideo($attachmentId, $targetFileName);

            if (is_wp_error($uploadResult)) {
                wp_send_json([
                    'message' => $uploadResult->get_error_message()
                ], 422);
            }

            // Get updated video list
            $videoList = BunnyCDNStorageService::listVideos($directory);
            $videos = is_wp_error($videoList) ? [] : ($videoList['videos'] ?? []);

            // Return the uploaded file info and refresh the directory listing
            wp_send_json([
                'message' => __('Video uploaded successfully', 'fluent-player-pro'),
                'file'    => Arr::get($uploadResult, 'file'),
                'videos'  => $videos
            ], 200);
        } catch (\Exception $e) {
            wp_send_json([
                'message' => __('Failed to upload video to Bunny storage', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * Delete a video from BunnyCDN Storage
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function deleteVideo(Request $request)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'file_name' => 'required|string'
            ]);

            if ($validation->fails()) {
                wp_send_json([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors' => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'file_name' => 'sanitizeTextField'
            ]);

            $fileName = $data['file_name'];

            // Security: prevent directory traversal
            if (BunnyCDNStorageService::hasPathTraversal($fileName)) {
                wp_send_json([
                    'message' => __('Invalid file path', 'fluent-player-pro'),
                ], 400);
                return;
            }

            // Call service to delete video
            $result = BunnyCDNStorageService::deleteVideo($fileName);

            if (is_wp_error($result)) {
                wp_send_json([
                    'message' => $result->get_error_message()
                ], 422);
            }

            wp_send_json([
                'message' => __('Video deleted successfully', 'fluent-player-pro')
            ], 200);
        } catch (\Exception $e) {
            wp_send_json([
                'message' => __('Failed to delete Bunny storage video', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * Stream a video file directly from BunnyCDN Storage
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function streamVideo(Request $request)
    {
        try {
            $validation = Validator::make($request->all(), [
                'file_name' => 'required|string'
            ]);

            if ($validation->fails()) {
                wp_send_json([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors' => $validation->errors()
                ], 422);
            }

            $fileName = trim(str_replace("\0", '', (string) $request->get('file_name')));

            // Security: prevent directory traversal
            if (BunnyCDNStorageService::hasPathTraversal($fileName)) {
                wp_send_json([
                    'message' => __('Invalid file path', 'fluent-player-pro'),
                ], 400);
                return;
            }

            $expires = sanitize_text_field((string) $request->get('expires', ''));
            $token   = sanitize_text_field((string) $request->get('token', ''));

            if (!BunnyCDNStorageService::verifyStreamToken($fileName, $expires, $token)) {
                wp_send_json([
                    'message' => __('Invalid or expired stream token', 'fluent-player-pro'),
                ], 403);
                return;
            }

            // Stream the video directly
            BunnyCDNStorageService::streamVideo($fileName);
            // This function will exit after outputting the file
        } catch (\Exception $e) {
            wp_send_json([
                'message' => __('An unexpected error occurred', 'fluent-player-pro'),
                'error' => __('Please try again later.', 'fluent-player-pro')
            ], 500);
        }
    }

    /**
     * Get a single video's information
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getVideo(Request $request)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'file_name' => 'required|string'
            ]);

            if ($validation->fails()) {
                wp_send_json([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors' => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'file_name' => 'sanitizeTextField'
            ]);

            $fileName = $data['file_name'];

            // Security: prevent directory traversal
            if (BunnyCDNStorageService::hasPathTraversal($fileName)) {
                wp_send_json([
                    'message' => __('Invalid file path', 'fluent-player-pro'),
                ], 400);
                return;
            }

            // Call service to get video
            $result = BunnyCDNStorageService::getVideo($fileName);

            if (is_wp_error($result)) {
                wp_send_json([
                    'message' => $result->get_error_message()
                ], 422);
            }

            wp_send_json([
                'video' => $result
            ], 200);
        } catch (\Exception $e) {
            wp_send_json([
                'message' => __('Failed to load Bunny storage video', 'fluent-player-pro'),
            ], 500);
        }
    }

    /**
     * Create a directory in BunnyCDN Storage
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function createDirectory(Request $request)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'name' => 'required|string|max:100',
                'current_path' => 'nullable|string'
            ]);

            if ($validation->fails()) {
                wp_send_json([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors' => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'name' => 'sanitizeTextField',
                'current_path' => 'sanitizeTextField'
            ]);

            $name = $data['name'];
            $currentPath = $data['current_path'] ?? '';

            // Security: prevent directory traversal
            if (BunnyCDNStorageService::hasPathTraversal($name) || BunnyCDNStorageService::hasPathTraversal($currentPath)) {
                wp_send_json([
                    'message' => __('Invalid file path', 'fluent-player-pro'),
                ], 400);
                return;
            }

            // Call service to create directory
            $result = BunnyCDNStorageService::createDirectory($name, $currentPath);

            if (is_wp_error($result)) {
                wp_send_json([
                    'message' => $result->get_error_message()
                ], 422);
            }

            wp_send_json($result, 200);
        } catch (\Exception $e) {
            wp_send_json([
                'message' => __('Failed to create Bunny storage directory', 'fluent-player-pro'),
            ], 500);
        }
    }

}
