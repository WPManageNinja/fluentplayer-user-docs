<?php

namespace FluentPlayerPro\App\Http\Controllers;

if (!defined('ABSPATH')) exit;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayerPro\App\Services\CloudflareStreamService;

/**
 * REST endpoints for the Cloudflare Stream provider: browser-direct uploads
 * (Direct Creator Upload), transcode-status polling, and listing existing videos.
 * Thin — business logic lives in CloudflareStreamService. Mirrors MuxController.
 */
class CloudflareStreamController extends Controller
{
    /**
     * Create a one-time Direct Creator Upload URL. The browser PUTs the file to
     * `uploadURL`, then polls getVideoStatus($uid) until ready.
     */
    public function createUpload(Request $request)
    {
        try {
            $opts = [];
            $maxDuration = intval($request->get('maxDurationSeconds', 0));
            if ($maxDuration > 0) {
                $opts['maxDurationSeconds'] = $maxDuration;
            }

            $result = CloudflareStreamService::createDirectUpload($opts);
            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return [
                'uploadURL' => \FluentPlayer\Framework\Support\Arr::get($result, 'uploadURL', ''),
                'uid'       => \FluentPlayer\Framework\Support\Arr::get($result, 'uid', ''),
            ];
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /** Stream a picked WP media-library attachment to Cloudflare (server-side). */
    public function uploadFromWpMedia(Request $request)
    {
        $attachmentId = absint($request->get('attachment_id', 0));
        if (!$attachmentId) {
            return $this->sendError(['message' => __('Attachment ID is required', 'fluent-player-pro')], 422);
        }
        $result = CloudflareStreamService::uploadFromAttachment($attachmentId);
        if (is_wp_error($result)) {
            return $this->sendError(['message' => $result->get_error_message()], 400);
        }
        return ['video' => $result];
    }

    /** Rename a video (Cloudflare meta.name). */
    public function renameVideo(Request $request, $id)
    {
        $id = sanitize_text_field($id);
        $name = sanitize_text_field($request->get('name', ''));
        if (empty($id) || $name === '') {
            return $this->sendError(['message' => __('Video ID and name are required', 'fluent-player-pro')], 422);
        }
        $result = CloudflareStreamService::renameVideo($id, $name);
        if (is_wp_error($result)) {
            return $this->sendError(['message' => $result->get_error_message()], 400);
        }
        return ['video' => $result];
    }

    /** Poll a video's transcode status (normalised). */
    public function getVideoStatus(Request $request, $id)
    {
        $id = sanitize_text_field($id);
        if (empty($id)) {
            return $this->sendError(['message' => __('Video ID is required', 'fluent-player-pro')], 422);
        }

        $result = CloudflareStreamService::getVideoStatus($id);
        if (is_wp_error($result)) {
            return $this->sendError(['message' => $result->get_error_message()], 400);
        }

        return ['video' => $result];
    }

    /** List existing account videos for the browse picker. */
    public function listVideos(Request $request)
    {
        $params = [
            'limit'  => min(1000, max(1, intval($request->get('limit', 50)))),
            'search' => sanitize_text_field($request->get('search', '')),
        ];

        $result = CloudflareStreamService::listVideos($params);
        if (is_wp_error($result)) {
            return $this->sendError(['message' => $result->get_error_message()], 400);
        }

        return ['videos' => $result];
    }

    /** Delete a video from the Cloudflare Stream account. */
    public function deleteVideo(Request $request, $id)
    {
        $id = sanitize_text_field($id);
        if (empty($id)) {
            return $this->sendError(['message' => __('Video ID is required', 'fluent-player-pro')], 422);
        }

        $result = CloudflareStreamService::client()->deleteVideo($id);
        if (is_wp_error($result)) {
            return $this->sendError(['message' => $result->get_error_message()], 400);
        }

        return ['deleted' => true];
    }

    /**
     * Public webhook receiver (transcode ready). Signature-verified via the
     * account's webhook secret; always 200s to prevent Cloudflare retries.
     */
    public function handleWebhook(Request $request)
    {
        $rawBody   = file_get_contents('php://input');
        $signature = $request->server('HTTP_WEBHOOK_SIGNATURE', '');
        $secret    = \FluentPlayer\Framework\Support\Arr::get(CloudflareStreamService::getSettings(), 'webhook_secret', '');

        if (!CloudflareStreamService::verifyWebhookSignature($rawBody, $signature, $secret)) {
            return $this->sendError(['message' => __('Invalid signature', 'fluent-player-pro')], 401);
        }

        $payload = json_decode($rawBody, true);
        if (is_array($payload)) {
            CloudflareStreamService::handleWebhookEvent($payload);
        }

        return ['received' => true];
    }
}
