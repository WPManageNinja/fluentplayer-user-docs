<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayerPro\App\Http\Controllers\Controller;
use FluentPlayer\App\Services\PresetService;
use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayer\Framework\Validator\ValidationException;

class PresetController extends Controller
{
    /**
    * Store a new preset
    *
    * @param Request $request
    */
    public function store(Request $request)
    {
        try {
            $data = $this->preparePreset($request->all());
            $slug = sanitize_title(Arr::get($data, 'name', 'custom'));
            if ($slug === '') {
                $slug = 'custom';
            }

            // Ensure unique slug
            $presets = PresetService::all();
            $baseSlug = $slug;
            $i = 1;
            while (Arr::get($presets, $slug)) {
                $slug = $baseSlug . '-' . $i++;
            }

            $presetData = [
                'name' => $data['name'],
                'slug' => $slug,
                'settings' => $data['settings'],
            ];
            $presetData['settings']['slug'] = $slug;

            PresetService::save($slug, $presetData);

            return $this->sendSuccess([
                'message' => __('Preset created successfully', 'fluent-player-pro'),
                'preset' => $presetData
            ]);
        } catch (ValidationException $e) {
            return $this->sendError($e->errors());
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to create preset', 'fluent-player-pro')]);
        }
    }

    /**
     * Update an existing preset
     *
     * @param Request $request
     * @param string $slug
     */
    public function update(Request $request, $slug)
    {
        try {
            $preset = PresetService::find($slug);
            if (!$preset) {
                return $this->sendError(['message' => __('Preset not found', 'fluent-player-pro')], 404);
            }

            $data = $this->preparePreset($request->all());

            $presetData = [
                'name' => $data['name'],
                'slug' => $slug, // slug is immutable
                'settings' => $data['settings'],
            ];
            $presetData['settings']['slug'] = $slug;

            PresetService::save($slug, $presetData);

            return $this->sendSuccess([
                'message' => __('Preset updated successfully', 'fluent-player-pro'),
                'preset' => $presetData
            ]);
        } catch (ValidationException $e) {
            return $this->sendError($e->errors());
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to update preset', 'fluent-player-pro')]);
        }
    }

    /**
     * Sanitize and validate preset data
     *
     * @param array $args
     * @return array
     * @throws ValidationException
     */
    protected function preparePreset($args)
    {
        $args['name'] = Sanitizer::sanitizeTextField(Arr::get($args, 'name', ''));
        $settings = json_decode(Arr::get($args, 'settings', ''), true);
        $args['settings'] = $this->sanitizePresetSettings($settings);

        $this->validate($args, [
            'name' => 'required|string|max:255',
            'settings' => 'required|array',
        ]);

        return $args;
    }


    public function delete($slug)
    {
        $preset = PresetService::find($slug);
        if (!$preset) {
            return $this->sendError(['message' => __('Preset not found', 'fluent-player-pro')], 404);
        }

        if (in_array($slug, PresetService::RESERVED_SLUGS)) {
            return $this->sendError([
                'message' => __('Cannot delete reserved preset', 'fluent-player-pro')
            ], 422);
        }

        PresetService::delete($slug);

        return $this->sendSuccess([
            'message' => __('Preset deleted successfully', 'fluent-player-pro')
        ]);
    }

    /**
     * Sanitize preset settings
     *
     * @param array $settings Raw settings array
     * @return array Sanitized settings array
     */
    protected function sanitizePresetSettings($settings)
    {
        $sanitizationRules = [
            // Basic preset info
            'slug' => 'sanitizeTextField',
            'skin' => 'sanitizeTextField',

            // Controls
            'controls.play' => 'rest_sanitize_boolean',
            'controls.volume' => 'rest_sanitize_boolean',
            'controls.fullscreen' => 'rest_sanitize_boolean',
            'controls.pip' => 'rest_sanitize_boolean',
            'controls.captions_toggle' => 'rest_sanitize_boolean',
            'controls.current_time' => 'rest_sanitize_boolean',
            'controls.playback_speed' => 'rest_sanitize_boolean',
            'controls.settings' => 'rest_sanitize_boolean',
            'controls.backward' => 'rest_sanitize_boolean',
            'controls.forward' => 'rest_sanitize_boolean',
            'controls.progress_bar' => 'rest_sanitize_boolean',

            // Behaviors
            'behaviors.autoplay' => 'rest_sanitize_boolean',
            'behaviors.muted_autoplay' => 'rest_sanitize_boolean',
            'behaviors.save_play_position' => 'rest_sanitize_boolean',
            'behaviors.plays_inline' => 'rest_sanitize_boolean',
            'behaviors.hide_top_controls' => 'rest_sanitize_boolean',
            'behaviors.hide_center_controls' => 'rest_sanitize_boolean',
            'behaviors.hide_bottom_controls' => 'rest_sanitize_boolean',
            'behaviors.on_video_end' => 'sanitizeTextField',

            // Context menu
            'context_menu.enabled' => 'rest_sanitize_boolean',
            'context_menu.items.copy_link' => 'rest_sanitize_boolean',
            'context_menu.items.copy_link_at_time' => 'rest_sanitize_boolean',
            'context_menu.items.loop' => 'rest_sanitize_boolean',
            'context_menu.items.playback_speed' => 'rest_sanitize_boolean',
            'context_menu.items.captions' => 'rest_sanitize_boolean',
            'context_menu.items.pip' => 'rest_sanitize_boolean',

            // Styles
            'styles.captions.enabled' => 'rest_sanitize_boolean',
            'styles.captions.font_size' => 'intval',
            'styles.captions.background' => 'sanitizeTextField',
            'styles.captions.color' => 'sanitizeTextField',

            // Action Bar
            'action_bar.enabled' => 'rest_sanitize_boolean',
            'action_bar.position' => 'sanitizeTextField',
            'action_bar.text' => 'sanitizeTextField',
            'action_bar.text_size' => 'intval',
            'action_bar.background_color' => 'sanitizeTextField',
            'action_bar.button_type' => 'sanitizeTextField',
            'action_bar.button_text' => 'sanitizeTextField',
            'action_bar.button_color' => 'sanitizeTextField',
            'action_bar.button_text_color' => 'sanitizeTextField',
            'action_bar.button_radius' => 'intval',
            'action_bar.button_link' => 'escUrlRaw',
            'action_bar.open_in_new_tab' => 'rest_sanitize_boolean',
            'action_bar.percentage_start' => 'intval',
            'action_bar.youtube_channel' => 'sanitizeTextField',
            'action_bar.button_count' => 'rest_sanitize_boolean',
            'action_bar.subscriber_count' => 'sanitizeTextField',
            'action_bar.close_button_color' => 'sanitizeTextField',
            'action_bar.close_button_text_color' => 'sanitizeTextField',
            'action_bar.show_close' => 'rest_sanitize_boolean',

            // Email Capture
            'email_capture.enabled' => 'rest_sanitize_boolean',
            'email_capture.percentage' => 'intval',
            'email_capture.allow_skip' => 'rest_sanitize_boolean',
            'email_capture.skip_if_crm_contact' => 'rest_sanitize_boolean',
            'email_capture.button_bg_color' => 'sanitizeTextField',
            'email_capture.button_color' => 'sanitizeTextField',
            'email_capture.border_radius' => 'intval',
            'email_capture.placeholder' => 'sanitizeTextField',
            'email_capture.headline' => 'sanitizeTextField',
            'email_capture.bottom_text' => 'sanitizeTextField',
            'email_capture.button_text' => 'sanitizeTextField',

            // Email providers - basic
            'email_capture.providers.*.enabled' => 'rest_sanitize_boolean',
            'email_capture.providers.*.type' => 'sanitizeTextField',

            // Email provider (type: email)
            'email_capture.providers.*.config.email_subject' => 'sanitizeTextField',
            'email_capture.providers.*.config.email_body' => 'ksesPost',

            // Mailchimp provider
            'email_capture.providers.*.config.list' => 'sanitizeTextField',
            'email_capture.providers.*.config.tags' => 'sanitizeTextField',

            // Webhook provider
            'email_capture.providers.*.config.webhook_id' => 'sanitizeTextField',
            'email_capture.providers.*.config.webhook_name' => 'sanitizeTextField',
            'email_capture.providers.*.config.webhook_url' => 'escUrlRaw',
            'email_capture.providers.*.config.webhook_method' => 'sanitizeTextField',
            'email_capture.providers.*.config.webhook_email_name' => 'sanitizeTextField',
            'email_capture.providers.*.config.webhook_headers.*' => 'sanitizeTextField',

            // FluentCRM provider
            'email_capture.providers.*.config.list_id' => 'sanitizeTextField',
            'email_capture.providers.*.config.tags.*' => 'sanitizeTextField',

            // Attachments
            'email_capture.providers.*.config.attachments.*.id' => 'intval',
            'email_capture.providers.*.config.attachments.*.url' => 'escUrlRaw',
            'email_capture.providers.*.config.attachments.*.name' => 'sanitizeTextField',
            'email_capture.providers.*.config.attachments.*.type' => 'sanitizeTextField',

            // CTA (Call to Action)
            'cta.enabled' => 'rest_sanitize_boolean',
            'cta.percentage' => 'intval',
            'cta.allow_skip' => 'rest_sanitize_boolean',
            'cta.content' => 'ksesPost',
            'cta.bg_color' => 'sanitizeTextField',
            'cta.text_color' => 'sanitizeTextField',
            'cta.completion_type' => 'sanitizeTextField',
            'cta.auto_dismiss_duration' => 'intval',
        ];

        return Sanitizer::sanitize($settings, $sanitizationRules);
    }
}
