<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayerPro\App\Services\PluginManager\FluentLicensing;

class LicenseController extends Controller
{
    public function activateLicense(Request $request)
    {
        try {
            $licenseKey = $request->getSafe('license_key', 'sanitize_text_field');
            $result = FluentLicensing::getInstance()->activate($licenseKey);

            if (is_wp_error($result)) {
                return $this->sendError([
                    'message' => $result->get_error_message(),
                ], 422);
            }

            $payload = [
                'message'       => __('Your Fluent Player Pro license has been activated successfully.', 'fluent-player-pro'),
                'license'       => $result,
                'admin_notices' => $this->adminNotices(),
            ];

            if (!empty($result['status']) && $result['status'] === 'valid') {
                $payload['notice'] = [
                    'id'      => 'fluent_player_pro_license_activated',
                    'html'    => '<div>' . __('Your Fluent Player Pro license has been activated successfully.', 'fluent-player-pro') . '</div>',
                    'timeout' => 5000,
                ];
            }

            return $this->sendSuccess($payload);
        } catch (\Exception $exception) {
            return $this->sendError([
                'message' => __('An unexpected error occurred while activating the license.', 'fluent-player-pro')
            ], 500);
        }
    }

    public function deactivateLicense()
    {
        try {
            $result = FluentLicensing::getInstance()->deactivate();

            if (is_wp_error($result)) {
                return $this->sendError([
                    'message' => $result->get_error_message(),
                ], 422);
            }

            return $this->sendSuccess([
                'message'       => __('Your Fluent Player Pro license has been deactivated.', 'fluent-player-pro'),
                'license'       => FluentLicensing::getInstance()->getStatus(),
                'admin_notices' => $this->adminNotices(),
            ]);
        } catch (\Exception $exception) {
            return $this->sendError([
                'message' => __('An unexpected error occurred while deactivating the license.', 'fluent-player-pro')
            ], 500);
        }
    }

    public function getLicenseDetails(Request $request)
    {
        try {
            $remoteFetch = rest_sanitize_boolean($request->get('refresh', false));
            $result = FluentLicensing::getInstance()->getStatus($remoteFetch);

            if (is_wp_error($result)) {
                return $this->sendError([
                    'message' => $result->get_error_message(),
                ], 422);
            }

            return $this->sendSuccess([
                'license'       => $result,
                'admin_notices' => $this->adminNotices(),
            ]);
        } catch (\Exception $exception) {
            return $this->sendError([
                'message' => __('An unexpected error occurred while fetching the license details.', 'fluent-player-pro')
            ], 500);
        }
    }

    /**
     * Current admin notices (same shape Free localizes), so the SPA can refresh
     * its in-app notices after a license change without a page reload.
     *
     * @return array
     */
    private function adminNotices()
    {
        return array_values(array_map(static function ($notice) {
            if (is_array($notice) && isset($notice['html'])) {
                $notice['html'] = wp_kses_post($notice['html']);
            }
            return $notice;
        }, (array) apply_filters('fluent_player/admin_notices', [])));
    }
}
