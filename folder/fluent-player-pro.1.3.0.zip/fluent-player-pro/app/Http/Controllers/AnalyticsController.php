<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\App\Models\Media;
use FluentPlayerPro\App\Services\AnalyticsService;
use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Validator\Validator;

class AnalyticsController extends Controller
{
    /**
     * Get general analytics stats
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getStats(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'date',
            'end_date'   => 'date'
        ]);

        if ($validator->fails()) {
            return $this->sendError([
                'message' => __('Invalid date format', 'fluent-player-pro'),
                'errors'  => $validator->errors()
            ], 422);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $stats = AnalyticsService::getDashboardStatsWithTrends($startDate, $endDate);

            return $this->sendSuccess($stats);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load analytics stats.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get top videos by views
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getTopVideos(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'date',
            'end_date'   => 'date',
            'limit'      => 'integer|min:1|max:100'
        ]);

        if ($validator->fails()) {
            return $this->sendError([
                'message' => __('Validation failed', 'fluent-player-pro'),
                'errors'  => $validator->errors()
            ], 422);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);
            $limit = absint($request->get('limit', 5));

            $topVideos = AnalyticsService::getTopVideos($startDate, $endDate, $limit);

            $mediaIds = $topVideos->pluck('media_id')->map(function ($id) {
                return (int) $id;
            })->unique()->values()->all();
            if (!empty($mediaIds)) {
                Media::batchLoadMediaSettings($mediaIds);
            }

            $enhancedVideos = [];
            foreach ($topVideos as $video) {
                $settings = Media::getMediaSettings($video->media_id);
                $title = Arr::get($settings, 'title', '');
                $thumbnail = Arr::get($settings, 'posterSrc', '');
                $views = (int) $video->views;
                $totalWatchTime = (float) ($video->total_watch_time ?? 0);
                $enhancedVideos[] = [
                    'media_id'           => $video->media_id,
                    'title'              => $title,
                    'thumbnail'          => $thumbnail,
                    'view_url'           => function_exists('get_permalink') ? get_permalink($video->media_id) : '',
                    'views'              => $video->views,
                    'total_watch_time'   => $video->total_watch_time,
                    'average_watch_time' => $views > 0 ? $totalWatchTime / $views : 0,
                    'completion_rate'    => round(min(100, (float) ($video->avg_percentage ?? 0)), 2)
                ];
            }

            return $this->sendSuccess($enhancedVideos);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load top videos.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get top users by watch time
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getTopUsers(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'date',
            'end_date'   => 'date',
            'limit'      => 'integer|min:1|max:100'
        ]);

        if ($validator->fails()) {
            return $this->sendError([
                'message' => __('Validation failed', 'fluent-player-pro'),
                'errors'  => $validator->errors()
            ], 422);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);
            $limit = absint($request->get('limit', 5));
            $data = AnalyticsService::getTopUsers($startDate, $endDate, $limit);
            return $this->sendSuccess($data);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load top users.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get video-specific stats
     *
     * @param Request $request
     * @param int $id Video ID
     * @return \WP_REST_Response
     */
    public function getVideoStats(Request $request, $id)
    {
        $mediaId = absint($id);
        if (!$mediaId) {
            return $this->sendError([
                'message' => __('Invalid video ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);
            $startTs = $startDate ? strtotime($startDate) : false;
            $endTs = $endDate ? strtotime($endDate) : false;
            $startDate = ($startTs !== false) ? gmdate('Y-m-d', $startTs) : null;
            $endDate = ($endTs !== false) ? gmdate('Y-m-d', $endTs) : null;

            $stats = AnalyticsService::getVideoStats($mediaId, $startDate, $endDate);

            return $this->sendSuccess($stats);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load video stats.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get video retention data
     *
     * @param Request $request
     * @param int $id Video ID
     * @return \WP_REST_Response
     */
    public function getVideoRetention(Request $request, $id)
    {
        $mediaId = absint($id);
        if (!$mediaId) {
            return $this->sendError([
                'message' => __('Invalid video ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $retentionData = AnalyticsService::getVideoRetention($mediaId, $startDate, $endDate);

            return $this->sendSuccess($retentionData);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load video retention data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get dashboard retention (aggregated across all videos in date range)
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getRetention(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'date',
            'end_date'   => 'date'
        ]);

        if ($validator->fails()) {
            return $this->sendError([
                'message' => __('Invalid date format', 'fluent-player-pro'),
                'errors'  => $validator->errors()
            ], 422);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $retentionResult = AnalyticsService::getDashboardRetention($startDate, $endDate);
            return $this->sendSuccess([
                'data'       => $retentionResult['data'],
                'duration'   => $retentionResult['duration'],
                'start_date' => $startDate,
                'end_date'   => $endDate
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load retention data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get video device breakdown
     *
     * @param Request $request
     * @param int $id Video ID
     * @return \WP_REST_Response
     */
    public function getVideoDevices(Request $request, $id)
    {
        $mediaId = absint($id);
        if (!$mediaId) {
            return $this->sendError([
                'message' => __('Invalid video ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $deviceData = AnalyticsService::getVideoDevices($mediaId, $startDate, $endDate);

            return $this->sendSuccess([
                'data'       => $deviceData,
                'start_date' => $startDate,
                'end_date'   => $endDate
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load video device data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get video location breakdown
     *
     * @param Request $request
     * @param int $id Video ID (media_id)
     * @return \WP_REST_Response
     */
    public function getVideoLocationBreakdown(Request $request, $id)
    {
        $mediaId = absint($id);
        if (!$mediaId) {
            return $this->sendError([
                'message' => __('Invalid video ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $locationData = AnalyticsService::getVideoLocationBreakdown($mediaId, $startDate, $endDate);

            return $this->sendSuccess([
                'data'       => $locationData,
                'start_date' => $startDate,
                'end_date'   => $endDate
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load video location data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get top users for a specific video
     *
     * @param Request $request
     * @param int $id Video ID (media_id)
     * @return \WP_REST_Response
     */
    public function getVideoTopViewers(Request $request, $id)
    {
        $mediaId = absint($id);
        if (!$mediaId) {
            return $this->sendError([
                'message' => __('Invalid video ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);
            $limit = absint($request->get('limit', 10));

            $data = AnalyticsService::getVideoTopViewers($mediaId, $startDate, $endDate, $limit);

            return $this->sendSuccess($data);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load video top users.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get users
     *
     * @param Request $request
     * @param int $id User ID
     * @return \WP_REST_Response
     */
    public function getUser(Request $request, $id)
    {
        $userId = absint($id);
        if (!$userId) {
            return $this->sendError([
                'message' => __('Invalid user ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            $stats = AnalyticsService::getUser($userId);
            return $this->sendSuccess($stats);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load user.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get user-specific stats
     *
     * @param Request $request
     * @param int $id User ID
     * @return \WP_REST_Response
     */
    public function getUserStats(Request $request, $id)
    {
        $userId = absint($id);
        if (!$userId) {
            return $this->sendError([
                'message' => __('Invalid user ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $stats = AnalyticsService::getUserStats($userId, $startDate, $endDate);

            return $this->sendSuccess($stats);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load user stats.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get user's top videos
     *
     * @param Request $request
     * @param int $id User ID
     * @return \WP_REST_Response
     */
    public function getUserTopVideos(Request $request, $id)
    {
        $userId = absint($id);
        if (!$userId) {
            return $this->sendError([
                'message' => __('Invalid user ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);
            $limit = absint($request->get('limit', 10));

            $topVideos = AnalyticsService::getUserTopVideos($userId, $startDate, $endDate, $limit);

            $mediaIds = $topVideos->pluck('media_id')->map(function ($id) {
                return (int) $id;
            })->unique()->values()->all();
            if (!empty($mediaIds)) {
                Media::batchLoadMediaSettings($mediaIds);
            }

            $enhancedVideos = [];
            foreach ($topVideos as $video) {
                $settings = Media::getMediaSettings($video->media_id);
                $title = Arr::get($settings, 'title', '');
                $thumbnail = Arr::get($settings, 'posterSrc', '');
                $enhancedVideos[] = [
                    'media_id'           => $video->media_id,
                    'title'              => $title,
                    'thumbnail'          => $thumbnail,
                    'views'              => $video->views,
                    'total_watch_time'   => $video->total_watch_time,
                    'average_watch_time' => $video->views > 0 ? $video->total_watch_time / $video->views : 0
                ];
            }

            return $this->sendSuccess($enhancedVideos);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load user top videos.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get user audience retention (aggregated across their top videos in date range)
     *
     * @param Request $request
     * @param int $id User ID
     * @return \WP_REST_Response
     */
    public function getUserRetention(Request $request, $id)
    {
        $userId = absint($id);
        if (!$userId) {
            return $this->sendError([
                'message' => __('Invalid user ID', 'fluent-player-pro')
            ], 400);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $retentionResult = AnalyticsService::getUserRetention($userId, $startDate, $endDate);

            return $this->sendSuccess([
                'data'       => $retentionResult['data'],
                'duration'   => $retentionResult['duration'],
                'start_date' => $startDate,
                'end_date'   => $endDate
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load user retention data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get location breakdown
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getLocationBreakdown(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'date',
            'end_date'   => 'date'
        ]);

        if ($validator->fails()) {
            return $this->sendError([
                'message' => __('Invalid date format', 'fluent-player-pro'),
                'errors'  => $validator->errors()
            ], 422);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $locationData = AnalyticsService::getLocationBreakdown($startDate, $endDate);

            return $this->sendSuccess([
                'data'       => $locationData,
                'start_date' => $startDate,
                'end_date'   => $endDate
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load location data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get dashboard device breakdown
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getDevices(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'date',
            'end_date'   => 'date'
        ]);

        if ($validator->fails()) {
            return $this->sendError([
                'message' => __('Invalid date format', 'fluent-player-pro'),
                'errors'  => $validator->errors()
            ], 422);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $deviceData = AnalyticsService::getDevices($startDate, $endDate);

            return $this->sendSuccess([
                'data'       => $deviceData,
                'start_date' => $startDate,
                'end_date'   => $endDate
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load device data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get new vs returning viewers
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getNewReturningViewers(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'date',
            'end_date'   => 'date'
        ]);

        if ($validator->fails()) {
            return $this->sendError([
                'message' => __('Invalid date format', 'fluent-player-pro'),
                'errors'  => $validator->errors()
            ], 422);
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request);

            $segmentationData = AnalyticsService::getNewVsReturningViewers($startDate, $endDate);

            return $this->sendSuccess([
                'data'       => $segmentationData,
                'start_date' => $startDate,
                'end_date'   => $endDate
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load new vs returning viewers data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get performance over time (dashboard, or scoped by video/user).
     * Routes: GET /performance-over-time | /performance-over-time/video/{id} | /performance-over-time/user/{id}
     *
     * @param Request $request
     * @param string|null $scope 'video' | 'user' | null (dashboard)
     * @param string|int|null $id Video ID or User ID when scope is set
     * @return \WP_REST_Response
     */
    public function getPerformanceOverTime(Request $request, $scope = null, $id = null)
    {
        $validator = Validator::make($request->all(), [
            'start_date' => 'date',
            'end_date'   => 'date',
            'metric'     => 'string|in:plays,watch_time'
        ]);

        if ($validator->fails()) {
            return $this->sendError([
                'message' => __('Validation failed', 'fluent-player-pro'),
                'errors'  => $validator->errors()
            ], 422);
        }

        $userId = null;
        $mediaId = null;
        if ($scope !== null && $scope !== '') {
            $scope = strtolower((string) $scope);
            if (!in_array($scope, ['video', 'user'], true)) {
                return $this->sendError([
                    'message' => __('Invalid scope for performance over time.', 'fluent-player-pro'),
                ], 400);
            }
            $idInt = absint($id);
            if (!$idInt) {
                return $this->sendError([
                    'message' => $scope === 'video' ? __('Invalid video ID', 'fluent-player-pro') : __('Invalid user ID', 'fluent-player-pro'),
                ], 400);
            }
            if ($scope === 'video') {
                $mediaId = $idInt;
            } else {
                $userId = $idInt;
            }
        }

        try {
            list($startDate, $endDate) = $this->getDateRangeFromRequest($request, 365);
            $metric = sanitize_text_field($request->get('metric', 'plays'));
            if (!in_array($metric, ['plays', 'watch_time'], true)) {
                $metric = 'plays';
            }

            $performanceData = AnalyticsService::getPerformanceOverTime($startDate, $endDate, $metric, $userId, $mediaId);

            return $this->sendSuccess([
                'data'       => $performanceData,
                'metric'     => $metric,
                'start_date' => $startDate,
                'end_date'   => $endDate
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => $this->formatErrorMessage($e, __('Failed to load performance over time data.', 'fluent-player-pro')),
            ], 500);
        }
    }

    /**
     * Get date range from request
     *
     * @param Request $request
     * @param int $defaultDays
     *
     * @return array{0: string, 1: string} [startDate, endDate]
     */
    private function getDateRangeFromRequest(Request $request, $defaultDays = 7)
    {
        $startDate = sanitize_text_field($request->get('start_date', gmdate('Y-m-d', strtotime("-{$defaultDays} days"))));
        $endDate = sanitize_text_field($request->get('end_date', gmdate('Y-m-d')));
        return [$startDate, $endDate];
    }

    /**
     * Format exception message for API: prefer getPrevious() message, strip SQL dump, return "Title - short error".
     *
     * @param \Exception $e
     * @param string $fallbackTitle
     * @return string
     */
    private function formatErrorMessage(\Exception $e, $fallbackTitle)
    {
        $detail = null;
        $previous = $e->getPrevious();
        if ($previous !== null && method_exists($previous, 'getMessage')) {
            $msg = $previous->getMessage();
            if ($msg !== null && $msg !== '') {
                $detail = $msg;
            }
        }
        if ($detail === null || $detail === '') {
            $detail = $e->getMessage();
        }
        
        if ($detail !== null && $detail !== '' && strpos($detail, ' (SQL:') !== false) {
            $detail = trim(substr($detail, 0, strpos($detail, ' (SQL:')));
        }
        if ($detail !== null && $detail !== '') {
            return $fallbackTitle . ' ' . $detail;
        }
        return $fallbackTitle;
    }
}

