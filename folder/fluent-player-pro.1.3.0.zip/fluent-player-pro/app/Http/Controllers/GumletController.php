<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayer\Framework\Validator\Validator;
use FluentPlayerPro\App\Services\GumletService;

class GumletController extends Controller
{
    /**
     * @param string $id
     * @return bool
     */
    private function isValidGumletId($id)
    {
        return strlen($id) <= 255 && (bool) preg_match('/^[a-zA-Z0-9_-]+$/', $id);
    }

    /**
     * @param Request $request
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function getVideos(Request $request, GumletService $service)
    {
        try {
            $data = Sanitizer::sanitize($request->all(), [
                'offset' => 'intval',
                'size'   => 'intval',
                'page'   => 'intval',
                'limit'  => 'intval',
            ]);

            // Accept either offset/size or page/limit (block sends page/limit).
            $size = !empty($data['size']) ? $data['size'] : (!empty($data['limit']) ? $data['limit'] : 20);
            $offset = isset($data['offset']) ? $data['offset'] : 0;
            if (empty($offset) && !empty($data['page']) && $data['page'] > 1) {
                $offset = ($data['page'] - 1) * $size;
            }

            $videos = $service->listVideos(['offset' => $offset, 'size' => $size]);

            if (is_wp_error($videos)) {
                return $this->sendError(['message' => $videos->get_error_message()], 400);
            }

            return $videos;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function getVideo(Request $request, $id, GumletService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id) || !$this->isValidGumletId($id)) {
                return $this->sendError(['message' => __('Invalid asset ID', 'fluent-player-pro')], 400);
            }

            $asset = $service->getVideo($id);
            if (is_wp_error($asset)) {
                return $this->sendError(['message' => $asset->get_error_message()], 400);
            }

            return $asset;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /**
     * Upload a WP media-library attachment to Gumlet (wp.media flow). The browser
     * sends only the attachment id; the server reads the file and streams it to
     * Gumlet's storage — no bytes are buffered/re-transferred in the browser
     * (matches the Cloudflare Stream flow) and it works on non-public sites.
     *
     * @param Request $request
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function createUpload(Request $request, GumletService $service)
    {
        try {
            $attachmentId = absint($request->get('attachment_id', 0));
            if (!$attachmentId) {
                return $this->sendError(['message' => __('A valid attachment is required', 'fluent-player-pro')], 400);
            }

            $attachment = get_post($attachmentId);
            $mimeType   = (string) get_post_mime_type($attachmentId);
            $isMedia    = strpos($mimeType, 'video/') === 0 || strpos($mimeType, 'audio/') === 0;
            if (!$attachment || 'attachment' !== $attachment->post_type || !$isMedia) {
                return $this->sendError(['message' => __('Invalid attachment ID or not a supported media file', 'fluent-player-pro')], 422);
            }

            $upload = $service->uploadFromAttachment($attachmentId);
            if (is_wp_error($upload)) {
                return $this->sendError(['message' => $upload->get_error_message()], 400);
            }

            // Gumlet transcodes audio into an extension-less HLS stream, so the source
            // MIME (known here) is the authoritative audio signal for the picker.
            if (is_array($upload)) {
                $upload['is_audio'] = strpos($mimeType, 'audio/') === 0;
            }

            return $upload;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function getStatus(Request $request, $id, GumletService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id) || !$this->isValidGumletId($id)) {
                return $this->sendError(['message' => __('Invalid asset ID', 'fluent-player-pro')], 400);
            }

            $status = $service->getAssetStatus($id);
            if (is_wp_error($status)) {
                return $this->sendError(['message' => $status->get_error_message()], 400);
            }

            return $status;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function renameVideo(Request $request, $id, GumletService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id) || !$this->isValidGumletId($id)) {
                return $this->sendError(['message' => __('Invalid asset ID', 'fluent-player-pro')], 400);
            }

            $title = sanitize_text_field($request->get('title', ''));
            if ($title === '') {
                return $this->sendError(['message' => __('Title is required', 'fluent-player-pro')], 400);
            }

            $result = $service->renameVideo($id, $title);
            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function deleteVideo(Request $request, $id, GumletService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id) || !$this->isValidGumletId($id)) {
                return $this->sendError(['message' => __('Invalid asset ID', 'fluent-player-pro')], 400);
            }

            $result = $service->deleteVideo($id);
            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    // ─── Live streaming ──────────────────────────────────────────────

    /**
     * @param Request $request
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function createLive(Request $request, GumletService $service)
    {
        try {
            $title = sanitize_text_field($request->get('title', ''));

            $resolution = (array) $request->get('resolution', []);
            $resolution = array_values(array_filter(array_map('sanitize_text_field', $resolution)));

            $result = $service->createLiveStream([
                'title'      => $title,
                'resolution' => $resolution,
            ]);

            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function getLiveStatus(Request $request, $id, GumletService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id) || !$this->isValidGumletId($id)) {
                return $this->sendError(['message' => __('Invalid live asset ID', 'fluent-player-pro')], 400);
            }

            $result = $service->getLiveStatus($id);
            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /**
     * @param Request $request
     * @param string $id
     * @param GumletService $service
     * @return array|\WP_REST_Response
     */
    public function deleteLive(Request $request, $id, GumletService $service)
    {
        try {
            $id = sanitize_text_field($id);
            if (empty($id) || !$this->isValidGumletId($id)) {
                return $this->sendError(['message' => __('Invalid live asset ID', 'fluent-player-pro')], 400);
            }

            $result = $service->deleteLiveStream($id);
            if (is_wp_error($result)) {
                return $this->sendError(['message' => $result->get_error_message()], 400);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }
}
