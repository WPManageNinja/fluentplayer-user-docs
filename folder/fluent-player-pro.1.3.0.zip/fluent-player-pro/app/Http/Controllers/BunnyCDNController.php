<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayerPro\App\Services\BunnyCDNService;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayer\Framework\Validator\Validator;

class BunnyCDNController extends Controller
{
    /**
     * Get videos from a specific library
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getVideos(Request $request, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id'    => 'required|numeric',
                'page'          => 'nullable|string',
                'per_page'      => 'nullable|string|max:100',
                'collection_id' => 'nullable|string',
                'search'        => 'nullable|string',
                'show_only_uncategorized' => 'nullable'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'library_id'    => 'sanitizeTextField',
                'page'          => 'sanitizeTextField',
                'per_page'      => 'sanitizeTextField',
                'collection_id' => 'sanitizeTextField',
                'search'        => 'sanitizeTextField',
                'show_only_uncategorized' => 'rest_sanitize_boolean'
            ]);

            // Prepare parameters
            $params = [
                'page'     => intval($data['page'] ?? 1),
                'per_page' => intval($data['per_page'] ?? 100)
            ];

            if (!empty($data['collection_id'])) {
                $params['collection_id'] = $data['collection_id'];
            }

            if (!empty($data['search'])) {
                $params['search'] = $data['search'];
            }

            if (!empty($data['show_only_uncategorized'])) {
                $params['show_only_uncategorized'] = true;
            }

            $videos = $bunnyService->getVideos($data['library_id'], $params);

            if (is_wp_error($videos)) {
                return $this->sendError([
                    'message' => $videos->get_error_message()
                ], 422);
            }

            return $videos;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to load Bunny videos', 'fluent-player-pro')], 422);
        }
    }

    /**
     * Get BunnyCDN libraries and setup stream if needed
     *
     * @param Request $request
     * @return \WP_REST_Response | Array
     */
    public function getLibraries(Request $request, BunnyCDNService $bunnyService)
    {
        try {
            $libraries = $bunnyService->getLibraries();

            if (is_wp_error($libraries)) {
                return $this->sendError([
                    'message' => $libraries->get_error_message()
                ], 422);
            }

            return $libraries;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to load Bunny libraries', 'fluent-player-pro')], 422);
        }
    }

    /**
     * Get collections from a specific library
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function getCollections(Request $request, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id' => 'required|numeric'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'library_id' => 'sanitizeTextField'
            ]);

            $collections = $bunnyService->getCollections($data['library_id']);

            if (is_wp_error($collections)) {
                return $this->sendError([
                    'message' => $collections->get_error_message(),
                ], 422);
            }

            return $collections;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to load Bunny collections', 'fluent-player-pro')], 500);
        }
    }

    /**
     * Create a new collection in a library
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function createCollection(Request $request, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id' => 'required|numeric',
                'name'       => 'required|string|max:100'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'library_id' => 'sanitizeTextField',
                'name'       => 'sanitizeTextField'
            ]);

            $collection = $bunnyService->createCollection($data['library_id'], $data['name']);

            if (is_wp_error($collection)) {
                return $this->sendError([
                    'message' => $collection->get_error_message(),
                ], 422);
            }

            return $collection;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to create Bunny collection', 'fluent-player-pro')], 500);
        }
    }

    /**
     * Create a new video in a library
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function createVideo(Request $request, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id'    => 'required|numeric',
                'title'         => 'required|string|max:200',
                'collection_id' => 'nullable|string'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            $data = Sanitizer::sanitize($request->all(), [
                'library_id'    => 'sanitizeTextField',
                'collection_id' => 'sanitizeTextField'
            ]);
            $title = $request->get('title');
            if ($title !== null && is_string($title)) {
                $title = str_replace(["\0", "\r", "\n"], '', $title);
                $title = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $title);
                $title = trim($title);
            }
            $title = ($title !== null && $title !== '') ? $title : null;
            if ($title === null) {

                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => ['title' => [__('Title is required', 'fluent-player-pro')]]
                ], 422);
            }
            $params = [];
            if (!empty($data['collection_id'])) {
                $params['collection_id'] = $data['collection_id'];
            }
            $video = $bunnyService->createVideo($data['library_id'], $title, $params);

            if (is_wp_error($video)) {
                return $this->sendError([
                    'message' => $video->get_error_message(),
                ], 422);
            }

            return $video;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to create Bunny video', 'fluent-player-pro')], 422);
        }
    }

    /**
     * Upload a video file to BunnyCDN
     *
     * @param Request $request
     * @return \WP_REST_Response
     */
    public function uploadVideo(Request $request, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id'    => 'required|numeric',
                'video_id'      => 'required|string',
                'attachment_id' => 'required|string'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'library_id'    => 'sanitizeTextField',
                'video_id'      => 'sanitizeTextField',
                'attachment_id' => 'sanitizeTextField'
            ]);

            // Verify attachment exists and is a media file (video or audio)
            $attachment = get_post(intval($data['attachment_id']));
            $mimeType = (string) get_post_mime_type($data['attachment_id']);
            $isMedia = strpos($mimeType, 'video/') === 0 || strpos($mimeType, 'audio/') === 0;
            if (!$attachment || 'attachment' !== $attachment->post_type || !$isMedia) {
                return $this->sendError([
                    'message' => __('Invalid attachment ID or not a supported media file', 'fluent-player-pro')
                ], 422);
            }

            $result = $bunnyService->uploadVideo($data['library_id'], $data['video_id'], intval($data['attachment_id']));

            if (is_wp_error($result)) {
                return $this->sendError([
                    'message' => $result->get_error_message(),
                ], 422);
            }

            // Persist the source media type (from the upload MIME) on the Bunny video.
            // Bunny transcodes audio into a real video, so this is the only authoritative
            // audio signal. Best-effort — never fail the upload if the metaTag write fails.
            $isAudio = strpos($mimeType, 'audio/') === 0;
            $bunnyService->markVideoMediaType($data['library_id'], $data['video_id'], $isAudio);

            if (is_array($result)) {
                $result['is_audio'] = $isAudio;
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to upload Bunny video', 'fluent-player-pro')], 500);
        }
    }

    /**
     * Delete a video from BunnyCDN
     *
     * @param Request $request
     * @param string $id
     * @return \WP_REST_Response
     */
    public function deleteVideo(Request $request, $id, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id' => 'required|numeric',
            ]);

            if ($validation->fails()) {

                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'library_id' => 'sanitizeTextField'
            ]);

            // Sanitize ID from URL
            $id = sanitize_text_field($id);

            if (empty($id)) {

                return $this->sendError([
                    'message' => __('Video ID is required', 'fluent-player-pro')
                ], 422);
            }

            $result = $bunnyService->deleteVideo($data['library_id'], $id);

            if (is_wp_error($result)) {

                return $this->sendError([
                    'message' => $result->get_error_message(),
                ], 422);
            }

            wp_send_json($result, 200);
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to delete Bunny video', 'fluent-player-pro')], 500);
        }
    }

    /**
     * Update a collection in a library
     *
     * @param Request $request
     * @param string $id Collection ID
     * @return \WP_REST_Response
     */
    public function updateCollection(Request $request, $id, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id' => 'required|numeric',
                'name'       => 'required|string|max:100'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'library_id' => 'sanitizeTextField',
                'name'       => 'sanitizeTextField'
            ]);

            // Sanitize ID from URL
            $id = sanitize_text_field($id);

            if (empty($id)) {

                return $this->sendError([
                    'message' => __('Collection ID is required', 'fluent-player-pro')
                ], 422);
            }

            $collection = $bunnyService->updateCollection($data['library_id'], $id, $data['name']);

            if (is_wp_error($collection)) {
                return $this->sendError([
                    'message' => $collection->get_error_message(),
                ], 422);
            }

            return $collection;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to update Bunny collection', 'fluent-player-pro')], 500);
        }
    }

    /**
     * Delete a collection from a library
     *
     * @param Request $request
     * @param string $id Collection ID
     * @return \WP_REST_Response
     */
    public function deleteCollection(Request $request, $id, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id' => 'required|numeric'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'library_id' => 'sanitizeTextField'
            ]);

            // Sanitize ID from URL
            $id = sanitize_text_field($id);

            if (empty($id)) {
                return $this->sendError([
                    'message' => __('Collection ID is required', 'fluent-player-pro')
                ], 422);
            }

            $result = $bunnyService->deleteCollection($data['library_id'], $id);

            if (is_wp_error($result)) {
                return $this->sendError([
                    'message' => $result->get_error_message(),
                ], 422);
            }

            return $result;
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to delete Bunny collection', 'fluent-player-pro')], 500);
        }
    }

    /**
     * Update a video in a library
     *
     * @param Request $request
     * @param string $id Video ID
     * @return \WP_REST_Response
     */
    public function updateVideo(Request $request, $id, BunnyCDNService $bunnyService)
    {
        try {
            // Validate request data
            $validation = Validator::make($request->all(), [
                'library_id' => 'required|numeric',
                'title'      => 'required|string|max:200'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            $data = Sanitizer::sanitize($request->all(), [
                'library_id' => 'sanitizeTextField'
            ]);
            $title = $request->get('title');
            if ($title !== null && is_string($title)) {
                $title = str_replace(["\0", "\r", "\n"], '', $title);
                $title = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $title);
                $title = trim($title);
            }
            $title = ($title !== null && $title !== '') ? $title : null;
            if ($title === null) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => ['title' => [__('Title is required', 'fluent-player-pro')]]
                ], 422);
            }
            $id = sanitize_text_field($id);
            if (empty($id)) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => ['id' => [__('Video ID is required', 'fluent-player-pro')]]
                ], 422);
            }
            $video = $bunnyService->updateVideo($data['library_id'], $id, [
                'title' => $title
            ]);

            if (is_wp_error($video)) {
                return $this->sendError([
                    'message' => $video->get_error_message(),
                ], 422);
            }

            wp_send_json($video, 200);
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('Failed to update Bunny video', 'fluent-player-pro')], 500);
        }
    }
}
