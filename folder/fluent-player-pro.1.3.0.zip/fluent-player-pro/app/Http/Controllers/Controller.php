<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayerPro\App\Core\App;
use FluentPlayer\App\Http\Controllers\Controller as BaseController;

abstract class Controller extends BaseController
{
    public function __construct()
    {
        parent::__construct(App::getInstance());
    }
}
