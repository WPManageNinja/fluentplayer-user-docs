<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\App\Models\Media;
use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayer\Framework\Support\Sanitizer;
use FluentPlayer\Framework\Validator\Validator;
use FluentPlayerPro\App\Services\SubtitleService;

class SubtitleController extends Controller
{
    protected function validateRequestedYouTubeVideoId($media, $requestedVideoId)
    {
        if (!SubtitleService::isValidYouTubeVideoId($requestedVideoId)) {
            return $this->sendError(['message' => __('A valid YouTube video ID is required', 'fluent-player-pro')], 422);
        }

        $savedVideoId = SubtitleService::getYouTubeVideoIdFromMedia($media);
        if (!$savedVideoId) {
            return $this->sendError(['message' => __('The saved media source does not contain a valid YouTube video ID.', 'fluent-player-pro')], 422);
        }

        if ($savedVideoId !== $requestedVideoId) {
            return $this->sendError(['message' => __('The requested YouTube video ID does not match the saved media source.', 'fluent-player-pro')], 422);
        }

        return null;
    }

    protected function makeSubtitleDedupKey($subtitle)
    {
        $trackId = (string) Arr::get($subtitle, 'trackId', Arr::get($subtitle, 'track_id', ''));
        if ($trackId !== '') {
            return 'track::' . $trackId;
        }

        $attachmentId = absint(Arr::get($subtitle, 'attachment_id', 0));
        if ($attachmentId) {
            return 'attachment::' . $attachmentId;
        }

        $id = (string) Arr::get($subtitle, 'id', '');
        if ($id !== '') {
            return 'id::' . $id;
        }

        $url = (string) Arr::get($subtitle, 'url', '');
        if ($url !== '') {
            return 'url::' . $url;
        }

        return 'langlabel::' . strtolower(
            (string) Arr::get($subtitle, 'language', '') . '::' . (string) Arr::get($subtitle, 'label', '')
        );
    }

    /**
     * Upload subtitle file for a media item
     *
     * @param Request $request
     * @param int $mediaId
     * @return \WP_REST_Response
     */
    public function uploadSubtitle(Request $request, $mediaId)
    {
        try {
            $mediaId = absint($mediaId);
            if (empty($mediaId)) {
                return $this->sendError(['message' => __('Media ID is required', 'fluent-player-pro')], 422);
            }

            $media = Media::find($mediaId);

            if (!$media) {
                return $this->sendError(['message' => __('Media not found', 'fluent-player-pro')], 404);
            }

            // Validate request data
            $validation = Validator::make($request->all(), [
                'attachment_id' => 'required|integer',
                'language'      => 'nullable|string|max:10',
                'label'         => 'nullable|string|max:100'
            ]);

            if ($validation->fails()) {
                return $this->sendError([
                    'message' => __('Validation failed', 'fluent-player-pro'),
                    'errors'  => $validation->errors()
                ], 422);
            }

            // Sanitize data
            $data = Sanitizer::sanitize($request->all(), [
                'attachment_id' => 'intval',
                'language'      => 'sanitizeTextField',
                'label'         => 'sanitizeTextField'
            ]);

            $attachmentId = Arr::get($data, 'attachment_id');
            $attachment = get_post($attachmentId);

            if (!$attachment || $attachment->post_type !== 'attachment') {
                return $this->sendError(['message' => __('Invalid attachment', 'fluent-player-pro')], 422);
            }

            // Validate file type
            $filePath = get_attached_file($attachmentId);
            $validation = SubtitleService::validateSubtitleFile($filePath);

            if (!$validation['valid']) {
                return $this->sendError(['message' => $validation['error']], 422);
            }

            $subtitleData = $this->processSubtitleFile($filePath, $attachmentId, $data);
            $settings = $media->settings;
            $subtitles = Arr::get($settings, 'subtitles', []);

            $subtitleId = uniqid('subtitle_');
            $subtitleData['id'] = $subtitleId;
            $subtitleData['attachment_id'] = $attachmentId;
            $subtitleData['url'] = wp_get_attachment_url($attachmentId);
            $subtitleData['filename'] = basename($filePath);
            $subtitleData['is_default'] = empty($subtitles);

            $existingKeys = array_map([$this, 'makeSubtitleDedupKey'], $subtitles);
            $subtitleKey = $this->makeSubtitleDedupKey($subtitleData);
            if (in_array($subtitleKey, $existingKeys, true)) {
                return $this->sendSuccess([
                    'success' => true,
                    'message' => __('This subtitle is already attached to the media.', 'fluent-player-pro'),
                    'data'    => null
                ]);
            }

            $subtitles[] = $subtitleData;
            $settings['subtitles'] = $subtitles;
            update_post_meta($media->ID, 'settings', $settings);
            SubtitleService::markSubtitleAttachmentAsManaged($attachmentId, $mediaId);

            return $this->sendSuccess([
                'success' => true,
                'message' => __('Subtitle uploaded successfully', 'fluent-player-pro'),
                'data'    => $subtitleData
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('Failed to upload subtitle', 'fluent-player-pro')
            ], 500);
        }
    }

    /**
     * Remove subtitle from a media item
     *
     * @param Request $request
     * @param string $mediaId
     * @param string $subtitleId
     * @return \WP_REST_Response | array
     */
    public function removeSubtitle(Request $request, $mediaId, $subtitleId)
    {
        try {
            $mediaId = absint($mediaId);
            $subtitleId = sanitize_text_field($subtitleId);

            if (empty($mediaId) || empty($subtitleId)) {
                return $this->sendError(['message' => __('Media ID & Subtitle ID is required', 'fluent-player-pro')], 422);
            }

            $media = Media::find($mediaId);

            if (!$media) {
                return $this->sendError(['message' => __('Media not found', 'fluent-player-pro')], 404);
            }

            $settings = $media->settings;
            $subtitles = Arr::get($settings, 'subtitles', []);
            $message = __('Subtitle removed successfully', 'fluent-player-pro');

            if (empty($subtitles)) {
                return $this->sendError(['message' => __('No subtitles found', 'fluent-player-pro')], 404);
            }

            $matchedSubtitle = null;
            $subtitles = array_filter($subtitles, function ($subtitle) use ($subtitleId, &$matchedSubtitle) {
                if (Arr::get($subtitle, 'id') === $subtitleId) {
                    $matchedSubtitle = $subtitle;
                    return false;
                }
                return true;
            });

            if (!$matchedSubtitle) {
                return $this->sendError(['message' => __('Subtitle not found', 'fluent-player-pro')], 404);
            }

            $attachmentId = absint(Arr::get($matchedSubtitle, 'attachment_id', 0));
            if ($attachmentId && SubtitleService::canDeleteManagedSubtitleAttachment($attachmentId, $mediaId)
                && !wp_delete_attachment($attachmentId, true)) {
                return $this->sendError(['message' => __('Failed to delete subtitle attachment', 'fluent-player-pro')], 500);
            }

            $settings['subtitles'] = array_values($subtitles);
            if (empty($settings['subtitles'])) {
                // Last-subtitle cleanup should only announce removal when managed storyboard state was actually cleared.
                $cleanup = SubtitleService::cleanupGeneratedStoryboard($settings, $mediaId);
                if (!empty($cleanup['warning'])) {
                    $message .= ' ' . $cleanup['warning'];
                } elseif (!empty($cleanup['cleared'])) {
                    $message .= ' ' . __('Hover preview removed.', 'fluent-player-pro');
                }
            }
            update_post_meta($media->ID, 'settings', $settings);

            return $this->sendSuccess([
                'success' => true,
                'message' => $message
            ]);
        } catch (\Exception $e) {
            return $this->sendError([
                'message' => __('Failed to remove subtitle', 'fluent-player-pro'),
            ], 500);
        }
    }

    public function getYouTubeCaptions(Request $request, $mediaId)
    {
        try {
            $mediaId = absint($mediaId);
            $videoId = sanitize_text_field($request->get('video_id', ''));

            if (empty($mediaId)) {
                return $this->sendError(['message' => __('Media ID is required', 'fluent-player-pro')], 422);
            }

            $media = Media::find($mediaId);
            if (!$media) {
                return $this->sendError(['message' => __('Media not found', 'fluent-player-pro')], 404);
            }

            if (!$this->isYouTubeMedia($media)) {
                return $this->sendError(['message' => __('YouTube subtitle import is only available for YouTube media.', 'fluent-player-pro')], 422);
            }

            $validationError = $this->validateRequestedYouTubeVideoId($media, $videoId);
            if ($validationError) {
                return $validationError;
            }

            $response = SubtitleService::listRemoteTracks($videoId);
            if (is_wp_error($response)) {
                return $this->sendError(['message' => $response->get_error_message()], (int) Arr::get($response->get_error_data(), 'status', 422));
            }

            $normalizedTracks = SubtitleService::normalizeRemoteTracks($response);

            return $this->sendSuccess([
                'success' => true,
                'tracks'  => $normalizedTracks,
            ]);
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    public function importYouTubeCaptions(Request $request, $mediaId)
    {
        try {
            $mediaId = absint($mediaId);
            $videoId = sanitize_text_field($request->get('video_id', ''));
            $tracks = $request->get('tracks', []);
            $generateStoryboard = rest_sanitize_boolean($request->get('generate_storyboard', true));

            if (empty($mediaId)) {
                return $this->sendError(['message' => __('Media ID is required', 'fluent-player-pro')], 422);
            }

            $media = Media::find($mediaId);

            if (!$media) {
                return $this->sendError(['message' => __('Media not found', 'fluent-player-pro')], 404);
            }

            if (!$this->isYouTubeMedia($media)) {
                return $this->sendError(['message' => __('YouTube subtitle import is only available for YouTube media.', 'fluent-player-pro')], 422);
            }

            $validationError = $this->validateRequestedYouTubeVideoId($media, $videoId);
            if ($validationError) {
                return $validationError;
            }

            if (!is_array($tracks)) {
                $tracks = json_decode($tracks, true) ?: [];
            }

            $selectedTrackIds = array_values(array_unique(array_filter(array_map('sanitize_text_field', $tracks))));
            if (empty($selectedTrackIds)) {
                return $this->sendError(['message' => __('At least one caption track is required', 'fluent-player-pro')], 422);
            }

            if (count($selectedTrackIds) > SubtitleService::MAX_REMOTE_TRACK_SELECTION) {
                return $this->sendError([
                    'message' => sprintf(
                        __('You can import up to %d subtitle tracks at once.', 'fluent-player-pro'),
                        SubtitleService::MAX_REMOTE_TRACK_SELECTION
                    ),
                    'max_track_selection' => SubtitleService::MAX_REMOTE_TRACK_SELECTION,
                ], 422);
            }

            $response = SubtitleService::downloadRemoteTracks($videoId, $selectedTrackIds);
            if (is_wp_error($response)) {
                $errorData = (array) $response->get_error_data();
                $remoteData = (array) Arr::get($errorData, 'data', []);

                return $this->sendError([
                    'message' => $response->get_error_message(),
                    'failed' => array_values((array) Arr::get($remoteData, 'detail.failed_track_ids', Arr::get($remoteData, 'failed_track_ids', []))),
                    'requested' => array_values((array) Arr::get($remoteData, 'detail.requested_track_ids', Arr::get($remoteData, 'requested_track_ids', []))),
                ], (int) Arr::get($errorData, 'status', 422));
            }

            $settings = $media->settings;
            $subtitles = Arr::get($settings, 'subtitles', []);
            $existingKeys = [];

            foreach ($subtitles as $subtitle) {
                $existingKeys[] = $this->makeSubtitleDedupKey($subtitle);
            }

            $imported = [];
            $skipped = [];
            $failed = array_values((array) Arr::get($response, 'failed', []));
            $mediaName = $media->post_title ?: Arr::get($media->settings, 'title', 'media');
            $storyboardQueued = false;
            $storyboardWarning = '';

            // Process tracks one by one so large VTT payloads are not duplicated
            // into a second normalized array before attachment creation starts.
            foreach ((array) Arr::get($response, 'tracks', []) as $rawTrack) {
                $track = SubtitleService::normalizeRemoteDownloadTrack($rawTrack);
                if (!$track) {
                    $failed[] = (string) Arr::get($rawTrack, 'label', Arr::get($rawTrack, 'track_id', ''));
                    continue;
                }

                $languageCode = Arr::get($track, 'language', '');
                $trackLabel = Arr::get($track, 'label', $languageCode);
                $subtitleKey = $this->makeSubtitleDedupKey([
                    'track_id' => Arr::get($track, 'track_id', ''),
                    'url'      => Arr::get($track, 'url', ''),
                    'language' => $languageCode,
                    'label'    => $trackLabel,
                ]);

                if (in_array($subtitleKey, $existingKeys, true)) {
                    $skipped[] = $trackLabel;
                    continue;
                }

                $attachment = SubtitleService::saveVttAsAttachment(
                    Arr::get($track, 'vtt_content', ''),
                    $languageCode,
                    $mediaId,
                    $mediaName,
                    $trackLabel,
                    Arr::get($track, 'filename', '')
                );
                if (!$attachment) {
                    $failed[] = $trackLabel;
                    continue;
                }

                $subtitleEntry = [
                    'id'            => 'yt_' . uniqid(),
                    'track_id'      => Arr::get($track, 'track_id', ''),
                    'trackId'       => Arr::get($track, 'track_id', ''),
                    'attachment_id' => Arr::get($attachment, 'id'),
                    'url'           => Arr::get($attachment, 'url', ''),
                    'filename'      => Arr::get($attachment, 'filename', $languageCode . '.vtt'),
                    'language'      => $languageCode,
                    'label'         => $trackLabel,
                    'is_default'    => empty($subtitles) && empty($imported),
                ];

                $subtitles[] = $subtitleEntry;
                $imported[] = $subtitleEntry;
                $existingKeys[] = $subtitleKey;
            }

            if ($generateStoryboard && empty(Arr::get($settings, 'thumbnails'))) {
                if (SubtitleService::isServiceConfigured()) {
                    $storyboardQueued = true;
                    $settings[\FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING] = 'queued';
                    $settings[\FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING] = __('Hover preview queued. Reload or refresh status in a moment.', 'fluent-player-pro');
                } else {
                    $storyboardWarning = __('Hover preview could not be queued because the subtitle service is not configured.', 'fluent-player-pro');
                    $settings[\FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING] = 'failed';
                    $settings[\FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING] = $storyboardWarning;
                }
            } elseif (empty(Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING))) {
                $settings[\FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING] = '';
                $settings[\FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING] = '';
            }

            $settings['subtitles'] = $subtitles;
            update_post_meta($media->ID, 'settings', $settings);

            if ($storyboardQueued) {
                $queued = SubtitleService::queueStoryboardGenerationForMedia($mediaId);
                $refreshedSettings = get_post_meta($media->ID, 'settings', true);
                if (is_array($refreshedSettings)) {
                    $settings = $refreshedSettings;
                }

                $storyboardStatus = (string) Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING, '');
                $storyboardQueued = $queued || in_array($storyboardStatus, ['queued', 'processing', 'completed'], true);

                if (!$storyboardQueued && empty(Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING, ''))) {
                    $storyboardWarning = __('Hover preview could not be queued right now.', 'fluent-player-pro');
                    $settings[\FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING] = 'failed';
                    $settings[\FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING] = $storyboardWarning;
                    update_post_meta($media->ID, 'settings', $settings);
                }
            }

            if (empty($imported)) {
                if (!empty($skipped) && empty($failed)) {
                    $message = sprintf(
                        _n(
                            '%d selected subtitle was already imported',
                            '%d selected subtitles were already imported',
                            count($skipped),
                            'fluent-player-pro'
                        ),
                        count($skipped)
                    );
                    if ($storyboardQueued) {
                        $message .= ' ' . (string) Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING, __('Hover preview queued. Reload or refresh status in a moment.', 'fluent-player-pro'));
                    } elseif ($storyboardWarning) {
                        $message .= ' ' . $storyboardWarning;
                    }

                    return $this->sendSuccess([
                        'success'   => true,
                        'message'   => $message,
                        'subtitles' => [],
                        'skipped'   => $skipped,
                        'failed'    => [],
                        'storyboard_status' => (string) Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING, ''),
                        'storyboard_message' => (string) Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING, ''),
                    ]);
                }

                $message = __('No subtitles could be imported.', 'fluent-player-pro');
                if (!empty($failed)) {
                    $message = sprintf(
                        __('None of the selected subtitles could be imported. Failed: %d.', 'fluent-player-pro'),
                        count($failed)
                    );
                }

                if (!empty($skipped)) {
                    $message .= ' ' . sprintf(
                        __('Already imported: %d.', 'fluent-player-pro'),
                        count($skipped)
                    );
                }

                return $this->sendError([
                    'message' => $message,
                    'failed' => $failed,
                    'skipped' => $skipped,
                    'requested' => $selectedTrackIds,
                ], 422);
            }

            $message = sprintf(
                __('%d subtitle(s) imported successfully', 'fluent-player-pro'),
                count($imported)
            );

            if (!empty($skipped) || !empty($failed)) {
                $message .= ' ' . sprintf(
                    __('Skipped: %d. Failed: %d.', 'fluent-player-pro'),
                    count($skipped),
                    count($failed)
                );
            }

            if ($storyboardQueued) {
                $message .= ' ' . (string) Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING, __('Hover preview queued. Reload or refresh status in a moment.', 'fluent-player-pro'));
            } elseif ($storyboardWarning) {
                $message .= ' ' . $storyboardWarning;
            }

            return $this->sendSuccess([
                'success'   => true,
                'message'   => $message,
                'subtitles' => $imported,
                'skipped'   => $skipped,
                'failed'    => $failed,
                'thumbnails' => Arr::get($settings, 'thumbnails', ''),
                'storyboard_attachment_id' => absint(Arr::get($settings, 'storyboard_attachment_id', 0)),
                'storyboard_status' => (string) Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING, ''),
                'storyboard_message' => (string) Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING, ''),
            ]);
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    public function generateYouTubeStoryboard(Request $request, $mediaId)
    {
        try {
            $mediaId = absint($mediaId);
            $requestedVideoId = sanitize_text_field($request->get('video_id', ''));

            if (empty($mediaId)) {
                return $this->sendError(['message' => __('Media ID is required', 'fluent-player-pro')], 422);
            }

            $media = Media::find($mediaId);
            if (!$media) {
                return $this->sendError(['message' => __('Media not found', 'fluent-player-pro')], 404);
            }

            if (!$this->isYouTubeMedia($media)) {
                return $this->sendError(['message' => __('YouTube hover preview generation is only available for YouTube media.', 'fluent-player-pro')], 422);
            }

            $validationError = $this->validateRequestedYouTubeVideoId($media, $requestedVideoId);
            if ($validationError) {
                return $validationError;
            }

            $settings = is_array($media->settings) ? $media->settings : [];
            if (!empty(Arr::get($settings, 'thumbnails'))) {
                return $this->sendSuccess([
                    'success' => true,
                    'message' => __('Hover preview is already enabled.', 'fluent-player-pro'),
                    'thumbnails' => (string) Arr::get($settings, 'thumbnails', ''),
                    'storyboard_attachment_id' => absint(Arr::get($settings, 'storyboard_attachment_id', 0)),
                    'storyboard_status' => 'completed',
                    'storyboard_message' => __('Hover preview is already enabled.', 'fluent-player-pro'),
                ]);
            }

            if (!SubtitleService::isServiceConfigured()) {
                return $this->sendError(['message' => __('Subtitle service is not configured.', 'fluent-player-pro')], 422);
            }

            $queued = SubtitleService::queueStoryboardGenerationForMedia($mediaId);
            $settings = get_post_meta($mediaId, 'settings', true);
            if (!is_array($settings)) {
                $settings = [];
            }

            $storyboardStatus = (string) Arr::get($settings, \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_SETTING, '');
            $storyboardMessage = (string) Arr::get(
                $settings,
                \FluentPlayerPro\App\Services\SubtitleService::STORYBOARD_STATUS_MESSAGE_SETTING,
                __('Hover preview queued. Reload or refresh status in a moment.', 'fluent-player-pro')
            );

            if (!$queued && !in_array($storyboardStatus, ['queued', 'processing', 'completed'], true)) {
                return $this->sendError(['message' => $storyboardMessage ?: __('Hover preview could not be queued right now.', 'fluent-player-pro')], 422);
            }

            return $this->sendSuccess([
                'success' => true,
                'message' => $storyboardMessage,
                'thumbnails' => (string) Arr::get($settings, 'thumbnails', ''),
                'storyboard_attachment_id' => absint(Arr::get($settings, 'storyboard_attachment_id', 0)),
                'storyboard_status' => $storyboardStatus,
                'storyboard_message' => $storyboardMessage,
            ]);
        } catch (\Exception $e) {
            return $this->sendError(['message' => __('An unexpected error occurred', 'fluent-player-pro')], 500);
        }
    }

    /**
     * Process subtitle file and extract metadata
     */
    protected function processSubtitleFile($filePath, $attachmentId, $data)
    {
        $language = Arr::get($data, 'language', 'en');
        $label = Arr::get($data, 'label', SubtitleService::getLanguageLabel($language));

        return [
            'language'    => $language,
            'label'       => $label,
            'uploaded_at' => current_time('mysql')
        ];
    }

    protected function isYouTubeMedia($media)
    {
        $settings = is_array($media->settings) ? $media->settings : [];

        return Arr::get($settings, 'provider') === 'youtube';
    }
}
