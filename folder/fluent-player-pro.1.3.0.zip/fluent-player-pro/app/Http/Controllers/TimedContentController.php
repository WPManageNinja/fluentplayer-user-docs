<?php

namespace FluentPlayerPro\App\Http\Controllers;

if (!defined('ABSPATH')) {
    exit;
}

use FluentPlayer\App\Models\Media;
use FluentPlayer\Framework\Http\Request\Request;

class TimedContentController extends Controller
{
    /**
     * Sync timed content blocks back to the CPT post.
     * Called from non-CPT pages when the user edits timed content and saves.
     */
    public function updateTimedContent(Request $request, $id)
    {
        $mediaId = absint($id);
        if (!$mediaId || !Media::find($mediaId)) {
            return $this->sendError(['message' => 'Media not found'], 404);
        }

        $post = get_post($mediaId);
        if (!$post) {
            return $this->sendError(['message' => 'Post not found'], 404);
        }

        // The route policy only requires manage_options; enforce a per-object
        // capability too so this write can never become an IDOR if that policy
        // is ever relaxed to a lower role.
        if (!current_user_can('edit_post', $mediaId)) {
            return $this->sendError([
                'message' => __('You are not allowed to edit this media.', 'fluent-player-pro')
            ], 403);
        }

        // Framework already strips slashes via stripslashes_deep()
        $timedContent = $request->get('timed_content', '');
        $timedContent = wp_kses_post($timedContent);

        // Preserve existing media block attributes from CPT
        $attrs = ['mediaId' => $mediaId];
        if (!empty($post->post_content)) {
            $blocks = parse_blocks($post->post_content);
            foreach ($blocks as $block) {
                if ($block['blockName'] === 'fluent-player/media') {
                    $attrs = !empty($block['attrs']) ? $block['attrs'] : $attrs;
                    break;
                }
            }
        }

        // Reconstruct post_content with updated timed content
        $attrsJson = wp_json_encode($attrs);
        $inner = trim($timedContent);
        $newContent = "<!-- wp:fluent-player/media {$attrsJson} -->"
                    . ($inner ? "\n{$inner}\n" : "\n")
                    . '<!-- /wp:fluent-player/media -->';

        $result = wp_update_post([
            'ID'           => $mediaId,
            'post_content' => $newContent,
        ], true);

        if (is_wp_error($result)) {
            return $this->sendError([
                'message' => $result->get_error_message()
            ], 500);
        }

        return $this->sendSuccess(['message' => __('Timed content updated', 'fluent-player-pro')]);
    }
}
