<?php

namespace FluentPlayerPro\App\Http\Controllers;

use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayerPro\App\Services\TagService;

class TagController extends Controller
{
    public function getTags(Request $request)
    {
        $bundle = TagService::getTagsBundle($request->get('with_counts'));

        return $this->sendSuccess($bundle);
    }

    public function createTag(Request $request)
    {
        $tagName = sanitize_text_field($request->get('tag_name'));

        if (empty($tagName)) {
            return $this->sendError(['message' => __('Tag name is required', 'fluent-player-pro')], 400);
        }

        $result = TagService::createTag($tagName);

        if (is_wp_error($result)) {
            $code = $result->get_error_code() === 'duplicate' ? 409 : 500;
            return $this->sendError(['message' => $result->get_error_message()], $code);
        }

        return $this->sendSuccess(['message' => __('Tag created successfully', 'fluent-player-pro')]);
    }

    public function renameTag(Request $request)
    {
        $oldName = sanitize_text_field($request->get('old_name'));
        $newName = sanitize_text_field($request->get('new_name'));

        if (empty($oldName) || empty($newName)) {
            return $this->sendError(['message' => __('Both old and new tag names are required', 'fluent-player-pro')], 400);
        }

        $result = TagService::renameTag($oldName, $newName);

        if (is_wp_error($result)) {
            $code = $result->get_error_code() === 'not_found' ? 404 : ($result->get_error_code() === 'duplicate' ? 409 : 500);
            return $this->sendError(['message' => $result->get_error_message()], $code);
        }

        return $this->sendSuccess(['message' => __('Tag renamed successfully', 'fluent-player-pro')]);
    }

    public function deleteTag(Request $request)
    {
        $tagName = sanitize_text_field($request->get('tag_name'));

        if (empty($tagName)) {
            return $this->sendError(['message' => __('Tag name is required', 'fluent-player-pro')], 400);
        }

        $result = TagService::deleteTag($tagName);

        if (is_wp_error($result)) {
            $code = $result->get_error_code() === 'not_found' ? 404 : 500;
            return $this->sendError(['message' => $result->get_error_message()], $code);
        }

        return $this->sendSuccess(['message' => __('Tag deleted successfully', 'fluent-player-pro')]);
    }
}
