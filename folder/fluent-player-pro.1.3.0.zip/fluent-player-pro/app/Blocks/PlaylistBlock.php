<?php

namespace FluentPlayerPro\App\Blocks;

if (!defined('ABSPATH')) {
    exit;
}

use FluentPlayer\App\Utils\Enqueuer\Enqueue;
use FluentPlayer\App\Utils\Enqueuer\Vite;
use FluentPlayer\Framework\Support\Arr;
use FluentPlayerPro\App\Hooks\Handlers\PlaylistShortcodeHandler;

class PlaylistBlock
{
    private static $isReactSupportAdded = false;
    private const ALLOWED_ORDERBY = ['date', 'title', 'modified', 'rand'];

    public static function register()
    {
        add_action('enqueue_block_editor_assets', [self::class, 'enqueueEditorAssets']);

        if (function_exists('register_block_type')) {
            register_block_type('fluent-player/playlist', [
                'api_version'     => 3,
                'title'           => __('Fluent Playlist', 'fluent-player-pro'),
                'description'     => __('Add a FluentPlayer playlist to your content', 'fluent-player-pro'),
                'category'        => 'media',
                'icon'            => 'playlist-video',
                'render_callback' => [self::class, 'render'],
                'editor_script'   => 'fluent-player-playlist-block-editor',
                'editor_style'    => 'fluent-player-playlist-block-editor-style',
                'attributes'      => [
                    'playlistId' => [
                        'type' => 'number'
                    ],
                    'sourceType' => [
                        'type'    => 'string',
                        'default' => 'playlist'
                    ],
                    'tags' => [
                        'type'    => 'array',
                        'default' => []
                    ],
                    'query' => [
                        'type'    => 'object',
                        'default' => [
                            'limit'   => 20,
                            'orderby' => 'date',
                            'order'   => 'DESC'
                        ]
                    ],
                    'settings' => [
                        'type'    => 'object',
                        'default' => []
                    ],
                    'align' => [
                        'type'    => 'string',
                        'default' => ''
                    ],
                    'className' => [
                        'type'    => 'string',
                        'default' => ''
                    ]
                ],
                'supports'        => [
                    'html'  => false,
                    'align' => ['wide', 'full'],
                ],
            ]);
        }
    }
	
	/**
	 * Enqueue toolbar script for block editor
	 */
	public static function enqueueToolbarScript()
	{
		global $post_type, $pagenow;
		
		if (!in_array($pagenow, ['post.php', 'post-new.php']) || $post_type !== 'fluent_playlist') {
			return;
		}
		Enqueue::script(
			'fluent-player-media-toolbar',
			'blocks/mediaToolbar.jsx',
			['wp-components', 'wp-data', 'wp-element', 'wp-i18n', 'wp-editor'],
			FLUENT_PLAYER_PRO_VERSION,
			true
		);

		// Destination for the editor "Back" button (replaces the close/site-icon).
		// Playlists return to the playlists list in the Fluent Player admin app.
		wp_localize_script('fluent-player-media-toolbar', 'fluentPlayerToolbar', self::getBackButtonVars());
	}

	/**
	 * Localize payload for the editor "Back" button on the playlist CPT — the link
	 * returns to the Fluent Player playlists list. (Free provides its own payload
	 * pointing at #/ for the media CPT.)
	 *
	 * @return array{backUrl:string, backLabel:string}
	 */
	public static function getBackButtonVars()
	{
		return [
			'backUrl'   => admin_url('admin.php?page=fluent-player#/playlists'),
			'backLabel' => __('Back', 'fluent-player-pro'),
		];
	}

    public static function enqueueEditorAssets()
    {
        if (!is_admin() && !wp_is_block_theme()) {
            return;
        }
        
        if (is_admin()) {
            $current_screen = function_exists('get_current_screen') ? get_current_screen() : null;
            if ($current_screen && !$current_screen->is_block_editor()) {
                return;
            }
        }
        
        Enqueue::script(
            'fluent-player-playlist-block-editor',
            'blocks/playlist/fluent-playlist-block.jsx',
            [
                'wp-blocks',
                'wp-element',
                'wp-i18n',
                'wp-components',
                'wp-block-editor',
                'wp-api-fetch',
                'jquery-ui-sortable',
            ],
            FLUENT_PLAYER_PRO_VERSION,
            true
        );

        Enqueue::style(
            'fluent-player-playlist-block-editor-style',
            'scss/fluent-player-playlist-block.scss',
            [],
            FLUENT_PLAYER_PRO_VERSION
        );

        self::addReactSupport();
		self::enqueueToolbarScript();
    }

    public static function render($attributes)
    {
        $sourceType = sanitize_key(Arr::get($attributes, 'sourceType', 'playlist'));

        if ($sourceType !== 'tags' && !absint(Arr::get($attributes, 'playlistId'))) {
            return '<div class="fluent-player-empty">' .
                   esc_html__('Please select a playlist to display.', 'fluent-player-pro') .
                   '</div>';
        }

        $callback = null;
        $className = trim((string) Arr::get($attributes, 'className', ''));
        if ($className !== '') {
            $classNames = preg_split('/\s+/', $className);
            $className = implode(' ', array_filter(array_map('sanitize_html_class', $classNames)));

            $callback = function ($classes) use ($className) {
                return trim($classes . ' ' . $className);
            };
            add_filter('fluent_player/playlist_layout_classes', $callback);
        }

        if ($sourceType === 'tags') {
            $output = self::renderTagSource($attributes);
        } else {
            $output = do_shortcode('[fluentplaylist id="' . absint(Arr::get($attributes, 'playlistId')) . '"]');
        }

        if ($callback) {
            remove_filter('fluent_player/playlist_layout_classes', $callback);
        }

        $align = Arr::get($attributes, 'align', '');
        if (!empty($align)) {
            $output = '<div class="align' . esc_attr($align) . '">' . $output . '</div>';
        }

        return $output;
    }

    /**
     * Render playlist by tags source.
     *
     * @param array $attributes
     * @return string
     */
    private static function renderTagSource($attributes)
    {
        $tags = [];
        $tagsAttribute = Arr::get($attributes, 'tags', []);
        if (!empty($tagsAttribute)) {
            $tags = array_values(array_filter(array_map('sanitize_text_field', $tagsAttribute)));
        }

        if (empty($tags)) {
            return '<div class="fluent-player-empty">' .
                esc_html__('Please select at least one tag to display playlist by tags.', 'fluent-player-pro') .
                '</div>';
        }

        $queryAttribute = Arr::get($attributes, 'query', []);
        $limit = min(max(absint(Arr::get($queryAttribute, 'limit', 20)), 1), 100);
        $orderby = sanitize_key(Arr::get($queryAttribute, 'orderby', 'date'));
        if (!in_array($orderby, self::ALLOWED_ORDERBY, true)) {
            $orderby = 'date';
        }
        $order = strtoupper(sanitize_text_field(Arr::get($queryAttribute, 'order', 'DESC'))) === 'ASC' ? 'ASC' : 'DESC';

        $settingsAttribute = Arr::get($attributes, 'settings', []);

        return (new PlaylistShortcodeHandler())->handle([
            'tags'     => $tags,
            'limit'    => $limit,
            'orderby'  => $orderby,
            'order'    => $order,
            'settings' => $settingsAttribute
        ]);
    }

    private static function addReactSupport()
    {
        if (!self::$isReactSupportAdded && Vite::isOnDevMode()) {
            Enqueue::script(
                'react-support-playlist',
                'blocks/reactSupport.jsx',
                ['wp-blocks', 'wp-components']
            );
            self::$isReactSupportAdded = true;
        }
    }
}
