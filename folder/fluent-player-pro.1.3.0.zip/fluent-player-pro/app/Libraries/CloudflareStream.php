<?php

namespace FluentPlayerPro\App\Libraries;

if (!defined('ABSPATH')) exit;

use FluentPlayer\Framework\Support\Arr;

/**
 * Thin client for the Cloudflare Stream API (account-scoped, Bearer token).
 * Mirrors the Libraries/Mux.php pattern. Every call returns the unwrapped
 * `result` payload or a WP_Error.
 *
 * @see https://developers.cloudflare.com/api/operations/stream-videos-list-videos
 */
class CloudflareStream
{
    const API_BASE_URL = 'https://api.cloudflare.com/client/v4';

    /** @var string */
    protected $accountId;

    /** @var string */
    protected $apiToken;

    public function __construct($accountId, $apiToken)
    {
        $this->accountId = $accountId;
        $this->apiToken  = $apiToken;
    }

    /** List videos in the account. @return array|\WP_Error */
    public function listVideos($params = [])
    {
        $query = [];
        if (!empty($params['limit'])) {
            $query['per_page'] = intval($params['limit']);
        }
        if (!empty($params['search'])) {
            $query['search'] = sanitize_text_field($params['search']);
        }
        $endpoint = 'stream';
        if ($query) {
            $endpoint .= '?' . http_build_query($query);
        }
        return $this->request('GET', $endpoint);
    }

    /** Fetch a single video by uid. @return array|\WP_Error */
    public function getVideo($uid)
    {
        return $this->request('GET', 'stream/' . rawurlencode($uid));
    }

    /**
     * Create a one-time Direct Creator Upload URL (browser uploads straight to
     * Cloudflare, then we poll the uid for readyToStream).
     * @return array|\WP_Error  { uploadURL, uid }
     */
    public function createDirectUpload($body = [])
    {
        $defaults = ['maxDurationSeconds' => 3600];
        return $this->request('POST', 'stream/direct_upload', array_merge($defaults, $body));
    }

    /** Delete a video by uid. @return array|\WP_Error */
    public function deleteVideo($uid)
    {
        return $this->request('DELETE', 'stream/' . rawurlencode($uid));
    }

    /** Update a video's metadata (e.g. name). @return array|\WP_Error */
    public function updateVideo($uid, $data)
    {
        return $this->request('POST', 'stream/' . rawurlencode($uid), $data);
    }

    /**
     * Basic upload a local file straight to Cloudflare Stream (server-side, up to
     * 200MB). Used to stream a WP media-library attachment to Cloudflare, mirroring
     * how R2 uploads a picked attachment. @return array|\WP_Error the video result
     */
    public function uploadFile($filePath, $filename)
    {
        if (!is_string($filePath) || !file_exists($filePath)) {
            return new \WP_Error('cloudflare_stream_error', __('The selected file could not be read.', 'fluent-player-pro'));
        }

        $boundary = wp_generate_password(24, false);
        $name = $filename ?: basename($filePath);
        $body = "--{$boundary}\r\n"
            . 'Content-Disposition: form-data; name="file"; filename="' . $name . "\"\r\n"
            . "Content-Type: application/octet-stream\r\n\r\n"
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local attachment upload to Cloudflare
            . file_get_contents($filePath) . "\r\n"
            . "--{$boundary}--\r\n";

        $url = self::API_BASE_URL . '/accounts/' . rawurlencode($this->accountId) . '/stream';
        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type'  => 'multipart/form-data; boundary=' . $boundary,
            ],
            'body'      => $body,
            'timeout'   => 300,
            'sslverify' => true,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !Arr::get($data, 'success')) {
            $message = Arr::get($data, 'errors.0.message', __('Cloudflare Stream upload failed.', 'fluent-player-pro'));
            return new \WP_Error('cloudflare_stream_error', $message);
        }

        return Arr::get($data, 'result', []);
    }

    /**
     * Mint a playback token for a private video (server-signed by Cloudflare with
     * the API token — no local signing key). @return string|\WP_Error the token
     */
    public function createSignedToken($uid, $expSeconds = 3600)
    {
        $res = $this->request('POST', 'stream/' . rawurlencode($uid) . '/token', [
            'exp' => time() + max(60, intval($expSeconds)),
        ]);
        if (is_wp_error($res)) {
            return $res;
        }
        return (string) \FluentPlayer\Framework\Support\Arr::get($res, 'token', '');
    }

    /** Subscribe a webhook URL; Cloudflare returns the signing secret. @return array|\WP_Error */
    public function subscribeWebhook($notificationUrl)
    {
        return $this->request('PUT', 'stream/webhook', ['notificationUrl' => $notificationUrl]);
    }

    /**
     * @return array|\WP_Error  Unwrapped Cloudflare `result` on success.
     */
    private function request($method, $endpoint, $body = null)
    {
        $url = self::API_BASE_URL . '/accounts/' . rawurlencode($this->accountId) . '/' . ltrim($endpoint, '/');

        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->apiToken,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'timeout'   => 30,
            'sslverify' => true,
        ];

        if ($body !== null && !in_array($method, ['GET', 'HEAD', 'DELETE'], true)) {
            $args['body'] = wp_json_encode($body);
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        return self::parseResponse(
            (int) wp_remote_retrieve_response_code($response),
            wp_remote_retrieve_body($response)
        );
    }

    /**
     * Parse a Cloudflare API response. A 2xx is success even when the body is empty
     * — DELETE /stream/{uid} returns 200 with no body — so only a non-2xx, or a 2xx
     * that carries an explicit success:false, is an error. Returns the unwrapped
     * `result` (or [] for an empty/no-result body).
     *
     * @return array|\WP_Error
     */
    public static function parseResponse($code, $rawBody)
    {
        $data = json_decode((string) $rawBody, true);

        $isError = ($code < 200 || $code >= 300)
            || (is_array($data) && array_key_exists('success', $data) && !$data['success']);

        if ($isError) {
            $message = Arr::get($data, 'errors.0.message', __('Cloudflare Stream API request failed.', 'fluent-player-pro'));
            return new \WP_Error('cloudflare_stream_error', $message, ['status' => $code, 'errors' => Arr::get($data, 'errors', [])]);
        }

        return Arr::get($data, 'result', is_array($data) ? $data : []);
    }
}
