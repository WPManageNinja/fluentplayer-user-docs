<?php

namespace FluentPlayerPro\App\Libraries;

use FluentPlayer\Framework\Support\Arr;

class Mux
{
    const API_BASE_URL = 'https://api.mux.com';
    const PLAYBACK_BASE_URL = 'https://stream.mux.com';
    const IMAGE_BASE_URL = 'https://image.mux.com';

    /**
     * @var string
     */
    protected $tokenId;

    /**
     * @var string
     */
    protected $tokenSecret;

    /**
     * @param string $tokenId
     * @param string $tokenSecret
     */
    public function __construct($tokenId, $tokenSecret)
    {
        $this->tokenId = $tokenId;
        $this->tokenSecret = $tokenSecret;
    }

    // ─── Assets ──────────────────────────────────────────────────────

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function getAssets($params = [])
    {
        $query = [];
        if (!empty($params['limit'])) {
            $query['limit'] = intval($params['limit']);
        }
        if (!empty($params['page'])) {
            $query['page'] = intval($params['page']);
        }

        $endpoint = 'video/v1/assets';
        if ($query) {
            $endpoint .= '?' . http_build_query($query);
        }

        return $this->request('GET', $endpoint);
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function getAsset($assetId)
    {
        return $this->request('GET', "video/v1/assets/{$assetId}");
    }

    /**
     * @param array $input
     * @param array $params
     * @return array|\WP_Error
     */
    public function createAsset($input, $params = [])
    {
        $body = array_merge(['input' => $input], $params);
        return $this->request('POST', 'video/v1/assets', $body);
    }

    /**
     * @param string $assetId
     * @param array $data
     * @return array|\WP_Error
     */
    public function updateAsset($assetId, $data)
    {
        return $this->request('PATCH', "video/v1/assets/{$assetId}", $data);
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function deleteAsset($assetId)
    {
        return $this->request('DELETE', "video/v1/assets/{$assetId}");
    }

    /**
     * @param string $assetId
     * @param string $mp4Support e.g. 'standard', 'capped-1080p', 'none'
     * @return array|\WP_Error
     */
    public function updateMp4Support($assetId, $mp4Support)
    {
        return $this->request('PUT', "video/v1/assets/{$assetId}/mp4-support", [
            'mp4_support' => $mp4Support,
        ]);
    }

    /**
     * @param string $assetId
     * @param string $masterAccess 'temporary' or 'none'
     * @return array|\WP_Error
     */
    public function updateMasterAccess($assetId, $masterAccess)
    {
        return $this->request('PUT', "video/v1/assets/{$assetId}/master-access", [
            'master_access' => $masterAccess,
        ]);
    }

    // ─── Tracks (subtitles/captions) ─────────────────────────────────

    /**
     * @param string $assetId
     * @param array $data
     * @return array|\WP_Error
     */
    public function createTrack($assetId, $data)
    {
        return $this->request('POST', "video/v1/assets/{$assetId}/tracks", $data);
    }

    /**
     * @param string $assetId
     * @param string $trackId
     * @return array|\WP_Error
     */
    public function deleteTrack($assetId, $trackId)
    {
        return $this->request('DELETE', "video/v1/assets/{$assetId}/tracks/{$trackId}");
    }

    /**
     * @param string $assetId
     * @param string $trackId
     * @param array $params
     * @return array|\WP_Error
     */
    public function generateSubtitles($assetId, $trackId, $params)
    {
        return $this->request('POST', "video/v1/assets/{$assetId}/tracks/{$trackId}/generate-subtitles", $params);
    }

    // ─── Direct Uploads ──────────────────────────────────────────────

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function createUpload($params)
    {
        return $this->request('POST', 'video/v1/uploads', $params);
    }

    /**
     * @param string $uploadId
     * @return array|\WP_Error
     */
    public function getUpload($uploadId)
    {
        return $this->request('GET', "video/v1/uploads/{$uploadId}");
    }

    // ─── Live Streams ────────────────────────────────────────────────

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function createLiveStream($params)
    {
        return $this->request('POST', 'video/v1/live-streams', $params);
    }

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function getLiveStreams($params = [])
    {
        $endpoint = 'video/v1/live-streams';
        if ($params) {
            $endpoint .= '?' . http_build_query($params);
        }

        return $this->request('GET', $endpoint);
    }

    /**
     * @param string $liveStreamId
     * @return array|\WP_Error
     */
    public function getLiveStream($liveStreamId)
    {
        return $this->request('GET', "video/v1/live-streams/{$liveStreamId}");
    }

    /**
     * @param string $liveStreamId
     * @return array|\WP_Error
     */
    public function deleteLiveStream($liveStreamId)
    {
        return $this->request('DELETE', "video/v1/live-streams/{$liveStreamId}");
    }

    /**
     * @param string $liveStreamId
     * @return array|\WP_Error
     */
    public function resetStreamKey($liveStreamId)
    {
        return $this->request('POST', "video/v1/live-streams/{$liveStreamId}/reset-stream-key");
    }

    /**
     * @param string $liveStreamId
     * @return array|\WP_Error
     */
    public function disableLiveStream($liveStreamId)
    {
        return $this->request('PUT', "video/v1/live-streams/{$liveStreamId}/disable");
    }

    /**
     * @param string $liveStreamId
     * @return array|\WP_Error
     */
    public function enableLiveStream($liveStreamId)
    {
        return $this->request('PUT', "video/v1/live-streams/{$liveStreamId}/enable");
    }

    // ─── Playback Restrictions ───────────────────────────────────────

    /**
     * @param array $data
     * @return array|\WP_Error
     */
    public function createPlaybackRestriction($data)
    {
        return $this->request('POST', 'video/v1/playback-restrictions', $data);
    }

    /**
     * @return array|\WP_Error
     */
    public function getPlaybackRestrictions()
    {
        return $this->request('GET', 'video/v1/playback-restrictions');
    }

    /**
     * @param string $id
     * @return array|\WP_Error
     */
    public function getPlaybackRestriction($id)
    {
        return $this->request('GET', "video/v1/playback-restrictions/{$id}");
    }

    /**
     * @param string $id
     * @return array|\WP_Error
     */
    public function deletePlaybackRestriction($id)
    {
        return $this->request('DELETE', "video/v1/playback-restrictions/{$id}");
    }

    // ─── Signing Keys ────────────────────────────────────────────────

    /**
     * @return array|\WP_Error
     */
    public function createSigningKey()
    {
        return $this->request('POST', 'system/v1/signing-keys');
    }

    /**
     * @return array|\WP_Error
     */
    public function getSigningKeys()
    {
        return $this->request('GET', 'system/v1/signing-keys');
    }

    /**
     * @param string $id
     * @return array|\WP_Error
     */
    public function deleteSigningKey($id)
    {
        return $this->request('DELETE', "system/v1/signing-keys/{$id}");
    }

    // ─── Delivery Usage ──────────────────────────────────────────────

    /**
     * @param array $params
     * @return array|\WP_Error
     */
    public function getDeliveryUsage($params = [])
    {
        $endpoint = 'video/v1/delivery-usage';
        if ($params) {
            $endpoint .= '?' . http_build_query($params);
        }

        return $this->request('GET', $endpoint);
    }

    // ─── URL Helpers ─────────────────────────────────────────────────

    /**
     * @param string $playbackId
     * @return string
     */
    public static function getPlaybackUrl($playbackId)
    {
        return self::PLAYBACK_BASE_URL . "/{$playbackId}.m3u8";
    }

    /**
     * @param string $playbackId
     * @param array $params e.g. ['width' => 640, 'height' => 360, 'time' => 5]
     * @return string
     */
    public static function getThumbnailUrl($playbackId, $params = [])
    {
        $url = self::IMAGE_BASE_URL . "/{$playbackId}/thumbnail.jpg";
        if ($params) {
            $url .= '?' . http_build_query($params);
        }

        return $url;
    }

    /**
     * @param string $playbackId
     * @param string $format 'jpg' or 'png'
     * @return string
     */
    public static function getStoryboardUrl($playbackId, $format = 'jpg')
    {
        return self::IMAGE_BASE_URL . "/{$playbackId}/storyboard.{$format}";
    }

    /**
     * @param string $playbackId
     * @param array $params e.g. ['start' => 0, 'end' => 5, 'width' => 320]
     * @return string
     */
    public static function getAnimatedGifUrl($playbackId, $params = [])
    {
        $url = self::IMAGE_BASE_URL . "/{$playbackId}/animated.gif";
        if ($params) {
            $url .= '?' . http_build_query($params);
        }

        return $url;
    }

    // ─── HTTP Layer ──────────────────────────────────────────────────

    /**
     * @param string $method
     * @param string $endpoint
     * @param array|null $body
     * @return array|\WP_Error
     */
    private function request($method, $endpoint, $body = null)
    {
        $url = self::API_BASE_URL . '/' . ltrim($endpoint, '/');

        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Required for HTTP Basic Auth per Mux API specification
        $authHeader = 'Basic ' . base64_encode($this->tokenId . ':' . $this->tokenSecret);

        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => $authHeader,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'timeout'   => 30,
            'sslverify' => true,
        ];

        if ($body !== null && !in_array($method, ['GET', 'HEAD', 'DELETE'], true)) {
            $args['body'] = wp_json_encode($body);
        }

        $response = wp_remote_request($url, $args);

        return $this->handleResponse($response);
    }

    /**
     * @param array|\WP_Error $response
     * @return array|\WP_Error
     */
    private function handleResponse($response)
    {
        if (is_wp_error($response)) {
            return $response;
        }

        $statusCode = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        // 204 No Content — successful deletion etc.
        if ($statusCode === 204) {
            return ['success' => true];
        }

        $data = json_decode($body, true);

        if ($statusCode >= 200 && $statusCode < 300) {
            return $data ?: ['success' => true];
        }

        $errorMessage = 'Mux API error';
        if (isset($data['error']['messages']) && is_array($data['error']['messages'])) {
            $errorMessage = implode('; ', $data['error']['messages']);
        } elseif (isset($data['error']['message'])) {
            $errorMessage = $data['error']['message'];
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Error logging for debugging
            error_log('Fluent Player Mux API error: ' . $errorMessage);
        }

        return new \WP_Error(
            'mux_api_error',
            $errorMessage,
            ['status' => $statusCode]
        );
    }
}
