<?php

namespace FluentPlayerPro\App\Libraries;

use FluentPlayer\Framework\Support\Arr;

/**
 * BunnyCDN Storage API Client
 */
class BunnyCDNStorage
{
    /**
     * The storage username
     * @var string
     */
    private $username = '';

    /**
     * The storage hostname
     * @var string
     */
    private $hostname = '';

    /**
     * The storage password
     * @var string
     */
    private $password = '';

    /**
     * The base URL for API requests
     * @var string
     */
    private $url = '';

    /**
     * Constructor
     *
     * @param string $username Storage user name
     * @param string $hostname Storage hostname
     * @param string $password Storage password/API key
     */
    public function __construct($username, $hostname, $password)
    {
        $this->username = trim($username ?? '');
        $this->password = trim($password ?? '');
        $this->hostname = trim($hostname ?? '');
        $this->url = "https://{$this->hostname}/{$this->username}/";
    }

    /**
     * Encode file path segments for URL.
     * Encodes each path segment individually while preserving '/' separators.
     *
     * @param string $path File path (e.g., "my folder/video file.mp4")
     * @return string URL-encoded path (e.g., "my%20folder/video%20file.mp4")
     */
    protected function encodePathForUrl($path)
    {
        return implode('/', array_map('rawurlencode', explode('/', $path)));
    }

    /**
     * Make an HTTP request to the BunnyCDN API
     *
     * @param string $url The URL to request
     * @param string $method HTTP method (GET, PUT, DELETE)
     * @param mixed $body Request body for PUT requests
     * @return mixed|\WP_Error Response data or WP_Error on failure
     */
    protected function makeRequest($url, $method = 'GET', $body = null)
    {
        try {
            $headers = [
                'AccessKey' => $this->password,
                'Accept'    => 'application/json',
            ];

            if ($method === 'PUT' && $body !== null) {
                $headers['Content-Type'] = 'application/octet-stream';
            }

            $args = [
                'method'    => $method,
                'headers'   => $headers,
                'timeout'   => 300,
                'sslverify' => true,
            ];

            if ($method === 'PUT' && $body !== null) {
                $args['body'] = $body;
            }

            $response = wp_remote_request($url, $args);

            if (is_wp_error($response)) {
                return $response;
            }

            $responseCode = wp_remote_retrieve_response_code($response);

            if ($responseCode === 404) {
                return new \WP_Error('not_found', sprintf(__('Resource not found: %s', 'fluent-player-pro'), $url));
            }

            if ($responseCode === 401) {
                return new \WP_Error('unauthorized', __('Authentication failed. Please check your API key.', 'fluent-player-pro'));
            }

            if ($method === 'DELETE' && $responseCode >= 200 && $responseCode < 300) {
                return true;
            }

            if ($responseCode < 200 || $responseCode >= 300) {
                $body = wp_remote_retrieve_body($response);
                return new \WP_Error('api_error', sprintf(__('API error (HTTP %d): %s', 'fluent-player-pro'), $responseCode, $body));
            }

            $body = wp_remote_retrieve_body($response);

            if (!empty($body)) {
                $decoded = json_decode($body, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    return $decoded;
                }
            }

            return $body;
        } catch (\Exception $e) {
            return new \WP_Error('request_error', $e->getMessage());
        }
    }

    /**
     * Get a list of storage objects
     *
     * @param string $path Directory path
     * @return array|WP_Error List of objects or error
     */
    public function getStorageObjects($path = '')
    {
        try {
            // Ensure path has trailing slash if not empty
            if (!empty($path)) {
                $path = rtrim($path, '/') . '/';
            }

            $url = $this->url . $this->encodePathForUrl($path);
            $response = $this->makeRequest($url);

            if (is_wp_error($response)) {
                return $response;
            }

            // If the response is a string, try to decode it as JSON
            if (is_string($response)) {
                $decoded = json_decode($response, true);

                // If JSON decode fails, return an error
                if (json_last_error() !== JSON_ERROR_NONE) {
                    return new \WP_Error('json_decode_error', sprintf(__('Failed to decode JSON response: %s', 'fluent-player-pro'), json_last_error_msg()));
                }

                return $decoded;
            }

            return $response;
        } catch (\Exception $e) {
            return new \WP_Error('list_error', $e->getMessage());
        }
    }

    /**
     * Fetch a file from BunnyCDN storage and pipe it directly to the client.
     *
     * BunnyCDN Storage always requires the AccessKey header, so the server must
     * proxy the response. PHP HTTP streams + fpassthru() pipe data chunk-by-chunk
     * without loading the entire file into memory.
     *
     * @param string $fileName The file path to retrieve
     * @throws \Exception On connection or HTTP errors
     */
    public function getFile($fileName)
    {
        $fileName = ltrim($fileName, '/');
        $url = $this->url . $this->encodePathForUrl($fileName);

        $pathInfo = pathinfo($fileName);
        $fileBasename = Arr::get($pathInfo, 'basename');
        $fileExtension = strtolower(Arr::get($pathInfo, 'extension', ''));
        $contentType = $this->getMimeTypeForExtension($fileExtension);

        // Forward Range header from client so BunnyCDN can serve partial content for seeking.
        // Validate format before forwarding to prevent CRLF injection into upstream request headers.
        $rangeHeader = '';
        if (isset($_SERVER['HTTP_RANGE'])) {
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validated via regex below
            $rawRange = wp_unslash($_SERVER['HTTP_RANGE']);
            if (preg_match('/^bytes=\d+-\d*$/', $rawRange)) {
                $rangeHeader = $rawRange;
            }
        }

        $requestHeaders = [
            'AccessKey: ' . $this->password,
            'Accept: */*',
        ];
        if ($rangeHeader) {
            $requestHeaders[] = 'Range: ' . $rangeHeader;
        }
        $requestHeaders = implode("\r\n", $requestHeaders) . "\r\n";

        $context = stream_context_create([
            'http' => [
                'method'        => 'GET',
                'header'        => $requestHeaders,
                'timeout'       => 300,
                'ignore_errors' => true,
            ],
            'ssl'  => ['verify_peer' => true],
        ]);

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Remote HTTP stream required to pipe binary data without loading into memory
        $stream = @fopen($url, 'r', false, $context);

        if (!$stream) {
            throw new \Exception(__('Could not connect to BunnyCDN storage.', 'fluent-player-pro'));
        }

        $meta = stream_get_meta_data($stream)['wrapper_data'] ?? [];
        $httpStatus = 200;
        $contentLength = '';
        $contentRange = '';
        foreach ($meta as $header) {
            if (preg_match('/HTTP\/[\d.]+\s+(\d+)/', $header, $matches)) {
                $httpStatus = intval($matches[1]);
            }
            if (stripos($header, 'Content-Length:') === 0) {
                $contentLength = trim(substr($header, strlen('Content-Length:')));
            }
            if (stripos($header, 'Content-Range:') === 0) {
                $contentRange = trim(substr($header, strlen('Content-Range:')));
            }
        }

        if ($httpStatus === 404) {
            fclose($stream);
            throw new \Exception(sprintf(__('File not found on storage: %s', 'fluent-player-pro'), esc_html($fileName)));
        }
        if ($httpStatus === 401) {
            fclose($stream);
            throw new \Exception(__('Storage authentication failed. Please check your API key.', 'fluent-player-pro'));
        }
        if ($httpStatus < 200 || $httpStatus >= 300) {
            fclose($stream);
            throw new \Exception("Storage returned HTTP {$httpStatus} for: " . esc_html($fileName));
        }

        while (ob_get_level()) {
            ob_end_clean();
        }

        http_response_code($httpStatus);
        header('Content-Type: ' . $contentType);
        header('Content-Disposition: inline; filename="' . esc_attr($fileBasename) . '"');
        header('Accept-Ranges: bytes');
        header('Cache-Control: public, max-age=3600');
        header('Access-Control-Allow-Origin: ' . esc_url(home_url()));
        header('Access-Control-Allow-Methods: GET, HEAD, OPTIONS');
        if ($contentLength !== '' && ctype_digit($contentLength) && $contentLength <= PHP_INT_MAX) {
            header('Content-Length: ' . $contentLength);
        }
        if ($contentRange !== '' && preg_match('/^bytes \d+-\d+\/(\d+|\*)$/', $contentRange)) {
            header('Content-Range: ' . $contentRange);
        }

        // Disable execution time limit for large file transfers
        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- set_time_limit may be disabled in restricted environments
        @set_time_limit(0);

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Binary file data piped from remote stream
        fpassthru($stream);
        fclose($stream);
        exit;
    }

    /**
     * Get MIME type for file extension
     *
     * @param string $extension File extension
     * @return string MIME type
     */
    protected function getMimeTypeForExtension($extension)
    {
        // Video / image / doc types local; audio ext → MIME is owned by the free Helper
        // (single source) so R2 and Bunny Storage can't drift.
        $mimeTypes = [
            'mp4' => 'video/mp4',
            'webm' => 'video/webm',
            'mov' => 'video/quicktime',
            'avi' => 'video/x-msvideo',
            'mkv' => 'video/x-matroska',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'pdf' => 'application/pdf'
        ];

        if (isset($mimeTypes[$extension])) {
            return $mimeTypes[$extension];
        }

        // method_exists guards the version-skew case (pro updated before free).
        if (method_exists(\FluentPlayer\App\Helpers\Helper::class, 'audioMimeType')) {
            $audioMime = \FluentPlayer\App\Helpers\Helper::audioMimeType($extension);
            if ($audioMime !== '') {
                return $audioMime;
            }
        }

        return 'application/octet-stream';
    }

    /**
     * Upload a file
     *
     * @param string $localPath Path to the local file
     * @param string $remoteFileName Remote file name (including path)
     * @return bool|WP_Error True on success, WP_Error on failure
     */
    public function uploadFile($localPath, $remoteFileName)
    {
        try {
            if (empty($localPath)) {
                return new \WP_Error('missing_local_path', 'Local file path is required');
            }

            if (empty($remoteFileName)) {
                $remoteFileName = basename($localPath);
            }

            if (!file_exists($localPath) || !is_readable($localPath)) {
                return new \WP_Error('file_not_found', 'Local file not found or not readable');
            }

            $fileSize = filesize($localPath);
            if ($fileSize === false || $fileSize === 0) {
                return new \WP_Error('empty_file', 'File is empty or cannot be read');
            }

            $remoteFileName = ltrim($remoteFileName, '/');
            $url = $this->url . $this->encodePathForUrl($remoteFileName);

            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
            $fileHandle = fopen($localPath, 'r');
            if (!$fileHandle) {
                return new \WP_Error('file_read_error', 'Could not open file for reading');
            }

            // Disable PHP execution timeout — upload duration is bounded by CURLOPT_TIMEOUT below.
            // Note: on VPS/self-hosted nginx, fastcgi_read_timeout (default 60 s) can still kill the
            // request if the upload takes longer. Fix: add `fastcgi_read_timeout 600;` to your nginx config.
            // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            @set_time_limit(0);

            // Stream the file via curl to avoid loading it into memory
            // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
            $ch = curl_init();
            if (!$ch) {
                fclose($fileHandle);
                return new \WP_Error('curl_init_error', 'Could not initialise cURL');
            }

            $responseBody = '';
            $statusCode = 0;
            $curlError = '';

            try {
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($ch, CURLOPT_URL, $url);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($ch, CURLOPT_PUT, true);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($ch, CURLOPT_INFILE, $fileHandle);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($ch, CURLOPT_INFILESIZE, $fileSize);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'AccessKey: ' . $this->password,
                    'Content-Type: application/octet-stream',
                    'Expect:',  // Disable Expect: 100-continue — avoids a round-trip wait before the body is sent
                ]);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($ch, CURLOPT_TIMEOUT, 600);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
                $responseBody = curl_exec($ch);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo
                $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_error
                $curlError = curl_error($ch);
            } finally {
                fclose($fileHandle);
                // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
                curl_close($ch);
            }

            if (!empty($curlError)) {
                return new \WP_Error('upload_error', sprintf(__('Upload failed: %s', 'fluent-player-pro'), $curlError));
            }

            if ($statusCode < 200 || $statusCode >= 300) {
                return new \WP_Error('api_error', sprintf(__('API error (HTTP %d): %s', 'fluent-player-pro'), $statusCode, $responseBody));
            }

            return true;
        } catch (\Exception $e) {
            return new \WP_Error('upload_error', $e->getMessage());
        }
    }

    /**
     * Delete an object
     *
     * @param string $fileName The file name to delete
     * @return bool|WP_Error
     */
    public function deleteObject($fileName = '')
    {
        try {
            // Validate inputs
            if (empty($fileName)) {
                return new \WP_Error('missing_filename', 'File name is required');
            }

            // Make sure the filename doesn't start with a slash
            $fileName = ltrim($fileName, '/');

            // Build the URL with properly encoded path segments
            $url = $this->url . $this->encodePathForUrl($fileName);

            // Make the request
            $result = $this->makeRequest($url, 'DELETE');

            if (is_wp_error($result)) {
                return $result;
            }

            return true;
        } catch (\Exception $e) {
            return new \WP_Error('delete_error', $e->getMessage());
        }
    }

    /**
     * Create a directory
     *
     * @param string $path Directory path to create
     * @return bool|WP_Error
     */
    public function createDirectory($path)
    {
        try {
            // Validate inputs
            if (empty($path)) {
                return new \WP_Error('missing_path', 'Directory path is required');
            }

            // Make sure the path doesn't start with a slash and ends with a slash
            $path = ltrim($path, '/');
            $path = rtrim($path, '/') . '/';

            // Build the URL with properly encoded path segments
            $url = $this->url . $this->encodePathForUrl($path);

            // Create an empty file to establish the directory
            // BunnyCDN storage creates directories implicitly when uploading files
            $result = $this->makeRequest($url, 'PUT', '');

            if (is_wp_error($result)) {
                return $result;
            }

            return true;
        } catch (\Exception $e) {
            return new \WP_Error('create_directory_error', $e->getMessage());
        }
    }
}
