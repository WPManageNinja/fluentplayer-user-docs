<?php

namespace FluentPlayerPro\App\Libraries;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Thin HTTP client for the Gumlet Video API.
 *
 * Auth: Bearer <api_key> (account-scoped). Base: https://api.gumlet.com/v1.
 * Playback manifests are served from https://video.gumlet.io/{workspace}/{asset}/main.m3u8.
 *
 * The pure layers (parseResponse, buildHeaders, playbackUrl) are separated from
 * the wp_remote_request transport so they can be unit-tested without the network.
 */
class Gumlet
{
    const API_BASE_URL = 'https://api.gumlet.com/v1';
    const PLAYBACK_HOST = 'https://video.gumlet.io';

    /**
     * @var string
     */
    protected $apiKey;

    /**
     * @param string $apiKey
     */
    public function __construct($apiKey)
    {
        $this->apiKey = $apiKey;
    }

    // ─── Video Assets (VOD) ──────────────────────────────────────────

    /**
     * List assets in a workspace. Gumlet paginates with offset/size (size max 100).
     *
     * @param string $workspaceId
     * @param array  $params e.g. ['offset' => 0, 'size' => 50]
     * @return array|\WP_Error
     */
    public function listAssets($workspaceId, $params = [])
    {
        $query = [];
        if (isset($params['offset'])) {
            $query['offset'] = intval($params['offset']);
        }
        if (!empty($params['size'])) {
            $query['size'] = min(100, intval($params['size']));
        }

        $endpoint = 'video/assets/list/' . rawurlencode($workspaceId);
        if ($query) {
            $endpoint .= '?' . http_build_query($query);
        }

        return $this->request('GET', $endpoint);
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function getAsset($assetId)
    {
        return $this->request('GET', 'video/assets/' . rawurlencode($assetId));
    }

    /**
     * Create an asset by importing from a source URL.
     *
     * @param array $body e.g. ['input' => $url, 'collection_id' => $id, 'format' => 'ABR']
     * @return array|\WP_Error
     */
    public function createAsset($body)
    {
        return $this->request('POST', 'video/assets', $body);
    }

    /**
     * Create a direct-upload asset. Returns a presigned S3 upload_url + asset_id;
     * the caller then PUTs the file bytes to upload_url.
     *
     * @param array $body e.g. ['workspace_id' => $id, 'format' => 'ABR']
     * @return array|\WP_Error
     */
    public function createDirectUpload($body)
    {
        return $this->request('POST', 'video/assets/upload', $body);
    }

    /**
     * Update asset metadata. Gumlet exposes this as POST /video/assets/update
     * with the asset_id in the body (not a PATCH on the asset path).
     *
     * @param string $assetId
     * @param array  $data e.g. ['title' => 'New title']
     * @return array|\WP_Error
     */
    public function updateAsset($assetId, $data)
    {
        $body = array_merge(['asset_id' => $assetId], (array) $data);
        return $this->request('POST', 'video/assets/update', $body);
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function deleteAsset($assetId)
    {
        return $this->request('DELETE', 'video/assets/' . rawurlencode($assetId));
    }

    // ─── Live Assets ─────────────────────────────────────────────────

    /**
     * @param array $body e.g. ['live_source_id' => $id, 'resolution' => ['720p']]
     * @return array|\WP_Error
     */
    public function createLiveAsset($body)
    {
        return $this->request('POST', 'video/live/assets', $body);
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function getLiveAsset($assetId)
    {
        return $this->request('GET', 'video/live/assets/' . rawurlencode($assetId));
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function startLiveStream($assetId)
    {
        return $this->request('POST', 'video/live/assets/' . rawurlencode($assetId) . '/start');
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function completeLiveStream($assetId)
    {
        return $this->request('POST', 'video/live/assets/' . rawurlencode($assetId) . '/complete');
    }

    /**
     * @param string $assetId
     * @return array|\WP_Error
     */
    public function deleteLiveAsset($assetId)
    {
        return $this->request('DELETE', 'video/live/assets/' . rawurlencode($assetId));
    }

    /**
     * Upload a local file to a Gumlet presigned S3 URL (server-side, from the
     * WP media attachment). Uses cURL with an in-file handle so the file streams
     * from disk without being buffered whole in PHP memory.
     *
     * @param string $url      Presigned S3 PUT URL.
     * @param string $filePath Absolute path to the local attachment file.
     * @return true|\WP_Error
     */
    public function putFile($url, $filePath)
    {
        if (!is_string($filePath) || $filePath === '' || !file_exists($filePath) || !is_readable($filePath)) {
            return new \WP_Error('file_unreadable', __('The upload file could not be read', 'fluent-player-pro'));
        }

        $size = filesize($filePath);
        $handle = fopen($filePath, 'rb');
        if ($handle === false) {
            return new \WP_Error('file_open_failed', __('Could not open the upload file', 'fluent-player-pro'));
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_PUT            => true,
            CURLOPT_UPLOAD         => true,
            CURLOPT_INFILE         => $handle,
            CURLOPT_INFILESIZE     => $size,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 900,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/octet-stream'],
        ]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        fclose($handle);

        if ($error !== '') {
            return new \WP_Error('upload_transport_error', $error);
        }
        if ($code < 200 || $code >= 300) {
            return new \WP_Error('upload_put_failed', __('Uploading the file to storage failed', 'fluent-player-pro'), ['status' => $code]);
        }

        return true;
    }

    // ─── URL Helpers ─────────────────────────────────────────────────

    /**
     * Public HLS manifest URL for an asset.
     *
     * @param string $workspaceId
     * @param string $assetId
     * @return string
     */
    public static function playbackUrl($workspaceId, $assetId)
    {
        return self::PLAYBACK_HOST . '/' . $workspaceId . '/' . $assetId . '/main.m3u8';
    }

    // ─── HTTP Layer ──────────────────────────────────────────────────

    /**
     * @return array<string,string>
     */
    protected function buildHeaders()
    {
        return [
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ];
    }

    /**
     * @param string     $method
     * @param string     $endpoint
     * @param array|null $body
     * @return array|\WP_Error
     */
    protected function request($method, $endpoint, $body = null)
    {
        $url = self::API_BASE_URL . '/' . ltrim($endpoint, '/');

        $args = [
            'method'    => $method,
            'headers'   => $this->buildHeaders(),
            'timeout'   => 30,
            'sslverify' => true,
        ];

        $encoded = self::encodeBody($method, $body);
        if ($encoded !== null) {
            $args['body'] = $encoded;
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        return self::parseResponse(
            wp_remote_retrieve_response_code($response),
            wp_remote_retrieve_body($response)
        );
    }

    /**
     * Build the request body for a method. Mutating methods (POST/PUT/PATCH)
     * always carry a JSON body — bodyless calls (live start/complete) must send
     * "{}" because the Content-Type is application/json and Gumlet errors trying
     * to parse an empty body ("Unexpected end of JSON input"). GET/HEAD/DELETE
     * never carry a body.
     *
     * @param string     $method
     * @param array|null $body
     * @return string|null JSON string, or null for bodyless methods.
     */
    protected static function encodeBody($method, $body)
    {
        if (in_array($method, ['GET', 'HEAD', 'DELETE'], true)) {
            return null;
        }
        return wp_json_encode($body !== null ? $body : new \stdClass());
    }

    /**
     * Parse a raw HTTP status + body into a decoded array or a WP_Error.
     * A 2xx with an empty body (e.g. DELETE) is a success, not an error.
     *
     * @param int    $statusCode
     * @param string $rawBody
     * @return array|\WP_Error
     */
    public static function parseResponse($statusCode, $rawBody)
    {
        $statusCode = (int) $statusCode;
        $data = json_decode((string) $rawBody, true);

        if ($statusCode >= 200 && $statusCode < 300) {
            return is_array($data) ? $data : ['success' => true];
        }

        $errorMessage = __('Gumlet API request failed', 'fluent-player-pro');
        if (isset($data['error']['message']) && is_string($data['error']['message'])) {
            $errorMessage = $data['error']['message'];
        } elseif (isset($data['message']) && is_string($data['message'])) {
            $errorMessage = $data['message'];
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Error logging for debugging
            error_log('Fluent Player Gumlet API error: ' . $errorMessage);
        }

        return new \WP_Error('gumlet_api_error', $errorMessage, ['status' => $statusCode]);
    }
}
