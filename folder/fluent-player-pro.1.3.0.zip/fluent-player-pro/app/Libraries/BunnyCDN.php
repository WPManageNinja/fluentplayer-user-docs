<?php

namespace FluentPlayerPro\App\Libraries;

use FluentPlayer\Framework\Support\Arr;

class BunnyCDN
{
    const API_BASE_URL = 'https://api.bunny.net';
    const STREAM_API_BASE_URL = 'https://video.bunnycdn.com';
    
    /**
     * API key
     *
     * @var string
     */
    protected $apiKey;
    
    /**
     * Constructor
     *
     * @param string $apiKey
     */
    public function __construct($apiKey)
    {
        $this->apiKey = $apiKey;
    }
    
    /**
     * Test API key
     *
     * @return bool
     */
    public function testApiKey()
    {
        try {
            $url = self::API_BASE_URL . '/apikey';
            
            $headers = [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'AccessKey' => $this->apiKey
            ];
            
            $args = [
                'method' => 'GET',
                'headers' => $headers
            ];
            
            $response = wp_remote_request($url, $args);
            
            if (is_wp_error($response)) {
                return false;
            }
            
            $statusCode = wp_remote_retrieve_response_code($response);
            
            return $statusCode === 200;
        } catch (\Exception $e) {
            return false;
        }
    }
    
    /**
     * Get all libraries from the account
     *
     * @return array|\WP_Error
     */
    public function getLibraries()
    {
        $url = self::API_BASE_URL . '/videolibrary';

        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $this->apiKey
        ];

        $args = [
            'method' => 'GET',
            'headers' => $headers,
            'timeout' => 30
        ];

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);

        if ($statusCode !== 200) {
            return new \WP_Error(
                $statusCode, 
                Arr::get($responseData, 'message', 'Failed to get libraries'),
                $responseData
            );
        }

        return $responseData;
    }
    
    /**
     * Get videos from a library
     *
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param array $params Additional parameters
     * @return array|\WP_Error
     */
    public function getVideos($libraryId, $libraryApiKey, $params = [], $pullZoneUrl = '')
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/videos";

        // Add query parameters
        $queryParams = [];
        if (!empty($params['page'])) {
            $queryParams['page'] = $params['page'];
        }
        if (!empty($params['per_page'])) {
            $queryParams['itemsPerPage'] = $params['per_page'];
        }

        // Handle collection filtering
        $filterByCollection = isset($params['collection_id']);
        $showOnlyUncategorized = !empty($params['show_only_uncategorized']) || (isset($params['collection_id']) && $params['collection_id'] === '');

        // Only add collection parameter if we're filtering by a specific collection
        if ($filterByCollection && !$showOnlyUncategorized) {
            $queryParams['collection'] = $params['collection_id'];
        }

        if (!empty($params['search'])) {
            $queryParams['search'] = $params['search'];
        }

        if (!empty($queryParams)) {
            $url = add_query_arg($queryParams, $url);
        }

        // Use library-specific API key for this request
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];

        $args = [
            'method' => 'GET',
            'headers' => $headers,
            'timeout' => 30
        ];

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);

        if ($statusCode !== 200) {
            return new \WP_Error(
                $statusCode,
                Arr::get($responseData, 'message', 'Failed to fetch videos'),
                $responseData
            );
        }

        // Use provided hostname or fall back to API lookup
        if (empty($pullZoneUrl)) {
            $pullZoneUrl = $this->getPullZoneUrlForLibrary($libraryId);
        }

        // Process videos to add URLs
        $items = Arr::get($responseData, 'items', []);

        // Make sure $items is an array before using foreach
        if (!is_array($items)) {
            $items = [];
        }

        // Filter by collection status
        if (!$filterByCollection || $showOnlyUncategorized) {
            // No collection filter or explicitly uncategorized: show only root-level videos
            $items = array_values(array_filter($items, function ($video) {
                return empty(Arr::get($video, 'collectionId'));
            }));
        } elseif ($filterByCollection) {
            // Specific collection: ensure exact match
            $items = array_values(array_filter($items, function ($video) use ($params) {
                return Arr::get($video, 'collectionId') === $params['collection_id'];
            }));
        }

        $processedItems = [];
        foreach ($items as $video) {
            $guid = Arr::get($video, 'guid');

            // Add URLs
            $video['playlistURL'] = "https://{$pullZoneUrl}/{$guid}/playlist.m3u8";
            $video['webPURL'] = "https://{$pullZoneUrl}/{$guid}/preview.webp";
            $video['thumbnailURL'] = "https://{$pullZoneUrl}/{$guid}/".Arr::get($video, 'thumbnailFileName', 'thumbnail.jpg');

            // Add MP4 URL (720p fallback for non-HLS players)
            $video['MP4URLs'] = "https://{$pullZoneUrl}/{$guid}/play_720p.mp4";

            // Add caption CDN URLs
            if (is_array(Arr::get($video, 'captions'))) {
                foreach ($video['captions'] as &$caption) {
                    $srclang = Arr::get($caption, 'srclang');
                    if (isset($srclang) && $srclang !== '') {
                        $caption['url'] = "https://{$pullZoneUrl}/{$guid}/captions/" . rawurlencode($srclang) . ".vtt";
                    }
                }
                unset($caption);
            }

            // Add additional fields for compatibility
            $video['id'] = $guid;
            $video['size'] = Arr::get($video, 'storageSize');
            $video['thumbnail'] = Arr::get($video, 'thumbnailURL');
            $video['updated_at'] = Arr::get($video, 'dateUploaded');
            $video['created_at'] = Arr::get($video, 'dateUploaded');

            $processedItems[] = $video;
        }

        // Use the API's total for pagination, fall back to current count
        $apiTotal = Arr::get($responseData, 'totalItems', count($processedItems));

        return [
            'totalItems' => $apiTotal,
            'currentPage' => Arr::get($responseData, 'currentPage', 1),
            'itemsPerPage' => Arr::get($responseData, 'itemsPerPage', count($processedItems)),
            'items' => $processedItems
        ];
    }
    
    /**
     * Get collections from a specific library
     * 
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @return array|\WP_Error
     */
    public function getCollections($libraryId, $libraryApiKey)
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/collections";
        
        // Use library-specific API key for this request
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];
        
        $args = [
            'method' => 'GET',
            'headers' => $headers,
            'timeout' => 30
        ];
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);
        
        if ($statusCode !== 200) {
            return new \WP_Error(
                $statusCode, 
                Arr::get($responseData, 'message', 'Failed to get collections'),
                $responseData
            );
        }
        
        return $responseData['items'] ?? [];
    }
    
    /**
     * Create a new collection in a library
     *
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param string $name Collection name
     * @return array|\WP_Error
     */
    public function createCollection($libraryId, $libraryApiKey, $name)
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/collections";

        // Use library-specific API key for this request
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];

        $args = [
            'method' => 'POST',
            'headers' => $headers,
            'body' => json_encode(['name' => $name]),
            'timeout' => 30
        ];

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);

        if ($statusCode !== 200 && $statusCode !== 201) {
            return new \WP_Error(
                $statusCode,
                Arr::get($responseData, 'message', 'Failed to create collection'),
                $responseData
            );
        }

        return $responseData;
    }

    /**
     * Update a collection in a library
     *
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param string $collectionId Collection ID
     * @param string $name New collection name
     * @return array|\WP_Error
     */
    public function updateCollection($libraryId, $libraryApiKey, $collectionId, $name)
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/collections/{$collectionId}";

        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];

        $args = [
            'method' => 'POST',
            'headers' => $headers,
            'body' => json_encode(['name' => $name]),
            'timeout' => 30
        ];

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);

        if ($statusCode !== 200 && $statusCode !== 201) {
            return new \WP_Error(
                $statusCode,
                Arr::get($responseData, 'message', 'Failed to update collection'),
                $responseData
            );
        }

        return $responseData;
    }

    /**
     * Delete a collection from a library
     *
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param string $collectionId Collection ID
     * @return bool|\WP_Error
     */
    public function deleteCollection($libraryId, $libraryApiKey, $collectionId)
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/collections/{$collectionId}";

        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];

        $args = [
            'method' => 'DELETE',
            'headers' => $headers,
            'timeout' => 30
        ];

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $statusCode = wp_remote_retrieve_response_code($response);

        if ($statusCode !== 200 && $statusCode !== 204) {
            $body = wp_remote_retrieve_body($response);
            $responseData = json_decode($body, true);

            return new \WP_Error(
                $statusCode,
                Arr::get($responseData, 'message', 'Failed to delete collection'),
                $responseData
            );
        }

        return true;
    }

    /**
     * Update a video's metadata
     *
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param string $videoId Video ID
     * @param array $data Video data to update (title, etc.)
     * @return array|\WP_Error
     */
    public function updateVideo($libraryId, $libraryApiKey, $videoId, $data)
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/videos/{$videoId}";

        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];

        $args = [
            'method' => 'POST',
            'headers' => $headers,
            'body' => json_encode($data),
            'timeout' => 30
        ];

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);

        if ($statusCode !== 200 && $statusCode !== 201) {
            return new \WP_Error(
                $statusCode,
                Arr::get($responseData, 'message', 'Failed to update video'),
                $responseData
            );
        }

        return $responseData;
    }
    
    /**
     * Create a new video in a library
     * 
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param array $params Video parameters
     * @return array|\WP_Error
     */
    public function createVideo($libraryId, $libraryApiKey, $params)
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/videos";
        
        $body = [
            'title' => $params['title']
        ];
        
        if (!empty($params['collection_id'])) {
            $body['collectionId'] = $params['collection_id'];
        }
        
        // Use library-specific API key for this request
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];
        
        $args = [
            'method' => 'POST',
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 30
        ];
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);
        
        if ($statusCode !== 200 && $statusCode !== 201) {
            return new \WP_Error(
                $statusCode, 
                Arr::get($responseData, 'message', 'Failed to create video'),
                $responseData
            );
        }
        
        return $responseData;
    }
    
    /**
     * Upload a video file to BunnyCDN
     * 
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param string $videoId Video ID
     * @param string $filePath Path to the video file
     * @return array|\WP_Error
     */
    public function uploadVideo($libraryId, $libraryApiKey, $videoId, $filePath)
    {
        if (!file_exists($filePath)) {
            return new \WP_Error('file_not_found', 'Video file not found');
        }

        $fileSize = filesize($filePath);
        if ($fileSize === false || $fileSize === 0) {
            return new \WP_Error('empty_file', 'File is empty or cannot be read');
        }

        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/videos/{$videoId}";

        // Stream upload using curl to avoid loading entire file into memory
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        $fileHandle = fopen($filePath, 'r');
        if (!$fileHandle) {
            return new \WP_Error('file_read_error', 'Could not open file for reading');
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_init
        $ch = curl_init();
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_URL, $url);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_PUT, true);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_INFILE, $fileHandle);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_INFILESIZE, $fileSize);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'AccessKey: ' . $libraryApiKey
        ]);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_TIMEOUT, 600);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_exec
        $body = curl_exec($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_getinfo
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_error
        $curlError = curl_error($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_close
        curl_close($ch);
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        fclose($fileHandle);

        if (!empty($curlError)) {
            return new \WP_Error('upload_error', 'Upload failed: ' . $curlError);
        }

        // BunnyCDN may return empty response on success
        if (empty($body) && ($statusCode === 200 || $statusCode === 201)) {
            return [
                'success' => true,
                'videoId' => $videoId
            ];
        }

        $responseData = json_decode($body, true);

        if ($statusCode !== 200 && $statusCode !== 201) {
            return new \WP_Error(
                $statusCode,
                Arr::get($responseData, 'message', 'Failed to upload video'),
                $responseData
            );
        }

        return $responseData ?: [
            'success' => true,
            'videoId' => $videoId
        ];
    }
    
    /**
     * Delete a video from BunnyCDN
     * 
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param string $videoId Video ID
     * @return bool|\WP_Error
     */
    public function deleteVideo($libraryId, $libraryApiKey, $videoId)
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/videos/{$videoId}";
        
        // Use library-specific API key for this request
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];
        
        $args = [
            'method' => 'DELETE',
            'headers' => $headers,
            'timeout' => 30
        ];
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $statusCode = wp_remote_retrieve_response_code($response);
        
        if ($statusCode !== 200 && $statusCode !== 204) {
            $body = wp_remote_retrieve_body($response);
            $responseData = json_decode($body, true);
            
            return new \WP_Error(
                $statusCode, 
                Arr::get($responseData, 'message', 'Failed to delete video'),
                $responseData
            );
        }
        
        return true;
    }
    
    /**
     * Create or update a video library
     *
     * @param string $name Library name
     * @return array|\WP_Error
     */
    public function createOrUpdateLibrary($name)
    {
        $url = self::API_BASE_URL . '/videolibrary';
        
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $this->apiKey
        ];
        
        $data = [
            'Name' => $name,
            'ReplicationRegions' => []
        ];
        
        $args = [
            'method' => 'POST',
            'headers' => $headers,
            'body' => json_encode($data),
            'timeout' => 30
        ];
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);
        
        if ($statusCode !== 200 && $statusCode !== 201) {
            return new \WP_Error(
                $statusCode, 
                Arr::get($responseData, 'message', 'Failed to create library'),
                $responseData
            );
        }
        
        return $responseData;
    }
    
    /**
     * Fetch pullzone by ID
     *
     * @param int $pullZoneId
     * @return array|\WP_Error
     */
    public function fetchPullZone($pullZoneId)
    {
        $url = self::API_BASE_URL . "/pullzone/{$pullZoneId}";
        
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $this->apiKey
        ];
        
        $args = [
            'method' => 'GET',
            'headers' => $headers,
            'timeout' => 30
        ];
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);
        
        if ($statusCode !== 200) {
            return new \WP_Error(
                $statusCode, 
                Arr::get($responseData, 'message', 'Failed to fetch pull zone'),
                $responseData
            );
        }
        
        return $responseData;
    }
    
    /**
     * Get default hostname from pullzone
     *
     * @param array $pullzone
     * @return string|\WP_Error
     */
    public function getDefaultHostname($pullzone)
    {
        $hostnames = Arr::get($pullzone, 'Hostnames', []);
        
        if (empty($hostnames)) {
            return new \WP_Error('no_hostnames', 'No hostnames found in pull zone');
        }
        
        foreach ($hostnames as $hostname) {
            if (Arr::get($hostname, 'IsSystemHostname', false)) {
                return Arr::get($hostname, 'Value', '');
            }
        }
        
        return Arr::get($hostnames[0], 'Value', '');
    }

    /**
     * Make a request to the BunnyCDN API
     *
     * @param string $endpoint API endpoint
     * @param string $method HTTP method
     * @param array $data Request data
     * @return array|\WP_Error
     */
    private function makeRequest($endpoint, $method = 'GET', $data = [])
    {
        $url = self::API_BASE_URL . '/' . $endpoint;
        
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $this->apiKey
        ];
        
        $args = [
            'method' => $method,
            'headers' => $headers,
            'timeout' => 30
        ];
        
        if (!empty($data) && $method !== 'GET') {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        
        if ($statusCode !== 200 && $statusCode !== 201 && $statusCode !== 204) {
            $responseData = json_decode($body, true);
            return new \WP_Error(
                $statusCode, 
                Arr::get($responseData, 'message', 'API request failed'),
                $responseData
            );
        }
        
        if (empty($body)) {
            return [];
        }
        
        return json_decode($body, true);
    }

    /**
     * Purge pull zone cache
     *
     * @param integer $id Pull zone ID
     * @return true|\WP_Error
     */
    public function purgePullZoneCache($id)
    {
        if (empty($id)) {
            return new \WP_Error('missing_id', 'Missing pull zone ID');
        }

        $url = self::API_BASE_URL . "/pullzone/{$id}/purgeCache";
        
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $this->apiKey
        ];
        
        $args = [
            'method' => 'POST',
            'headers' => $headers,
            'timeout' => 30
        ];
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $statusCode = wp_remote_retrieve_response_code($response);
        
        if ($statusCode !== 200 && $statusCode !== 204) {
            $body = wp_remote_retrieve_body($response);
            $responseData = json_decode($body, true);
            
            return new \WP_Error(
                $statusCode, 
                Arr::get($responseData, 'message', 'Failed to purge cache'),
                $responseData
            );
        }
        
        return true;
    }

    /**
     * Get pull zone URL for a library
     *
     * @param string $libraryId
     * @return string
     */
    private function getPullZoneUrlForLibrary($libraryId)
    {
        // First check if we have it in memory
        static $pullZoneUrls = [];
        
        if (isset($pullZoneUrls[$libraryId])) {
            return $pullZoneUrls[$libraryId];
        }
        
        // Get library details
        $libraries = $this->getLibraries();
        
        if (is_wp_error($libraries)) {
            return '';
        }
        
        foreach ($libraries as $library) {
            if (Arr::get($library, 'Id') == $libraryId) {
                $pullZoneId = Arr::get($library, 'PullZoneId');
                
                if ($pullZoneId) {
                    $pullzone = $this->fetchPullZone($pullZoneId);
                    
                    if (!is_wp_error($pullzone)) {
                        $hostname = $this->getDefaultHostname($pullzone);
                        
                        if (!is_wp_error($hostname)) {
                            $pullZoneUrls[$libraryId] = $hostname;
                            return $hostname;
                        }
                    }
                }
                
                break;
            }
        }
        
        return '';
    }

    /**
     * Get a single video's details
     *
     * @param string $libraryId Library ID
     * @param string $libraryApiKey Library-specific API key
     * @param string $videoId Video ID
     * @return array|\WP_Error
     */
    public function getVideo($libraryId, $libraryApiKey, $videoId, $pullZoneUrl = '')
    {
        $url = self::STREAM_API_BASE_URL . "/library/{$libraryId}/videos/{$videoId}";

        // Use library-specific API key for this request
        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'AccessKey' => $libraryApiKey
        ];

        $args = [
            'method' => 'GET',
            'headers' => $headers,
            'timeout' => 30
        ];

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        $statusCode = wp_remote_retrieve_response_code($response);
        $responseData = json_decode($body, true);

        if ($statusCode !== 200) {
            return new \WP_Error(
                $statusCode,
                Arr::get($responseData, 'message', 'Failed to fetch video details'),
                $responseData
            );
        }

        // Use provided hostname or fall back to API lookup
        if (empty($pullZoneUrl)) {
            $pullZoneUrl = $this->getPullZoneUrlForLibrary($libraryId);
        }

        // Add URLs
        $responseData['playlistURL'] = "https://{$pullZoneUrl}/{$videoId}/playlist.m3u8";
        $responseData['webPURL'] = "https://{$pullZoneUrl}/{$videoId}/preview.webp";
        $responseData['thumbnailURL'] = "https://{$pullZoneUrl}/{$videoId}/".Arr::get($responseData, 'thumbnailFileName', 'thumbnail.jpg');
        $responseData['MP4URLs'] = "https://{$pullZoneUrl}/{$videoId}/play_720p.mp4";

        // Add caption CDN URLs
        if (is_array(Arr::get($responseData, 'captions'))) {
            foreach ($responseData['captions'] as &$caption) {
                $srclang = Arr::get($caption, 'srclang');
                if (isset($srclang) && $srclang !== '') {
                    $caption['url'] = "https://{$pullZoneUrl}/{$videoId}/captions/" . rawurlencode($srclang) . ".vtt";
                }
            }
            unset($caption);
        }

        // Add additional fields for compatibility
        $responseData['id'] = $videoId;
        $responseData['size'] = Arr::get($responseData, 'storageSize', 0);
        $responseData['thumbnail'] = Arr::get($responseData, 'thumbnailURL');
        $responseData['updated_at'] = Arr::get($responseData, 'dateUploaded', '');
        $responseData['created_at'] = Arr::get($responseData, 'dateUploaded', '');

        return $responseData;
    }
}
