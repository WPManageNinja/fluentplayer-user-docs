<?php
/**
 * @var array $playlist
 * @var array $medias
 * @var array $defaultSettings
 * @var int $playlist_id
 * @var string $playlist_var_name
 */

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Template variables passed from controller, not global variables

use FluentPlayerPro\App\Layouts\PlaylistLayoutFactory;

if (!defined('ABSPATH')) {
    exit;
}

// Get the first media for initial player setup
$firstMedia = !empty($medias) ? $medias[0] : null;
if (!$firstMedia) {
    return '<div class="fluent-playlist-empty">' .
        esc_html__('This playlist is empty. Please add media items.', 'fluent-player-pro') .
        '</div>';
}

// Create layout instance using factory
try {
    $layout = PlaylistLayoutFactory::create($playlist, $medias, $defaultSettings, $playlist_id, $playlist_var_name);
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- layout HTML escaped by view partials; not using wp_kses to preserve script tags from shortcode layers
    echo $layout->render();
} catch (Exception $e) {
    // Fallback to basic error message
    echo '<div class="fluent-playlist-error">Error loading playlist: ' . esc_html($e->getMessage()) . '</div>';
}
