<?php
/**
 * Grid layout: single grid item card.
 *
 * Variables from content.php scope:
 * @var array  $item  Pre-built item data from GridPlaylistLayout.
 * @var bool   $showThumbnailInfo
 * @var string $titlePosition
 * @var string $displayMode
 * @var string $modalLayout
 */

if (!defined('ABSPATH')) {
    exit;
}

$media           = $item['media'];
$index           = $item['index'];
$duration        = $item['duration'];
$durationFmt     = $item['durationFormatted'];
$deepLinkRef     = $item['deepLinkRef'] ?? '';
$isWatched       = $item['isWatched'];
$loadingStrategy = $item['loadingStrategy'];
$activeClass     = $item['isActive'] ? ' fp-grid-item--active active' : '';
$progress        = $item['progress'];
?>
<div class="grid-item fp-grid-item fp-grid-item-<?php echo esc_attr($titlePosition); ?> <?php echo esc_attr($isWatched ? 'watched' : ''); ?><?php echo esc_attr($activeClass); ?>"
      data-media-id="<?php echo esc_attr($media->ID); ?>"
      data-flp-ref="<?php echo esc_attr($deepLinkRef); ?>"
      data-media-index="<?php echo esc_attr($index); ?>"
      data-duration="<?php echo esc_attr($duration); ?>"
      data-title="<?php echo esc_attr(strtolower($media->post_title)); ?>"
      data-description="<?php echo esc_attr(strtolower($media->settings['description'] ?? '')); ?>"
      data-category="<?php echo esc_attr($media->settings['category'] ?? ''); ?>"
      data-tags="<?php echo esc_attr(implode(',', $media->settings['tags'] ?? [])); ?>"
      data-play-mode="<?php echo esc_attr($displayMode); ?>"
      data-modal-layout="<?php echo esc_attr($modalLayout); ?>">

    <div class="grid-item-thumbnail fp-grid-item-thumb">
        <?php if (!empty($media->settings['posterSrc'])): ?>
            <img src="<?php echo esc_url($media->settings['posterSrc']); ?>"
                 alt="<?php echo esc_attr($media->post_title); ?>"
                 loading="<?php echo esc_attr($loadingStrategy); ?>">
        <?php else: ?>
            <div class="no-thumbnail fp-grid-item-no-thumb">
                <media-icon type="video-play" aria-hidden="true"></media-icon>
            </div>
        <?php endif; ?>

        <?php if ($isWatched): ?>
            <div class="watched-badge">
                <media-icon type="check-circle" aria-hidden="true"></media-icon>
            </div>
        <?php endif; ?>

        <?php if ($progress > 0 && !$isWatched): ?>
            <div class="progress-bar"
                 role="progressbar"
                 aria-valuemin="0"
                 aria-valuemax="100"
                 aria-valuenow="<?php echo esc_attr($progress); ?>"
                 aria-label="<?php echo esc_attr(sprintf(__('%s%% watched', 'fluent-player-pro'), $progress)); ?>">
                <div class="progress-fill" style="width: <?php echo esc_attr($progress); ?>%"></div>
            </div>
        <?php endif; ?>

        <div class="grid-item-overlay">
            <div class="play-button">
                <media-icon type="play" aria-hidden="true"></media-icon>
            </div>
            <div class="duration-badge fp-duration-display" data-duration="<?php echo esc_attr($duration !== '' && $duration !== null ? (string) (float) $duration : ''); ?>"><?php echo esc_html($durationFmt); ?></div>
        </div>

        <?php if ($showThumbnailInfo && $titlePosition === 'overlay'): ?>
            <div class="fp-grid-item-title-overlay"><?php echo esc_html($media->post_title); ?></div>
        <?php endif; ?>

        <div class="grid-item-info" <?php echo (!$showThumbnailInfo || $titlePosition !== 'below') ? 'style="display:none;"' : ''; ?>>
            <h5 class="grid-item-title fp-grid-item-title"><?php echo esc_html($media->post_title); ?></h5>
            <?php if (!empty($media->settings['description'])): ?>
                <p class="grid-item-description"><?php echo esc_html(wp_trim_words($media->settings['description'], 15)); ?></p>
            <?php endif; ?>

            <div class="grid-item-meta">
                <?php if (!empty($media->settings['category'])): ?>
                    <span class="category-badge"><?php echo esc_html($media->settings['category']); ?></span>
                <?php endif; ?>

                <?php
                $tags = $media->settings['tags'] ?? [];
                if (!empty($tags)):
                    $displayTags = array_slice($tags, 0, 2);
                    foreach ($displayTags as $tag):
                ?>
                    <span class="tag-badge">#<?php echo esc_html($tag); ?></span>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if ($showThumbnailInfo && $titlePosition === 'below'): ?>
        <div class="fp-grid-item-title"><?php echo esc_html($media->post_title); ?></div>
    <?php endif; ?>
</div>
