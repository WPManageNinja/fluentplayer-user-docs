<?php
/**
 * Grid layout: modal player overlay.
 *
 * @var string $modalOverlayClass
 * @var string $modalPlayerClass
 * @var string $modalPlayerStyle
 * @var bool   $isAudio
 * @var array  $medias
 * @var object $presetSourceMedia  Media resolved from playlist's preset_source_media_id.
 *                                 Provides the rendered skin, controls, and behaviors.
 *                                 Falls back to medias[0] when no source is configured.
 * @var bool   $showNavButtons
 * @var object $layout  The layout instance (for renderPerVideoFeatures).
 * @var array  $defaultSettings
 */

if (!defined('ABSPATH')) {
    exit;
}

use FluentPlayer\Framework\Support\Arr;
?>
<div class="<?php echo esc_attr($modalOverlayClass); ?>" id="grid-modal-overlay" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr__('Video player', 'fluent-player-pro'); ?>">
    <div class="grid-modal-content">
        <div class="<?php echo esc_attr($modalPlayerClass); ?>"<?php echo $modalPlayerStyle ? ' style="' . esc_attr($modalPlayerStyle) . '"' : ''; ?>>
            <button type="button" class="grid-modal-close" aria-label="<?php echo esc_attr__('Close', 'fluent-player-pro'); ?>">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                    <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </button>

            <?php if ($showNavButtons): ?>
            <button type="button" class="grid-modal-nav prev" aria-label="<?php echo esc_attr__('Previous video', 'fluent-player-pro'); ?>">
                <media-icon type="previous" aria-hidden="true"></media-icon>
            </button>
            <button type="button" class="grid-modal-nav next" aria-label="<?php echo esc_attr__('Next video', 'fluent-player-pro'); ?>">
                <media-icon type="next" aria-hidden="true"></media-icon>
            </button>
            <?php endif; ?>

            <media-player id="grid-modal-player"<?php if ($isAudio): ?> view-type="audio" media-type="audio"<?php endif; ?>>
                <media-provider>
                    <?php if (!$isAudio): ?>
                    <media-poster id="grid-modal-poster"></media-poster>
                    <?php endif; ?>
                    <?php
                    $settings = $medias[0]->settings ?? [];
                    $default_settings = $defaultSettings ?? [];
                    $media_id = $medias[0]->ID ?? 0;

                    if (Arr::get($settings, 'chapters')):
                        include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/chapters-track.php';
                    endif;

                    $subtitleTracksPath = FLUENT_PLAYER_DIR_PATH . 'app/Views/player/subtitle-tracks.php';
                    if (file_exists($subtitleTracksPath)) {
                        include $subtitleTracksPath;
                    }
                    ?>
                </media-provider>

                <?php
                $layout->renderPerVideoFeatures($medias[0]);

                $presetSourceSettings = ($presetSourceMedia ?? $medias[0])->settings ?? [];
                $settings = $medias[0]->settings ?? [];
                $skin = Arr::get($presetSourceSettings, 'skin', 'modern');
                $controls = Arr::get($presetSourceSettings, 'controls', []);
                $behaviors = Arr::get($presetSourceSettings, 'behaviors', []);

                // A mixed playlist renders BOTH skins; the runtime shows the right
                // one per item (GridPlaylistManager toggles .fp-audio on the modal
                // player). Pure playlists render only their own skin.
                $isMixedModal = !empty($isMixed);
                $renderAudioSkin = $isMixedModal || $isAudio;
                $renderVideoSkin = $isMixedModal || !$isAudio;

                if ($renderAudioSkin):
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/captions.php';
                    if (!Arr::isTrue($behaviors, 'hide_bottom_controls')):
                        include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/bottom-controls-audio.php';
                    endif;
                endif;

                if ($renderVideoSkin):
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/email-capture.php';
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/cta-overlay.php';
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/action-bar-overlay.php';
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/overlays.php';
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/gestures.php';
                    if (!$renderAudioSkin):
                        include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/captions.php';
                    endif;
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/logo.php';
                    include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/youtube-subscribe.php';

                    if ($skin !== 'minimal' && !Arr::isTrue($behaviors, 'hide_top_controls')):
                        include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/top-controls.php';
                    endif;

                    if ($skin === 'minimal' || !Arr::isTrue($behaviors, 'hide_center_controls')):
                        include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/center-controls.php';
                    endif;

                    if ($skin !== 'minimal' && !Arr::isTrue($behaviors, 'hide_bottom_controls')):
                        include FLUENT_PLAYER_DIR_PATH . 'app/Views/player/bottom-controls.php';
                    endif;
                endif;
                ?>
            </media-player>
        </div>
    </div>
</div>
