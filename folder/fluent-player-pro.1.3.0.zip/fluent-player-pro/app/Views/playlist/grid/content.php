<?php
/**
 * Grid layout: main content area with grid items, pagination, and modal.
 *
 * @var int    $columns
 * @var int    $itemsPerPage
 * @var bool   $lazyLoad
 * @var string $playlistTitle
 * @var int    $totalVideos
 * @var string $videoText
 * @var bool   $showThumbnailInfo
 * @var string $titlePosition
 * @var string $displayMode
 * @var string $modalLayout
 * @var array  $items       Pre-built per-item data arrays.
 * @var bool   $showPagination
 * @var int    $totalPages
 * @var bool   $showModal
 * @var string $modalHtml
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="fp-grid-container grid-container" data-columns="<?php echo esc_attr($columns); ?>">
    <div class="fp-grid-header">
        <h4 class="fp-grid-header-title"><?php echo esc_html($playlistTitle); ?></h4>
        <div class="fp-grid-header-right">
            <span class="fp-grid-header-count"><?php echo esc_html($totalVideos); ?> <?php echo esc_html($videoText); ?></span>
        </div>
    </div>
    <div class="fp-grid-content grid-items" data-items-per-page="<?php echo esc_attr($itemsPerPage); ?>" data-lazy-load="<?php echo esc_attr($lazyLoad ? 'true' : 'false'); ?>">
        <?php foreach ($items as $item):
            include __DIR__ . '/grid-item.php';
        endforeach; ?>
    </div>

    <?php if ($showPagination): ?>
        <div class="fp-grid-footer">
            <div class="fp-grid-pagination grid-pagination">
                <button type="button" class="fp-grid-pagination-btn pagination-btn prev-btn" disabled>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                        <path d="M15 18l-6-6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <?php echo esc_html__('Previous', 'fluent-player-pro'); ?>
                </button>
                <span class="fp-grid-pagination-info pagination-info">
                    <span class="current-page">1</span>
                    <span class="separator"><?php echo esc_html__('of', 'fluent-player-pro'); ?></span>
                    <span class="total-pages"><?php echo esc_html($totalPages); ?></span>
                </span>
                <button type="button" class="fp-grid-pagination-btn pagination-btn next-btn">
                    <?php echo esc_html__('Next', 'fluent-player-pro'); ?>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
                        <path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <!-- No results message -->
    <div class="fplayer-no-results" style="display: none;">
        <div class="fplayer-no-results-content">
            <media-icon type="search" aria-hidden="true"></media-icon>
            <h5><?php echo esc_html__('No videos found', 'fluent-player-pro'); ?></h5>
            <p><?php echo esc_html__('Try adjusting your search or filter criteria', 'fluent-player-pro'); ?></p>
        </div>
    </div>
</div>

<?php if ($showModal):
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- modal HTML escaped by view partials; not using wp_kses to preserve script tags from shortcode layers
    echo $modalHtml;
endif; ?>
