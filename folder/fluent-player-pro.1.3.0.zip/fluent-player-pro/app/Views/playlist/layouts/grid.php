<?php
/**
 * Grid playlist layout wrapper.
 *
 * @var string $layoutClasses
 * @var string $playlistId
 * @var string $playlistVarName
 * @var string $playlistDeepLinkRef
 * @var string $styleAttributes
 * @var string $playerHtml
 * @var string $contentHtml
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="<?php echo esc_attr($layoutClasses); ?>" id="fluent_playlist_<?php echo esc_attr($playlistId); ?>" data-var_name="<?php echo esc_attr($playlistVarName); ?>" data-flp-ref="<?php echo esc_attr($playlistDeepLinkRef); ?>" role="region" aria-label="<?php echo esc_attr__('Playlist', 'fluent-player-pro'); ?>"<?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr in buildCssStyleAttribute()
    echo $styleAttributes; ?>>
    <?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- player HTML escaped by view partials; not using wp_kses to preserve script tags from shortcode layers
    echo $playerHtml; ?>
    <?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- content contains modal with player HTML; not using wp_kses to preserve script tags from shortcode layers
    echo $contentHtml; ?>
</div>
