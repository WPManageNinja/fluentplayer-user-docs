<?php
/**
 * Standard playlist layout wrapper.
 *
 * @var string $layoutClasses
 * @var string $playlistId
 * @var string $playlistVarName
 * @var string $playlistDeepLinkRef
 * @var string $styleAttributes
 * @var string $positionClass
 * @var string $separatorClass
 * @var string $position
 * @var string $playerHtml
 * @var string $contentHtml
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="<?php echo esc_attr($layoutClasses); ?>" id="fluent_playlist_<?php echo esc_attr($playlistId); ?>" data-var_name="<?php echo esc_attr($playlistVarName); ?>" data-flp-ref="<?php echo esc_attr($playlistDeepLinkRef); ?>" role="region" aria-label="<?php echo esc_attr__('Playlist', 'fluent-player-pro'); ?>"<?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr in buildCssStyleAttribute()
    echo $styleAttributes; ?>>
    <div class="fluent-playlist-container <?php echo esc_attr($positionClass); ?> <?php echo esc_attr($separatorClass); ?>">
        <?php
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- player HTML escaped by view partials; not using wp_kses to preserve script tags from shortcode layers
        echo $playerHtml; ?>

        <?php if ($position === 'left' || $position === 'right'): ?>
        <button type="button" class="fp-playlist-open-btn" aria-label="<?php echo esc_attr__('Show playlist', 'fluent-player-pro'); ?>">
            <media-icon type="playlist" aria-hidden="true"></media-icon>
        </button>
        <?php endif; ?>

        <?php
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized by fluentplayer_sanitize_html()
        echo fluentplayer_sanitize_html($contentHtml); ?>
    </div>
</div>
