<?php
/**
 * Learning playlist layout wrapper.
 *
 * @var string $layoutClasses
 * @var string $playlistId
 * @var string $playlistVarName
 * @var string $playlistDeepLinkRef
 * @var string $playerHtml
 * @var string $headerHtml
 * @var string $contentHtml
 * @var string $footerHtml
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="<?php echo esc_attr($layoutClasses); ?>" id="fluent_playlist_<?php echo esc_attr($playlistId); ?>" data-var_name="<?php echo esc_attr($playlistVarName); ?>" data-flp-ref="<?php echo esc_attr($playlistDeepLinkRef); ?>">
    <div class="learning-player">
        <?php
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- player HTML escaped by view partials; not using wp_kses to preserve script tags from shortcode layers
        echo $playerHtml; ?>
    </div>

    <button type="button" class="sidebar-toggle-btn" aria-label="<?php echo esc_attr__('Toggle sidebar', 'fluent-player-pro'); ?>">
        <media-icon type="chevron-right" aria-hidden="true"></media-icon>
    </button>

    <div class="learning-sidebar">
        <?php
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized by fluentplayer_sanitize_html()
        echo fluentplayer_sanitize_html($headerHtml); ?>

        <div class="learning-navigation">
            <?php
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized by fluentplayer_sanitize_html()
            echo fluentplayer_sanitize_html($contentHtml); ?>
        </div>

        <?php
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized by fluentplayer_sanitize_html()
        echo fluentplayer_sanitize_html($footerHtml); ?>
    </div>
</div>
