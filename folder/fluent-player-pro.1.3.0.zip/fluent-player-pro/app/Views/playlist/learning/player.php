<?php
/**
 * Learning layout: player container with progress overlay.
 *
 * @var string $containerOpen    Opening <div> from openPlayerContainer().
 * @var string $mediaPlayerHtml  Rendered <media-player> HTML.
 * @var int    $lessonNumber
 * @var string $lessonTitle
 * @var int    $lessonProgress
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside openPlayerContainer()
echo $containerOpen;
// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- player HTML escaped by view partials; not using wp_kses to preserve script tags from shortcode layers
echo $mediaPlayerHtml;
?>
    <div class="learning-progress-overlay">
        <div class="current-lesson-info">
            <span class="lesson-number"><?php echo esc_html__('Lesson', 'fluent-player-pro'); ?> <?php echo esc_html($lessonNumber); ?></span>
            <span class="lesson-title"><?php echo esc_html($lessonTitle); ?></span>
        </div>
        <div class="lesson-progress">
            <div class="progress-bar"
                 role="progressbar"
                 aria-valuemin="0"
                 aria-valuemax="100"
                 aria-valuenow="<?php echo esc_attr($lessonProgress); ?>"
                 aria-label="<?php echo esc_attr__('Lesson progress', 'fluent-player-pro'); ?>">
                <div class="progress-fill" style="width: <?php echo esc_attr($lessonProgress); ?>%"></div>
            </div>
        </div>
    </div>
</div>
