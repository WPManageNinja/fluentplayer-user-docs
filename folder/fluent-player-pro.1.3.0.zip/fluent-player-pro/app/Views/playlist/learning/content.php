<?php
/**
 * Learning layout: lessons list with collapsible sections.
 *
 * @var bool   $hasChapters
 * @var string $chaptersNavHtml
 * @var array  $items  Pre-built lesson item data arrays.
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<?php if ($hasChapters): ?>
    <div class="fpl-collapsible-section open">
        <button type="button" class="fpl-section-header" aria-expanded="true">
            <span class="fpl-section-title"><?php echo esc_html__('Course Chapters', 'fluent-player-pro'); ?></span>
            <media-icon type="chevron-down" aria-hidden="true"></media-icon>
        </button>
        <div class="fpl-section-content">
            <div class="chapters-list" style="padding: 20px;">
                <?php
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized by fluentplayer_sanitize_html()
                echo fluentplayer_sanitize_html($chaptersNavHtml); ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="fpl-collapsible-section open">
    <button type="button" class="fpl-section-header" aria-expanded="true">
        <span class="fpl-section-title"><?php echo esc_html__('Lessons', 'fluent-player-pro'); ?></span>
        <media-icon type="chevron-down" aria-hidden="true"></media-icon>
    </button>
    <div class="fpl-section-content">
        <ul class="playlist-items learning-items" role="list">
            <?php foreach ($items as $item):
                include __DIR__ . '/lesson-item.php';
            endforeach; ?>
        </ul>
    </div>
</div>
