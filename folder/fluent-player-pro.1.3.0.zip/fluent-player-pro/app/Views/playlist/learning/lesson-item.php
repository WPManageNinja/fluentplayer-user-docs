<?php
/**
 * Learning layout: single lesson item.
 *
 * Variables from content.php scope:
 * @var array $item  Pre-built lesson data.
 */

if (!defined('ABSPATH')) {
    exit;
}

use FluentPlayer\App\Helpers\Helper;

$media       = $item['media'];
$index       = $item['index'];
$deepLinkRef = $item['deepLinkRef'] ?? '';
$isCompleted = $item['isCompleted'];
$isLocked    = $item['isLocked'];
$progress    = $item['progress'];
?>
<li class="playlist-item learning-item <?php echo esc_attr($index === 0 ? 'active' : ''); ?> <?php echo esc_attr($isCompleted ? 'completed' : ''); ?> <?php echo esc_attr($isLocked ? 'locked' : ''); ?>"
    data-media-id="<?php echo esc_attr($media->ID); ?>"
    data-flp-ref="<?php echo esc_attr($deepLinkRef); ?>"
    data-media-index="<?php echo esc_attr($index); ?>">

    <div class="lesson-status">
        <?php if ($isLocked): ?>
            <media-icon type="lock" class="lock-icon" aria-hidden="true"></media-icon>
        <?php elseif ($isCompleted): ?>
            <media-icon type="check" class="completed-icon" aria-hidden="true"></media-icon>
        <?php else: ?>
            <media-icon type="circle" class="incomplete-icon" aria-hidden="true"></media-icon>
        <?php endif; ?>
    </div>

    <div class="item-thumbnail">
        <?php if (!empty($media->settings['posterSrc'])): ?>
            <img src="<?php echo esc_url($media->settings['posterSrc']); ?>"
                 alt="<?php echo esc_attr($media->post_title); ?>"
                 loading="lazy">
        <?php endif; ?>

        <?php if (!$isLocked && $progress > 0 && $progress < 100): ?>
            <div class="thumbnail-progress"
                 role="progressbar"
                 aria-valuemin="0"
                 aria-valuemax="100"
                 aria-valuenow="<?php echo esc_attr($progress); ?>"
                 aria-label="<?php echo esc_attr(sprintf(__('%s%% watched', 'fluent-player-pro'), $progress)); ?>">
                <div class="progress-fill" style="width: <?php echo esc_attr($progress); ?>%"></div>
            </div>
        <?php endif; ?>

        <div class="thumbnail-overlay">
            <media-icon class="play-icon" type="play" aria-hidden="true"></media-icon>
            <media-icon class="pause-icon" type="pause" aria-hidden="true" style="display: none;"></media-icon>
        </div>
    </div>

    <div class="playlist-item-content">
        <div class="item-title"><?php echo esc_html($media->post_title); ?></div>
        <div class="item-meta">
            <?php if (!empty($media->settings['duration'])): ?>
                <span class="item-duration"><?php echo esc_html(Helper::formatDuration($media->settings['duration'])); ?></span>
            <?php endif; ?>
        </div>
    </div>
</li>
