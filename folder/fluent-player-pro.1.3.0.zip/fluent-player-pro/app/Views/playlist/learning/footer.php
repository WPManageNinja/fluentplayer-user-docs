<?php
/**
 * Learning layout: navigation footer.
 *
 * @var bool   $hasPrevious
 * @var bool   $hasNext
 * @var string $currentMediaId
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="playlist-footer learning-footer">
    <div class="navigation-controls">
        <button type="button" class="nav-btn prev-btn fp-prev-btn primary" <?php echo $hasPrevious ? '' : 'disabled'; ?>>
            <?php echo esc_html__('Previous', 'fluent-player-pro'); ?>
        </button>

        <button type="button" class="nav-btn mark-complete-btn fp-mark-complete-btn" data-media-id="<?php echo esc_attr($currentMediaId); ?>">
            <?php echo esc_html__('Mark as Complete', 'fluent-player-pro'); ?>
        </button>

        <button type="button" class="nav-btn next-btn fp-next-btn primary" <?php echo $hasNext ? '' : 'disabled'; ?>>
            <?php echo esc_html__('Next', 'fluent-player-pro'); ?>
        </button>
    </div>
</div>
