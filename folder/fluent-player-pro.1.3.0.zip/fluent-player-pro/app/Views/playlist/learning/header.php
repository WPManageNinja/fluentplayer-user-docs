<?php
/**
 * Learning layout: progress header.
 *
 * @var string $playlistTitle
 * @var int    $totalVideos
 * @var int    $completedVideos
 * @var int    $progressPercentage
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="playlist-header learning-header">
    <div class="header-content">
        <h4><?php echo esc_html($playlistTitle); ?></h4>
        <div class="playlist-meta">
            <span class="progress-text"><?php echo esc_html($completedVideos); ?>/<?php echo esc_html($totalVideos); ?> <?php echo esc_html__('completed', 'fluent-player-pro'); ?></span>
            <span class="playlist-count"><?php echo esc_html($totalVideos); ?> <?php echo esc_html__('lessons', 'fluent-player-pro'); ?></span>
        </div>
    </div>
    <div class="progress-container">
        <div class="progress-bar"
             role="progressbar"
             aria-valuemin="0"
             aria-valuemax="100"
             aria-valuenow="<?php echo esc_attr($progressPercentage); ?>"
             aria-label="<?php echo esc_attr__('Course progress', 'fluent-player-pro'); ?>">
            <div class="progress-fill" style="width: <?php echo esc_attr($progressPercentage); ?>%"></div>
        </div>
        <span class="progress-percentage"><?php echo esc_html($progressPercentage); ?>%</span>
    </div>
</div>
