<?php
/**
 * Shared player container partial.
 * Used by Standard and Grid layouts (not Learning — it adds extra overlay content).
 *
 * @var string $containerOpen  Opening <div> tag from openPlayerContainer().
 * @var string $mediaPlayerHtml  Rendered <media-player> HTML.
 */

if (!defined('ABSPATH')) {
    exit;
}

// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside openPlayerContainer()
echo $containerOpen;
// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- player HTML escaped by view partials; not using wp_kses to preserve script tags from shortcode layers
echo $mediaPlayerHtml;
?>
</div>
