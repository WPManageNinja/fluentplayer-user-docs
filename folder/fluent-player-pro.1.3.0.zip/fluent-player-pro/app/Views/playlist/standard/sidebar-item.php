<?php
/**
 * Standard layout: single playlist item.
 *
 * Variables inherited from sidebar.php scope:
 * @var object $media
 * @var int    $index
 * @var string $durationRaw
 * @var string $durationFormatted
 * @var bool   $showThumbnails
 * @var bool   $thumbnailGridLayout
 * @var bool   $showThumbnailInfo
 * @var string $titlePosition
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<li role="listitem" class="playlist-item fp-playlist-item-<?php echo esc_attr($titlePosition); ?> <?php echo esc_attr($thumbnailGridLayout ? 'fp-playlist-media-item-grid' : ''); ?> <?php echo esc_attr($showThumbnails ? 'fp-playlist-media-item' : ''); ?> <?php echo esc_attr($index === 0 ? 'active' : ''); ?>" <?php echo $index === 0 ? 'aria-current="true"' : ''; ?>
    data-media-id="<?php echo esc_attr($media->ID); ?>"
    data-flp-ref="<?php echo esc_attr($deepLinkRef); ?>"
    data-media-index="<?php echo esc_attr($index); ?>">

    <?php if ($showThumbnails): ?>
        <div class="item-thumbnail fp-playlist-item-thumb <?php echo $thumbnailGridLayout ? 'thumbnail-grid-mode' : ''; ?>">
            <?php if (!empty($media->settings['posterSrc'])): ?>
                <img src="<?php echo esc_url($media->settings['posterSrc']); ?>"
                     alt="<?php echo esc_attr($media->post_title); ?>"
                     loading="lazy">
            <?php endif; ?>
            <div class="thumbnail-overlay">
                <media-icon class="play-icon" type="play" aria-hidden="true"></media-icon>
                <media-icon class="pause-icon" type="pause" aria-hidden="true" style="display: none;"></media-icon>
            </div>
            <?php if ($showThumbnailInfo && $thumbnailGridLayout && $titlePosition === 'overlay'): ?>
                <div class="thumbnail-info">
                    <div class="thumbnail-title fp-playlist-item-title"><?php echo esc_html($media->post_title); ?></div>
                    <div class="thumbnail-duration fp-duration-display" data-duration="<?php echo esc_attr($durationRaw); ?>"><?php echo esc_html($durationFormatted); ?></div>
                </div>
            <?php endif; ?>
        </div>
        <?php if ($showThumbnailInfo && $thumbnailGridLayout && $titlePosition === 'below'): ?>
            <div class="fp-playlist-thumb-title-below"><?php echo esc_html($media->post_title); ?></div>
        <?php endif; ?>
    <?php else: ?>
        <div class="item-play-icon">
            <media-icon class="play-icon" type="play" aria-hidden="true"></media-icon>
            <media-icon class="pause-icon" type="pause" aria-hidden="true" style="display: none;"></media-icon>
        </div>
    <?php endif; ?>

    <?php if (!$thumbnailGridLayout || !$showThumbnails): ?>
        <div class="playlist-item-content fp-playlist-item-content">
            <div class="item-title fp-playlist-item-title"><?php echo esc_html($media->post_title); ?></div>
            <div class="item-duration fp-duration-display" data-duration="<?php echo esc_attr($durationRaw); ?>"><?php echo esc_html($durationFormatted); ?></div>
        </div>
    <?php endif; ?>
</li>
