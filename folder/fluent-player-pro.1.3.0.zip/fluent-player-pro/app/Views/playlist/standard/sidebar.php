<?php
/**
 * Standard layout: playlist sidebar with item list.
 *
 * @var string $position
 * @var string $headerPosition
 * @var bool   $showHeader
 * @var bool   $showThumbnails
 * @var bool   $thumbnailGridLayout
 * @var bool   $showThumbnailInfo
 * @var string $titlePosition
 * @var string $sidebarHeaderHtml
 * @var array  $items  Pre-built per-item data arrays.
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="playlist-sidebar">
    <?php if ($position === 'left' || $position === 'right'): ?>
    <button type="button" class="fp-playlist-sidebar-close" aria-label="<?php echo esc_attr__('Close playlist', 'fluent-player-pro'); ?>">
        <media-icon type="x-mark" aria-hidden="true"></media-icon>
    </button>
    <?php endif; ?>

    <?php if ($headerPosition === 'top'):
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized by fluentplayer_sanitize_html()
        echo fluentplayer_sanitize_html($sidebarHeaderHtml);
    endif; ?>

    <ul class="playlist-items <?php echo ($thumbnailGridLayout && $showThumbnails) ? 'playlist-thumbnail-grid' : ''; ?>" role="list">
        <?php foreach ($items as $item):
            // Make item data available to the partial
            $media              = $item['media'];
            $index              = $item['index'];
            $deepLinkRef        = $item['deepLinkRef'] ?? '';
            $durationRaw        = $item['durationRaw'];
            $durationFormatted  = $item['durationFormatted'];
            include __DIR__ . '/sidebar-item.php';
        endforeach; ?>
    </ul>

    <?php if ($headerPosition === 'bottom'):
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized by fluentplayer_sanitize_html()
        echo fluentplayer_sanitize_html($sidebarHeaderHtml);
    endif; ?>
</div>
