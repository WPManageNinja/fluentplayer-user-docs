<?php
/**
 * Standard layout: sidebar header with title and count.
 *
 * @var string $playlistTitle
 * @var int    $totalVideos
 * @var string $videoText
 * @var string $headerPosition
 * @var string $positionClass
 * @var string $hiddenClass
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="playlist-header fp-playlist-header fp-playlist-header-<?php echo esc_attr($headerPosition); ?> <?php echo esc_attr($positionClass); ?><?php echo esc_attr($hiddenClass); ?>">
    <h4 class="fp-playlist-header-title"><?php echo esc_html($playlistTitle); ?></h4>
    <span class="playlist-count fp-playlist-header-count" aria-live="polite" aria-atomic="true">
        <span class="current-video-index">1</span> / <?php echo esc_html($totalVideos); ?> <?php echo esc_html($videoText); ?>
    </span>
</div>
