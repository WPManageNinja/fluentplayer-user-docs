<?php

namespace FluentPlayerPro\App\Models;

use FluentPlayer\Framework\Database\Orm\Model;

class Visit extends Model
{
    protected $table = 'flp_visits';

    protected $fillable = [
        'media_id',
        'user_id',
        'ip_address',
        'browser',
        'device',
        'duration',
        'percentage',
        'country',
        'created_at',
        'updated_at'
    ];
}
