<?php

namespace FluentPlayerPro\App\Models;

use FluentPlayer\App\Models\Post;
use FluentPlayer\Framework\Database\Orm\Model;
use FluentPlayer\Framework\Http\Request\Request;
use FluentPlayer\Framework\Support\Arr;

class Playlist extends Model
{
    protected static $postType = 'fluent_playlist';

    public static function boot()
    {
        parent::boot();
    }

    /**
     * @return string
     */
    public static function getPostType()
    {
        return self::$postType;
    }


    public function save($options = [])
    {

        if ($this->id) {
            wp_update_post([
                'ID'         => $this->id,
                'post_title' => $this->title,
            ]);
        } else {
            $playListId = wp_insert_post([
                'post_title'  => $this->title,
                'post_type'   => self::$postType,
                'post_status' => 'publish',
            ]);

            if (is_wp_error($playListId)) {
                throw new \Exception(esc_html($playListId->get_error_message()));
            }

            $this->id = $playListId;
        }

        $this->savePlaylistSettings();

        return self::find($this->id);
    }

    public function delete()
    {
        return wp_trash_post($this->id);
    }

    public static function deleteById($id)
    {
        $playlist = self::find($id);
        if ($playlist) {
            // Use the explicit id — the model's $this->id is unreliable here.
            return wp_trash_post(absint($id));
        }
        return false;
    }

    public static function restoreById($id)
    {
        $id = absint($id);
        if (!$id || get_post_type($id) !== self::$postType) {
            return false;
        }
        return wp_untrash_post($id);
    }

    public static function forceDeleteById($id)
    {
        $id = absint($id);
        if (!$id || get_post_type($id) !== self::$postType) {
            return false;
        }
        return wp_delete_post($id, true);
    }

    /**
     * Set a playlist's status; ignores wrong-type or trashed posts.
     *
     * @return bool
     */
    public static function changeStatusById($id, $status)
    {
        $id = absint($id);
        if (!$id || get_post_type($id) !== self::$postType || get_post_status($id) === 'trash') {
            return false;
        }
        $result = wp_update_post(['ID' => $id, 'post_status' => $status], true);
        return !is_wp_error($result) && $result > 0;
    }

    /**
     * Generate the next default playlist title, e.g. "Playlist 3".
     *
     * @return string
     */
    public static function generateDefaultTitle()
    {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Count query for default title, no caching needed
        $count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status != %s",
                self::$postType,
                'auto-draft'
            )
        );

        /* translators: %d: playlist number */
        return sprintf(__('Playlist %d', 'fluent-player-pro'), $count + 1);
    }

    protected function savePlaylistSettings()
    {
        if ($settings = Arr::get($this, 'settings')) {
            update_post_meta($this->id, 'settings', $settings);
        }
    }

    protected static function getPlaylistSettings($id)
    {
        $settings = get_post_meta($id, 'settings', true);
        if (!$settings || !is_array($settings)) {
            return [];
        }

        return $settings;
    }

    public static function find($id)
    {
        if (!is_numeric($id)) {
            return null;
        }
        $playlist = Post::where('post_type', self::$postType)
            ->select(['post_title', 'ID', 'post_status', 'post_date'])
            ->find($id);
        if ($playlist) {
            $playlist->settings = self::getPlaylistSettings($playlist->ID);
        }
        return $playlist;
    }

    /**
     * Delete all auto-draft playlists — called via fluentplayer/daily_cleanup cron hook.
     */
    public static function cleanupAutoDrafts()
    {
        $autoDrafts = Post::where('post_type', static::$postType)
            ->where('post_status', 'auto-draft')
            ->limit(100)
            ->get();

        foreach ($autoDrafts as $post) {
            wp_delete_post($post->ID, true);
        }
    }

    public static function paginate(Request $request)
    {
        $status = sanitize_text_field($request->get('status', 'all'));
        $searchQuery = sanitize_text_field($request->get('query', ''));
        $perPage = (int)$request->get('per_page', 10);
        $orderBy = sanitize_text_field($request->get('orderby', 'ID'));
        $allowedOrderBy = ['ID', 'post_title', 'post_date', 'post_status', 'post_name'];
        if (!in_array($orderBy, $allowedOrderBy, true)) {
            $orderBy = 'ID';
        }
        $order = strtoupper(sanitize_text_field($request->get('order', 'desc')));
        if (!in_array($order, ['ASC', 'DESC'], true)) {
            $order = 'DESC';
        }
        $query = Post::select(['post_title', 'ID', 'post_status', 'post_date', 'post_name'])
            ->where('post_type', self::$postType)
            ->where('post_status', '!=', 'auto-draft')
            ->when($status === 'trash', function ($q) {
                return $q->where('post_status', 'trash');
            })
            ->when($status && $status !== 'all' && $status !== 'trash', function ($q) use ($status) {
                return $q->where('post_status', $status);
            })
            ->when(!$status || $status === 'all', function ($q) {
                return $q->where('post_status', '!=', 'trash');
            });
        if ($searchQuery) {
            global $wpdb;
            $likeQuery = '%' . $wpdb->esc_like($searchQuery) . '%';
            $query->where(function ($q) use ($likeQuery) {
                $q->where('post_title', 'LIKE', $likeQuery)
                    ->orWhere('ID', 'LIKE', $likeQuery)
                    ->orWhere('post_status', 'LIKE', $likeQuery)
                    ->orWhere('post_name', 'LIKE', $likeQuery);
            });
        }
        if ($orderBy && $order) {
            $query->orderBy($orderBy, $order);
        } else {
            $query->latest('ID');
        }
        $paginator = $query->paginate($perPage);

        $collection = $paginator->getCollection();
        $playlistsArray = [];
        foreach ($collection as $item) {
            $itemId = isset($item->ID) ? $item->ID : (isset($item->id) ? $item->id : null);
            if ($itemId) {
                $item->settings = self::getPlaylistSettings($itemId);
            }

            $item->first_media_type = 'video';
            $mediaIds = Arr::get($item->settings, 'medias', []);
            if (!empty($mediaIds)) {
                $firstSettings = \FluentPlayer\App\Models\Media::getMediaSettings((int)$mediaIds[0]);
                $item->first_media_type = Arr::get($firstSettings, 'viewType') === 'audio' ? 'audio' : 'video';

                if (!Arr::get($item->settings, 'posterSrc')) {
                    $firstPoster = Arr::get($firstSettings, 'posterSrc')
                        ?: Arr::get($firstSettings, 'bunny.thumbnail')
                        ?: Arr::get($firstSettings, 'mux.thumbnail');
                    if ($firstPoster) {
                        $settings = $item->settings;
                        $settings['posterSrc'] = $firstPoster;
                        $item->settings = $settings;
                    }
                }
            }

            $playlistsArray[] = $item;
        }
        $paginator->setCollection(new \FluentPlayer\Framework\Support\Collection($playlistsArray));
        return $paginator;
    }

}
