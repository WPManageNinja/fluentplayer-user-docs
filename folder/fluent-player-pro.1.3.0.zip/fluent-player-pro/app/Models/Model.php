<?php

namespace FluentPlayerPro\App\Models;

use FluentPlayer\App\Models\Model as BaseModel;

class Model extends BaseModel
{
    // ...
}
