<?php
defined('ABSPATH') or exit;
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.InvalidPrefixPassed -- Hook names with slashes are valid strings

/**
 * Plugin Name: FluentPlayer Pro
 * Description: Pro extension for FluentPlayer - Adds advanced integrations and features
 * Version: 1.3.0
 * Author: WPManageNinja
 * Author URI: https://fluentplayer.com
 * Plugin URI: https://fluentplayer.com
 * License: GPLv2 or later
 * Text Domain: fluent-player-pro
 * Domain Path: /language
 **/

define('FLUENT_PLAYER_PRO_DIR_PATH', plugin_dir_path(__FILE__));
define('FLUENT_PLAYER_PRO_URL', plugin_dir_url(__FILE__));
define('FLUENT_PLAYER_PRO_DIR_FILE', __FILE__);
define('FLUENT_PLAYER_PRO_VERSION', '1.3.0');
define('FLUENT_PLAYER_PRO_DB_VERSION', '1.1.0');
define('FLUENT_PLAYER_PRO_MIN_CORE_VERSION', '1.0.9');

require __DIR__ . '/vendor/autoload.php';

call_user_func(function ($bootstrap) {
    $bootstrap(__FILE__);
}, require(__DIR__ . '/boot/app.php'));
